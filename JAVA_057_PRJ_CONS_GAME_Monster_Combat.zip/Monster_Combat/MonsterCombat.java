//MonsterCombat 1.0, Java Version - C. S. Germany, June 28, 2006

//Unlike C++, there is no "PAUSE", so we will make our own here.
//Unlike C++, there is no "cin", so we will make our own from LineNumberReader.
//Unlike C++. there is no "CLS" to clear screen, so we make our own.
//Unlike C++, there is no "sleep()", we will use Thread.Sleep().

import javax.swing.*;
import java.io.*;
import java.util.Random;


public class MonsterCombat
{
       //Global Initializaions and Instantiations - Stuff to Happen Outside in Main
       static LineNumberReader cin = new LineNumberReader(new InputStreamReader(System.in));
       static Random RAND = new Random();
              
//-----------------------------------------------------------------------------------------------
       
       public static void main(String[] args)
       {
              ClearScreen(10);
              System.out.println("\tMortal Combat 1.0, Java Version - 2006 C. Germany");
              System.out.println("\tOnly the strong will survive!\n\n");
              PAUSE();              
              
              Attack();
             
              System.exit(0);
       }//close main() function  
       
//-----------------------------------------------------------------------------------------------
       
             public static int GenerateRandomNumber(int x)   { return RAND.nextInt(x) + 1; }
             
//-----------------------------------------------------------------------------------------------
             
//-----------------------------------------------------------------------------------------------
       
             public static void ClearScreen(int x)   
             { 
                 for(int z = 0; z < x; z++)
                 {
                     System.out.println("\n");
                 }
             }
             
//-----------------------------------------------------------------------------------------------
             
            public static void PAUSE()
            {
                   //Since Java doesn't have a PAUSE command lie C++, make your own
                   String CONTINUE = "";
                   while(CONTINUE == "")
                   {    
                        System.out.print("\n\n\tPaused. Press ENTER to continue.   ");
                        ClearScreen(5);
                        try { CONTINUE = cin.readLine(); }
                        catch (IOException e) { System.err.println("Error."); }
                   }
            }
             
//-----------------------------------------------------------------------------------------------
             
       
             public static void Attack()
             {  
                    int damage = 0;
                    int hit = 0;
                    int MothraWins = 0;
                    int GodzillaWins = 0;
                    
                    int WhoStartsIt = 0;
                    
                    //Note: Java doesn't call these pointers, but essentially that's what
                    //they are. You can see the C++ behind the Java, here's a pointer 
                    //to an object created on the heap. As such, it can be reassigned and
                    //point to another LifeForm to randomize who gets the first attack.
                    //Unlike C++, Java doesn't separate the creation of the pointer from
                    //the creation of the object on the heap;
                    LifeForm AttackFirst = new LifeForm();
                    LifeForm AttackSecond = new LifeForm(); 
   
                    //Create 2 LifeForms
                    hit = GenerateRandomNumber(100);
                    LifeForm Godzilla = new LifeForm();
                    Godzilla.setHit(hit);
                    Godzilla.setName("Godzilla");
                    
                    hit = GenerateRandomNumber(100);   
                    LifeForm Mothra = new LifeForm();
                    Mothra.setHit(hit);
                    Mothra.setName("Mothra");
                    
                    System.out.print("\n--------------------------------------------------------------\n");                    
                    System.out.print("\tGodzilla and Mothra are locked in mortal combat!");
                    System.out.print("\n--------------------------------------------------------------\n\n");                     
                    PAUSE();
                    
                    //Have LifeForm objects loop into mortal combat, calculate the best of 3 matches
                    for(int x = 0; x<3; x++)
                    { 
                        System.out.print("\n---------------------------------------------------------\n"); 
         
                        System.out.print("\n\tCombat session " + (x+1) + ".\n\n");     
                        System.out.print("\tCurrent Wins:\n\n");
                        System.out.print("\tMothra: " + MothraWins + "  Godzilla: " + GodzillaWins + "\n\n");       

                       //Hitpoints begin with value initialized by the LifeForm constructor.                   
                       System.out.print("\tGodzilla begins this fight with " 
                                        + Godzilla.getHit() + " hitpoints.\n");
        
                       System.out.print("\tMothra begins this fight with " 
                                        + Mothra.getHit() + " hitpoints.\n"); 
   
                       System.out.print("\n---------------------------------------------------------\n");
                       PAUSE();

                       
                       //Decide who gets the first attack - by luck of the draw, 50% chance either way
                       WhoStartsIt = GenerateRandomNumber(2);
                       switch(WhoStartsIt)
                       {
                           case 1 : AttackFirst = Godzilla; AttackSecond = Mothra; break;
                           case 2 : AttackFirst = Mothra; AttackSecond = Godzilla; break;
                       }
                       
                       
                       //Each individual match of 3 between LifeForm objects plays out until one dies.
                       while(Godzilla.getHit() > 0 || Mothra.getHit() > 0)      
                       {      
                            //Generate random number for combat                            
                            damage = GenerateRandomNumber(30);                                               
                            System.out.print("\n\t" + AttackFirst.getName()  + " attacks first, doing "
                                              + damage + " points of damage.\n");
                            
                             //We need to make sure Godzilla's hitpoints are at least equal to
                             //or greater than damage, otherwise we'll end up with a negative
                             //value. If so, we just set it to 0 and break out of the while
                             //true loop - Godzilla dies. Without checking for this, Godzilla
                             //may still be able to attack even when he is dead.      
                            if(AttackSecond.getHit() <= damage)
                            {
                               AttackSecond.setHit(0);
                               break;
                            }
                            else
                            {   //Subtract the randomly calculated damage from opponent's hitpoints.
                                AttackSecond.setHit((AttackSecond.getHit() - damage));
                            }

                            System.out.print("\n\t" + AttackSecond.getName()  + " now has " + 
                                             AttackSecond.getHit() + " hitpoints.\n");
 
                            //Pauses program for 5 seconds. Uses the Thread.sleep() function.
                            try { Thread.sleep(5000); } 
                            catch (Exception e) {  }
      
                            damage = GenerateRandomNumber(30);                                               
                            System.out.print("\n\t" + AttackSecond.getName()  + " attacks second, doing "
                                             + damage + " points of damage.\n");
           
                            if(AttackFirst.getHit() <= damage)
                            { 
                                AttackFirst.setHit(0);
                                break;
                            }
                            else
                            {
                                AttackFirst.setHit((AttackFirst.getHit() - damage));
                            }
      
                            System.out.print("\n\t" + AttackFirst.getName() + " now has " 
                                             + Mothra.getHit() + " hitpoints.\n");     
               
                       } //closes while true loop

                       //Determine who wins each of the three battles and count wins.  
                       if(Godzilla.getHit() <= 0)
                       {
                          System.out.print("\n\n\tGodzilla loses.\n");
                          MothraWins = MothraWins + 1;
                       } 
                       if(Mothra.getHit() <= 0)
                       {
                          System.out.print("\n\n\tMothra loses.\n");
                          GodzillaWins = GodzillaWins + 1;                   
                       }
                       
                       System.out.print("\n---------------------------------------------------------\n"); 
   
                       try { Thread.sleep(5000); } 
                       catch (Exception e) {  }
   
                       hit = GenerateRandomNumber(100);
                       Godzilla.setHit(hit);
                       hit = GenerateRandomNumber(100);
                       Mothra.setHit(hit);

                    }//closes for loop

                    PAUSE();
                    ClearScreen(2);
                    System.out.print("\n---------------------------------------------------------\n"); 
                    System.out.print("\n\tFinal Results of All Three Battles:\n\n");
                    System.out.print("\tMothra: " + MothraWins + "  Godzilla: " + GodzillaWins + "\n\n\n");  

                    //Determine who won the war, best out of three battles.  
                    if(GodzillaWins > MothraWins)
                    {
                          System.out.print("\tGodzilla wins the war!\n");
                    }
                    else
                    {
                         System.out.print("\tMothra Wins the war!\n"); 
                    }
                    
                    System.out.print("\n---------------------------------------------------------\n");
                    ClearScreen(4);
                    
             }//close Attack() Function
             
 //-----------------------------------------------------------------------------------------------
      
}//close MonsterCombat class

