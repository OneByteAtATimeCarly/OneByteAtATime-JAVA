//LifeForm class for Monster Combat, Java version, C. S. Germany - June 27, 2006

public class LifeForm
{

   //Constructor
   public LifeForm()
   {
       System.out.print("\tA LifeForm has been created!\n");
       hitpoints = 20; LifeFormName = "";
             
   }     
  
   //Accesor methods
   public int getHit() { return hitpoints; }  
   public void setHit(int hp) { hitpoints = hp; }
   public String getName() { return LifeFormName; }
   public void setName(String nm) { LifeFormName = nm; }   
         
   //Private Data Members
   private int hitpoints;
   private String LifeFormName;                    
      
}//close LifeForm class



