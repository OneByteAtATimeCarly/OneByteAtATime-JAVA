//Project: Mortal Combat Game - 2008 Carly Salali Germany

//Derived/Sub Class

import javax.swing.*;
import java.io.*;

public class Human extends LifeForm
{
       public Human()
       {
              System.out.print("\nBuilding a Human.\n");
       }

       public Human(String x)
       {
              System.out.print("\nBuilding a Human.\n");
              SetName(x);
       }

}