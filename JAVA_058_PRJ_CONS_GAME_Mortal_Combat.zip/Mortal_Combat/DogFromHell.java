//Project: Mortal Combat Game - 2008 Carly Salali Germany

//Derived/Sub Class

import javax.swing.*;
import java.io.*;
import java.util.*;

public class DogFromHell extends MutantAnimal
{
       Random TALK = new Random();

       public DogFromHell()
       {
              System.out.print("\nBuilding a DogFromHell.\n");
       }

       //Overloading Constructor
       public DogFromHell(String x)
       {
              System.out.print("\nBuilding a DogFromHell.\n");
              SetName(x);
       }

       //Overriding Speak() from parent (base class LifeForm)
       public void Speak() 
       {
               int WhatToSay = TALK.nextInt(10) + 1;

               switch(WhatToSay)
               {
                    case 1 : System.out.print(" Hi, my name is Cerberos and I'm going to eat you."); break;
                    case 2 : System.out.print(" Sure is nice weather today..."); break;
                    case 3 : System.out.print(" Pick a card, any card will do..."); break;
                    case 4 : System.out.print(" It's not easy being the 3-headed hound of Hades..."); break;
                    case 5 : System.out.print(" I like you. A lot. So much, I could taste you..."); break;
                    case 6 : System.out.print(" Don't hurt me, please"); break;
                    case 7 : System.out.print(" Drop a clue # 1."); break;
                    case 8 : System.out.print(" Here kitty kitty..."); break;
                    case 9 : System.out.print(" Grrrrrrrrrrrrrrrrr!"); break;
                    case 10 : System.out.print(" Drop a clue # 2."); break;
               }
       }

}