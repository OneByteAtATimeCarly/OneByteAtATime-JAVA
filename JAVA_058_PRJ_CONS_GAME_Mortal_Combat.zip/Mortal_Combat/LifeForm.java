//Project: Mortal Combat Game - 2008 Carly Salali Germany

//ADT Base Class

import javax.swing.*;
import java.io.*;
import java.util.*;

public class LifeForm
{
       public LifeForm()
       {
              System.out.print("\nBuilding a LifeForm.\n");
       }

       //Overloaded Constructor Function (same name, different args)
       public LifeForm(String x)
       {
              System.out.print("\nBuilding a LifeForm named " + x + ".\n");
              Name = x;
       }

       String RESPONSE = " ";
       public LineNumberReader INPUT = new LineNumberReader(new InputStreamReader(System.in));

       public String IN()
       {
             String RESPONSE = "nothing";
             try { RESPONSE = INPUT.readLine(); }
             catch(IOException Z) {  }
             return RESPONSE;
       }

       //LifeForm Functions---------------------------------------
       public void Attack(LifeForm opponent)
       {
              Random DAMAGE = new Random();
              final int MAX_Damage = 50;
              int damage = 0;

              damage = DAMAGE.nextInt(MAX_Damage);

              //Account for LifeForm's ATK skill
              int MultiDamage = DAMAGE.nextInt(10);
              if(MultiDamage > 6)
              {
                 System.out.print("\n " + Name + "'s ATK ability multiplies the damage (" +
                                  damage + ") by (" + ATK + ") !\n");
                 damage = damage * ATK;
              }

              //Account for opponent's DEF capability
              if(damage - opponent.GetDEF() > 0)
              {
                  System.out.print("\n " + opponent.GetName() + "'s DEF reduces damage by " +
                                   opponent.GetDEF() + " point(s).\n");
                  damage = damage - opponent.GetDEF();
              }
              else
              { damage = 0; }

              //-------Weapon Selection------------------------------------------------
              if(SelectedWeapon.equals("Pipe"))
              { 
                  System.out.print("\n "+ Name + " pounds with the pipe!\n");
                  damage = damage + 5;
              }
              else if(SelectedWeapon.equals("Pistol"))
              { 
                   if(pistol_ammo > 0)
                   {
                      System.out.print("\n "+ Name + " fires the pistol!\n");
                      damage = damage + 8;
                      pistol_ammo = pistol_ammo - 1;
                   }
                   else
                   { System.out.print("\n Sorry, you have no remaining 9mm ammunition for the pistol."); }
              }
              else
              { System.out.print("\n"+ Name + " lets fly with the fists of fury!\n"); }
              //------------------------------------------------------------------------

              //Armor Selection---------------------------------------------------------
              if(SelectedArmor.equals("Kevlar Vest"))
              { 
                  System.out.print("\n Your body armor absorbs 4 points of damage!\n");
                  damage = damage - 4;
              }
              else
              { System.out.print("\n You have no damage-absorbing armor."); }
              //------------------------------------------------------------------------

              System.out.print("\n Before " + Name + "'s attack: "
                               + Name + " HP = " + HP +  "     "
                               + opponent.GetName() + " HP = " + opponent.GetHP() + "\n");

              System.out.print("\n " + Name + " attacks first, doing " +
                      damage + " points" + " of damage\n by landing a hard right!\n");

              if(opponent.GetHP() - damage > 0)
              { opponent.SetHP(opponent.GetHP() - damage); }
              else { opponent.SetHP(0); }

              System.out.print("\n " + opponent.GetName() + " now has only "
                               + opponent.GetHP() + " hitpoints left...\n\n\n");

              System.out.print("\n After " + Name + "'s attack: "
                               + Name + " HP = " + HP +  "     "
                               + opponent.GetName() + " HP = " + opponent.GetHP() + "\n");

              System.out.print("\n-------------------------------------------------------------\n");
       }


       public void Defend()   {    }
      
       public void Cheat()
       {
              System.out.print("\n  Cheater!  Cheat Activated. \n");
              pipe = true;
              pistol = true;
              kevlar_vest = true;
              pistol_ammo = 1000;
              MedKit = 100;
              FOOD = 100;
              DRINK = 100;
              HP = 10000;
       }

       public void Stats()
       {
              System.out.print("\n  ---------------------------------STATS---------------------------------\n");
              System.out.print("  |  Name:" + Name + "  Sex:" + Gender + "  HP:" + HP + "  ATK:" + ATK + "  DEF: "
                               + DEF + "  SPEED:" + SPD + "  DEX: " + DEX + "  |\n");
              System.out.print("  |  ENERGY:" + ENERGY + "  Weapon:" + SelectedWeapon + "  Armor:"
                               + SelectedArmor  + "        |\n");
              System.out.print("  -----------------------------------------------------------------------\n");
       }

       public void Inventory()
       {
              int count = 1;
              System.out.print("\n\n\n       ---------------------Inventory------------------------");
              if(pipe) { System.out.print("\n         " + count++ + ". Pipe"); }
              if(pistol) { System.out.print("\n         " + count++ + ". Pistol   Ammo = " + pistol_ammo); }
              if(kevlar_vest) { System.out.print("\n         " + count++ + ". Kevlar Vest"); }
              if(MedKit > 0) { System.out.print("\n         " + count++ + ". Medkits = " + MedKit); }
              if(FOOD > 0) { System.out.print("\n         " + count++ + ". Food = " + FOOD); }
              if(DRINK > 0) { System.out.print("\n         " + count++ + ". Drink = " + DRINK); }

              if(!pipe && !pistol && !kevlar_vest &&
                 pistol_ammo <= 0 && MedKit <= 0 && FOOD <= 0 && DRINK <= 0)
              { System.out.print("\n         Absolutely nothing!\n"); }

              System.out.print("\n       ------------------------------------------------------\n\n");
       }

       public void Use_Inventory()
       {
              String choice = " ";
              int count = 1;

              while(choice.charAt(0) != 'q')
              {
                  count = 1;
                  System.out.print("\n       --------------------Use Inventory Item--------------------\n");

                  if(pipe) { System.out.print("\n         " + count++ + ". (P)ipe"); }
                  if(pistol) { System.out.print("\n         " + count++ + ". (9)mm Pistol   Ammo = " + pistol_ammo); }
                  if(kevlar_vest) { System.out.print("\n         " + count++ + ". (K)evlar Vest"); }
                  if(MedKit > 0) { System.out.print("\n         " + count++ + ". (M)edkits = " + MedKit); }
                  if(FOOD > 0) { System.out.print("\n         " + count++ + ". (F)ood = " + FOOD); }
                  if(DRINK > 0) { System.out.print("\n         " + count++ + ". (D)rink = " + DRINK); }
                  System.out.print("\n         (Q)uit");
                  System.out.print("\n\n       ----------------------------------------------------\n\n ");

                  choice = IN();
                  choice = choice.toLowerCase();

                  switch(choice.charAt(0))
                  {

                     case 'p' : if(pipe)
                                {
                                   if(!SelectedWeapon.equals("Pipe"))
                                   {
                                      SelectedWeapon = "Pipe";
                                      System.out.print("\n  You pull out your long lead pipe. "
                                                       + "Time to crack some skulls!\n");
                                   }
                                   else { System.out.print("\n You are already holding the lead pipe! ");  }
                                }
                                else
                                {
                                    System.out.print("\n You don't have the lead pipe! \n");
                                }
                                break;
                     case '9' : if(pistol)
                                {
                                   if(!SelectedWeapon.equals("Pistol"))
                                   {
                                      SelectedWeapon = "Pistol";
                                      System.out.print("\n  You pull out your trusty 9mm and stack "
                                                       + "one in the chamber.\n");
                                   }
                                   else { System.out.print("\n You are already holding your 9mm! ");  }
                                }
                                else
                                {
                                    System.out.print("\n You don't have the pistol! \n");
                                }
                                break;
                     case 'k' : if(kevlar_vest)
                                {
                                   if(!SelectedArmor.equals("Kevlar Vest"))
                                   {
                                      SelectedArmor = "Kevlar Vest";
                                      System.out.print("\n  You put on your kevlar body armor. \n");
                                   }
                                   else { System.out.print("\n You are already wearing body armor! "); }
                                }
                                else
                                {
                                    System.out.print("\n You don't have the kevlar body armor! \n");
                                }
                                break;
                     case 'm' : if(MedKit > 0)
                                {
                                    System.out.print("\n You open and apply a medkit to your wounds! You begin"
                                                   + "\n to feel better. It adds 10 points to your life.\n");
                                    HP = HP + 10;
                                    MedKit = MedKit - 1;
                                }
                                else
                                {
                                    System.out.print("\n You don't have any medkits! \n");
                                }
                                break;
                     case 'f' : if(FOOD > 0)
                                {
                                    System.out.print("\n Hungry, you open an MRE and chow down. You begin"
                                                   + "\n to feel better. It adds 5 points to your life.\n");
                                    HP = HP + 5;
                                    FOOD = FOOD - 1;
                                }
                                else
                                {
                                    System.out.print("\n You don't have any FOOD! \n");
                                }
                                break;
                     case 'd' : if(DRINK > 0)
                                {
                                    System.out.print("\n Thirsty, you pop a can of eloctrolyte! Your"
                                                   + "\n thisrt is quencehd. It adds 3 points to your life.\n");
                                    HP = HP + 3;
                                    DRINK = DRINK - 1;
                                }
                                else
                                {
                                    System.out.print("\n You don't have any DRINK! \n");
                                }
                                break;
                     case 'q' : break;
                     default: System.out.print("\n Invalid input.\n");
                  }
              }
       }

       public void Eat() {   }
       public void Drink() {  }
       public void Speak() {   }
     //------------------------------------------------------------

       //Accessor Methods------------------------------------------
       public int GetHP() { return HP; }
       public void SetHP(int x) { HP = x; }
       public int GetATK() { return ATK; }
       public void SetATK(int x) { ATK = x; }
       public int GetDEF() { return DEF; }
       public void SetDEF(int x) { DEF = x; }
       public String GetName() { return Name; }
       public void SetName(String x) { Name = x; }
       public double GetWT() { return WT; }
       public void SetWT(double x) { WT = x; }
       public double GetSZ() { return SZ; }
       public void SetSZ(double x) { SZ = x; }
       public String GetGender() { return Gender; }
       public void SetGender(String sex) { Gender = sex; }
       public int GetENERGY() { return ENERGY; }
       public void SetENERGY(int x) { ENERGY = x; }
       public int GetSPD() { return SPD; }
       public void SetSPD(int x) { SPD = x; }
       public int GetDEX() { return DEX; }
       public void SetDEX(int x) { DEX = x; }
       public void SetSelectedWeapon(String x) { SelectedWeapon = x; }
       public String GetSelectedWeapon() { return SelectedWeapon; }
       public void SetSelectedArmor(String x) { SelectedArmor = x; }
       public String GetSelectedArmor() { return SelectedArmor; }

       //Data Members - Attributes of an Object
       private int HP = 100;
       private int ATK = 1;
       private int DEF = 1;
       private int ENERGY = 100;
       private int SPD = 100;
       private int DEX = 100;
       public String Gender = "Blob";
       private String Name = "Anonymous";
       private double WT = 1.0;
       private double SZ = 1.0;
       private String SelectedWeapon = "Nothing but your fists!";
       private String SelectedArmor = "Bare Skin";
       //--------------------------------------

       //Accessor Methods for Inventory Items
       public int GetFOOD() { return FOOD; }
       public void SetFOOD(int x) { FOOD = x; }
       public int GetDRINK() { return DRINK; }
       public void SetDRINK(int x) { DRINK = x; }
       public int GetMedKit() { return MedKit; }
       public void SetMedKit(int x) { MedKit = x; }
       public int Getpistol_ammo() { return pistol_ammo; }
       public void Setpistol_ammo(int x) { pistol_ammo = x; }

       public boolean Getpipe() { return pipe; }
       public void Setpipe(boolean x) { pipe = x; }
       public boolean Getpistol() { return pistol; }
       public void Setpistol(boolean x) { pistol = x; }
       public boolean Getkevlar_vest() { return kevlar_vest; }
       public void Setkevlar_vest(boolean x) { kevlar_vest = x; }

       //Data Members - Inventory
       private int FOOD = 0;
       private int DRINK = 0;
       private int MedKit = 0;
       private int pistol_ammo = 0;
       private boolean pipe = false;
       private boolean pistol = false;
       private boolean kevlar_vest = false;
       //--------------------------------------
}
