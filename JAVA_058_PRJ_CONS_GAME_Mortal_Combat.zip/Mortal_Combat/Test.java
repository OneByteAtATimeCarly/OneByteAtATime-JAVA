//Project: Mortal Combat Game - 2008 Carly Salali Germany

public class Test
{
        public static void main(String [] args)
        {
                 int [] a = {1, 2, 3, 4, 5, 6, 7, 8, 9};
                 int value = 9;
                 boolean foundIt = false;
                 
                 for(int i=0; i < a.length; i++) 
                 {
                       if (a[i] == value) 
                       {
                               System.out.println(i);
                               foundIt = true;
                       }
                  } 
 
                  if(!foundIt)
                  {   System.out.println("value not found");   }

     }//close main() function

}//close class
