//Project: Mortal Combat Game - 2008 Carly Salali Germany

//Derived/Sub Class

import javax.swing.*;
import java.io.*;

public class Spectre extends MutantHuman
{
       public Spectre()
       {
              System.out.print("\nBuilding a Spectre.\n");
       }

}