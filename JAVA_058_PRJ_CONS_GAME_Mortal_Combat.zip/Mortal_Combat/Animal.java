//Project: Mortal Combat Game - 2008 Carly Salali Germany

//ADT Derived/Sub Class

import javax.swing.*;
import java.io.*;

public class Animal extends LifeForm
{
       public Animal()
       {
              System.out.print("\nBuilding a Animal.\n");
       }

       public Animal(String x)
       {
              System.out.print("\nBuilding a Animal.\n");
              SetName(x);
       }
}