//Project: Mortal Combat Game - 2008 Carly Salali Germany

import javax.swing.*;
import java.io.*;
import java.util.*;

public class Game
{
       public static void main(String args[])
       {
              Events TheGame = new Events();
              
       }//close function

}//close class