//Project: Mortal Combat Game - 2008 Carly Salali Germany

import javax.swing.*;
import java.io.*;
import java.util.*;

public class Game
{
       public static void main(String args[])
       {
              LifeForm Monster1 = new LifeForm("Godzilla");
              LifeForm Monster2 = new LifeForm("Mothra");
              Random DAMAGE = new Random();
              final int MAX_Damage = 50;
              int M1_score = 0;
              int M2_score = 0;
              int PAUSE = 2000;
              int damage = 0;
              int GoFirst = 0;

              //A Battle = 3 matches
              for(int x = 1; x < 4; x++)
              {

                 //Reset HP for opponents
                 Monster1.SetHP(100);
                 Monster2.SetHP(100);

              System.out.print("\n\n--------------Beginning Match # " + x + "--------------\n\n");

              //Begin Combat
              System.out.print(Monster1.GetName() + " begins match with "
                                                  + Monster1.GetHP() + " hitpoints.\n");

              System.out.print(Monster2.GetName() + " begins match with "
                                                  + Monster2.GetHP() + " hitpoints.\n");

              GoFirst = DAMAGE.nextInt(2) + 1;

              //A Match Continues In Combat Until Monster1 or Monster2 Dies
              while(Monster1.GetHP() > 0 && Monster2.GetHP() > 0)
              {
                  if(GoFirst == 1)
                  {
                   //Monster1 Attack----------------------------------------------
                  if(Monster1.GetHP() > 0)
                  {
                     damage = DAMAGE.nextInt(MAX_Damage);

                     System.out.print("\n " + Monster1.GetName() + " attacks first, doing " +
                             damage + " points" + " of damage\n by landing a hard right!\n");

                     if(Monster2.GetHP() - damage > 0)
                     { Monster2.SetHP(Monster2.GetHP() - damage); }
                     else { Monster2.SetHP(0); }

                     System.out.print("\n " + Monster2.GetName() + " now has only "
                                            + Monster2.GetHP() + " hitpoints left...\n\n\n");
                  }//close Monster1 Attack

                  try { Thread.sleep(PAUSE); }
                  catch(Exception e) {  }

                  //Monster2 Attack----------------------------------------------
                  if(Monster2.GetHP() > 0)
                  {
                     damage = DAMAGE.nextInt(MAX_Damage);

                     System.out.print("\n " + Monster2.GetName() + " attacks second, doing " +
                             damage + " points" + " of damage\n by landing a hard right!\n");

                     if(Monster1.GetHP() - damage > 0)
                     { Monster1.SetHP(Monster1.GetHP() - damage); }
                     else { Monster1.SetHP(0); }

                     System.out.print("\n " + Monster1.GetName() + " now has only "
                                            + Monster1.GetHP() + " hitpoints left...\n\n\n");
                  } //close Monster2 Attack
                  }//close if for GoFirst == 0

                  if(GoFirst == 2)
                  {
                  //Monster2 Attack----------------------------------------------
                  if(Monster2.GetHP() > 0)
                  {
                     damage = DAMAGE.nextInt(MAX_Damage);

                     System.out.print("\n " + Monster2.GetName() + " attacks second, doing " +
                             damage + " points" + " of damage\n by landing a hard right!\n");

                     if(Monster1.GetHP() - damage > 0)
                     { Monster1.SetHP(Monster1.GetHP() - damage); }
                     else { Monster1.SetHP(0); }

                     System.out.print("\n " + Monster1.GetName() + " now has only "
                                            + Monster1.GetHP() + " hitpoints left...\n\n\n");
                  } //close Monster2 Attack

                  try { Thread.sleep(PAUSE); }
                  catch(Exception e) {  }

                   //Monster1 Attack----------------------------------------------
                  if(Monster1.GetHP() > 0)
                  {
                     damage = DAMAGE.nextInt(MAX_Damage);

                     System.out.print("\n " + Monster1.GetName() + " attacks first, doing " +
                             damage + " points" + " of damage\n by landing a hard right!\n");

                     if(Monster2.GetHP() - damage > 0)
                     { Monster2.SetHP(Monster2.GetHP() - damage); }
                     else { Monster2.SetHP(0); }

                     System.out.print("\n " + Monster2.GetName() + " now has only "
                                            + Monster2.GetHP() + " hitpoints left...\n\n\n");
                  }//close Monster1 Attack

                  }//close if for GoFirst == 1

                  try { Thread.sleep(PAUSE); }
                  catch(Exception e) {  }

              }//close while true loop

       if(Monster1.GetHP() > 0)
       {
          System.out.print("\n " + Monster1.GetName() + " wins this match!");
          System.out.print("\n " + Monster2.GetName() + " was defeated!\n\n");
          M1_score++;
       }
       else
       {
          System.out.print("\n " + Monster2.GetName() + " wins this match!");
          System.out.print("\n " + Monster1.GetName() + " was defeated!\n\n");
          M2_score++;
       }

              System.out.print("\n\n" + Monster1.GetName() + " wins = " + M1_score
                               + "      " + Monster2.GetName() + " wins = " + M2_score);

       }//close for loop - ends battle

       if(M1_score > M2_score)
       {
          System.out.print("\n " + Monster1.GetName() + " wins the entire tournament of 3 matches!");
          System.out.print("\n " + Monster2.GetName() + " was defeated!\n\n");
       }
       else
       {
          System.out.print("\n " + Monster2.GetName() + " wins the entire tournament of 3 matches!");
          System.out.print("\n " + Monster1.GetName() + " was defeated!\n\n");
       }

       }//close function

}//close class