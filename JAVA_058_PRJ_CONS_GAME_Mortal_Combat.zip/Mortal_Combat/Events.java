//Project: Mortal Combat Game - 2008 Carly Salali Germany

import javax.swing.*;
import java.io.*;
import java.util.*;

public class Events
{
       //Globals
       public Human PLAYER;
       public DogFromHell CERBEROS;
       public int LOCATION = 0;
       public LineNumberReader INPUT = new LineNumberReader(new InputStreamReader(System.in));
       public Random PLAYERSTART = new Random();

       //Constant Values for Game Locations/Tracking
       public final int QUIT = 0;
       public final int INTRO = 1;
       public final int C1 = 2;
       public final int N1 = 3;
       public final int S1 = 4;
       public final int E1 = 5;
       public final int W1 = 6;
       public final int N2 = 7;

       //Inventory Item Booleans
       public boolean FoundMedKit_S1 = false;
       public boolean FoundMedKit_S2 = false;
       public boolean Fought_SPECTRE1 = false;

//---------------------------------------------------------------------------------
       public Events()
       {
              PLAYER = new Human();
              CERBEROS = new DogFromHell("Cerberos");
              LOCATION = INTRO;

              while(LOCATION != QUIT)
              {
                    SwitchBoard();
              }
       }

//---------------------------------------------------------------------------------

       public void SwitchBoard()
       {
              switch(LOCATION)
              {
                  case INTRO : INTRODUCTION(); break;
                  case C1 : CENTER1(); break;
                  case N1 : NORTH1(); break;
                  case S1 : SOUTH1(); break;
                  case E1 : EAST1(); break;
                  case W1 : WEST1(); break;
                  case N2 : NORTH2(); break;
                  default : System.out.print("\nERROR! Inavlid value for location.\n");
              }
       }

//---------------------------------------------------------------------------------

      public String IN()
      {
             String RESPONSE = "nothing";
             try { RESPONSE = INPUT.readLine(); }
             catch(IOException Z) {  }
             return RESPONSE;
      }
//---------------------------------------------------------------------------------
public void Options()
{
       String choice = " ";

       while(choice.charAt(0) != 'q' && choice.charAt(0) != 'e')
       {
           System.out.print("\n       --------------------Options--------------------\n");
           System.out.print("\n           (I)nventory");
           System.out.print("\n           (U)se Item");
           System.out.print("\n           (S)tats");
           System.out.print("\n           (Q)uit");
           System.out.print("\n           (E)xit Game");
           System.out.print("\n\n       -----------------------------------------------\n\n ");

           choice = IN();
           choice = choice.toLowerCase();

           switch(choice.charAt(0))
           {
              case 'i' : PLAYER.Inventory(); break;
              case 'u' : PLAYER.Use_Inventory(); break;
              case 's' : PLAYER.Stats(); break;
              case 'q' : break;
              case 'e' : LOCATION = QUIT; break;
              case '~' : PLAYER.Cheat(); break;
              default: System.out.print("\n Invalid input.\n");
           }
       }

}
//---------------------------------------------------------------------------------

//Level Locations
public void INTRODUCTION()
{
       System.out.print("\n\n Welcome to \"Name of Game\" ...\n\n\n");

       System.out.print("\n What will you name your character, player?  ");
       PLAYER.SetName(IN());

       System.out.print("\n What gender will you give your character, player?  ");
       PLAYER.SetGender(IN());

       //Player Start
       //LOCATION = PLAYERSTART.nextInt(4) + 2;
       LOCATION = C1;
}
//---------------------------------------------------------------------------------
public void CENTER1()
{
       System.out.print("\n\n\n\n\n\n\n\n\n\n");
       PLAYER.Stats();

       String choice = " ";

       System.out.print("\n\n " + PLAYER.GetName() + " finds ");

       if(PLAYER.GetGender().toLowerCase().charAt(0) == 'm')
       {      System.out.print("himself "); }
       else if(PLAYER.GetGender().toLowerCase().charAt(0) == 'f')
       {      System.out.print(" herself "); }
       else
       {      System.out.print(" itself ");  }


       System.out.print("in a post-apocalyptic nightmare...");

       System.out.print("\n\n [PLAYER START] Inside CENTER1. Describe scene...\n\n\n");

       while(choice.charAt(0) != 'n' &&
             choice.charAt(0) != 's' &&
             choice.charAt(0) != 'e' &&
             choice.charAt(0) != 'w' &&
             LOCATION != QUIT)
       {
             System.out.print("\n You may go n, s, e, or w. Where will you go?" +
                              "\n o = Options                                     ");

             choice = IN();
             choice = choice.toLowerCase();

             switch(choice.charAt(0))
             {
                  case 'n' : LOCATION = N1; break;
                  case 's' : LOCATION = S1; break;
                  case 'e' : LOCATION = E1; break;
                  case 'w' : LOCATION = W1; break;
                  case 'o' : Options(); break;
                  default: System.out.print("\n Invalid input.\n");
             }
       }

}
//---------------------------------------------------------------------------------

public void NORTH1()
{
       System.out.print("\n\n\n\n\n\n\n\n\n\n");
       PLAYER.Stats();
       String choice = " ";

       System.out.print("\n\n Inside NORTH1. Describe scene...\n\n\n");

       while(choice.charAt(0) != 's' && LOCATION != QUIT)
       {
             System.out.print("\n You may go n, s, e, or w. Where will you go?" +
                              "\n o = Options                                     ");

             choice = IN();
             choice = choice.toLowerCase();

             switch(choice.charAt(0))
             {
                  case 'n' : System.out.print("\n You see a wall with paintings.\n"); break;
                  case 's' : LOCATION = C1; break;
                  case 'e' : System.out.print("\n You see a locked door.\n"); break;
                  case 'w' : System.out.print("\n You see a window with broken glass\n"); break;
                  case 'o' : Options(); break;
                  default: System.out.print("\n Invalid input.\n");
             }
       }
}
//---------------------------------------------------------------------------------
public void SOUTH1()
{
       System.out.print("\n\n\n\n\n\n\n\n\n\n");
       PLAYER.Stats();
       String choice = " ";

       System.out.print("\n\n Inside SOUTH1. Describe scene...\n\n\n");

       while(choice.charAt(0) != 'n' && LOCATION != QUIT)
       {
             System.out.print("\n You may go n, s, e, or w. Where will you go?" +
                              "\n o = Options                                     ");

             choice = IN();
             choice = choice.toLowerCase();

             switch(choice.charAt(0))
             {
                  case 'n' : LOCATION = C1;  break;
                  case 's' : System.out.print("\n You see a table and chairs.\n"); break;
                  case 'e' : if(!FoundMedKit_S1)
                             {
                                System.out.print("\n You see a bookshelf. On it, you\n" +
                                                 " find a MEDKIT!");
                                                 PLAYER.SetMedKit(PLAYER.GetMedKit() + 1);
                                                 FoundMedKit_S1 = true;
                             }
                             else
                             {
                                System.out.print("\n You see an empty bookshelf.\n");
                             }
                             break;
                  case 'w' : System.out.print("\n You see a a stone fireplace\n"); break;
                  case 'o' : Options(); break;
                  default: System.out.print("\n Invalid input.\n");
             }
       }

}
//---------------------------------------------------------------------------------
public void EAST1()
{
       System.out.print("\n\n\n\n\n\n\n\n\n\n");
       PLAYER.Stats();
       String choice = " ";

       System.out.print("\n\n Inside EAST1. Describe scene...\n\n\n");

       while(choice.charAt(0) != 'w' && LOCATION != QUIT)
       {
             System.out.print("\n You may go n, s, e, or w. Where will you go?" +
                              "\n o = Options                                     ");

             choice = IN();
             choice = choice.toLowerCase();

             switch(choice.charAt(0))
             {
                  case 'n' : System.out.print("\n You see a garden with mutant vegetables!\n"); break;
                  case 's' : System.out.print("\n You see a delapidated wooden gate.\n"); break;
                  case 'e' : if(!Fought_SPECTRE1)
                             {
                                 System.out.print("\n You see a Spectre! He charges.\n");
                                 Spectre SPECTRE1 = new Spectre();
                                 Combat(PLAYER, SPECTRE1);
                                 if(PLAYER.GetHP() <= 0)
                                 { LOCATION = QUIT; }
                                 Fought_SPECTRE1 = true;
                             }
                             else
                             { System.out.print("\n You see the corpse of the Spectre you recently vanquished!\n"); }
                             break;
                  case 'w' : LOCATION = C1; break;
                  case 'o' : Options(); break;
                  default: System.out.print("\n Invalid input.\n");
             }
       }
}
//---------------------------------------------------------------------------------
public void WEST1()
{
       System.out.print("\n\n\n\n\n\n\n\n\n\n");
       PLAYER.Stats();
       String choice = " ";

       System.out.print("\n\n Inside WEST1. Describe scene...\n\n\n");

       while(choice.charAt(0) != 'e' && LOCATION != QUIT)
       {
             System.out.print("\n You may go n, s, e, or w. Where will you go?" +
                              "\n o = Options                                     ");

             choice = IN();
             choice = choice.toLowerCase();

             switch(choice.charAt(0))
             {
                  case 'n' : System.out.print("\n Looking north, you see a stained glass window.\n"); break;
                  case 's' : System.out.print("\n To the south, you see a large, bronze chest.\n"); break;
                  case 'e' : LOCATION = C1;  break;
                  case 'w' : System.out.print("\n You find the 3-headed hound of hell!" +
                                              "\n He looks at you and says: \"");
                             CERBEROS.Speak();
                             System.out.print("\"\n\n");
                             break;
                  case 'o' : Options(); break;
                  default: System.out.print("\n Invalid input.\n");
             }
       }
}

//---------------------------------------------------------------------------------

public void NORTH2()
{

}

//---------------------------------------------------------------------------------

public void Combat(LifeForm OPPONENT1, LifeForm OPPONENT2)
{
              Random WhoFirst = new Random();
              int M1_score = 0;
              int M2_score = 0;
              int PAUSE = 5000;

              int GoFirst = 0;

              System.out.print("\n\n-------------- Mortal Combat! --------------\n\n");

              //Begin Combat
              System.out.print(OPPONENT1.GetName() + " begins match with "
                                                  + OPPONENT1.GetHP() + " hitpoints.\n");

              System.out.print(OPPONENT2.GetName() + " begins match with "
                                                  + OPPONENT2.GetHP() + " hitpoints.\n");

              GoFirst = WhoFirst.nextInt(2) + 1;

              //A Match Continues In Combat Until OPPONENT1 or OPPONENT2 Dies
              while(OPPONENT1.GetHP() > 0 && OPPONENT2.GetHP() > 0)
              {
                  if(GoFirst == 1)
                  {
                       //OPPONENT1 Attack----------------------------------------------
                       if(OPPONENT1.GetHP() > 0)
                       { OPPONENT1.Attack(OPPONENT2); }

                       try { Thread.sleep(PAUSE); }
                       catch(Exception e) {  }

                      //OPPONENT2 Attack----------------------------------------------
                      if(OPPONENT2.GetHP() > 0)
                      { OPPONENT2.Attack(OPPONENT1); }

                  }//close if for GoFirst == 0

                  if(GoFirst == 2)
                  {
                      //OPPONENT2 Attack----------------------------------------------
                      if(OPPONENT2.GetHP() > 0)
                      { OPPONENT2.Attack(OPPONENT1); }

                      try { Thread.sleep(PAUSE); }
                      catch(Exception e) {  }

                      //OPPONENT1 Attack----------------------------------------------
                      if(OPPONENT1.GetHP() > 0)
                      { OPPONENT1.Attack(OPPONENT2); }

                  }//close if for GoFirst == 1

                  try { Thread.sleep(PAUSE); }
                  catch(Exception e) {  }

              }//close while true loop

       if(OPPONENT1.GetHP() > 0)
       {
          System.out.print("\n " + OPPONENT1.GetName() + " survives this battle!");
          System.out.print("\n " + OPPONENT2.GetName() + " was defeated, dying an honorable death.\n\n");
          M1_score++;
       }
       else
       {
          System.out.print("\n " + OPPONENT2.GetName() + " survives this battle!");
          System.out.print("\n " + OPPONENT1.GetName() + " was defeated, dying an honorable death.\n\n");
          M2_score++;
       }

}//closes combat() function

//---------------------------------------------------------------------------------

}//closes class