//Project: UnNatural Selection Console Game - Carly Salali Germany - 07/18/2008

public class SNABBIT extends LifeForm
{
       public SNABBIT()
       {
              System.out.println("\n\tCreating a SNAKE + RABBIT = SNABBIT.");
              SetSpecies("SNABBIT");
       }
       
       public SNABBIT(boolean NEW)
       {
              System.out.println("\n\tCreating a SNAKE + RABBIT = SNABBIT.");
              if(NEW)
              {
                  SetSpecies("SNABBIT");
                  ModifyStats();
                  Set_Speed_N_Weight();
                  SetAttributes();
                  Set_Special_Abilities();
              }
              else { SetSpecies("SNABBIT"); }
       }
}