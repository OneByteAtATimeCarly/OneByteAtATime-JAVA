//Project: UnNatural Selection Console Game - Carly Salali Germany - 07/18/2008

public class HONKEY extends LifeForm
{
       public HONKEY()
       { 
              System.out.println("\n\tCreating a HIPPO + DONKEY = HONKEY.");
              SetSpecies("HONKEY");
       }

       public HONKEY(boolean NEW)
       {
              System.out.println("\n\tCreating a HIPPO + DONKEY = HONKEY.");
              if(NEW)
              {
                  SetSpecies("HONKEY");
                  ModifyStats();
                  Set_Speed_N_Weight();
                  SetAttributes();
                  Set_Special_Abilities();
              }
              else { SetSpecies("HONKEY"); }
       }
}