//Project: UnNatural Selection Console Game - Carly Salali Germany - 07/18/2008

public interface LION
{
       
}