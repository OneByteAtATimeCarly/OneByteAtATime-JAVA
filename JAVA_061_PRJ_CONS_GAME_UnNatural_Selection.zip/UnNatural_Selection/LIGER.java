//Project: UnNatural Selection Console Game - Carly Salali Germany - 07/18/2008

public class LIGER extends LifeForm
{
       public LIGER() 
       { 
              System.out.println("\n\tCreating a LION + TIGER = LIGER.");
              SetSpecies("LIGER");
       }
       
       public LIGER(boolean NEW)
       {
              System.out.println("\n\tCreating a LION + TIGER = LIGER.");
              if(NEW)
              {
                  SetSpecies("LIGER");
                  ModifyStats();
                  Set_Speed_N_Weight();
                  SetAttributes();
                  Set_Special_Abilities();
              }
              else { SetSpecies("LIGER"); }
       }
}