//Project: UnNatural Selection Console Game - Carly Salali Germany - 07/18/2008

//LifeForm ADT Base class for "UnNatural Selection"

//Required Packages
import javax.swing.*;
import java.io.*;
import java.util.Random;

public class LifeForm
{
       //Globals
       public LineNumberReader INPUT = new LineNumberReader(new InputStreamReader(System.in));
       Random COCONUT = new Random();
       public final int MaxPoints = 1000;
       public final int Max_Speed_Weight = 100;
       public final int Max_Spec_Ability_Energy = 100;
       public final int Max_Damage = 150;
       public boolean Dodged = false;
       public boolean Spec_Automatic = false;
       public boolean Total_Mass_Defense = false;

//-----------------------------------------------------------------------------------------------------

       public LifeForm()
       { System.out.println("\n\tCreating ADT LifeForm object."); }

//-----------------------------------------------------------------------------------------------------

       public LifeForm(boolean NEW)
       {
              System.out.println("\n\tCreating ADT LifeForm object.");
              if(NEW)
              {
                   ModifyStats();
                   Set_Speed_N_Weight();
                   SetAttributes();
                   Set_Special_Abilities();
              }
       }

//-----------------------------------------------------------------------------------------------------

       public void SetAttributes()
       {
              String REPLY = "";

              System.out.print("\n\tBIO-engineer, what is YOUR name?  ");
              try { REPLY = INPUT.readLine(); }
              catch(IOException Z) { System.out.print("\n\tInput error..."); }
              Creator = REPLY;

              System.out.print("\n\tWhat is your LifeForm's GENDER?  ");
              try { REPLY = INPUT.readLine(); }
              catch(IOException Z) { System.out.print("\n\tInput error..."); }
              Gender = REPLY;
              
              System.out.print("\n\tWhat is your LifeForm's NAME?  ");
              try { REPLY = INPUT.readLine(); }
              catch(IOException Z) { System.out.print("\n\tInput error..."); }
              Name = REPLY;

              System.out.print("\n\tWhat is your LifeForm's origin?  ");
              try { REPLY = INPUT.readLine(); }
              catch(IOException Z) { System.out.print("\n\tInput error..."); }
              Origin = REPLY;

              System.out.print("\n\tGive a short description of your LifeForm:  ");
              try { REPLY = INPUT.readLine(); }
              catch(IOException Z) { System.out.print("\n\tInput error..."); }
              Desc = REPLY;
       }

//-----------------------------------------------------------------------------------------------------

       public void Set_Speed_N_Weight()
       {
              int PointsUsed = 0;
              int x = 0;
              String choice = " ";
              String amt = " ";

              while(choice.charAt(0) != 'q')
              {
                  PointsUsed = SPEED + WEIGHT;

                  DisplayStats();

                  System.out.print("\n\tYou have " + (Max_Speed_Weight - PointsUsed) + " left to allocate.\n");
                  System.out.print("\n\tAllocate SPEED and WEIGHT of the LifeForm:\n");
                  System.out.print("\n\t(S)peed");
                  System.out.print("\n\t(W)eight");
                  System.out.print("\n\t(F)ree Up Points");
                  System.out.print("\n\t(Q)uit\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                  switch(choice.charAt(0))
                  {
                       case 's' : System.out.print("\n\tHow many points for SPEED?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = SPEED + WEIGHT;

                                  if((PointsUsed + x) > Max_Speed_Weight)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  SPEED = SPEED + x;  }
                                  break;
                       case 'w' : System.out.print("\n\tHow many points for WEIGHT?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = SPEED + WEIGHT;

                                  if((PointsUsed + x) > Max_Speed_Weight)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  WEIGHT = WEIGHT + x;  }
                                  break;
                       case 'f' : Free_Up_WT_Speed_Pts();
                                  break;
                       case 'q' : //Give any remaining unsed points to WEIGHT
                                  System.out.print("\n\n\tAny remaining points allocated to WEIGHT!\n");
                                  WEIGHT = WEIGHT + (Max_Speed_Weight - PointsUsed);
                                  break;
                       default : System.out.print("\n\tInvalid choice..."); break;
                  }//close switch
              
              }//close while loop

              DisplayStats();
       }

//-----------------------------------------------------------------------------------------------------

       public void Free_Up_WT_Speed_Pts()
       {
              int PointsUsed = 0;
              int x = 0;
              String choice = " ";
              String amt = " ";

              while(choice.charAt(0) != 'q')
              {
                  PointsUsed = SPEED + WEIGHT;

                  DisplayStats();

                  System.out.print("\n\tYou have used " + (PointsUsed) + " points for this LifeForm.\n");
                  System.out.print("\n\tDo you wish to remove points from SPEED or WEIGHT?\n");
                  System.out.print("\n\t(S)peed");
                  System.out.print("\n\t(W)eight");
                  System.out.print("\n\t(Q)uit\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                  switch(choice.charAt(0))
                  {
                       case 's' : System.out.print("\n\tHow many points to remove from SPEED?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(SPEED - x < 0) { x = 0; } //prevent negative values
                                  else { SPEED = SPEED - x; }
                                  break;
                       case 'w' : System.out.print("\n\tHow many points to remove from WEIGHT?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(WEIGHT - x < 0) { x = 0; } //prevent negative values
                                  else { WEIGHT = WEIGHT - x; }
                                  break;
                       case 'q' : System.out.print("\n\n\tExiting...\n");
                                  DisplayStats();
                       default : System.out.print("\n\tInvalid choice...\n"); break;
                  }//close switch
              
              }//close while loop
       }

//-----------------------------------------------------------------------------------------------------

       public void ModifyStats()
       {
              int PointsUsed = 0;
              int x = 0;
              String choice = " ";
              String amt = " ";

              while(choice.charAt(0) != 'q')
              {
                  PointsUsed = ATK + DEF + STR + DEX + HP;

                  DisplayStats();

                  System.out.print("\n\n\tYou now have " + (MaxPoints - PointsUsed)
                                   + " points left to allocate for your"
                                   + "\n\tLifeForm's vital stats. Choose wisely.\n");
                  System.out.print("\n\tChoose an Item to Set:\n");
                  System.out.print("\n\t(A)ttack");
                  System.out.print("\n\t(D)efense");
                  System.out.print("\n\t(S)trength");
                  System.out.print("\n\tDe(X)terity");
                  System.out.print("\n\t(H)itpoints");
                  System.out.print("\n\t(F)ree Up Points");
                  System.out.print("\n\t(Q)uit\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                  switch(choice.charAt(0))
                  {
                       case 'a' : System.out.print("\n\tHow many points for ATTACK?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = ATK + DEF + STR + DEX + HP;

                                  if((PointsUsed + x) > MaxPoints)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  ATK = ATK + x;  }
                                  break;
                       case 'd' : System.out.print("\n\tHow many points for DEFENSE?  ");
                                  
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = ATK + DEF + STR + DEX + HP;

                                  if((PointsUsed + x) > MaxPoints)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  DEF = DEF = x;  }
                                  break;
                       case 's' : System.out.print("\n\tHow many points for STRENGTH?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = ATK + DEF + STR + DEX + HP;

                                  if((PointsUsed + x) > MaxPoints)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  STR = STR + x;  }
                                  break;
                       case 'x' : System.out.print("\n\tHow many points for DEXTERITY?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = ATK + DEF + STR + DEX + HP;

                                  if((PointsUsed + x) > MaxPoints)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  DEX = DEX + x;  }
                                  break;
                       case 'h' : System.out.print("\n\tHow many points for HITPOINTS?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = ATK + DEF + STR + DEX + HP;

                                  if((PointsUsed + x) > MaxPoints)
                                  { System.out.print("\n\tExceeds max allocated point value!\n"); }
                                  else
                                  {  HP = HP + x;  }
                                  break;
                       case 'f' : Free_Up_Points();
                                  break;
                       case 'q' : //Give any remaining unsed points to HP
                                  System.out.print("\n\n\tAny remaining points allocated to HP!\n");
                                  HP = HP + (MaxPoints - PointsUsed);
                                  break;
                       default : System.out.print("\n\tInvalid choice..."); break;
                  }//close switch
              
              }//close while loop

       }

//-----------------------------------------------------------------------------------------------------

       public void Free_Up_Points()
       {
              int PointsUsed = 0;
              int x = 0;
              String choice = " ";
              String amt = " ";

              while(choice.charAt(0) != 'q')
              {
                  PointsUsed = ATK + DEF + STR + DEX + HP;

                  DisplayStats();

                  System.out.print("\n\tYou have used " + (PointsUsed) + " points for this LifeForm.\n");
                  System.out.print("\n\tWhich Category Do You Wish to Remove Points From?\n");
                  System.out.print("\n\t(A)ttack");
                  System.out.print("\n\t(D)efense");
                  System.out.print("\n\t(S)trength");
                  System.out.print("\n\tDe(X)terity");
                  System.out.print("\n\t(H)itpoints");
                  System.out.print("\n\t(Q)uit\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                  switch(choice.charAt(0))
                  {
                       case 'a' : System.out.print("\n\tHow many points to remove from ATTACK?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(ATK - x < 0) { x = 0; } //prevent negative values
                                  else { ATK = ATK - x; }
                                  break;
                       case 'd' : System.out.print("\n\tHow many points to remove from DEFENSE?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(DEF - x < 0) { x = 0; } //prevent negative values
                                  else { DEF = DEF - x; }
                                  break;
                       case 's' : System.out.print("\n\tHow many points to remove from STRENGTH?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(STR - x < 0) { x = 0; } //prevent negative values
                                  else { STR = STR - x; }
                                  break;
                       case 'x' : System.out.print("\n\tHow many points to remove from DEXTERITY?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(DEX - x < 0) { x = 0; } //prevent negative values
                                  else { DEX = DEX - x; }
                                  break;
                       case 'h' : System.out.print("\n\tHow many points to remove from HITPOINTS?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(HP - x < 1) { x = 0; } //prevent negative or 0 values
                                  else { HP = HP - x; }
                                  break;
                       case 'q' : System.out.print("\n\n\tExiting...\n");
                                  DisplayStats();
                       default : System.out.print("\n\tInvalid choice...\n"); break;
                  }//close switch

              }//close while loop
       }

//-----------------------------------------------------------------------------------------------------

       public void DisplayStats()
       {
              System.out.print("\n\n\t---------------LifeForm's Stats---------------");
              System.out.print("\n\tSPECIES: " + Species);
              System.out.print("   NAME: " + Name);
              System.out.print("\n\tGENDER: " + Gender);
              System.out.print("   CREATOR: " + Creator);
              System.out.print("\n\tORIGIN: " + Origin);
              System.out.print("\n\tDESCRIPTION: " + Desc);

              System.out.print("\n\n\t---------------LifeForm's Vital Stats----------------");
              System.out.print("\n\tHP: " + HP);
              System.out.print("   ATK: " + ATK);
              System.out.print("   DEF: " + DEF);
              System.out.print("   STR: " + STR);
              System.out.print("   DEX: " + DEX);
              System.out.print("\n\t-----------------------------------------------------");
              
              System.out.print("\n\n\t---------------LifeForm's Attributes---------------");
              System.out.print("\n\tWEIGHT: " + WEIGHT);
              System.out.print("   SPEED: " + SPEED);
              System.out.print("   AGE: " + AGE);
              System.out.print("   EXP: " + EXP);
              System.out.print("   LVL: " + LVL);
              System.out.print("\n\t---------------------------------------------------");
              
              System.out.print("\n\n\t-------------LifeForm's Special Abilities-------------");
              System.out.print("\n\tSpecial Attack: " + Spec_Attack);
              System.out.print("   Damage Amt: " + Spec_Attack_Damage);
              System.out.print("\n\tSpecial Defense: " + Spec_Defense);
              System.out.print("   Defense Amt: " + Spec_Defense_Damage);
              System.out.print("\n\tSpecial Ability Energy: " + Special_Ability_Energy);
              System.out.print("\n\t--------------------------------------------------------\n");
       }

//-----------------------------------------------------------------------------------------------------

       public void SaveLifeForm()
       {
              //Open for Append
              String FileName = Name + ".LF";
              File LifeForm_File = new File(FileName);

              try
              {
                  FileOutputStream LF_FOS = new FileOutputStream(LifeForm_File, false);
                  PrintStream LF_PS = new PrintStream(LF_FOS);

                  //Write LifeForm's Vital Stats
                  LF_PS.println(ATK);
                  LF_PS.println(DEF);
                  LF_PS.println(STR);
                  LF_PS.println(DEX);
                  LF_PS.println(HP);

                  //Write LifeForm's Attributes
                  LF_PS.println(WEIGHT);
                  LF_PS.println(SPEED);
                  LF_PS.println(AGE);
                  LF_PS.println(EXP);
                  LF_PS.println(LVL);
                  
                  //Write LifeForm's General Stats
                  LF_PS.println(Species);
                  LF_PS.println(Name);
                  LF_PS.println(Gender);
                  LF_PS.println(Creator);
                  LF_PS.println(Origin);
                  LF_PS.println(Desc);
                  
                  //Write Special Abilities
                  LF_PS.println(Spec_Attack);
                  LF_PS.println(Spec_Attack_Damage);
                  LF_PS.println(Spec_Defense);
                  LF_PS.println(Spec_Defense_Damage);
                  LF_PS.println(Special_Ability_Energy);

                  System.out.print("\n\tFile was sucessfully saved as \"" + FileName + "\".\n");
              }

              catch(IOException e) { System.out.print("Error saving file..."); }

              // MutantWars.WritePlayer = new PrintStream(MutantWars.PlayerOut);

       }

//-----------------------------------------------------------------------------------------------------

       public void LoadLifeForm()
       {
              System.out.print("\n\tEnter the name of the LifeForm object to load: ");
              String Life_Form_Name = "";

              try { Life_Form_Name = INPUT.readLine(); }
              catch(IOException Z) { System.out.print("\n\tInput error..."); }

              Life_Form_Name = Life_Form_Name + ".LF";

              File LifeForm_File = new File(Life_Form_Name);

              try
              {
                   FileInputStream LF_FIS = new FileInputStream(LifeForm_File);
                   InputStreamReader LF_ISR = new InputStreamReader(LF_FIS);
                   BufferedReader LF_BR = new BufferedReader(LF_ISR);

                   //Read and Set LifeForm's Vital Stats
                   ATK = Integer.parseInt(LF_BR.readLine());
                   DEF = Integer.parseInt(LF_BR.readLine());
                   STR = Integer.parseInt(LF_BR.readLine());
                   DEX = Integer.parseInt(LF_BR.readLine());
                   HP = Integer.parseInt(LF_BR.readLine());

                   //Read and Set LifeForm's Attributes
                   WEIGHT = Integer.parseInt(LF_BR.readLine());
                   SPEED = Integer.parseInt(LF_BR.readLine());
                   AGE = Integer.parseInt(LF_BR.readLine());
                   EXP = Integer.parseInt(LF_BR.readLine());
                   LVL = Integer.parseInt(LF_BR.readLine());

                   //Read and Set LifeForm's General Stats
                   Species = LF_BR.readLine();
                   Name = LF_BR.readLine();
                   Gender = LF_BR.readLine();
                   Creator = LF_BR.readLine();
                   Origin = LF_BR.readLine();
                   Desc  = LF_BR.readLine();

                   //Read Special Abilities
                   Spec_Attack  = LF_BR.readLine();
                   Spec_Attack_Damage  = Integer.parseInt(LF_BR.readLine());
                   Spec_Defense  = LF_BR.readLine();
                   Spec_Defense_Damage  = Integer.parseInt(LF_BR.readLine());
                   Special_Ability_Energy  = Integer.parseInt(LF_BR.readLine());

                   DisplayStats();
              }
              catch(IOException e)
              { System.out.print("\n\n\tError loading file...\n"); }
       }

//-----------------------------------------------------------------------------------------------------

       public void Attack(LifeForm opponent)
       {
              int damage = COCONUT.nextInt(Max_Damage) + 1;
              int STR_damage = COCONUT.nextInt(1000) + 1;
              int DEX_dodge = COCONUT.nextInt(1000) + 1;
              String choice = " ";

              damage = damage + ATK + (WEIGHT/4);

              System.out.print("\n  -----------------------------------------------------------------------\n");

              System.out.print("\n\t" + Name + " attacks " + opponent.GetName() + ".");
              
              //-----------------------------------------------------------------------------

              if(Special_Ability_Energy > 0)
              {
                  if(Spec_Automatic)
                  {
                       Use_Spec_Attack = true;
                       Use_Spec_Defense = true;
                  }

                  else
                  {
                      while(choice.charAt(0) != 'd' &&
                            choice.charAt(0) != 'a' &&
                            choice.charAt(0) != 'n' &&
                            choice.charAt(0) != 's'
                           )
                      {
                          System.out.print("\n\tSpecial Ability Energy Remaining: " + Special_Ability_Energy);
                          System.out.print("\n\n\tChoose one of " + Name + "'s special abilities:\n");

                          System.out.print("\n\t(A)ttack ability: " + Spec_Attack
                                           + "   Point Cost:" + Spec_Attack_Damage);
                          System.out.print("\n\t(D)efense ability: " + Spec_Defense
                                           + "   Point Cost:" + Spec_Defense_Damage);
                          System.out.print("\n\t(N)o ability");
                          System.out.print("\n\t(S)elect Abilities Automatically");
                          System.out.print("\n\t");

                          try { choice = INPUT.readLine(); }
                          catch(IOException Z) { System.out.print("\n\tInput error..."); }

                          switch(choice.charAt(0))
                          {
                               case 'd' : Use_Spec_Defense = true;
                                          break;
                               case 'a' : Use_Spec_Attack = true;
                                          break;
                               case 'n' : break;
                               case 's' : Spec_Automatic = true;
                                          Use_Spec_Attack = true;
                                          Use_Spec_Defense = true;
                                          break;
                               default :  System.out.print("\n\tThat was an invalid choice...");
                                          break;
                          }//close switch

                      }//close while loop
                  
                  }//close else

                  if(Use_Spec_Attack)
                  {
                      System.out.print("\n\tEmploying special attack " + Spec_Attack +
                                       "\n\tfor " + Spec_Attack_Damage + " additional points of damage.");
                      Special_Ability_Energy = Special_Ability_Energy - Spec_Attack_Damage;
                      damage = damage + Spec_Attack_Damage;
                      Use_Spec_Attack = false;
                  }

              }//close if

              else
              { System.out.print("\n\tNo special abilities available - not enough energy!\n"); }

              //------------------------------------------------------------------------------------

              if(STR > STR_damage)
              {
                 System.out.print("\n\t" + Name + "'s incredible strength produces Double Damage!");
                 damage = damage * 2;
              }

              if(((opponent.GetDEX() * 3) / 4) > DEX_dodge)
              {
                 System.out.print("\n\t" + opponent.GetName() + "'s smooth dexterity allows him to dodge the attack!");
                 Dodged = true;
                 damage = 0;
              }

              System.out.print("\n\n\tBefore attack: " + Name + ":" + HP + "     "
                               + opponent.GetName() + ":" + opponent.GetHP());

              int Defense_By_Mass = COCONUT.nextInt(800)+ 1;

              if(WEIGHT > Defense_By_Mass)
              {
                  int Energy_Absorbed = COCONUT.nextInt(opponent.GetWEIGHT())+ 1;
                  System.out.print("\n\t" + opponent.GetName() + "'s incredible mass absorbs " +
                                   Energy_Absorbed + " points of energy from " + Name + "'s blow.\n");
                  if(damage - Energy_Absorbed > 0) { damage = damage - Energy_Absorbed; }
                  else 
                  { 
                    damage = 0;
                    Total_Mass_Defense = true;
                  }

              }

              if(damage - opponent.GetDEF() > 0)
              {
                 System.out.print("\n\t" + opponent.GetName() + "'s defense blocks " + opponent.GetDEF()
                                  + " points of damage from the total: " + damage + ".");
                 damage = damage - opponent.GetDEF();
                 System.out.print("\n\t" + opponent.GetName() + " receives " + damage
                                  + " points of remaining damage.");
              }
              else
              {
                 if(!Dodged && !Total_Mass_Defense)
                 {
                     System.out.print("\n\t" + opponent.GetName() + "'s massive DEFENSE completely "
                                    + "blocks " + Name + "'s damage.\n\tMerely a scratch.");
                     damage = 1;
                 }

                 Dodged = false;
                 Total_Mass_Defense = false;
              }

              //Don't Use Special Defense Unless Necessary
              if(opponent.Get_Use_Spec_Defense())
              {
                  if(damage > 0)
                  {
                      System.out.print("\n\t" + opponent.GetName() + " employs the special defense of "
                      + opponent.GetSpec_Defense() + ",\n\tthus reducing damage by " + opponent.GetSpec_Defense_Damage()
                      + ".");
                      opponent.SetSpecial_Ability_Energy(
                      opponent.GetSpecial_Ability_Energy() -
                      opponent.GetSpec_Defense_Damage());

                      if(damage - opponent.GetSpec_Defense_Damage() > 0)
                      { damage = damage - opponent.GetSpec_Defense_Damage(); }
                      else { damage = 0; }

                  }
                  else
                  {
                      System.out.print("\n\tSpecial defense ability not required.");

                  }

                  opponent.Set_Use_Spec_Defense(false);

              }

              if(opponent.GetHP() - damage > 0)
              {  opponent.SetHP(opponent.GetHP() - damage); }
              else
              { opponent.SetHP(0); }

              System.out.print("\n\tAfter attack: " + Name + ":" + HP + "     "
                              + opponent.GetName() + ":" + opponent.GetHP());

              System.out.print("\n\n  -----------------------------------------------------------------------\n");

               int SecondAttack = COCONUT.nextInt(1000) + 1;

               if(SPEED / 2 > SecondAttack)
               {
                     System.out.print("\n\t" + Name + "'s nimble speed allows a second attack!\n");
                     Attack(opponent);
               }

              //Special MEthod based on a species
              /*
              if(Species.equals("LIGER"))
              {
                 //Attack method for a LIGER   (LION + TIGER)
              }
              */
       }

//-----------------------------------------------------------------------------------------------------

       public void Set_Special_Abilities()
       {
              int PointsUsed = 0;
              int x = 0;
              String choice = " ";
              String amt = " ";

              while(choice.charAt(0) != 'q')
              {
                  PointsUsed = Spec_Defense_Damage + Spec_Attack_Damage;

                  DisplayStats();

                  System.out.print("\n\tYou have " + (Max_Spec_Ability_Energy - PointsUsed) + " points of"
                                   + " special energy left to allocate for your LifeForm.");
                  System.out.print("\n\t(D)efensive Ability");
                  System.out.print("\n\t(A)ttack Ability");
                  System.out.print("\n\t(F)ree Up Points");
                  System.out.print("\n\t(Q)uit\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                  
                  

                  switch(choice.charAt(0))
                  {
                       case 'd' : System.out.print("\n\tEnter title of special DEFENSIVE capability: ");
                                  try { Spec_Defense = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  System.out.print("\n\tHow many points will you allocate for the "
                                                   + "special \n\tdefensive capability of ");
                                  System.out.print(Spec_Defense + "?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = Spec_Defense_Damage + Spec_Attack_Damage;

                                  if((PointsUsed + x) > Max_Spec_Ability_Energy)
                                  { System.out.print("\n\tExceeds max allocated point value for "
                                                     + "special abilities!\n"); }
                                  else
                                  {  Spec_Defense_Damage = Spec_Defense_Damage + x;  }
                                  break;
                       case 'a' : System.out.print("\n\tEnter title of special OFFENSIVE capability: ");
                                  try { Spec_Attack = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  System.out.print("\n\tHow many points will you allocate for the "
                                                   + "special \n\toffensive capability of ");
                                  System.out.print(Spec_Attack + "?  ");

                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                                  x = Integer.parseInt(amt);

                                  PointsUsed = Spec_Defense_Damage + Spec_Attack_Damage;

                                  if((PointsUsed + x) > Max_Spec_Ability_Energy)
                                  { System.out.print("\n\tExceeds max allocated point value for "
                                                     + "special abilities!\n"); }
                                  else
                                  {  Spec_Attack_Damage = Spec_Attack_Damage + x;  }
                                  break;
                       case 'f' : Free_Up_Spec_Ability_Pts();
                                  break;
                       case 'q' : //Give any remaining unsed points to WEIGHT
                                  System.out.print("\n\n\tAny remaining points allocated to WEIGHT!\n");
                                  Spec_Defense_Damage = Spec_Defense_Damage +
                                  (Max_Spec_Ability_Energy - PointsUsed);
                                  break;
                       default : System.out.print("\n\tInvalid choice..."); break;
                  }//close switch
              
              }//close while loop

              DisplayStats();
       }

//-----------------------------------------------------------------------------------------------------

       public void Free_Up_Spec_Ability_Pts()
       {
              int PointsUsed = 0;
              int x = 0;
              String choice = " ";
              String amt = " ";

              while(choice.charAt(0) != 'q')
              {
                  PointsUsed = Spec_Defense_Damage + Spec_Attack_Damage;

                  DisplayStats();

                  System.out.print("\n\tYou have used " + (PointsUsed) + " special ability points for this LifeForm.\n");
                  System.out.print("\n\tDo you wish to remove special ability points from DEFENSE or ATTACK?\n");
                  System.out.print("\n\t(D)efensive Special Ability");
                  System.out.print("\n\t(A)ttack Special Ability");
                  System.out.print("\n\t(Q)uit\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch(IOException Z) { System.out.print("\n\tInput error..."); }

                  switch(choice.charAt(0))
                  {
                       case 'd' : System.out.print("\n\tHow many points to remove from DEFENSE?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(Spec_Defense_Damage - x < 0) { x = 0; } //prevent negative values
                                  else { Spec_Defense_Damage = Spec_Defense_Damage - x; }
                                  break;
                       case 'a' : System.out.print("\n\tHow many points to remove from ATTACK?  ");
                                  try { amt = INPUT.readLine(); }
                                  catch(IOException Z) { System.out.print("\n\tInput error..."); }
                                  x = Integer.parseInt(amt);
                                  if(Spec_Attack_Damage - x < 0) { x = 0; } //prevent negative values
                                  else { Spec_Attack_Damage = Spec_Attack_Damage - x; }
                                  break;
                       case 'q' : System.out.print("\n\n\tExiting...\n");
                                  DisplayStats();
                       default : System.out.print("\n\tInvalid choice...\n"); break;
                  }//close switch

              }//close while loop
       }

//-----------------------------------------------------------------------------------------------------

       //Public Accessors
       public int GetATK() { return ATK; }
       public void SetATK(int x) { ATK = x; }
       public int GetDEF() { return DEF; }
       public void SetDEF(int x) { DEF = x; }
       public int GetSTR() { return STR; }
       public void SetSTR(int x) { STR = x; }
       public int GetDEX() { return DEX; }
       public void SetDEX(int x) { DEX = x; }
       public int GetHP() { return HP; }
       public void SetHP(int x) { HP = x; }

       //Data Members
       private int ATK = 0;
       private int DEF = 0;
       private int STR = 0;
       private int DEX = 0;
       private int HP = 0;

       //Public Accessors
       public int GetSPEED() { return SPEED; }
       public void SetSPEED(int x) { SPEED = x; }
       public int GetWEIGHT() { return WEIGHT; }
       public void SetWEIGHT(int x) { WEIGHT = x; }
       public int GetAGE() { return AGE; }
       public void SetAGE(int x) { AGE = x; }
       public int GetEXP() { return EXP; }
       public void SetEXP(int x) { EXP = x; }
       public int GetLVL() { return LVL; }
       public void SetLVL(int x) { LVL = x; }
       public String GetSpecies() { return Species; }
       public void SetSpecies(String x) { Species = x; }
       public String GetOrigin() { return Origin; }
       public void SetOrigin(String x) { Origin = x; }
       public String GetDesc() { return Desc; }
       public void SetDesc(String x) { Desc = x; }

       private int SPEED = 0;
       private int WEIGHT = 0;
       private int AGE = 1;
       private int EXP = 1;
       private int LVL = 1;
       private String Species = "LifeForm";
       private String Origin = "???";
       private String Desc = "???";

       //Public Accessors
       public String GetName() { return Name; }
       public void SetName(String x) { Name = x; }
       public String GetGender() { return Gender; }
       public void SetGender(String x) { Gender = x; }
       public String GetCreator() { return Creator; }
       public void SetCreator(String x) { Creator = x; }

       //Image Object Graphic Image
       //AudioClip Object Battle  Sound
       private String Name = "No_Name_Yet";
       private String Gender = "No_Sex";
       private String Creator = "No_One";

       //Public Accessors
       public String GetSpec_Attack() { return Spec_Attack; }
       public void SetSpec_Attack(String x) { Spec_Attack = x; }
       public String GetSpec_Defense() { return Spec_Defense; }
       public void SetSpec_Defense(String x) { Spec_Defense = x; }
       public int GetSpec_Attack_Damage() { return Spec_Attack_Damage; }
       public void SetSpec_Attack_Damage(int x) { Spec_Attack_Damage = x; }
       public int GetSpec_Defense_Damage() { return Spec_Defense_Damage; }
       public void SetSpec_Defense_Damage(int x) { Spec_Defense_Damage = x; }
       public int GetSpecial_Ability_Energy() { return Special_Ability_Energy; }
       public void SetSpecial_Ability_Energy(int x) { Special_Ability_Energy = x; }

       public void Set_Use_Spec_Attack(boolean x) { Use_Spec_Attack = x; }
       public void Set_Use_Spec_Defense(boolean x) { Use_Spec_Defense = x; }
       public boolean Get_Use_Spec_Attack() { return Use_Spec_Attack; }
       public boolean Get_Use_Spec_Defense() { return Use_Spec_Defense; }

       //Special Abilities
       private String Spec_Attack = "";
       private String Spec_Defense = "";
       private boolean Use_Spec_Attack = false;
       private boolean Use_Spec_Defense = false;
       private int Spec_Attack_Damage = 0;
       private int Spec_Defense_Damage = 0;
       private int Special_Ability_Energy = Max_Spec_Ability_Energy;
}

