//Project: UnNatural Selection Console Game - Carly Salali Germany - 07/18/2008

import java.io.*;
import java.util.Random;

public class UnNatural_Selection
{
       public static LifeForm CRITTERS[] = new LifeForm[50];
       public static Random MANGO;
       public static final int PauseAmt = 1500;
       public static int CritterCount = 0;

       public static void main(String args[])
       {
              System.out.print("\n\n\tUn_Natural Selection 1.0\n");
              CRITTERS[0] = new LifeForm(false);
              MENU();

       }//close main function

       public static void MENU()
       {
             String choice = " ";
             LineNumberReader INPUT = new LineNumberReader(new InputStreamReader(System.in));
             boolean CRITTER_CREATED = false;

             while(choice.charAt(0) != 'q')
             {
                  System.out.print("\n\n\t---What Do You Want to Do?---");
                  System.out.print("\n\t(C)reate a New LifeForm");
                  System.out.print("\n\t(M)odify LifeForm's Vital Stats");
                  System.out.print("\n\t(A)tribute Modification");
                  System.out.print("\n\t(W)eight and Speed Modification");
                  System.out.print("\n\tS(P)ecial Ability Modification");
                  System.out.print("\n\t(D)isplay Stats Of New LifeForm");
                  System.out.print("\n\t(S)ave LifeForm");
                  System.out.print("\n\t(L)oad LifeForm");
                  System.out.print("\n\t(T)est LifeForm Objects");
                  System.out.print("\n\t(Q)uit");
                  System.out.print("\n\t------------------------------\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch (IOException e) { System.err.println("Input Error..."); }

                  choice.toLowerCase();

                  switch(choice.charAt(0))
                  {
                        case 'c' : Mad_Science();
                                   break;
                        case 'm' : CRITTERS[0].ModifyStats();
                                   break;
                        case 's' : CRITTERS[0].SaveLifeForm();
                                   break;
                        case 'l' : CRITTERS[0].LoadLifeForm();
                                   break;
                        case 'd' : CRITTERS[0].DisplayStats();
                                   break;
                        case 'a' : CRITTERS[0].SetAttributes();
                                   break;
                        case 'w' : CRITTERS[0].Set_Speed_N_Weight();
                                   break;
                        case 'p' : CRITTERS[0].Set_Special_Abilities();
                                   break;
                        case 't' : TEST();
                                   break;
                        case 'q' : break;
                        default : System.out.print("\n\tInvalid Input..."); break;
                  }
           }//close while loop
      }
      
      public static void TEST()
      {
             System.out.print("\n\tLoad first LifeForm:");
             CRITTERS[0] = new LifeForm(false);
             CRITTERS[0].LoadLifeForm();
             System.out.print("\n\tLoad second LifeForm:");
             CRITTERS[1] = new LifeForm(false);
             CRITTERS[1].LoadLifeForm();

             MANGO = new Random();
             int FirstAttack = MANGO.nextInt(10) + 1;


             if(CRITTERS[0].GetSPEED() > CRITTERS[1].GetSPEED())
             { FirstAttack = FirstAttack - 2; }

             if(CRITTERS[0].GetSPEED() < CRITTERS[1].GetSPEED())
             { FirstAttack = FirstAttack + 2; }


             while(CRITTERS[0].GetHP() > 0 && CRITTERS[1].GetHP() > 0)
             {
                   if(FirstAttack < 6)
                   {
                       if(CRITTERS[0].GetHP() > 0) { CRITTERS[0].Attack(CRITTERS[1]); }
                       if(CRITTERS[1].GetHP() > 0) { CRITTERS[1].Attack(CRITTERS[0]); }
                       try { Thread.sleep(PauseAmt); }
                       catch(Exception e) {  }
                   }
                   else
                   {
                       if(CRITTERS[1].GetHP() > 0) { CRITTERS[1].Attack(CRITTERS[0]); }
                       if(CRITTERS[0].GetHP() > 0) { CRITTERS[0].Attack(CRITTERS[1]); }
                       try { Thread.sleep(PauseAmt); }
                       catch(Exception e) {  }
                   }
             }

             System.out.print("\n");
      }

      public static void Mad_Science()
      {
             String choice = " ";
             int ITEM = 100;
             LineNumberReader INPUT = new LineNumberReader(new InputStreamReader(System.in));
             boolean CRITTER_CREATED = false;

             while(choice.charAt(0) != 'q')
             {
                  System.out.print("\n\n\t---What Sort of LifeForm Will We Create Today?---");
                  System.out.print("\n\t1. LIGER (LION + TIGER)");
                  System.out.print("\n\t2. SNABBIT (SNAKE + RABBIT)");
                  System.out.print("\n\t3. HONKEY (HIPPO + DONKEY)");
                  System.out.print("\n\t4. Generic LifeForm");
                  System.out.print("\n\t(Q)uit");
                  System.out.print("\n\t---------------------------------------------\n\n\t");

                  try { choice = INPUT.readLine(); }
                  catch (IOException e) { System.err.println("Input Error..."); }

                  if(choice.charAt(0) != 'q')
                  { 
                      ITEM = Integer.parseInt(choice);

                      switch(ITEM)
                      {
                           case 1 : CRITTERS[CritterCount] = new LIGER(true);
                                    CritterCount++;
                                    break;
                           case 2 : CRITTERS[CritterCount] = new SNABBIT(true);
                                    CritterCount++;
                                    break;
                           case 3 : CRITTERS[CritterCount] = new HONKEY(true);
                                    CritterCount++;
                                    break;
                           case 4 : CRITTERS[CritterCount] = new LifeForm(true);
                                    CritterCount++;
                                    break;
                           case 5 : break;
                           default : System.out.print("\n\tInvalid Input..."); break;
                     }
                     
                  }//close if
                  
           }//close while loop
      }

}//close class

