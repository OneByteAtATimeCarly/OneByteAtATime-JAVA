package Characters;
import Interface.*;

//Object extends Abductor

public class Gray extends AlienMalevolent
{
       public Gray()
       { 
           Conspiracy.TA_MainOutput.append("\n\tCreating an Gray.");
           SetCharacterClass("Alien - Gray");
       }
}