package Characters;
import Interface.*;

//ADT - extends FreeMason

public class FreeMasonMalevolent extends FreeMason
{
       public FreeMasonMalevolent()
       { Conspiracy.TA_MainOutput.append("\n\tCreating an FreeMasonMalevolent."); }
}
