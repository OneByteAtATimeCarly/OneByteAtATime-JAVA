package Characters;
import Interface.*;

public class FBI extends Government
{
       public FBI()
       { 
           Conspiracy.TA_MainOutput.append("\n Creating an FBI object.");
           SetCharacterClass("FBI");
       }
}
