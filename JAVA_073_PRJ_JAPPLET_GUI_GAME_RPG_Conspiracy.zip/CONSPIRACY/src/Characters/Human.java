package Characters;
import Interface.*;

//ADT - extends Entity

public class Human extends Entity
{
       public Human() 
       { Conspiracy.TA_MainOutput.append("\n Creating an Human."); }
}
