package Characters;
import Interface.*;

public class Military extends Government
{
       public void Military()
       { Conspiracy.TA_MainOutput.append("\n Creating a Military object."); }
}
