package Characters;
import Interface.*;

//Object class extends FreeMasonMalevolent

public class Luciferian extends FreeMasonMalevolent
{
       public Luciferian()
       { 
           Conspiracy.TA_MainOutput.append("\n\tBuilding a Malevolent Masonic Luciferian.");
           SetCharacterClass("Luciferian");
       }
}
