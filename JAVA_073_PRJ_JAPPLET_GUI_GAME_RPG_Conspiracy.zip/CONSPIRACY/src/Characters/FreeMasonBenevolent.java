package Characters;
import Interface.*;

//ADT - extends FreeMason

public class FreeMasonBenevolent extends FreeMason
{
       public FreeMasonBenevolent()
       {
           Conspiracy.TA_MainOutput.append("\n Creating an FreeMasonBenevolent.");
           SetCharacterClass("Benevolent Mason");
       }
}

