package Characters;
import Interface.*;

public class CIA extends Government
{
       public CIA()
       {
           Conspiracy.TA_MainOutput.append("\n Creating a CIA object.");
           SetCharacterClass("CIA");
       }
}
