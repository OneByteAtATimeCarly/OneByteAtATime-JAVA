//ADT superclass for all object in hiearchy

package Characters;

import Interface.*;
import java.util.Random;

public class Entity
{
       //Globals
       public final int MaxDamage = 25;
       public boolean wearing = false;

       //OVERLOADED constructors
//------------------------------------------------------------
       public Entity()
       {
              Conspiracy.TA_MainOutput.append("\n Building a superclass ADT Entity.");
              Initialize();
              NAME = "Anonymous Entity";
       }
//------------------------------------------------------------
       public Entity(String x)
       {
              Conspiracy.TA_MainOutput.append("\n Building a superclass ADT Entity\n  object.");
              Initialize();
              NAME = x;
       }
//------------------------------------------------------------

       public Entity(String n, int h, int a, int d)
       {
              Conspiracy.TA_MainOutput.append("\n Building a superclass ADT Entity\n  object.");
              Initialize();
              NAME = n;
              health = h;
              atk = a;
              def = d;
       }

//------------------------------------------------------------
       public void Initialize()
       {
              //Stats
              health = 100;
              size = 5;
              mass = 10;
              atk = 1;
              def = 1;
              speed = 5;
              species = "Undefined Entity";
              gender = "Udefined Sex";
              characterclass = "Undefined Class";

              //Inventory
              JackKnife = false;
              Sword = false;
              Glock = false;
              Stones = false;
              TitaniumStaff = false;
              Grenade = 0;
              FlashGrenade = 0;
              KevlarVest = false;
              KeyCard = false;
              Key = false;
              KeyStone = false;
              GlockAmmo = 0;

              //Abilities
              Shape_Shift = false;
              Space_Shift = false;
              Time_Shift = false;
              Regenerate = false;
              Electromagnetism = false;
              GravityBend = false;
              Singularity = false;
              ENERGY = 0;
       }

//------------------------------------------------------------

       public void CHEAT()
       {
              Conspiracy.TA_MainOutput.append("\n Activating Cheat!");

              //Stats
              health = 1000;
              size = 5;
              mass = 10;
              atk = 10;
              def = 10;
              speed = 50;
              species = "Super Being";
              characterclass = "Hero";

              //Inventory
              JackKnife = true;
              Sword = true;
              Glock = true;
              Stones = true;
              TitaniumStaff = true;
              Grenade = 1000;
              FlashGrenade = 1000;
              KevlarVest = true;
              KeyCard = true;
              Key = true;
              KeyStone = true;
              GlockAmmo = 1000;

              //Abilities
              Shape_Shift = true;
              Space_Shift = true;
              Time_Shift = true;
              Regenerate = true;
              Electromagnetism = true;
              GravityBend = true;
              Singularity = true;
              ENERGY = 10000;

              Conspiracy.RB_Fists.setEnabled(true);
              Conspiracy.RB_JackKnife.setEnabled(true);
              Conspiracy.RB_Glock.setEnabled(true);
              Conspiracy.RB_Stone.setEnabled(true);
              Conspiracy.RB_Staff.setEnabled(true);

              Display();
              ShowInventory();
              ShowWeapons();
              ShowAbilities();
       }

//------------------------------------------------------------

       public void SHOW()
       {
              Display();
              ShowInventory();
              ShowWeapons();
              ShowAbilities();
       }

//------------------------------------------------------------

       public void Display()
       {
              Conspiracy.L_NameBox.setText(NAME);
              Conspiracy.L_GenderBox.setText(gender);
              Conspiracy.L_SpeciesBox.setText(species);
              Conspiracy.L_ClassBox.setText(characterclass);
              Conspiracy.L_SizeBox.setText(Integer.toString(size));
              Conspiracy.L_HealthBox.setText(Integer.toString(health));
              Conspiracy.L_AttackBox.setText(Integer.toString(atk));
              Conspiracy.L_DefenseBox.setText(Integer.toString(def));
              Conspiracy.L_SpeedBox.setText(Integer.toString(speed));
              Conspiracy.L_MassBox.setText(Integer.toString(mass));
       }

//------------------------------------------------------------

public void ShowInventory()
{      //                    0    1   2   3   4   5   6   7   8   9  10  11
       String[] INVENTORY = {" "," "," "," "," "," "," "," "," "," "," "," "};

       int x = 0;

       if(JackKnife)
       {   INVENTORY[x] = (x+1) + ". Jack Knife"; x++; }

       if(Sword)
       {   INVENTORY[x] = (x+1) + ". Sword"; x++; }

       if(Glock)
       {   INVENTORY[x] = (x+1) + ". Glock"; x++; }

       if(GlockAmmo > 0)
       {   INVENTORY[x] = (x+1) + ". G Ammo: " + GlockAmmo; x++; }

       if(Stones)
       {   INVENTORY[x] = (x+1) + ". Stones"; x++; }

       if(TitaniumStaff)
       {   INVENTORY[x] = (x+1) + ". Staff"; x++; }

       if(Grenade > 0)
       {   INVENTORY[x] = (x+1) + ". Grenades: " + Grenade; x++; }

       if(FlashGrenade > 0)
       {   INVENTORY[x] = (x+1) + ". Flash: " + FlashGrenade; x++; }

       if(KevlarVest)
       {   INVENTORY[x] = (x+1) + ". Kevlar"; x++; }

       if(KeyCard)
       {   INVENTORY[x] = (x+1) + ". Key Card"; x++; }

       if(Key)
       {   INVENTORY[x] = (x+1) + ". Key"; x++; }

       if(KeyStone)
       {   INVENTORY[x] = (x+1) + ". Key Stone"; x++; }

       Conspiracy.L_AmmoBox.setText(Integer.toString(GlockAmmo));

       Conspiracy.JL_Inventory.setListData(INVENTORY);
       Conspiracy.JL_Inventory.setSelectedIndex(0);
}

//------------------------------------------------------------

       public void ShowWeapons()
       {
              Conspiracy.RB_Fists.setEnabled(true);

              if(Sword) { Conspiracy.RB_JackKnife.setEnabled(true); }
              else { Conspiracy.RB_JackKnife.setEnabled(false); }

              if(Glock) { Conspiracy.RB_Glock.setEnabled(true); }
              else { Conspiracy.RB_Glock.setEnabled(false); }

              if(Stones) { Conspiracy.RB_Stone.setEnabled(true); }
              else { Conspiracy.RB_Stone.setEnabled(false); }

              if(TitaniumStaff) { Conspiracy.RB_Staff.setEnabled(true); }
              else { Conspiracy.RB_Staff.setEnabled(false); }
       }

//------------------------------------------------------------

public void ShowAbilities()
{
       int x = 0;

       Conspiracy.CB_Abilities.removeAllItems();

       if(Shape_Shift)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Shape Shift"); x++; }

       if(Space_Shift)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Space Shift"); x++; }

       if(Time_Shift)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Time Shift"); x++; }

       if(Regenerate)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Regenerate"); x++; }

       if(Electromagnetism)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Electromagnetism"); x++; }

       if(GravityBend)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Gravity Bend"); x++; }

       if(Singularity)
       { Conspiracy.CB_Abilities.addItem((x+1) + ". Singularity"); x++; }

       Conspiracy.L_EnergyBox.setText(Integer.toString(ENERGY));

       Conspiracy.JL_Inventory.setSelectedIndex(0);
}

//------------------------------------------------------------

       //Functions
       public void Eat() {  Conspiracy.TA_MainOutput.append("\n Eating..."); }

       public void Attack(Entity x)
       {
              Conspiracy.TA_MainOutput.append("\n -------------Before Attack-------------");
              Conspiracy.TA_MainOutput.append("\n " + NAME + ": " + health);
              Conspiracy.TA_MainOutput.append("\n " + x.GetName() + ": " + x.GetHealth());
              Conspiracy.TA_MainOutput.append("\n ------------------------------------------");
              Conspiracy.TA_MainOutput.append("\n\n " + NAME + " attacks\n " + x.GetName() + "!\n");

              Random DAM = new Random();
              int damage = DAM.nextInt(MaxDamage) + 1;

              //Add strength of attacker
              Conspiracy.TA_MainOutput.append(
              "\n Adding " + atk + " to damage due to\n " + NAME + "'s ATK skill.");
              damage = damage + atk;

              //Subtract defense of Attackee
              Conspiracy.TA_MainOutput.append(
              "\n\n Subtracting " + x.GetDef() +
              " from damge due to\n " + x.GetName() + "'s DEF skill.\n");
              damage = damage - x.GetDef();

              damage = CheckWeapons(damage);
              Conspiracy.TA_MainOutput.append("\n");
              CheckAbilities();        

              //Incorporate mass with chance attack of greater damage
              int HeavyBlow = DAM.nextInt(mass) + 1;
              if(HeavyBlow > 4)
              {
                  Conspiracy.TA_MainOutput.append("\n\n Heavy Attack due to mass!");
                  HeavyBlow = DAM.nextInt(mass) + 1;
                  Conspiracy.TA_MainOutput.append("\n Mass increases damage by " + HeavyBlow + ".");
                  damage = damage + HeavyBlow;
              }

              //Incorporate speed into damage
              int ExtraAttack = DAM.nextInt(speed) + 1;
              if(ExtraAttack > 4)
              {
                  Conspiracy.TA_MainOutput.append("\n\n Due to speed, " + NAME + "\n makes a sneak attack!");
                  ExtraAttack = DAM.nextInt(speed) + 1;
                  Conspiracy.TA_MainOutput.append("\n\n The sneak attack inflicts\n " + ExtraAttack + " more damage.");
                  damage = damage + ExtraAttack;
              }

              //Subtract damage from health
              if(x.GetHealth() - damage > 0)
              { x.SetHealth(x.GetHealth() - damage); }
              else { x.SetHealth(0); }

              Conspiracy.TA_MainOutput.append("\n\n --------------After Attack--------------");
              Conspiracy.TA_MainOutput.append("\n " + NAME + ": " + health);
              Conspiracy.TA_MainOutput.append("\n " + x.GetName() + ": " + x.GetHealth());
              Conspiracy.TA_MainOutput.append("\n -------------------------------------------");
       }

//------------------------------------------------------------

       public int CheckWeapons(int damage)
       {
              if(Conspiracy.RB_Fists.isSelected()) 
              { 
                  Conspiracy.TA_MainOutput.append(
                  "\n " + NAME + " attacks with\n FISTS of FURY!\n");

                  if(JackKnife)
                  {
                     Conspiracy.TA_MainOutput.append(
                     "\n A JackKnife augments the damage\n by 2 points.");
                     damage = damage + 2;
                  }
              
              }

              if(Conspiracy.RB_JackKnife.isSelected())
              { 
                 Conspiracy.TA_MainOutput.append(
                 "\n " + NAME + " attacks with the SWORD!" +
                 "\n A quivering blade slices into the air adding 4 points to damage.");
                 damage = damage + 4;
              }

              if(Conspiracy.RB_Glock.isSelected())
              {
                 Conspiracy.TA_MainOutput.append("\n " + NAME + " fires the GLOCK!" +
                 "\n Bullets tear through flesh adding 6 points to damage.");
                 damage = damage + 6;
              }

              if(Conspiracy.RB_Stone.isSelected())
              {
                 Conspiracy.TA_MainOutput.append("\n " + NAME + " uses the STONES!" +
                 "\n A bolt of energy explodes adding 10 points to damage.");
                 damage = damage + 10;
              }

              if(Conspiracy.RB_Staff.isSelected())
              {
                 Conspiracy.TA_MainOutput.append("\n " + NAME + " uses the Power Staff!" +
                 "\n A bright flash vaporizes the atmosphere adding 12 points to damage.");
                 damage = damage + 12;
              }

              return damage;
       }

 //------------------------------------------------------------

       public void CheckAbilities()
       {
              Object TEMP = Conspiracy.CB_Abilities.getSelectedItem();    
              String CHOICE = TEMP.toString();
              CHOICE = CHOICE.substring(3);

              if(CHOICE.equals("Shape Shift"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n to Shape Shift!"); }

              if(CHOICE.equals("Space Shift"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n to Space Shift!"); }

              if(CHOICE.equals("Time Shift"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n to Time Shift!"); }

              if(CHOICE.equals("Regenerate"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n to Regenerate!"); }

              if(CHOICE.equals("Electromagnetism"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n of Electromagnetism!"); }

              if(CHOICE.equals("Gravity Bend"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n to Bend Gravity!"); }

              if(CHOICE.equals("Singularity"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME + " summons the power\n to create a Singularity!"); }

       }

 //------------------------------------------------------------
       
       public void UseInventory()
       {
              Object TEMP = Conspiracy.JL_Inventory.getSelectedValue();
              String CHOICE = TEMP.toString();
              CHOICE = CHOICE.substring(3);

              if(CHOICE.equals("Jack Knife"))
              { Conspiracy.TA_MainOutput.append("\n Using the Jack Knife."); }

              if(CHOICE.equals("Sword"))
              { Conspiracy.TA_MainOutput.append("\n Using the Sword."); }

              if(CHOICE.equals("Glock"))
              { Conspiracy.TA_MainOutput.append("\n Using the Glock."); }

              if(CHOICE.equals("Stones"))
              { Conspiracy.TA_MainOutput.append("\n Using the Stones."); }

              if(CHOICE.equals("Staff"))
              { Conspiracy.TA_MainOutput.append("\n Using the Power Staff"); }

              if(CHOICE.equals("Kevlar"))
              {
                  if(!wearing)
                  {
                      Conspiracy.TA_MainOutput.append(
                      "\n Putting on the Kevlar vest.");
                      def = def + 4;
                      wearing = true;
                      Display();
                  }
                  else
                  {
                     Conspiracy.TA_MainOutput.append(
                      "\n Taking off the Kevlar vest.");
                      def = def - 4;
                      wearing = false;
                      Display();
                  }
              }

              if(CHOICE.equals("Key Card"))
              { Conspiracy.TA_MainOutput.append("\n Using the Key Card."); }

              if(CHOICE.equals("Key"))
              { Conspiracy.TA_MainOutput.append("\n Using the Key."); }

              if(CHOICE.equals("Key Stone"))
              { Conspiracy.TA_MainOutput.append("\n Using the Key Stone."); }

       }
 //------------------------------------------------------------

       public void Rest() { Conspiracy.TA_MainOutput.append("\n\tResting..."); }
       public void Die() { Conspiracy.TA_MainOutput.append("\n\tDieing..."); }
       public void Reproduce() { Conspiracy.TA_MainOutput.append("\n\tReproducing..."); }

       //Character Data Accessors -------------------------------------------
       public int GetHealth() { return health; }
       public void SetHealth(int x) { health = x; }
       public int GetSize() { return size; }
       public void SetSize(int x) { size = x; }
       public int GetMass() { return mass; }
       public void SetMass(int x) { mass = x; }
       public int GetAtk() { return atk; }
       public void SetAtk(int x) { atk = x; }
       public int GetDef() { return def; }
       public void SetDef(int x) { def = x; }
       public int GetSpeed() { return speed; }
       public void SetSpeed(int x) { speed = x; }
       public String GetName() { return NAME; }
       public void SetName(String x) { NAME = x; }
       public String GetGender() { return gender; }
       public void SetGender(String x)
       {
           switch(x.toLowerCase().charAt(0))
           {
               case 'a' : gender = "Androgenous"; break;
               case 'f' : gender = "Female"; break;
               case 'm' : gender = "Male"; break;
           }
       }
       public String GetSpecies() { return species; }
       public void SetSpecies(String x)
       {
           switch(x.toLowerCase().charAt(0))
           {
               case 'a' : species = "Alien"; break;
               case 'h' : species = "Human"; break;
               case 'p' : species = "Hybrid"; break;
           }
       }
       public void SetCharacterClass(String x) { characterclass = x; }
       public String GetCharacterClass() { return characterclass; }

       //Character Data------------------------------------------------------
       private int health;
       private int size;
       private int mass;
       private int atk;
       private int def;
       private int speed;
       private String NAME;
       private String gender;
       private String species;
       private String characterclass;

       //Inventory Accessors----------------------------------------------
       public boolean GetJackKnife() { return JackKnife; }
       public void SetJackKnife(boolean x) { JackKnife = x; }
       public boolean GetSword() { return Sword; }
       public void SetSword(boolean x) { Sword = x; }
       public boolean GetGlock() { return Glock; }
       public void SetGlock(boolean x) { Glock = x; }
       public boolean GetStones() { return Stones; }
       public void SetStones(boolean x) { Stones = x; }
       public boolean GetVest() { return KevlarVest; }
       public void SetVest(boolean x) { KevlarVest = x; }
       public boolean GetStaff() { return TitaniumStaff; }
       public void SetStaff(boolean x) { TitaniumStaff = x; }
       public boolean GetKeyCard() { return KeyCard; }
       public void SetKeyCard(boolean x) { KeyCard = x; }
       public boolean GetKey() { return Key; }
       public void SetKey(boolean x) { Key = x; }
       public boolean GetKeyStone() { return KeyStone; }
       public void SetKeyStone(boolean x) { KeyStone = x; }
       public int GetGlockAmmo() { return GlockAmmo; }
       public void SetGlockAmmo(int x) { GlockAmmo = x; }
       public int GetGrenade() { return Grenade; }
       public void SetGrenade(int x) { Grenade = x; }
       public int GetFlashGrenade() { return FlashGrenade; }
       public void SetFlashGrenade(int x) { FlashGrenade = x; }

       //Inventory ---------------------------------------------------------
       private boolean JackKnife;
       private boolean Sword;
       private boolean Glock;
       private boolean Stones;
       private boolean TitaniumStaff;
       private boolean KevlarVest;
       private boolean KeyCard;
       private boolean Key;
       private boolean KeyStone;
       private int GlockAmmo;
       private int Grenade;
       private int FlashGrenade;

       //Ability Accessors----------------------------------------------
       public boolean GetShapeShift() { return Shape_Shift; }
       public void SetShapeShift(boolean x) { Shape_Shift = x; }
       public boolean GetSpaceShift() { return Space_Shift; }
       public void SetSpaceShift(boolean x) { Space_Shift = x; }
       public boolean GetTimeShift() { return Time_Shift; }
       public void SetTimeShift(boolean x) { Time_Shift = x; }
       public boolean GetRegenerate() { return Regenerate; }
       public void SetRegenerate(boolean x) { Regenerate = x; }
       public boolean GetElectromagnetism() { return Electromagnetism; }
       public void SetElectromagnetism(boolean x) { Electromagnetism = x; }
       public boolean GetGravityBend() { return GravityBend; }
       public void SetGravityBend(boolean x) { GravityBend = x; }
       public boolean GetSingularity() { return Singularity; }
       public void SetSingularity(boolean x) { Singularity = x; }
       public int GetEnergy() { return ENERGY; }
       public void SetEnergy(int x) { ENERGY = x; }

       //Abilities -----------------------------------------------------
       private boolean Shape_Shift;
       private boolean Space_Shift;
       private boolean Time_Shift;
       private boolean Regenerate;
       private boolean Electromagnetism;
       private boolean GravityBend;
       private boolean Singularity;
       public int ENERGY;
}
