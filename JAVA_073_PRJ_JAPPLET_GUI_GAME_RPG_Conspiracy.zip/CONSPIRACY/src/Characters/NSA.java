package Characters;
import Interface.*;

public class NSA extends Government
{
       public NSA()
       { 
           Conspiracy.TA_MainOutput.append("\n Creating an NSA agent.");
           SetCharacterClass("NSA");
       }
}
