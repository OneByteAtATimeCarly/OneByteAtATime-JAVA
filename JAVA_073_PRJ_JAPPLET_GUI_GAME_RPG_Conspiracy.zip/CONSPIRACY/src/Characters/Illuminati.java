package Characters;
import Interface.*;

//Object class extends FreeMasonMalevolent

public class Illuminati extends FreeMasonMalevolent
{
       public Illuminati()
       {
           Conspiracy.TA_MainOutput.append("\n\tBuilding an Illuminati.");
           SetCharacterClass("Illuminati");
       }
}
