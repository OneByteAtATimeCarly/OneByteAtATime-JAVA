package Characters;
import Interface.*;

public class ATF extends Government
{
       public ATF()
       {
           Conspiracy.TA_MainOutput.append("\n\tCreating an ATF agent.");
           SetCharacterClass("ATF");
       }
}
