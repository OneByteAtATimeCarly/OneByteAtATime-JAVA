package Characters;
import Interface.*;

public class Civilian extends Human
{
       public Civilian()
       {
           Conspiracy.TA_MainOutput.append("\n Building a Civilian.");
           SetCharacterClass("Civilian");
       }
}
