package Characters;
import Interface.*;

//Object class extends FreeMasonBenevolent

public class Builder extends FreeMasonBenevolent
{
       public Builder()
       { 
           Conspiracy.TA_MainOutput.append("\n\tBuilding a Benevolent Masonic Builder.");
           SetCharacterClass("Builder");
       }
}