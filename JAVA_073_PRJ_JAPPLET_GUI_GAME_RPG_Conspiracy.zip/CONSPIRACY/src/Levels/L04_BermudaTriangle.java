package Levels;

public class L04_BermudaTriangle
{

}
