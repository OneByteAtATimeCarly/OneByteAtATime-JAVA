//Conspiracy!  copyright 2010 Charles Germany  (07/01/2010)
//Note: In this example, we create and pass pointers to the JApplet's
//interface to function and level classes to allow interaction.

package Levels;

import java.io.*;
import GameFunctions.*;
import Interface.*;
import java.net.URL;
import javax.swing.JApplet;
import javax.swing.JOptionPane;

public class L01_DenverAirport
{
       //Global pointer to Interface for Images and paint()
       public JApplet INTERFACE;

       //Globals
       public int INTRO_CutScene = 1;

       //Boolean Environment Items Found in Level 1
       public boolean Security_FoundAmmo = false;
       public boolean StaffRoom_FoundStaff = false;
       public boolean JT_00_FoundGrenades = false;
       public boolean JT_03_FoundJackKnife = false;
       public boolean JT_12_FoundAmmo = false;
       public boolean JT_20_FoundAmmo = false;
       public boolean FM_22_FoundKey = false;
       public boolean FM_50_FoundAmmo = false;
       public boolean FM_72_TookCoffee = false;
       public boolean FM_81_FoundGlock = false;
       public boolean CU_00_FoundAmmo = false;
       public boolean CU_41_FoundGrenade = false;
       public boolean CU_60_FoundAmmo = false;
       public boolean CU_72_TookCoffee = false;
       public boolean CU_81_FoundVest = false;
       public boolean SW_10_FoundAmmo = false;
       public boolean SW_72_TookCoffee = false;
       public boolean SW_82_FoundKeystone = false;
       public boolean TRAIN_4_TookCoffee = false;
       public boolean TRAIN_9_TookCoffee = false;
       public boolean TRAIN_14_TookCoffee = false;

       //Level 1 Doors and Room Access
       public boolean StaffRoom_DoorUnlocked = false;      //JT_23
       public boolean SecurityOffice_DoorUnlocked = false; //JT_20
       public boolean KeyCardRoom_DoorUnlocked = false;    //JT_00
       public boolean CovertOps_DoorUnlocked = false;      //JT_03

       //Locations
       public static final int QUIT = 0;
       public static final int INTRO = 1;
       public static final int SecurityOffice = 2;
       public static final int StaffRoom = 3;
       public static final int CovertOpsRoom = 4;
       public static final int KeyCardRoom = 5;
       public static final int TRAIN = 6;
       public static final int JeppesenTerminal = 7;
       public static final int FrontierMidwest = 8;
       public static final int ContinentalUSAirways = 9;
       public static final int SouthWest = 10;
       public static final int Train_Tunnel = 11;

       //Location Sectors
       public static int[][] JT_SECTORS = {  {00,01,02,03},
                                          {10,11,12,13},
                                          {20,21,22,23}  };

       public static int[] TRAIN_SECTORS = { 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14 };

       public static int [][] FM_SECTORS = {  { 00, 01, 02 },
                                           { 10, 11, 12 },
                                           { 20, 21, 22 },
                                           { 30, 31, 32 },
                                           { 40, 41, 42 },
                                           { 50, 51, 52 },
                                           { 60, 61, 62 },
                                           { 70, 71, 72 },
                                           { 80, 81, 82 }  };

       public static int [][] CU_SECTORS = {  { 00, 01, 02 },
                                           { 10, 11, 12 },
                                           { 20, 21, 22 },
                                           { 30, 31, 32 },
                                           { 40, 41, 42 },
                                           { 50, 51, 52 },
                                           { 60, 61, 62 },
                                           { 70, 71, 72 },
                                           { 80, 81, 82 }  };

       public static int [][] SW_SECTORS = {  { 00, 01, 02 },
                                           { 10, 11, 12 },
                                           { 20, 21, 22 },
                                           { 30, 31, 32 },
                                           { 40, 41, 42 },
                                           { 50, 51, 52 },
                                           { 60, 61, 62 },
                                           { 70, 71, 72 },
                                           { 80, 81, 82 }  };
//------------------------------------------------------------
       //Overloaded Constructors
       public L01_DenverAirport()
       { 
           Conspiracy.TA_MainOutput.setText(
           "\n\n Building Level 1 - \n The Denver Airport.\n\n");
           INTRO_CutScene = 1;
           F.LOCATION = INTRO;
       }

//------------------------------------------------------------

       public L01_DenverAirport(JApplet X)
       {
           Conspiracy.TA_MainOutput.setText(
           "\n\n Building Level 1 - \n The Denver Airport.\n\n");
           INTRO_CutScene = 1;
           F.LOCATION = INTRO;
           INTERFACE = X; //pass interface pointer to global
       }

//------------------------------------------------------------
    //Helper Function. URL Allows retrieving Image from JAR archive.
    public URL Get_Location(String filename)
    {
             URL url = null;
             try { url = INTERFACE.getClass().getResource(filename); }
             catch (Exception e) { /*STUFF*/ }
             return url;
    }

//------------------------------------------------------------

public void SwitchBoard()
{
      F.PLAYER.Display();
      
      switch(F.LOCATION)
      {
          case QUIT : System.out.print("\n\tExiting game..."); break;
          case INTRO : Intro(); break;
          case SecurityOffice : Security_Office(); break;
          case StaffRoom : Staff_Room(); break;
          case CovertOpsRoom : CovertOps_Room(); break;
          case KeyCardRoom : Key_Card_Room(); break;

          case JeppesenTerminal : switch(JT_SECTORS[F.ROW][F.COLUMN])
                                  {
                                     case 00 : JT_00(); break;
                                     case 01 : JT_01(); break;
                                     case 02 : JT_02(); break;
                                     case 03 : JT_03(); break;
                                     case 10 : JT_10(); break;
                                     case 11 : JT_11(); break;
                                     case 12 : JT_12(); break;
                                     case 13 : JT_13(); break;
                                     case 20 : JT_20(); break;
                                     case 21 : JT_21(); break;
                                     case 22 : JT_22(); break;
                                     case 23 : JT_23(); break;
                                  }
                                  break;

          case FrontierMidwest : switch(FM_SECTORS[F.ROW][F.COLUMN])
                                 {
                                     case 00 : FM_00(); break;
                                     case 01 : FM_01(); break;
                                     case 02 : FM_02(); break;
                                     case 10 : FM_10(); break;
                                     case 11 : FM_11(); break;
                                     case 12 : FM_12(); break;
                                     case 20 : FM_20(); break;
                                     case 21 : FM_21(); break;
                                     case 22 : FM_22(); break;
                                     case 30 : FM_30(); break;
                                     case 31 : FM_31(); break;
                                     case 32 : FM_32(); break;
                                     case 40 : FM_40(); break;
                                     case 41 : FM_41(); break;
                                     case 42 : FM_42(); break;
                                     case 50 : FM_50(); break;
                                     case 51 : FM_51(); break;
                                     case 52 : FM_52(); break;
                                     case 60 : FM_60(); break;
                                     case 61 : FM_61(); break;
                                     case 62 : FM_62(); break;
                                     case 70 : FM_70(); break;
                                     case 71 : FM_71(); break;
                                     case 72 : FM_72(); break;
                                     case 80 : FM_80(); break;
                                     case 81 : FM_81(); break;
                                     case 82 : FM_82(); break;
                                 }
                                 break;

          case ContinentalUSAirways : switch(CU_SECTORS[F.ROW][F.COLUMN])
                                 {
                                     case 00 : CU_00(); break;
                                     case 01 : CU_01(); break;
                                     case 02 : CU_02(); break;
                                     case 10 : CU_10(); break;
                                     case 11 : CU_11(); break;
                                     case 12 : CU_12(); break;
                                     case 20 : CU_20(); break;
                                     case 21 : CU_21(); break;
                                     case 22 : CU_22(); break;
                                     case 30 : CU_30(); break;
                                     case 31 : CU_31(); break;
                                     case 32 : CU_32(); break;
                                     case 40 : CU_40(); break;
                                     case 41 : CU_41(); break;
                                     case 42 : CU_42(); break;
                                     case 50 : CU_50(); break;
                                     case 51 : CU_51(); break;
                                     case 52 : CU_52(); break;
                                     case 60 : CU_60(); break;
                                     case 61 : CU_61(); break;
                                     case 62 : CU_62(); break;
                                     case 70 : CU_70(); break;
                                     case 71 : CU_71(); break;
                                     case 72 : CU_72(); break;
                                     case 80 : CU_80(); break;
                                     case 81 : CU_81(); break;
                                     case 82 : CU_82(); break;
                                 }
                                 break;

          case SouthWest : switch(SW_SECTORS[F.ROW][F.COLUMN])
                                 {
                                     case 00 : SW_00(); break;
                                     case 01 : SW_01(); break;
                                     case 02 : SW_02(); break;
                                     case 10 : SW_10(); break;
                                     case 11 : SW_11(); break;
                                     case 12 : SW_12(); break;
                                     case 20 : SW_20(); break;
                                     case 21 : SW_21(); break;
                                     case 22 : SW_22(); break;
                                     case 30 : SW_30(); break;
                                     case 31 : SW_31(); break;
                                     case 32 : SW_32(); break;
                                     case 40 : SW_40(); break;
                                     case 41 : SW_41(); break;
                                     case 42 : SW_42(); break;
                                     case 50 : SW_50(); break;
                                     case 51 : SW_51(); break;
                                     case 52 : SW_52(); break;
                                     case 60 : SW_60(); break;
                                     case 61 : SW_61(); break;
                                     case 62 : SW_62(); break;
                                     case 70 : SW_70(); break;
                                     case 71 : SW_71(); break;
                                     case 72 : SW_72(); break;
                                     case 80 : SW_80(); break;
                                     case 81 : SW_81(); break;
                                     case 82 : SW_82(); break;
                                 }
                                 break;

            case TRAIN: switch(TRAIN_SECTORS[F.COLUMN])
                        {
                           case 0 : TRAIN_0(); break;
                           case 1 : TRAIN_1(); break;
                           case 2 : TRAIN_2(); break;
                           case 3 : TRAIN_3(); break;
                           case 4 : TRAIN_4(); break;
                           case 5 : TRAIN_5(); break;
                           case 6 : TRAIN_6(); break;
                           case 7 : TRAIN_7(); break;
                           case 8 : TRAIN_8(); break;
                           case 9 : TRAIN_9(); break;
                           case 10 : TRAIN_10(); break;
                           case 11 : TRAIN_11(); break;
                           case 12 : TRAIN_12(); break;
                           case 13 : TRAIN_13(); break;
                           case 14 : TRAIN_14(); break;
                       }
                       break;

          default : Conspiracy.TA_MainOutput.setText(
                    "\n\tSomething went wrong! Navigation error.");

      }
}

//------------------------------------------------------------

       public void Intro()
       {
              switch(INTRO_CutScene)
              {
                 case 1: Conspiracy.TA_MainOutput.setText(
                         "\n Imagine...   What  if  all  those " +
                         "\n \"conspiracy theories\" you hear about" +
                         "\n on the internet were somehow true?" +
                         "\n What if?\n" +
                         "\n Sometimes the truth IS stranger than" +
                         "\n fiction, and actual historical events" +
                         "\n become more macbre and surreal than " +
                         "\n the grizzliest urban legend...\n" +
                         "\n So it was through a seemingly random " +
                         "\n series of capricious coincidences that"+
                         "\n you found yourself in seriptitiously" +
                         "\n subtle synchronicity with the weakest" +
                         "\n links that forge the chains of cause" +
                         "\n and effect in our universe.\n" +
                         "\n It was for this reason that you came" +
                         "\n to Denver International Airport," +
                         "\n leaving behind your once blissful " +
                         "\n ignorance for this abysmal certainty...\n" +
                         "\n There must be an answer, out there," +
                         "\n somewhere...\n");

                         Conspiracy.TA_MainOutput.append(
                         "\n Click \"GO\" to continue.\n\n");
                         INTRO_CutScene++;
                         break;

                  case 2: Conspiracy.TA_MainOutput.setText(
                           "\n Nothing could have prepared you for" +
                           "\n the oddities that soon became an" +
                           "\n every-day occurence. People whom" +
                           "\n you had never met before began to" +
                           "\n to show up in your life daily, " +
                           "\n seemingly in possession of" +
                           "\n knowledge of intimate personal" +
                           "\n details that you had shared with" +
                           "\n no one else. These individuals" +
                           "\n seemed to constantly hint at and" +
                           "\n make references to private" +
                           "\n converstations they should have" +
                           "\n had no knowledge of - even subtle" +
                           "\n comments you had mentioned only" +
                           "\n to yourself in times of inner" +
                           "\n reflection.\n" +
                           "\n Could they actually read your" +
                           "\n mind? Who were they? And why" +
                           "\n the constant, disturbing" +
                           "\n feelings of \"De ja vu\"? The" +
                           "\n incessant confusion? Hours of" +
                           "\n missing time? Entire days that" +
                           "\n could not be accounted for in" +
                           "\n your memory?\n");

                           Conspiracy.TA_MainOutput.append(
                           "\n Click \"GO\" to continue.\n\n");
                           INTRO_CutScene++;
                           break;

                  case 3: Conspiracy.TA_MainOutput.setText(
                          "\n What was so important about" +
                          "\n the endless trivialities of" +
                          "\n your banal and mundane" +
                          "\n existence that seemed to" +
                          "\n utterly fascinate them?" +
                          "\n Was it a joke, a ruse, a" +
                          "\n clever game played by an" +
                          "\n esoteric elite who enjoyed" +
                          "\n toying with the \"common " +
                          "\n folk\" or manipulating the" +
                          "\n masses? Who has that much" +
                          "\n time on their hands?\n" +
                          "\n Did they really have nothing" +
                          "\n better to do? Or had you" +
                          "\n stumbled onto a secret they" +
                          "\n thought you simply could not" +
                          "\n keep? If so, why hadn't they" +
                          "\n simply snuffed you out?" +
                          "\n They had an infinite number" +
                          "\n of opportunities to do so" +
                          "\n and the obvious resources" +
                          "\n necessary to make it look" +
                          "\n like an accident...\n");

                           Conspiracy.TA_MainOutput.append(
                           "\n Click \"GO\" to continue.\n\n");
                           INTRO_CutScene++;
                           break;

                  case 4: Conspiracy.TA_MainOutput.setText(
                          "\n Here you were, trying to jump" + 
                          "\n ahead and make an unexpected" +
                          "\n move. Had you truly been" +
                          "\n unpredictable, or were you" + 
                          "\n merely playing into their" +
                          "\n assortment of pre-determined" +
                          "\n possibilities and patterns" +
                          "\n for individuals pertaining" +
                          "\n to a particular profile?\n");

                           Conspiracy.TA_MainOutput.append(
                           "\n Click \"GO\" to continue.\n\n");
                           INTRO_CutScene++;
                           break;

                  case 5: Conspiracy.TA_MainOutput.setText(
                          "\n You took the \"red pill\"... " + 
                          "\n left your job, your home," +
                          "\n your family and friends" +
                          "\n - all behind you now. " + 
                          "\n Fading into the distance," +
                          "\n your past seemed more and" +
                          "\n more a fabricated existence" +
                          "\n with each passing day." +
                          "\n Sacrificing everything to" +
                          "\n search out the ultimate" +
                          "\n truth. There was nothing" +
                          "\n left for you now but to" +
                          "\n seek it...\n");

                          Conspiracy.TA_MainOutput.append(
                          "\n Click \"GO\" to continue.\n\n");
                          INTRO_CutScene++;
                          break;

                  case 6: F.LOCATION = JeppesenTerminal;
                          F.ROW = 2;
                          F.COLUMN = 3;
                          Conspiracy.EnableAllButtons();
                          SwitchBoard();
                          break;

              }//close switch

       }//close function

//-----------------------------------------------------------------------------

public void Security_Office()
{
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Security_Office] You find" +
           "\n yourself standing in the midst" +
           "\n of the Denver International" +
           "\n Airport's main security" +
           "\n headquarters.\n" + 
           "\n The office is surrounded by" +
           "\n cubicles, computers, phones" +
           "\n and locker facilities.\n" +
           "\n As you look around the room," +
           "\n no one seems to be \"home\"" +
           "\n today.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the office");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/SecurityOffice_Center.jpg"));
           Conspiracy.ComputerSound1.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(F.CHOICE.charAt(0))
           {
               case 'x' : F.LOCATION = JeppesenTerminal;
                          F.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n': Conspiracy.TA_MainOutput.setText(
                          "\n You see several computer terminals" +
                          "\n and switch devices with multiple" +
                          "\n connection LEDs blinking.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_North.jpg"));
                          Conspiracy.ComputerSound2.play();
                          //Note: break left off on purpose
               case '~' : Security_FoundAmmo =
                          F.FIND("Super MEGA ammo clip","Glock Ammo",Security_FoundAmmo,200);
                          F.CHOICE = "~";
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n You see colorless, gray" +
                          "\n cubicles surrounding you" +
                          "\n in all directions.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_South.jpg"));
                          break;
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n You see several computers" +
                          "\n with \"Die Hard\" the movie" +
                          "\n screen savers running in" +
                          "\n the background.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_East.jpg"));
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a row of rusty" +
                          "\n silver lockers.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_West.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Security Office option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void Staff_Room()
{
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Staff_Room] You enter into" +
           "\n a strange, oddly-shaped room" +
           "\n gleaming with an alien," +
           "\n irredescent light.\n" + 
           "\n All around you on every" +
           "\n side exists technology that" +
           "\n simply can not be of" +
           "\n this earth!\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the Staff Room");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/StaffRoom_Center.jpg"));
           Conspiracy.ElectronicHum.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(F.CHOICE.charAt(0))
           {
               case 'x' : F.LOCATION = JeppesenTerminal;
                          F.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n': Conspiracy.TA_MainOutput.setText(
                          "\n You see technology! Everywhere" +
                          "\n you look are servers, computers," +
                          "\n blinking lights and machines!");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/StaffRoom_North.jpg"));
                          Conspiracy.ComputerSound1.play();
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n You survey a plethora" +
                          "\n of bio-mechanical devices -" +
                          "\n all aglow with other-worldly" +
                          "\n light.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/StaffRoom_South.jpg"));
                          Conspiracy.ComputerSound2.play();
                          break;
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n Your gaze is obfuscated by" +
                          "\n a cornucopia of alien" +
                          "\n technology.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/StaffRoom_East.jpg"));
                          Conspiracy.KeyPadPressing.play();
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You spy what appears to be" +
                          "\n pillars leaning against the" +
                          "\n west wall.");
                          //Note: break left off on purpose
               case '^' : if(!StaffRoom_FoundStaff)
                          {
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/PowerStaff.jpg"));
                          }
                          else
                          {
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/StaffRoom_West.jpg"));
                          }
                          StaffRoom_FoundStaff =
                          F.FIND("Alien Power Staff","Titanium Staff",
                          StaffRoom_FoundStaff,0);
                          F.CHOICE = "^";   
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void CovertOps_Room()
{
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [CovertOps_Room] You enter a large," +
           "\n dimly lit operational center. It" +
           "\n contains many computers, monitors" +
           "\n and displays that output the feed" +
           "\n from covert surveillance cameras" +
           "\n strategically placed throughout" +
           "\n the airport and its concourses.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the Key Room");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/SecurityOffice_Center.jpg"));
           Conspiracy.ComputerSound1.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(F.CHOICE.charAt(0))
           {
               case 'x' : F.LOCATION = JeppesenTerminal;
                          F.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n' : Conspiracy.TA_MainOutput.setText(
                          "\n You see gray, drab, plain," +
                          "\n boring, completely uninteresting," +
                          "\n mind-numbingly regular walls.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_North.jpg"));
                          Conspiracy.FootSteps.play();
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n Against this wall a hidden" +
                          "\n mural is painted. The world" +
                          "\n emerges from a major paradigm" +
                          "\n shift or cataclysm - scathed" +
                          "\n and weary...");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/Mural_Peace.jpg"));
                          break; 
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n A shelf attached to the wall" +
                          "\n holds several notbooks and" +
                          "\n cleaning supplies.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_East.jpg"));
                          Conspiracy.FootSteps.play();
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n A small table with a coffee" +
                          "\n pot sits pushed against this" +
                          "\n western wall.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_West.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void Key_Card_Room()
{
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Key_Card_Room] You enter a," +
           "\n bright silver-metallic room.\n" +
           "\n In the center is a podium.\n" +
           "\n On the podium sits a large" +
           "\n brown book.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the Key Card Room");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/KeyCardRoom.jpg"));
           Conspiracy.FootSteps.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(F.CHOICE.charAt(0))
           {
               case 'x' : F.LOCATION = JeppesenTerminal;
                          F.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a metallic wall" +
                          "\n upon which are hanging" +
                          "\n several apocalyptic murals.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_East.jpg"));
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n Against this wall leans a" +
                          "\n lonely, solitary dust mop." +
                          "\n Poor thing!");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_West.jpg"));
                          break;
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n A shelf attached to the wall" +
                          "\n holds several notbooks and" +
                          "\n cleaning supplies.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_East.jpg"));
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n A small table with a coffee" +
                          "\n sits pushed against this" +
                          "\n western wall.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_West.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}
//------------------------------------------------------------------------------
//********************** Jeppesen Terminal Sectors *****************************
//------------------------------------------------------------------------------

 public void JT_00()
 {
        if(F.CHOICE.isEmpty())
        {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_00] You are standing in" +
            "\n the north-west corner of" +
            "\n Jeppesen Terminal. To the " +
            "\n south is the Masonic panel.\n" +
            "\n To your east a marble floor." +
            "\n To the west a disturbing" +
            "\n mural of cataclysm and death.\n" +
            "\n To your north you see a" +
            "\n black metal door.\n");

            Conspiracy.TA_MainOutput.append(
            "\n You may go: (e)ast or (s)outh\n");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/JeppesenTerminal.jpg"));
            Conspiracy.AirportAnnounce1.play();
        }

        else
        {
            switch(F.CHOICE.charAt(0))
            {
                case 'n' : Conspiracy.TA_MainOutput.setText(
                           "\n You can't open the black" +
                           "\n metal door. It's locked.\n");
                          //Note: break left off here on purpose
                case '#': if(!KeyCardRoom_DoorUnlocked)
                          {
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/SteelDoor3.jpg"));

                             KeyCardRoom_DoorUnlocked =
                             F.Room_Access("Black, silvery",
                             KeyCardRoom_DoorUnlocked,F.PLAYER.GetKey());

                             if(KeyCardRoom_DoorUnlocked)
                             {
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/SteelOpen.jpg"));
                             }
                           }
                           else
                           {
                              F.LOCATION = KeyCardRoom;
                              F.CHOICE = "";
                              SwitchBoard();
                           }
                           F.CHOICE = "#";
                           break;
                case 's' : F.ROW++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : F.COLUMN++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : Conspiracy.TA_MainOutput.setText(
                           "\n You see a grotesque mural" +
                           "\n on the wall. Children are in" +
                           "\n coffins and the world burns!");
                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Mural_CasketFire.jpg"));
                           //Note: break left off on purpose
                case '^' : JT_00_FoundGrenades =
                           F.FIND("Fragmentation Grenades",
                           "Grenade",JT_00_FoundGrenades,2);
                           F.CHOICE = "^";
                           break;
                case '~' : Conspiracy.TA_MainOutput.setText(
                           "\n Cheater! Cheater! " +
                           "\n Pumpkin eater...\n");
                           F.PLAYER.CHEAT();
                           break;
                default:  Conspiracy.TA_MainOutput.setText(
                          "\n That does not apply here...");

            }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_01()
 {
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_01] You are standing " +
           "\n against the north wall of " +
           "\n Jeppesen Terminal. To the" +
           "\n south is the room's center.\n" +
           "\n You notice a large apocalyptic" +
           "\n mural painted against the north" +
           "\n wall.\n" +
           "\n To your west is the marble" +
           "\n floor sprawls onward...\n" +
           "\n To your north you see an other-" +
           "\n wise unremarkable wooden door.\n");

            Conspiracy.TA_MainOutput.append(
            "\n You may go:" + 
            "\n (e)ast, (s)outh or (w)est");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/Mural_FloorShot1.jpg"));
            Conspiracy.FootSteps.play();
        }

        else
        {
            switch(F.CHOICE.charAt(0))
            {
                case 'n' : Conspiracy.TA_MainOutput.setText(
                           "\n A mural spread itself against" +
                           "\n the wall. Who is wearing the" +
                           "\n gas mask? Is it DEATH? Is it" +
                           "\n a global dictator? Is it" +
                           "\n of war or pestilence?");
                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Mural_GasMask.jpg"));
                           break;
                case 's' : F.ROW++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : F.COLUMN++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : F.COLUMN--;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                default: Conspiracy.TA_MainOutput.setText(
                         "\n Just not an option...");

             }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_02()
 {
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_02] You are standing" +
           "\n against the north wall of" +
           "\n Jeppesen Terminal. To the" +
           "\n south is theroom's center.\n" +
           "\n To your east is the marble" +
           "\n floor that leads to the" +
           "\n north-east corner of the" +
           "\n Great Hall.\n" +
           "\n To your north you see an" +
           "\n electronic sliding door.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:\n" +
           " (e)ast, (s)outh or (w)est");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.Crowd.play();
        }

        else
        {
            switch(F.CHOICE.charAt(0))
            {
                case 'n' : Conspiracy.TA_MainOutput.setText(
                           "\n You see an entrance way to some" +
                           "\n sort of security facility...");
                          //Note: break left off here on purpose
                case '#': if(!CovertOps_DoorUnlocked)
                          {
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/SteelDoor3.jpg"));

                             CovertOps_DoorUnlocked =
                             F.Room_Access("Red Steel Blast",
                             CovertOps_DoorUnlocked,F.PLAYER.GetKey());

                             if(CovertOps_DoorUnlocked)
                             {
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/SteelOpen.jpg"));
                             }
                           }
                           else
                           {
                              F.LOCATION = CovertOpsRoom;
                              F.CHOICE = "";
                              SwitchBoard();
                           }
                           F.CHOICE = "#";
                           break;
                case 's' : F.ROW++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : F.COLUMN++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : F.COLUMN--;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                default: Conspiracy.TA_MainOutput.setText(
                         "\n Not an option at this time...");

             }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_03()
 {
        if(F.CHOICE.isEmpty())
        {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_03] You are standing in the" +
            "\n north-east corner of Jeppesen" +
            "\n Terminal. Far to the south is" +
            "\n is the door in front of which" +
            "\n you first started.\n" +
            "\n Against the north wall you see" +
            "\n another disturbing mural.\n" +
            "\n To your west the shiny marble" +
            "\n floor edges along.\n" +
            "\n To your east you see a giant LETTER" +
            "\n with some sort of MESSAGE painted" +
            "\n against the concrete wall.\n");

            Conspiracy.TA_MainOutput.append(
            "\n You may go: " +
            "(w)est or (s)outh\n");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/Mural_FloorShot2.jpg"));
            Conspiracy.FootSteps.play();
        }

        else
        {
            switch(F.CHOICE.charAt(0))
            {
                 case 'n' : Conspiracy.TA_MainOutput.setText(
                            "\n You examine the disturbing" +
                            "\n murals further. A global" +
                            "\n dictator lies dead amidst" +
                            "\n the ruins, finally peace is" +
                            "\n victorious.");
                            Conspiracy.CurrentView =
                            INTERFACE.getImage(Get_Location(
                            "../Images/Mural_Peace.jpg"));
                            break;
                 case 's' : F.ROW++;
                            F.CHOICE = "";
                            SwitchBoard();
                            break;
                 case 'e' : Conspiracy.TA_MainOutput.setText(
                            "\n Against the east wall a mural is" +
                            "\n painted of a letter written by a" +
                            "\n child while in a WWII Nazi" +
                            "\n concentration camp. It reads:\n" +
                            "\n       \"I was once a little child" +
                            "\n       who longed for other worlds." +
                            "\n       But I am no more a child" +
                            "\n       for I have known fear." +
                            "\n       I have learned to hate..." +
                            "\n       How trajic, then, is youth" +
                            "\n       which lives with enemies,"+
                            "\n       with gallows ropes." +
                            "\n       Yet, I still believe" +
                            "\n       I only sleep today," +
                            "\n       that I'll wake up," +
                            "\n       a child again, and" +
                            "\n       start to laugh" +
                            "\n       and play.\"");
                            Conspiracy.TA_MainOutput.setCaretPosition(0);
                            Conspiracy.CurrentView =
                            INTERFACE.getImage(Get_Location(
                            "../Images/Mural_LetterConctCamp.jpg"));
                            //Note: break left off on purpose
                 case '^' : JT_03_FoundJackKnife =
                            F.FIND("shiny metal object","Jack Knife",
                            JT_03_FoundJackKnife,0);
                            F.CHOICE = "^";
                            break;
                 case 'w' : F.COLUMN--;
                            F.CHOICE = "";
                            SwitchBoard();
                            break;
                 default: Conspiracy.TA_MainOutput.setText(
                          "\n\tNot a valid option...");

            }//close switch

      }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_10()
 {
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_10] You are standing in " +
           "\n the center of the the far west" +
           "\n wall of Jeppesen Terminal." +
           "\n There in front of you is the" +
           "\n Masonic panel. It has the" +
           "\n Masonic seal and several " +
           "\n symbols and ruins which you" +
           "\n do not recognize." +
           "\n Perhaps they are ancient" +
           "\n egyptian. The panel seems" +
           "\n hewn from something like" +
           "\n obsidian and mounted on a" +
           "\n slab of granite.\n" +
           "\n Further to the north lies" +
           "\n the north-west corner of the" +
           "\n great hall and what looks like" +
           "\n a red metal door in the " +
           "\n distance. In front of you sits" +
           "\n the Masonic panel doing nothing.\n" +
           "\n To the south lies the south-west" +
           "\n corner.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (e)ast, (n)orth or (s)outh\n");

           Conspiracy.TA_MainOutput.setCaretPosition(0);

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/Capsule_Keypad.jpg"));
           Conspiracy.AirportAnnounce2.play();
        }

        else
        {
           switch(F.CHOICE.charAt(0))
           {
                case 'n' : F.ROW--;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 's' : F.ROW++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : F.COLUMN++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : Conspiracy.TA_MainOutput.setText(
                           "\n The Masonic panel captures your" +
                           "\n gaze. It is glossy and shiny but" +
                           "\n does not appear to do anything" +
                           "\n interesting at this time.\n");

                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Capstone.jpg"));

                           break;
               default: Conspiracy.TA_MainOutput.setText(
                        "\n Not a valid option...");

           }//close switch

     }//close else

 }//close

//-----------------------------------------------------------------------------

 public void JT_11()
 {
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_11]. You step into the" +
           "\n western center of \"The" +
           "\n Great Hall\".\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (n)orth, (s)outh, (e)ast, (w)est\n");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.FootSteps.play();
        }
        else
        {
                     switch(F.CHOICE.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 's' : F.ROW++;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         default: Conspiracy.TA_MainOutput.setText(
                                  "\n Not a valid option...");

                     }//close switch

         }//close else
               
 }//close function


//-----------------------------------------------------------------------------

 public void JT_12()
 {
        if(F.CHOICE.isEmpty())
        {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_12]. You step into the" +
            "\n eastern center of:" +
            "\n \"The Great Hall\".\n");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/JeppesenTerminal.jpg"));
            Conspiracy.Crowd.play();

            if(!Conspiracy.Navigation_Lock)
            {
                Conspiracy.TA_MainOutput.append(
                "\n You may go:" +
                "\n (n)orth, (s)outh, (e)ast, (w)est\n");
            }

            JT_12_FoundAmmo =
            F.FIND("unused ammo clip","Glock Ammo",JT_12_FoundAmmo,7);

        }
        else
        {
             switch(F.CHOICE.charAt(0))
             {
                  case 'n' : F.ROW--;
                             F.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 's' : F.ROW++;
                             F.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 'e' : F.COLUMN++;
                             F.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 'w' : F.COLUMN--;
                             F.CHOICE = "";
                             SwitchBoard();
                             break;
                  default: Conspiracy.TA_MainOutput.setText(
                           "\n Not a valid option...");

                    }//close switch

        }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_13()
 {
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_13]. You are standing in the" +
           "\n center of the eastern wall of" +
           "\n Jeppesen Terminal. To your east" +
           "\n you see an escalator leading down" +
           "\n to a subterranean tunnel. A sign" +
           "\n hangs over it marked \"Train\"." +
           "\n To your north in the distance you" +
           "\n see a metalic red door. To the" +
           "\n south in the distance lies a " +
           "\n silver door.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (n)orth, (s)outh or (w)est\n" +
           "\n Or, Take the escalator to" +
           "\n (G)o underground.\n");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/TrainsUpper.jpg"));
           Conspiracy.FootSteps.play();
       }
       else
       {
           switch(F.CHOICE.charAt(0))
           {
              case 'n' : F.ROW--;
                         F.CHOICE = "";
                         SwitchBoard();
                         break;
              case 's' : F.ROW++;
                         F.CHOICE = "";
                         SwitchBoard();
                         break;
              case 'e' : Conspiracy.TA_MainOutput.setText(
                         "\n You see a concrete wall.");
                         break;
              case 'w' : F.COLUMN--;
                         F.CHOICE = "";
                         SwitchBoard();
                         break;
              case 'g' : F.ROW = 0;
                         F.COLUMN = 0;
                         F.LOCATION = TRAIN;
                         F.CHOICE = "";
                         SwitchBoard();
                         break;
              default: System.out.print("\n\tNot a valid option...");

           }//close switch

      }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_20()
 {
        if(F.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_20] You are standing in the" +
           "\n south-west corner of Jeppesen" +
           "\n Terminal. Directly north is the" +
           "\n Masonic panel. To your east -" + 
           "\n a shiny marble floor tiles" +
           "\n towards the center of the" +
           "\n Great Hall.\n" +
           "\n To the west - a disturbing mural.\n" +
           "\n South of where you stand lies " +
           "\n another mural and a metal door.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go: (e)ast or (n)orth");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.AirportAnnounce3.play();

        }
        else
        {
           switch(F.CHOICE.charAt(0))
           {
               case 'n' : F.ROW--;
                          F.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a wall with grotesque," +
                          "\n apocalyptic murals. In the" +
                          "\n mural children of various" +
                          "\n nationalities are laid out" +
                          "\n neatly in coffins and fire" +
                          "\n burns up the earth.\n");
                          //Note: break left off here on purpose
                case '^':  if(!SecurityOffice_DoorUnlocked)
                           {
                                Conspiracy.CurrentView =
                                INTERFACE.getImage(Get_Location(
                                "../Images/SteelDoor3.jpg"));

                                SecurityOffice_DoorUnlocked =
                                F.Room_Access("Silver Metallic Staff",
                                SecurityOffice_DoorUnlocked,F.PLAYER.GetKey());

                                if(SecurityOffice_DoorUnlocked)
                                {
                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/SteelOpen.jpg"));
                                }
                             }
                             else
                             {
                                  F.LOCATION = SecurityOffice;
                                  F.CHOICE = "";
                                  SwitchBoard();
                             }
                             F.CHOICE = "^";
                             break;
                  case 'e' : F.COLUMN++;
                             F.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 'w' : Conspiracy.TA_MainOutput.setText(
                             "\n You see another apocalyptic" +
                             "\n mural. In this one, a giant" +
                             "\n soldier wears a bio-hazard" +
                             "\n suit and a gas mask. He holds" +
                             "\n a sword in his hand and he is" +
                             "\n ramming its point into the " +
                             "\n dove of peace.");
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/Mural_GasMask.jpg"));
                             //Note: break left off on purpose
                  case '~' : JT_20_FoundAmmo =
                             F.FIND("unused ammo clip","Glock Ammo",JT_20_FoundAmmo,13);
                             F.CHOICE = "~";
                             break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a valid option...");

           }//close switch

       }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_21()
 {
        if(F.CHOICE.isEmpty())
        {

           Conspiracy.TA_MainOutput.setText(
           "\n [JT_21] You are standing along" +
           "\n the side of the south wall of" +
           "\n Jeppesen Terminal. To the north" +
           "\n is the room's center. To your" +
           "\n east the marble floor leads to" +
           "\n the south-east corner of the" +
           "\n Great Hall. To the west is the" +
           "\n opposite corner.\n" +
           "\n To your south you see another " +
           "\n disturbing mural.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (e)ast, (w)est or (n)orth");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.FootSteps.play();
        }

        else
        {
                     switch(F.CHOICE.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 's' : Conspiracy.TA_MainOutput.setText(
                                    "\n You see an odd, grotesque mural." +
                                    "\n Painted in this mural, colorful" +
                                    "\n mosaics depicting what might be" +
                                    "\n the artist's prediction of WWIII" +
                                    "\n and dark visions of concentration" +
                                    "\n camps tell the story of man's" +
                                    "\n cruelty upon himself and his" +
                                    "\n destructive legacy.");
                                    Conspiracy.CurrentView =
                                    INTERFACE.getImage(Get_Location(
                                    "../Images/Mural_CasketFire.jpg"));
                                    break;
                         case 'e' : F.COLUMN++;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    F.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         default: Conspiracy.TA_MainOutput.setText(
                                  "\n Not a valid option...");

                     }//close switch

         }//close else

 }//close function


//-----------------------------------------------------------------------------

  public void JT_22()
 {
         if(F.CHOICE.isEmpty())
         {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_22] You are standing against" +
            "\n the south wall of Jeppesen Terminal." +
            "\n To the north is the room's center." +
            "\n To your east the marble floor leads" +
            "\n to the south-east corner of this" +
            "\n Great Hall. To the west is the" +
            "\n opposite corner.\n");

            Conspiracy.TA_MainOutput.append(
            "\n South of your position a macabre," +
            "\n cataclysmic mural is painted" +
            "\n against an otherwise uninteresting" +
            "\n wall. In it lies a young girl" +
            "\n lieing within a coffin.\n" +
            "\n You may go: " +
            "\n (n)orth, (e)ast or (w)est");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/JeppesenTerminal.jpg"));
            Conspiracy.Crowd.play();

        }

        else
        {
            switch(F.CHOICE.charAt(0))
            {
                case 'n' : F.ROW--;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 's' : Conspiracy.TA_MainOutput.setText(
                           "\n You see a colorful mosaic " +
                           "\n depicting a deceased child" +
                           "\n placed peacefully into her" +
                           "\n coffin - obviously meandering" +
                           "\n from the darkest recesses of" +
                           "\n the artist's very worst and" +
                           "\n darkest nightmares...\n");
                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Mural_Casket.jpg"));
                           break;
                case 'e' : F.COLUMN++;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : F.COLUMN--;
                           F.CHOICE = "";
                           SwitchBoard();
                           break;
                default: Conspiracy.TA_MainOutput.append(
                         "\n Not a valid option...");

              }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

       public void JT_23()
       {
              if(F.CHOICE.isEmpty())
              {
                   Conspiracy.TA_MainOutput.setText(
                   "\n [JT_23] You find yourself standing" +
                   "\n in the south-east corner of the" +
                   "\n Jeppensen Terminal at the Denver" +
                   "\n International Airport. You see odd," +
                   "\n colorful, apocalyptic murals running" +
                   "\n parallel to the entrance.\n" + 
                   "\n At a distance in this huge room," +
                   "\n near the center of the far western" +
                   "\n wall of the \"Great Hall\" in which" +
                   "\n you are standing is an odd stone" +
                   "\n panel, composed of something" +
                   "\n like granite and bearing the symbol" +
                   "\n and seal of one of the ancient" +
                   "\n and mysterious masonic orders.\n" +
                   "\n What is that odd image to your EAST?\n");

                   Conspiracy.TA_MainOutput.append(
                   "\n You may go: (n)orth or (w)est\n\n");

                   Conspiracy.TA_MainOutput.setCaretPosition(0);

                   Conspiracy.CurrentView =
                   INTERFACE.getImage(Get_Location(
                   "../Images/JeppesenTerminal.jpg"));
                   Conspiracy.FootSteps.play();

              }

              else
              {
                   switch(F.CHOICE.charAt(0))
                   {
                      case 'n' : F.ROW--;
                                 F.CHOICE = "";
                                 SwitchBoard();
                                 break;
                      case 's' : Conspiracy.TA_MainOutput.setText(
                                 "\n You see a wall with grotesque," +
                                 "\n apocalyptic murals. In the" +
                                 "\n mural children of various" +
                                 "\n nationalities are laid out" +
                                 "\n neatly in coffins and fire" +
                                 "\n burns up the earth.\n");
                                 //Note: break left off here on purpose
                      case '^':  if(!StaffRoom_DoorUnlocked)
                                 {
                                    Conspiracy.CurrentView =
                                    INTERFACE.getImage(Get_Location(
                                    "../Images/SteelDoor3.jpg"));

                                    StaffRoom_DoorUnlocked =
                                    F.Room_Access("Silver Metallic Staff",
                                    StaffRoom_DoorUnlocked,F.PLAYER.GetKey());
                                    
                                    if(StaffRoom_DoorUnlocked)
                                    {
                                        Conspiracy.CurrentView =
                                        INTERFACE.getImage(Get_Location(
                                        "../Images/SteelOpen.jpg"));
                                    }
                                 }
                                 else
                                 {
                                     F.LOCATION = StaffRoom;
                                     F.CHOICE = "";
                                     SwitchBoard();
                                 }
                                 F.CHOICE = "^";
                                 break;
                      case 'e' : Conspiracy.TA_MainOutput.setText(
                                 "\n You see a mural covered wall..." +
                                 "\n The aliens have landed!");
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/Mural_ALien.jpg"));
                                 break;
                      case 'w' : F.COLUMN--;
                                 F.CHOICE = "";
                                 SwitchBoard();
                                 break;
                      default: Conspiracy.TA_MainOutput.append(
                               "\n Not a valid option...");

                  }//close switch

              }//close else

       }//close function

//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//*********************** FrontierMidwest Sectors *****************************
//------------------------------------------------------------------------------
     

       public void FM_00()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_00] You are inside the" +
               "\n Frontier Midwest concourse...\n" +
               "\n To your north another eerie mural." +
               "\n To your west is yet another...\n" );

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh and (e)ast");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Maybe there is hope...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Peace.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_01()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_01] You are inside the" +
               "\n Frontier Midwest concourse and" +
               "\n standing beside Auntie Anne's" +
               "\n scrumptious pretzel shop.\n" +
               "\n Peering into a glass case, you" +
               "\n see row upon row of fresh-baked" +
               "\n pretzels glistening with butter" +
               "\n and salt.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (w)est (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_AuntiAnnesSoftPretzels1.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Wow! Those pretzels smell great!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_AuntiAnnesSoftPretzels2.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_02()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_02] You are standing in the" +
               "\n north-eastern most corner of" +
               "\n the Frontier Midwest concourse...\n" +
               "\n To the north and east are yet more" +
               "\n strange images...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh or (w)est");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Uber-Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket2.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Like the angel of death...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_GasMask.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

       public void FM_10()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_10] Walking inside the" +
               "\n Frontier Midwest concourse" +
               "\n you stumble upon a solitary" +
               "\n Burger King - beloved bastion" +
               "\n of blessed burger benevolence!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BurgerKing.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Mr. BK king sits here...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BurgerKing.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_11()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_11] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_12()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_12] You are against the" +
               "\n eastern wall of the Frontier" +
               "\n Midwest concourse...\n" +
               "\n The delicious smell of sizzling" +
               "\n fajitas wafts from the Cantina" +
               "\n Grill to your east...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CantinaGrill.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n You spy a bonita chicita almost" + 
                              "\n finita with her pocita Fajita!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CantinaGrill.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_20()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_20] You are inside the" +
               "\n Frontier Midwest concourse where" +
               "\n to your west is the Islamic" +
               "\n Prayer Hall and Chapel.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast \n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
               Conspiracy.AirportAnnounce2.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Feeling penitent, are we?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_21()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_21] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_22()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_22] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              //Note: break left off here on purpose
                   case '^':  FM_22_FoundKey =
                              F.FIND("Silver Staff Room Key",
                                     "Key",FM_22_FoundKey,0);
                              F.CHOICE = "^";
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_30()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_30] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_31()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_31] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_32()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_32] You are inside the" +
               "\n Frontier Midwest concourse.\n" +
               "\n To the east lies a veritable" +
               "\n oasis - Colorado Sports Bar!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ColoradoSportsBar.jpg"));
               Conspiracy.AirportAnnounce1.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Sure could use a drink...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ColoradoSportsBar.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_40()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_40] You are inside the" +
               "\n Frontier Midwest concourse.\n" +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'g' : F.ROW = 0;
                              F.COLUMN = 4;
                              F.CHOICE = "";
                              F.LOCATION = TRAIN;
                              SwitchBoard();
                              break;
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_41()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_41] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_42()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_42] You are inside the Frontier" +
               "\n Midwest concourse and standing" +
               "\n against the eastern wall. Below you" +
               "\n an escalator descends into a" +
               "\n subterranean tunnel where a sign" +
               "\n hangs marked \"Train\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n" +
               "\n Or, Take the escalator to" +
               "\n (G)o underground.\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'g' : F.ROW = 0;
                              F.COLUMN = 5;
                              F.LOCATION = TRAIN;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_50()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_50] You stand within the" +
               "\n Frontier Midwest concourse.\n" +
               "\n Directly to your east you smell" +
               "\n the sweet, malty musk of micro-" +
               "\n brewed beverages from the swanky" +
               "\n Boulder Beer Tap House.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BoulderBeerTapHouse.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Ice cold... WooHoo!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BoulderBeerTapHouse.jpg"));
                              //Note: break left off here on purpose
                   case '^':  FM_50_FoundAmmo =
                              F.FIND("unused ammo clip",
                                     "Glock Ammo",FM_50_FoundAmmo,25);
                              F.CHOICE = "^";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_51()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_51] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_52()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_52] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void FM_60()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_60] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_61()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_61] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_62()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_62] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_70()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_70] You are inside the" +
               "\n Frontier Midwest concourse" +
               "\n where, best of all possible" +
               "\n blessings, a Ben and Jerry's" +
               "\n presides over the eastern" +
               "\n wall of the concourse.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys1.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Brain freeze!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_71()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_71] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_72()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_72] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee4.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              Conspiracy.Crowd.play();

                              if(!FM_72_TookCoffee)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n A young, pale \"Caribou Coffee\"" +
                                 "\n associate with shoulder-length" +
                                 "\n auburn-crimson hair and large, deep," +
                                 "\n inquisitive green eyes directs her" +
                                 "\n captivating gaze towards your" +
                                 "\n direction.\n" +
                                 "\n The moment she realizes she has" +
                                 "\n caught your eye she walks over" +
                                 "\n to your right. Clad in a red blouse" +
                                 "\n and a green, ankle-length skirt - she" +
                                 "\n permeates the surrounding atmosphere" +
                                 "\n with the faint anticipation of" +
                                 "\n some seasonal holiday that eludes" +
                                 "\n your memory at present.\n" +
                                 "\n She looks piercingly into your eyes" +
                                 "\n and says:\n" +
                                 "\n   \"I made this. It is very good." +
                                 "\n   Would you like some, stranger?\"\n" +
                                 "\n Will you accept her gracious offer?");
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You have returned to where you" +
                                  "\n met the hauntingly beautiful" +
                                  "\n red-haired attendant.\n" +
                                  "\n However, the shop is currently" +
                                  "\n closed down and the lights are" +
                                  "\n off on all its signs.");
                              }
                              Conspiracy.TA_MainOutput.setCaretPosition(0);
                              //Note: break left off here on purpose
                    case '~' : FM_72_TookCoffee =
                               F.FIND("DELICIOUS coffee","Coffee",FM_72_TookCoffee,0);
                               F.CHOICE = "~";
                               break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void FM_80()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_80] You are inside the" +
               "\n Frontier Midwest concourse" +
               "\n and completely enveloped in" +
               "\n the Ben and Jerry's goodness" +
               "\n consuming the eastern wall.\n" +
               "\n In contrast to these icy" +
               "\n offerings, the fires of HELL" +
               "\n burn mercilessly to the south.");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (n)orth or (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys2.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A dark and disturbing mural.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_CasketFire2.jpg"));
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n How many delicous flavors?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys1.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_81()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_81] You are inside the" +
               "\n Frontier Midwest concourse.\n" +
               "\n Against the south wall is yet" +
               "\n another mosaic nightmare...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_FloorShot1.jpg"));
                              //Note: break left off on purpose
                   case '~' : FM_81_FoundGlock =
                              F.FIND("Black Metal-Plastic Gun","Glock",FM_81_FoundGlock,0);
                              F.CHOICE = "~";
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_82()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_82] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee1.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Smells like heaven...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//****************** ContinentalUSAirways Terminal Sectors *********************
//------------------------------------------------------------------------------

       public void CU_00()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_00] You are inside the" +
               "\n Continental US Airways concourse...\n" +
               "\n To your north another eerie mural." +
               "\n To your west is yet another...\n" );

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh and (e)ast");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket.jpg"));
                             //Note: break left off here on purpose
                   case '^':  CU_00_FoundAmmo =
                              F.FIND("unused ammo clip",
                                     "Glock Ammo",CU_00_FoundAmmo,25);
                              F.CHOICE = "^";
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Maybe there is hope...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Peace.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_01()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_01] You are inside the" +
               "\n Continental US Airways concourse and" +
               "\n standing beside Auntie Anne's" +
               "\n scrumptious pretzel shop.\n" +
               "\n Peering into a glass case, you" +
               "\n see row upon row of fresh-baked" +
               "\n pretzels glistening with butter" +
               "\n and salt.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (w)est (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_AuntiAnnesSoftPretzels1.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Wow! Those pretzels smell great!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_AuntiAnnesSoftPretzels2.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_02()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_02] You are standing in the" +
               "\n north-eastern most corner of" +
               "\n the Continental US Airways concourse...\n" +
               "\n To the north and east are yet more" +
               "\n strange images...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh or (w)est");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Uber-Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket2.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Like the angel of death...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_GasMask.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

       public void CU_10()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_10] Walking inside the" +
               "\n Continental US Airways concourse" +
               "\n you stumble upon a solitary" +
               "\n Burger King - beloved bastion" +
               "\n of blessed burger benevolence!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BurgerKing.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Mr. BK king sits here...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BurgerKing.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_11()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_11] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_12()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_12] You are against the" +
               "\n eastern wall of the Frontier" +
               "\n Midwest concourse...\n" +
               "\n The dilicous smell of sizzling" +
               "\n fajitas wafts from the Cantina" +
               "\n Grill to your east...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CantinaGrill.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n You spy a bonita chicita almost" +
                              "\n finita with her pocita Fajita!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CantinaGrill.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_20()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_20] You are inside the" +
               "\n Continental US Airways concourse" +
               "\n where meandering to your west is" +
               "\n the Islamic Prayer Hall and Chapel.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast \n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
               Conspiracy.AirportAnnounce2.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Feeling penitent, are we?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_21()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_21] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_22()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_22] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_30()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_30] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_31()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_31] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_32()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_32] You are inside the" +
               "\n Continental US Airways concourse.\n" +
               "\n To the east lies a veritable" +
               "\n oasis - Colorado Sports Bar!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ColoradoSportsBar.jpg"));
               Conspiracy.AirportAnnounce1.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Sure could use a drink...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ColoradoSportsBar.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_40()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_40] You are inside the" +
               "\n Continental US Airways concourse." +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'g' : F.ROW = 0;
                              F.COLUMN = 9;
                              F.CHOICE = "";
                              F.LOCATION = TRAIN;
                              SwitchBoard();
                              break;
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_41()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_41] You are inside the" +
               "\n Continental US Airways concourse...\n");

               if(!Conspiracy.Navigation_Lock)
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n You may go:" +
                  "\n (n)orth, (s)outh, (e)ast, (w)est");
               }

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();

               CU_41_FoundGrenade = F.FIND("Fragmentation Grenade",
                                 "Grenade",CU_41_FoundGrenade,1);
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_42()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_42] You are inside the" +
               "\n Continental US Airways concourse.\n" +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                  case 'g' : F.ROW = 0;
                             F.COLUMN = 10;
                             F.CHOICE = "";
                             F.LOCATION = TRAIN;
                             SwitchBoard();
                             break;
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_50()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_50] You stand within the" +
               "\n Continental US Airways concourse.\n" +
               "\n On the east side the Boulder" +
               "\n Beer Tap House is open for" +
               "\n business!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BoulderBeerTapHouse.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Ice cold... WooHoo!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BoulderBeerTapHouse.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_51()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_51] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_52()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_52] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void CU_60()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_60] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              //Note: break left off here on purpose
                   case '^':  CU_60_FoundAmmo =
                              F.FIND("unused ammo clip",
                                     "Glock Ammo",CU_60_FoundAmmo,25);
                              F.CHOICE = "^";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_61()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_61] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_62()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_62] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_70()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_70] You are inside the" +
               "\n Continental US Airways concourse" +
               "\n where, best of all possible" +
               "\n blessings, a Ben and Jerry's" +
               "\n presides over the eastern" +
               "\n wall of the concourse.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys1.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Brain freeze!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_71()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_71] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_72()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_72] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee4.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              Conspiracy.Crowd.play();

                              if(!CU_72_TookCoffee)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n An elderly \"Caribou Coffee\"" +
                                 "\n clerk with silver hair and pale," +
                                 "\n skin waves to you. You can't be sure," +
                                 "\n but for a split second you think" +
                                 "\n you notice something reptillian" +
                                 "\n about his eyes.\n" + 
                                 "\n As you glance away and then look" +
                                 "\n back his eyes seem to shift into" +
                                 "\n a more convincingly human projection." +
                                 "\n He cracks a smile in a serpentine" +
                                 "\n fashion and asks seripticiously:\n" +
                                  "\n   \"Would you like a cup of" +
                                  "\n   coffee? It is on the house," +
                                  "\n   as you say...\"\n" +
                                  "\n Will you accept his generosity?");
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n Here you are again where once" +
                                  "\n before you met that creepy, " +
                                  "\n reptillian Caribou attendant.\n" +
                                  "\n Even so, he offered you FREE" +
                                  "\n coffee, so he couldn't be all" +
                                  "\n that bad...");
                              }
                              Conspiracy.TA_MainOutput.setCaretPosition(0);
                              //Note: break left off here on purpose
                    case '~' : CU_72_TookCoffee =
                               F.FIND("DELICIOUS coffee","Coffee",CU_72_TookCoffee,0);
                               F.CHOICE = "~";
                               break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void CU_80()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_80] You are inside the" +
               "\n Continental US Airways concourse" +
               "\n and completely enveloped in" +
               "\n the Ben and Jerry's goodness" +
               "\n consuming the eastern wall.\n" +
               "\n In contrast to these icy" +
               "\n offerings, the fires of HELL" +
               "\n burn mercilessly to the south.");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (n)orth or (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys2.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A dark and disturbing mural.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_CasketFire2.jpg"));
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n How many delicous flavors?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys1.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_81()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_81] You are inside the" +
               "\n Continental US Airways concourse.\n" +
               "\n Against the south wall is yet" +
               "\n another mosaic nightmare...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_FloorShot1.jpg"));
                              //Note: break left off on purpose
                   case '~' : CU_81_FoundVest =
                              F.FIND("FBI Kevlar Vest","Vest",CU_81_FoundVest,0);
                              F.CHOICE = "~";
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_82()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_82] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee1.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Smells like heaven...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//*********************** Southwest Terminal Sectors ***************************
//------------------------------------------------------------------------------


       public void SW_00()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_00] You are inside the" +
               "\n SouthWest concourse...\n" +
               "\n To your north another eerie mural." +
               "\n To your west is yet another...\n" );

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh and (e)ast");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Maybe there is hope...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Peace.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_01()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_01] You are inside the" +
               "\n SouthWest concourse and" +
               "\n standing beside Auntie Anne's" +
               "\n scrumptious pretzel shop.\n" +
               "\n Peering into a glass case, you" +
               "\n see row upon row of fresh-baked" +
               "\n pretzels glistening with butter" +
               "\n and salt.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (w)est (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_AuntiAnnesSoftPretzels1.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Wow! Those pretzels smell great!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_AuntiAnnesSoftPretzels2.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_02()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_02] You are standing in the" +
               "\n north-eastern most corner of" +
               "\n the SouthWest concourse...\n" +
               "\n To the north and east are yet more" +
               "\n strange images...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh or (w)est");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Uber-Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket2.jpg"));
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Like the angel of death...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_GasMask.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

       public void SW_10()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_10] Walking inside the" +
               "\n SouthWest concourse" +
               "\n you stumble upon a solitary" +
               "\n Burger King - beloved bastion" +
               "\n of blessed burger benevolence!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BurgerKing.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Mr. BK king sits here...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BurgerKing.jpg"));
                              //Note: break left off on purpose
                   case '~' : SW_10_FoundAmmo  =
                              F.FIND("un-used ammo clip","Glock Ammo",SW_10_FoundAmmo ,15);
                              F.CHOICE = "~";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_11()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_11] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_12()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_12] You are against the" +
               "\n eastern wall of the Frontier" +
               "\n Midwest concourse...\n" +
               "\n The dilicous smell of sizzling" +
               "\n fajitas wafts from the Cantina" +
               "\n Grill to your east...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CantinaGrill.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n You spy a bonita chicita almost" +
                              "\n finita with her pocita Fajita!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CantinaGrill.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_20()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_20] You are inside the" +
               "\n SouthWest concourse where" +
               "\n to your west is the Islamic" +
               "\n Prayer Hall and Chapel.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast \n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
               Conspiracy.AirportAnnounce2.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Feeling penitent, are we?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_21()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_21] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_22()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_22] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");               
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_30()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_30] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_31()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_31] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_32()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_32] You are inside the" +
               "\n SouthWest concourse.\n" +
               "\n To the east lies a veritable" +
               "\n oasis - Colorado Sports Bar!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ColoradoSportsBar.jpg"));
               Conspiracy.AirportAnnounce1.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Sure could use a drink...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ColoradoSportsBar.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_40()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_40] You are inside the" +
               "\n SouthWest concourse.\n" +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'g' : F.ROW = 0;
                              F.COLUMN = 14;
                              F.CHOICE = "";
                              F.LOCATION = TRAIN;
                              SwitchBoard();
                              break;
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_41()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_41] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_42()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_42] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_50()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_50] You stand within the" +
               "\n SouthWest concourse." +
               "\n On the east side the Boulder" +
               "\n Beer Tap House is open for" +
               "\n business.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BoulderBeerTapHouse.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Ice cold... WooHoo!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BoulderBeerTapHouse.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_51()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_51] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_52()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_52] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void SW_60()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_60] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_61()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_61] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_62()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_62] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_70()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_70] You are inside the" +
               "\n SouthWest concourse where," +
               "\n best of all possible blessings" +
               "\n a Ben and Jerry's has been set" +
               "\n up on the south-eastern side" +
               "\n of the concourse.\n" +
               "\n As you look to the south, the" +
               "\n unquenchable fire of Hell on" +
               "\n Earth burns in a mural.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys1.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Brain freeze!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_71()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_71] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_72()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_72] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee4.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : F.ROW++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              Conspiracy.Crowd.play();

                              if(!SW_72_TookCoffee)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n A beautiful \"Caribou Coffee\" server" +
                                 "\n with dark almond skin and gorgeous," +
                                 "\n soft brown eyes looks at you. She is" +
                                 "\n wearing a khaki, knee-length skirt and" +
                                 "\n a dull purple blouse.\n" +
                                 "\n Long locks of bead-braided jet-black" +
                                 "\n tresses fall down across her narrow," +
                                 "\n graceful shoulders.\n" +
                                 "\n Through moistened lips of cholcolate" +
                                 "\n meringue she calls to you like a" +
                                 "\n mythological siren:\n" +
                                 "\n   \"Would you like a fresh, hot" +
                                 "\n   cup of Caribou coffee? It was" +
                                 "\n   brewed only a minute ago!\"\n" +
                                 "\n Will you accept her delicious offer?");
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You return to the spot where you" +
                                  "\n once accepted that divine nectar" +
                                  "\n from the hands of a goddess...\n" +
                                  "\n Your heart pines within you," +
                                  "\n smitten with unbearable sorrow.\n" +
                                  "\n The coffee shop is empty. Against" +
                                  "\n the register is a sign that reads:\n" +
                                  "\n     \"Gone for the day. But" +
                                  "\n      I'll be back tomorrow!\"\n" +
                                  "\n Dare you return once again?");
                              }
                              Conspiracy.TA_MainOutput.setCaretPosition(0);
                              //Note: break left off here on purpose
                    case '~' : SW_72_TookCoffee =
                               F.FIND("DELICIOUS coffee","Coffee",SW_72_TookCoffee,0);
                               F.CHOICE = "~";
                               break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void SW_80()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_80] You are inside the" +
               "\n SouthWest concourse" +
               "\n and completely enveloped in" +
               "\n the Ben and Jerry's goodness" +
               "\n consuming the eastern wall.\n" +
               "\n In contrast to these icy" +
               "\n offerings, the fires of HELL" +
               "\n burn mercilessly to the south.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (n)orth or (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys2.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A dark and disturbing mural.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_CasketFire2.jpg"));
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n How many delicous flavors?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys1.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_81()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_81] You are inside the" +
               "\n SouthWest concourse.\n" +
               "\n Against the south wall is yet" +
               "\n another mosaic nightmare...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_FloorShot1.jpg"));
                              break;
                   case 'e' : F.COLUMN++;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_82()
       {
           if(F.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_82] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee1.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(F.CHOICE.charAt(0))
               {
                   case 'n' : F.ROW--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              //Note: break left off on purpose
                   case '~' : SW_82_FoundKeystone   =
                              F.FIND("Quantum Key Stone","KeyStone",
                              SW_82_FoundKeystone,0);
                              F.CHOICE = "~";
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Smells like heaven...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              break;
                   case 'w' : F.COLUMN--;
                              F.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//******************************* TRAIN Sectors ********************************
//------------------------------------------------------------------------------

       public void TRAIN_0()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_0] Coming down the escalator," +
                 "\n from Jeppesen Terminal above," +
                 "\n you arrive at the boarding area" +
                 "\n to enter and exit the underground" +
                 "\n train system. An east-bound train" +
                 "\n is resting at this location. You" +
                 "\n look around and notice there are" +
                 "\n neither passengers nor an operator.\n" +
                 "\n Looking ahead you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. A long lever rests in" +
                 "\n the middle position between slots " +
                 "\n marked \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may: (G)o UP the escalator\n" +
                 "\n You may also enter the train and:" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever\n" +
                 "\n You may also explore the directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'g' : F.ROW = 1;
                               F.COLUMN = 3;
                               F.LOCATION = JeppesenTerminal;
                               F.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : Conspiracy.TA_MainOutput.setText(
                               "\n You press the lever backward." +
                               "\n Brakes hiss and a red panel" +
                               "\n indicator marked \"ERROR\"" +
                               "\n lights up on the console in" +
                               "\n front of you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               Conspiracy.Telephone_Busy.play();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You see the entry-way whereby" +
                               "\n passengers enter and leave" +
                               "\n trains that run between the." +
                               "\n concourses.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainsLower.jpg"));
                               Conspiracy.TrainDoor2.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you lies row upon" +
                               "\n row of people in seats laid out" +
                               "\n in neat little rows - it's a" +
                               "\n waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_2.jpg"));
                               Conspiracy.Crowd.play();
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.FootSteps.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see a public restroom" +
                               "\n facility behind some weary" +
                               "\n travelers resting in chairs" +
                               "\n in the waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_1.jpg"));
                               break;
                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_1()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_1] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of Jeppesen Terminal.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore in directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");


                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left several metalic" +
                               "\n panels with indicators blinking" +
                               "\n first RED and then GREEN.\n"+
                               "\n There are several locked storage" +
                               "\n compartments holding " +
                               "\n miscellaneous equipment.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, a large glass" +
                               "\n window crisscrossed with" +
                               "\n reinforcement safety wires" +
                               "\n looks out into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. The darkness" +
                               "\n outside is intermittently" +
                               "\n broken into dim flashes of" +
                               "\n silver tracks illuminated by" +
                               "\n the occasional sparks emanating" +
                               "\n from beneath you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n It has many panels and blinking" +
                               "\n lights. In the center is a large" +
                               "\n control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you at the" +
                               "\n rear wall of the car you are in." +
                               "\n A small window allows you to" +
                               "\n peer backwards into other cars" +
                               "\n on the empty train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Not as many options to" +
                                              "\n choose from here. Should" +
                                              "\n be easier for you to enter" +
                                              "\n something that makes sense," +
                                              "\n huh?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_2()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_2] You are riding the DIA" +
                 "\n underground train - midway" +
                 "\n between Fronteir Midwest and" +
                 "\n Jeppesen Terminal.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left you peer out" +
                               "\n the window and notice a" +
                               "\n section of tunnel under"+
                               "\n construction. It projects far" +
                               "\n away from the concourse towards" +
                               "\n what appears to be 5 large" +
                               "\n underground buildings.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, the window port" +
                               "\n overlooks anbother underground" +
                               "\n section under construction..." +
                               "\n It's leading AWAY from the" +
                               "\n airport concourses!. Why?\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_4.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n A blue light is flashing and" +
                               "\n a radio hisses. In the center," +
                               "\n a large control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind through the" +
                               "\n central small window but your" +
                               "\n view is mostly obscured by the" +
                               "\n curvature of the tunnels behind" +
                               "\n you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Inside_Back2.jpg"));
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_3()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_3] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of Frontier Midwest.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore towards the:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n To your left, as you gaze out" +
                               "\n the window, you watch an " +
                               "\n auxilliary access tunnel as it" +
                               "\n trails towards a hidden nook" +
                               "\n that appears to be a secluded," +
                               "\n underground base obfuscated" +
                               "\n by a painted facade...");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_1.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n You look out the south " +
                               "\n window into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. Beneath you" +
                               "\n sparks flying from the tracks" +
                               "\n cast shadows and sillohuetes" +
                               "\n against the dark concrete" +
                               "\n walls of the train tunnel.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front is the train's" +
                               "\n directional control panel.\n" +
                               "\n It has several controls and" +
                               "\n blinking lights. In the" +
                               "\n center - a large control" +
                               "\n stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you through the" +
                               "\n small port window of the rear door" +
                               "\n of the car you are traveling in.\n" +
                               "\n Through a small window you see" +
                               "\n flickering flourescent lights in" +
                               "\n the cars behind you on the empty" +
                               "\n train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Please choose an option that" +
                                              "\n is meaningful. O.k.?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_4()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_4] Near the escalator, from" +
                 "\n the Frontier Midwest concourse" +
                 "\n above, you arrive at the boarding" +
                 "\n to enter and exit the underground" +
                 "\n train system. A west-bound" +
                 "\n train is resting at this location." +
                 "\n You see that there are neither" +
                 "\n passengers nor an operator" +
                 "\n anywhere in sight. \n" +
                 "\n Looking around you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. You step inside the car." +
                 "\n As you stand in front of the " +
                 "\n console you are facing WEST." +
                 "\n In front of you a long lever" +
                 "\n sits flipped in the middle position" +
                 "\n between \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (G)o UP the escalator" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore your:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'g' : F.ROW = 4;
                               F.COLUMN = 0;
                               F.LOCATION = FrontierMidwest;
                               F.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You admire a MAGNIFICENT" +
                               "\n Brittish Airways logo" +
                               "\n emblazoned upon the otherwise" +
                               "\n drab and utliitarian concrete" +
                               "\n slabs that wall this underground" +
                               "\n abyss like a tomb.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BrittishAirways.jpg"));
                               Conspiracy.AirportAnnounce1.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n A glorious \"Caribou Coffee\" stand" +
                               "\n lies before you emitting an" +
                               "\n irresistible aroma that tingles" +
                               "\n with savory roasty-toasty goodness." +
                               "\n Oh - sweet nectar of the gods!\n");

                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_CaribouCoffee3.jpg"));
                               Conspiracy.Crowd.play();

                               if(!TRAIN_4_TookCoffee)
                               {
                                   Conspiracy.TA_MainOutput.append(
                                   "\n While you are gawking, the " +
                                   "\n stand's attendant asks you:\n" +
                                   "\n   \"Would you like a complimentary" +
                                   "\n   cup of Caribou coffee, sir? You" +
                                   "\n   seem like such a weary traveler!\"\n" +
                                   "\n Will you accept his kind offer?");
                               }
                               else
                               {
                                   Conspiracy.TA_MainOutput.append(
                                   "\n The attendant who previously gave " +
                                   "\n you the coffee is gone. Beside the" +
                                   "\n counter is a sign that reads:\n" +
                                   "\n     \"Only ONE complimentary cup" +
                                   "\n      per patron please. Oh weary" +
                                   "\n      traveler - this means you!\"");
                               }
                               Conspiracy.TA_MainOutput.setCaretPosition(0);
                               //Note: break left off here on purpose
                    case '~' : TRAIN_4_TookCoffee =
                               F.FIND("DELICIOUS coffee","Coffee",TRAIN_4_TookCoffee,0);
                               F.CHOICE = "~";
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n Nothing but a few benches, an" +
                               "\n abandoned concession stand and" +
                               "\n an obscure business center.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BusinessCenter.jpg"));
                               Conspiracy.KeyPadPressing.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.TrainDoor1.play();
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_5()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_5] Coming down the escalator," +
                 "\n from the FrontierMidwest concourse" +
                 "\n above, you arrive at a boarding area" +
                 "\n to enter and exit the underground" +
                 "\n train system. An east-bound train" +
                 "\n is resting at this location. You" +
                 "\n look around and notice there are" +
                 "\n neither passengers nor an operator.\n" +
                 "\n Looking ahead you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. A long lever rests in" +
                 "\n the middle position between slots " +
                 "\n marked \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may: (G)o UP the escalator\n" +
                 "\n You may also enter the train and:" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever\n" +
                 "\n You may also explore the directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'g' : F.ROW = 4;
                               F.COLUMN = 2;
                               F.LOCATION = FrontierMidwest;
                               F.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You see the entry-way whereby" +
                               "\n passengers enter and leave" +
                               "\n trains that run between the." +
                               "\n concourses.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainsLower.jpg"));
                               Conspiracy.TrainDoor2.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you lies row upon" +
                               "\n row of people in seats laid out" +
                               "\n in neat little rows - it's a" +
                               "\n waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_2.jpg"));
                               Conspiracy.Crowd.play();
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.FootSteps.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see a public restroom" +
                               "\n facility behind some weary" +
                               "\n travelers resting in chairs" +
                               "\n in the waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_1.jpg"));
                               break;
                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_6()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_6] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of Frontier Midwest concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore in directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");


                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left several metalic" +
                               "\n panels with indicators blinking" +
                               "\n first RED and then GREEN.\n"+
                               "\n There are several locked storage" +
                               "\n compartments holding " +
                               "\n miscellaneous equipment.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, a large glass" +
                               "\n window crisscrossed with" +
                               "\n reinforcement safety wires" +
                               "\n looks out into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. The darkness" +
                               "\n outside is intermittently" +
                               "\n broken into dim flashes of" +
                               "\n silver tracks illuminated by" +
                               "\n the occasional sparks emanating" +
                               "\n from beneath you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n It has many panels and blinking" +
                               "\n lights. In the center is a large" +
                               "\n control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you at the" +
                               "\n rear wall of the car you are in." +
                               "\n A small window allows you to" +
                               "\n peer backwards into other cars" +
                               "\n on the empty train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Not as many options to" +
                                              "\n choose from here. Should" +
                                              "\n be easier for you to enter" +
                                              "\n something that makes sense," +
                                              "\n huh?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_7()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_7] You are riding the DIA" +
                 "\n underground train - midway" +
                 "\n between the Fronteir Midwest and" +
                 "\n Continental US Airways concourses.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left you peer out" +
                               "\n the window and notice a" +
                               "\n section of tunnel under"+
                               "\n construction. It projects far" +
                               "\n away from the concourse towards" +
                               "\n what appears to be 5 large" +
                               "\n underground buildings.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, the window port" +
                               "\n overlooks anbother underground" +
                               "\n section under construction..." +
                               "\n It's leading AWAY from the" +
                               "\n airport concourses!. Why?\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_4.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n A blue light is flashing and" +
                               "\n a radio hisses. In the center," +
                               "\n a large control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind through the" +
                               "\n central small window but your" +
                               "\n view is mostly obscured by the" +
                               "\n curvature of the tunnels behind" +
                               "\n you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Inside_Back2.jpg"));
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_8()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_8] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of the Continental US Airways" +
                 "\n concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore towards the:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n To your left, as you gaze out" +
                               "\n the window, you watch an " +
                               "\n auxilliary access tunnel as it" +
                               "\n trails towards a hidden nook" +
                               "\n that appears to be a secluded," +
                               "\n underground base obfuscated" +
                               "\n by a painted facade...");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_1.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n You look out the south " +
                               "\n window into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. Beneath you" +
                               "\n sparks flying from the tracks" +
                               "\n cast shadows and sillohuetes" +
                               "\n against the dark concrete" +
                               "\n walls of the train tunnel.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front is the train's" +
                               "\n directional control panel.\n" +
                               "\n It has several controls and" +
                               "\n blinking lights. In the" +
                               "\n center - a large control" +
                               "\n stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you through the" +
                               "\n small port window of the rear door" +
                               "\n of the car you are traveling in.\n" +
                               "\n Through a small window you see" +
                               "\n flickering flourescent lights in" +
                               "\n the cars behind you on the empty" +
                               "\n train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Please choose an option that" +
                                              "\n is meaningful. O.k.?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_9()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_9] Near the escalator, from" +
                 "\n the Continental US Airways" +
                 "\n concourse ascending above, you" +
                 "\n arrive at a boarding area" +
                 "\n to enter and exit the underground" +
                 "\n train system. A passenger" +
                 "\n train is resting at this location." +
                 "\n You see several passengers" +
                 "\n waiting for the next stop but" +
                 "\n no operator.\n" +
                 "\n Looking around you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. You step inside the car." +
                 "\n As you stand in front of the " +
                 "\n console you are facing WEST." +
                 "\n In front of you a long lever" +
                 "\n sits flipped in the middle position" +
                 "\n between \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (G)o UP the escalator" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore your:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'g' : F.ROW = 4;
                               F.COLUMN = 0;
                               F.LOCATION = ContinentalUSAirways;
                               F.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You admire a MAGNIFICENT" +
                               "\n Brittish Airways logo" +
                               "\n emblazoned upon the otherwise" +
                               "\n drab and utliitarian concrete" +
                               "\n slabs that wall this underground" +
                               "\n abyss like a tomb.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BrittishAirways.jpg"));
                               Conspiracy.AirportAnnounce1.play();
                               break;
                    case 's' : Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_CaribouCoffee3.jpg"));
                               Conspiracy.Crowd.play();

                               if(!TRAIN_9_TookCoffee)
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n A \"Caribou Coffee\" shop packed" +
                                   "\n full of patrons sprawls out in" +
                                   "\n front of you. Sitting down at the" +
                                   "\n bar, a lady in her early twenties" +
                                   "\n beckons to you with a subtle gesture.\n" +
                                   "\n She wears her silky blond strands" +
                                   "\n tied in a tight pony tail behind her" +
                                   "\n and silver-rimmed glasses frame her" +
                                   "\n large blue eyes. A lavender blouse" +
                                   "\n and mini skirt fall loosely across" +
                                   "\n the petite folds of her svelte figure.\n" +
                                   "\n She winks at you and hands you a cup" +
                                   "\n of Caribou Coffee. Will you accept it" +
                                   "\n from her graceful hands?");
                               }
                               else
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n You return but the lady who gave" +
                                   "\n gave you the cup of coffee at this" +
                                   "\n particular spot has gone. In fact," +
                                   "\n the shop is now completely empty.");
                               }
                               Conspiracy.TA_MainOutput.setCaretPosition(0);
                               //Note: break left off here on purpose
                    case '~' : TRAIN_9_TookCoffee =
                               F.FIND("DELICIOUS coffee","Coffee",TRAIN_9_TookCoffee,0);
                               F.CHOICE = "~";
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n Nothing but a few benches, an" +
                               "\n abandoned concession stand and" +
                               "\n an obscure business center.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BusinessCenter.jpg"));
                               Conspiracy.KeyPadPressing.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.TrainDoor1.play();
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_10()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_10] Above you looms the chrome," +
                 "\n escalator ascending to the" +
                 "\n Continental-US Airways concourse." +
                 "\n You arrive at the boarding area used" +
                 "\n to enter and exit the underground" +
                 "\n train system. An east-bound train" +
                 "\n is resting at this location. You" +
                 "\n look around and notice there are" +
                 "\n neither passengers nor an operator.\n" +
                 "\n Looking ahead you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. A long lever rests in" +
                 "\n the middle position between slots " +
                 "\n marked \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may: (G)o UP the escalator\n" +
                 "\n You may also enter the train and:" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever\n" +
                 "\n You may also explore the directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'g' : F.ROW = 4;
                               F.COLUMN = 2;
                               F.LOCATION = ContinentalUSAirways;
                               F.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You see the entry-way whereby" +
                               "\n passengers enter and leave" +
                               "\n trains that run between the." +
                               "\n concourses.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainsLower.jpg"));
                               Conspiracy.TrainDoor2.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you lies row upon" +
                               "\n row of people in seats laid out" +
                               "\n in neat little rows - it's a" +
                               "\n waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_2.jpg"));
                               Conspiracy.Crowd.play();
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.FootSteps.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see a public restroom" +
                               "\n facility behind some weary" +
                               "\n travelers resting in chairs" +
                               "\n in the waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_1.jpg"));
                               break;
                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_11()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_11] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of the Continental-US Airways" +
                 "\n concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore in directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");


                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left several metalic" +
                               "\n panels with indicators blinking" +
                               "\n first RED and then GREEN.\n"+
                               "\n There are several locked storage" +
                               "\n compartments holding " +
                               "\n miscellaneous equipment.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, a large glass" +
                               "\n window crisscrossed with" +
                               "\n reinforcement safety wires" +
                               "\n looks out into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. The darkness" +
                               "\n outside is intermittently" +
                               "\n broken into dim flashes of" +
                               "\n silver tracks illuminated by" +
                               "\n the occasional sparks emanating" +
                               "\n from beneath you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n It has many panels and blinking" +
                               "\n lights. In the center is a large" +
                               "\n control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you at the" +
                               "\n rear wall of the car you are in." +
                               "\n A small window allows you to" +
                               "\n peer backwards into other cars" +
                               "\n on the empty train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Not as many options to" +
                                              "\n choose from here. Should" +
                                              "\n be easier for you to enter" +
                                              "\n something that makes sense," +
                                              "\n huh?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_12()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_12] You are riding the DIA" +
                 "\n underground train - midway" +
                 "\n between the Continental-US" +
                 "\n Airways concourse and the" +
                 "\n Southwest concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left you peer out" +
                               "\n the window and notice a" +
                               "\n section of tunnel under"+
                               "\n construction. It projects far" +
                               "\n away from the concourse towards" +
                               "\n what appears to be 5 large" +
                               "\n underground buildings.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, the window port" +
                               "\n overlooks anbother underground" +
                               "\n section under construction..." +
                               "\n It's leading AWAY from the" +
                               "\n airport concourses!. Why?\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_4.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n A blue light is flashing and" +
                               "\n a radio hisses. In the center," +
                               "\n a large control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind through the" +
                               "\n central small window but your" +
                               "\n view is mostly obscured by the" +
                               "\n curvature of the tunnels behind" +
                               "\n you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Inside_Back2.jpg"));
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_13()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_13] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of the Southwest concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore towards the:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'f' : F.COLUMN++;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n To your left, as you gaze out" +
                               "\n the window, you watch an " +
                               "\n auxilliary access tunnel as it" +
                               "\n trails towards a hidden nook" +
                               "\n that appears to be a secluded," +
                               "\n underground base obfuscated" +
                               "\n by a painted facade...");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_1.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n You look out the south " +
                               "\n window into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. Beneath you" +
                               "\n sparks flying from the tracks" +
                               "\n cast shadows and sillohuetes" +
                               "\n against the dark concrete" +
                               "\n walls of the train tunnel.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front is the train's" +
                               "\n directional control panel.\n" +
                               "\n It has several controls and" +
                               "\n blinking lights. In the" +
                               "\n center - a large control" +
                               "\n stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you through the" +
                               "\n small port window of the rear door" +
                               "\n of the car you are traveling in.\n" +
                               "\n Through a small window you see" +
                               "\n flickering flourescent lights in" +
                               "\n the cars behind you on the empty" +
                               "\n train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Please choose an option that" +
                                              "\n is meaningful. O.k.?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_14()
       {
              if(F.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_14] You stand at the boarding" +
                 "\n area of the Southwest concourse" +
                 "\n in the underground terminal of the" +
                 "\n DIA train system. Another train" +
                 "\n passes departing west for Jeppesen" +
                 "\n Terminal. You see a few scattered" +
                 "\n passengers chatting and an engineer" +
                 "\n checking something in the distance. \n" +
                 "\n Looking around you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. You step inside the car." +
                 "\n As you stand in front of the " +
                 "\n console you are facing WEST." +
                 "\n In front of you a long lever" +
                 "\n sits flipped in the middle position" +
                 "\n between \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (G)o UP the escalator" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore your:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(F.CHOICE.charAt(0))
                 {
                    case 'g' : F.ROW = 4;
                               F.COLUMN = 0;
                               F.LOCATION = SouthWest;
                               F.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : Conspiracy.TA_MainOutput.setText(
                               "\n You press the lever forward." +
                               "\n Brakes hiss and a panel" +
                               "\n indicator marked:" +
                               "\n \"END of the line!\"" +
                               "\n lights up on the console in" +
                               "\n front of you.\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               Conspiracy.Telephone_Busy.play();
                               break;
                    case 'b' : F.COLUMN--;
                               F.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You admire a MAGNIFICENT" +
                               "\n Brittish Airways logo" +
                               "\n emblazoned upon the otherwise" +
                               "\n drab and utliitarian concrete" +
                               "\n slabs that wall this underground" +
                               "\n abyss like a tomb.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BrittishAirways.jpg"));
                               Conspiracy.AirportAnnounce1.play();
                               break;
                    case 's' : Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_CaribouCoffee3.jpg"));
                               Conspiracy.Crowd.play();

                               if(!TRAIN_14_TookCoffee)
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n A \"Caribou Coffee\" stand lies" +
                                   "\n completely empty. On a table outside" +
                                   "\n the shop sits a solitary cup" +
                                   "\n of coffee. Beneath it is a sign" +
                                   "\n marked \"Free Samples!\"");
                               }
                               else
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n You find the shop is still closed.\n" +
                                   "\n The table from which you took the" +
                                   "\n coffee is still there, but no" +
                                   "\n samples have been replenished.");
                               }
                               Conspiracy.TA_MainOutput.setCaretPosition(0);
                               //Note: break left off here on purpose
                    case '~' : TRAIN_14_TookCoffee =
                               F.FIND("DELICIOUS coffee","Coffee",TRAIN_14_TookCoffee,0);
                               F.CHOICE = "~";
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n Nothing but a few benches, an" +
                               "\n abandoned concession stand and" +
                               "\n an obscure business center.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BusinessCenter.jpg"));
                               Conspiracy.KeyPadPressing.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.TrainDoor1.play();
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function


//----------------------------------------------------------------------------

}//close Level 1 class




/*
 
Note:
A. Have new JFrame pop up and place each of these 3 links on it for
strategic clues and background INFO. If possible, embed?
1. NWO  http://www.youtube.com/watch?v=9FBlRIVBn4U&feature=related
2. Conspiracy 1  http://www.youtube.com/watch?v=JjjIy1DO0gs&feature=related
3. Conspiracy 2 (Jesse Ventura)  http://www.youtube.com/watch?v=B9EpqBf0oCY


B. Add telephone key pad as secret code, etc. To access key.

C. Add a menu toolbar.

D. 3D, animation or video?

E. MP3 support?

F. JFileChooser for LOAD and SAVE

*/