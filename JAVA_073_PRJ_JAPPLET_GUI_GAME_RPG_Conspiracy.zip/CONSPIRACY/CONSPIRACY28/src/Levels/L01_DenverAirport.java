//Conspiracy!  copyright 2010 Charles Germany  (07/01/2010)
//Note: In this example, we create and pass pointers to the JApplet's
//interface to function and level classes to allow interaction.

package Levels;

import Characters.*;
import java.io.*;
import GameFunctions.*;
import Interface.*;
import java.net.URL;
import java.util.Random;
import javax.swing.JApplet;

public class L01_DenverAirport
{
       public void TEST()
       {
         /*     ClosetPassPhrase = true;
              Closet_GotStaffKey = true;
              JT_01_FoundSuitCase = true;
              JT_01_GivenSuitCase = true;
              TRAIN_9_TalkedToLady = true;
              TRAIN_9_TookMoney = true;
              SW_10_GotBurger = true;
              FM_01_GaveGreyBurger = true;
              KeyRoom_DoorUnlocked = true;
              KeyRoom_FoundLockerKey = true;
              LockerRoom_FoundOfficeKey = true;
              PylonRoom_FoundStones = true;

              GF.PLAYER.SetShapeShift(true);
              GF.PLAYER.SetEnergy(100);
              GF.PLAYER.SetKeyLocker(true);
              GF.PLAYER.SetKeySecurityOffice(true);
              GF.PLAYER.SetKeyStaffRoom(true);
              GF.PLAYER.SetStaff(true);
              GF.PLAYER.SetGlock(true);
              GF.PLAYER.SetGlockAmmo(100);
              GF.PLAYER.SetSword(true);
              GF.PLAYER.SetKeyCard(true);
              GF.PLAYER.SetSignetRing(true);
              GF.PLAYER.SetStones(true);
              GF.PLAYER.SetCoffeePellet(20);
              //------------------------------------
                 MasonPassPhrase = true;
                 ReceivedMasonMission = true;
              //------------------------------------
              GF.LOCATION = ContinentalUSAirways;
              GF.ROW = 7;
              GF.COLUMN = 1;
              //GF.PLAYER.SetHealth(50);
              GF.PLAYER.SHOW();
           */
       }

       //Global pointer to Interface for Images and paint()
       public JApplet INTERFACE;

       //Globals
       public int INTRO_CutScene = 1;
       public int PassPhrase = 1;

       //Boolean Environment Items Found in Level 1
       public boolean GotKeyCard = false;
       public boolean CIA_Agent_Defeated = false;
       public boolean Reptillian_Defeated = false;
       public boolean MasonPassPhrase = false;
       public boolean ReceivedMasonMission = false;
       public boolean MasonGivenRing = false;
       public boolean MasonicSword = false;
       public boolean KeyRoom_FoundLockerKey = false;
       public boolean LockerRoom_FoundOfficeKey = false;
       public boolean LockerCodeEntered = false;
       public boolean ClosetPassPhrase = false;
       public boolean Closet_GotStaffKey = false;
       public static boolean PylonBattery_Charged = false;
       public static boolean PylonRoom_FoundStones = false;
       public boolean Security_FoundAmmo = false;
       public boolean StaffRoom_FoundStaff = false;
       public boolean JT_00_FoundGrenades = false;
       public boolean JT_01_FoundSuitCase = false;
       public boolean JT_01_GivenSuitCase = false;
       public boolean JT_02_CrossedSwords = false;
       public boolean JT_03_FoundJackKnife = false;
       public boolean JT_12_FoundAmmo = false;
       public boolean JT_20_FoundAmmo = false;
       public boolean GreyView = true;
       public boolean FM_01_GaveGreyBurger = false;
       public boolean FM_22_FoundKey = false;
       public boolean FM_42_FoundCoffeePellets = false;
       public boolean FM_50_FoundAmmo = false;
       public boolean FM_72_TookCoffee = false;
       public boolean FM_81_FoundGlock = false;
       public boolean CU_00_FoundAmmo = false;
       public boolean CU_41_FoundGrenade = false;
       public boolean CU_52_FoundCoffeePellets = false;
       public boolean CU_60_FoundAmmo = false;
       public boolean CU_72_TookCoffee = false;
       public boolean CU_81_FoundVest = false;
       public boolean SW_10_FoundAmmo = false;
       public boolean SW_10_GotBurger = false;
       public boolean SW_50_FoundCoffeePellets = false;
       public boolean SW_61_GateUnlocked = false;
       public boolean SW_72_TookCoffee = false;
       public boolean SW_81_FoundKeystone = false;
       public boolean TRAIN_4_TookCoffee = false;
       public boolean TRAIN_9_TookCoffee = false;
       public boolean TRAIN_9_TalkedToLady = false;
       public boolean TRAIN_9_TookMoney = false;
       public boolean TRAIN_14_TookCoffee = false;

       //Level 1 Doors and Room Access
       public boolean StaffRoom_DoorUnlocked = false;      //JT_23
       public boolean SecurityOffice_DoorUnlocked = false; //JT_20
       public boolean KeyRoom_DoorUnlocked = false;        //JT_00
       public boolean CovertOps_DoorUnlocked = false;      //JT_03
       public boolean Locker_DoorUnlocked = false;         //SW_02

       //Level 1 Traps
       public boolean SprungTrap_FM_10 = false;
       public boolean SprungTrap_FM_80 = false;
       public boolean SprungTrap_CU_02 = false;
       public boolean SprungTrap_CU_41 = false;
       public boolean SprungTrap_SW_52 = false;

       //Locations
       public static final int QUIT = 0;
       public static final int INTRO = 1;
       public static final int SecurityOffice = 2;
       public static final int StaffRoom = 3;
       public static final int CovertOpsRoom = 4;
       public static final int KeyRoom = 5;
       public static final int TRAIN = 6;
       public static final int JeppesenTerminal = 7;
       public static final int FrontierMidwest = 8;
       public static final int ContinentalUSAirways = 9;
       public static final int SouthWest = 10;
       public static final int Train_Tunnel = 11;
       public static final int OldLady = 12;
       public static final int BurgerKing = 13;
       public static final int GreyEncounter = 14;
       public static final int Locker = 15;
       public static final int Closet = 16;
       public static final int PylonRoom = 17;
       public static final int MasonEncounter = 18;
       public static final int CIAEncounter = 19;
       public static final int ReptilianEncounter = 20;

       //Location Sectors
       public static int[][] JT_SECTORS = {  {00,01,02,03},
                                          {10,11,12,13},
                                          {20,21,22,23}  };

       public static int[] TRAIN_SECTORS = { 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14 };

       public static int [][] FM_SECTORS = {  { 00, 01, 02 },
                                           { 10, 11, 12 },
                                           { 20, 21, 22 },
                                           { 30, 31, 32 },
                                           { 40, 41, 42 },
                                           { 50, 51, 52 },
                                           { 60, 61, 62 },
                                           { 70, 71, 72 },
                                           { 80, 81, 82 }  };

       public static int [][] CU_SECTORS = {  { 00, 01, 02 },
                                           { 10, 11, 12 },
                                           { 20, 21, 22 },
                                           { 30, 31, 32 },
                                           { 40, 41, 42 },
                                           { 50, 51, 52 },
                                           { 60, 61, 62 },
                                           { 70, 71, 72 },
                                           { 80, 81, 82 }  };

       public static int [][] SW_SECTORS = {  { 00, 01, 02 },
                                           { 10, 11, 12 },
                                           { 20, 21, 22 },
                                           { 30, 31, 32 },
                                           { 40, 41, 42 },
                                           { 50, 51, 52 },
                                           { 60, 61, 62 },
                                           { 70, 71, 72 },
                                           { 80, 81, 82 }  };
//------------------------------------------------------------
       //Overloaded Constructors
       public L01_DenverAirport()
       { 
           Conspiracy.TA_MainOutput.setText(
           "\n\n Building Level 1 - \n The Denver Airport.\n\n");
           INTRO_CutScene = 1;
           GF.LOCATION = INTRO;
       }

//------------------------------------------------------------

       public L01_DenverAirport(JApplet X)
       {
           Conspiracy.TA_MainOutput.setText(
           "\n\n Building Level 1 - \n The Denver Airport.\n\n");
           INTRO_CutScene = 1;
           GF.LOCATION = INTRO;
           INTERFACE = X; //pass interface pointer to global
       }

//------------------------------------------------------------
    //Helper Function. URL Allows retrieving Image from JAR archive.
    public URL Get_Location(String filename)
    {
             URL url = null;
             try { url = INTERFACE.getClass().getResource(filename); }
             catch (Exception e) { /*STUFF*/ }
             return url;
    }

//------------------------------------------------------------

public void SwitchBoard()
{
      GF.PLAYER.Display();
      
      switch(GF.LOCATION)
      {
          case QUIT : System.out.print("\n\tExiting game..."); break;
          case INTRO : Intro(); break;
          case SecurityOffice : Security_Office(); break;
          case StaffRoom : Staff_Room(); break;
          case CovertOpsRoom : CovertOps_Room(); break;
          case KeyRoom : Key_Room(); break;
          case OldLady : Old_Lady(); break;
          case BurgerKing: Burger_King(); break;
          case GreyEncounter: Grey_Encounter(); break;
          case Locker: Locker_Room(); break;
          case Closet: Closet_With_StaffRoom_Key(); break;
          case PylonRoom: Pylon_Room(); break;
          case MasonEncounter: Mason_Encounter(); break;
          case CIAEncounter: CIA_Encounter(); break;
          case ReptilianEncounter: Reptilian_Encounter(); break;

          case JeppesenTerminal : switch(JT_SECTORS[GF.ROW][GF.COLUMN])
                                  {
                                     case 00 : JT_00(); break;
                                     case 01 : JT_01(); break;
                                     case 02 : JT_02(); break;
                                     case 03 : JT_03(); break;
                                     case 10 : JT_10(); break;
                                     case 11 : JT_11(); break;
                                     case 12 : JT_12(); break;
                                     case 13 : JT_13(); break;
                                     case 20 : JT_20(); break;
                                     case 21 : JT_21(); break;
                                     case 22 : JT_22(); break;
                                     case 23 : JT_23(); break;
                                  }
                                  break;

          case FrontierMidwest : switch(FM_SECTORS[GF.ROW][GF.COLUMN])
                                 {
                                     case 00 : FM_00(); break;
                                     case 01 : FM_01(); break;
                                     case 02 : FM_02(); break;
                                     case 10 : FM_10(); break;
                                     case 11 : FM_11(); break;
                                     case 12 : FM_12(); break;
                                     case 20 : FM_20(); break;
                                     case 21 : FM_21(); break;
                                     case 22 : FM_22(); break;
                                     case 30 : FM_30(); break;
                                     case 31 : FM_31(); break;
                                     case 32 : FM_32(); break;
                                     case 40 : FM_40(); break;
                                     case 41 : FM_41(); break;
                                     case 42 : FM_42(); break;
                                     case 50 : FM_50(); break;
                                     case 51 : FM_51(); break;
                                     case 52 : FM_52(); break;
                                     case 60 : FM_60(); break;
                                     case 61 : FM_61(); break;
                                     case 62 : FM_62(); break;
                                     case 70 : FM_70(); break;
                                     case 71 : FM_71(); break;
                                     case 72 : FM_72(); break;
                                     case 80 : FM_80(); break;
                                     case 81 : FM_81(); break;
                                     case 82 : FM_82(); break;
                                 }
                                 break;

          case ContinentalUSAirways : switch(CU_SECTORS[GF.ROW][GF.COLUMN])
                                 {
                                     case 00 : CU_00(); break;
                                     case 01 : CU_01(); break;
                                     case 02 : CU_02(); break;
                                     case 10 : CU_10(); break;
                                     case 11 : CU_11(); break;
                                     case 12 : CU_12(); break;
                                     case 20 : CU_20(); break;
                                     case 21 : CU_21(); break;
                                     case 22 : CU_22(); break;
                                     case 30 : CU_30(); break;
                                     case 31 : CU_31(); break;
                                     case 32 : CU_32(); break;
                                     case 40 : CU_40(); break;
                                     case 41 : CU_41(); break;
                                     case 42 : CU_42(); break;
                                     case 50 : CU_50(); break;
                                     case 51 : CU_51(); break;
                                     case 52 : CU_52(); break;
                                     case 60 : CU_60(); break;
                                     case 61 : CU_61(); break;
                                     case 62 : CU_62(); break;
                                     case 70 : CU_70(); break;
                                     case 71 : CU_71(); break;
                                     case 72 : CU_72(); break;
                                     case 80 : CU_80(); break;
                                     case 81 : CU_81(); break;
                                     case 82 : CU_82(); break;
                                 }
                                 break;

          case SouthWest : switch(SW_SECTORS[GF.ROW][GF.COLUMN])
                                 {
                                     case 00 : SW_00(); break;
                                     case 01 : SW_01(); break;
                                     case 02 : SW_02(); break;
                                     case 10 : SW_10(); break;
                                     case 11 : SW_11(); break;
                                     case 12 : SW_12(); break;
                                     case 20 : SW_20(); break;
                                     case 21 : SW_21(); break;
                                     case 22 : SW_22(); break;
                                     case 30 : SW_30(); break;
                                     case 31 : SW_31(); break;
                                     case 32 : SW_32(); break;
                                     case 40 : SW_40(); break;
                                     case 41 : SW_41(); break;
                                     case 42 : SW_42(); break;
                                     case 50 : SW_50(); break;
                                     case 51 : SW_51(); break;
                                     case 52 : SW_52(); break;
                                     case 60 : SW_60(); break;
                                     case 61 : SW_61(); break;
                                     case 62 : SW_62(); break;
                                     case 70 : SW_70(); break;
                                     case 71 : SW_71(); break;
                                     case 72 : SW_72(); break;
                                     case 80 : SW_80(); break;
                                     case 81 : SW_81(); break;
                                     case 82 : SW_82(); break;
                                 }
                                 break;

            case TRAIN: switch(TRAIN_SECTORS[GF.COLUMN])
                        {
                           case 0 : TRAIN_0(); break;
                           case 1 : TRAIN_1(); break;
                           case 2 : TRAIN_2(); break;
                           case 3 : TRAIN_3(); break;
                           case 4 : TRAIN_4(); break;
                           case 5 : TRAIN_5(); break;
                           case 6 : TRAIN_6(); break;
                           case 7 : TRAIN_7(); break;
                           case 8 : TRAIN_8(); break;
                           case 9 : TRAIN_9(); break;
                           case 10 : TRAIN_10(); break;
                           case 11 : TRAIN_11(); break;
                           case 12 : TRAIN_12(); break;
                           case 13 : TRAIN_13(); break;
                           case 14 : TRAIN_14(); break;
                       }
                       break;

          default : Conspiracy.TA_MainOutput.setText(
                    "\n\tSomething went wrong! Navigation error.");

      }
}

//------------------------------------------------------------

       public void Intro()
       {
              switch(INTRO_CutScene)
              {
                 case 1: Conspiracy.TA_MainOutput.setText(
                         "\n Imagine...   What  if  all  those " +
                         "\n \"conspiracy theories\" you hear about" +
                         "\n on the internet were somehow true?" +
                         "\n What if?\n" +
                         "\n Sometimes the truth IS stranger than" +
                         "\n fiction, and actual historical events" +
                         "\n become more macbre and surreal than " +
                         "\n the grizzliest urban legend...\n" +
                         "\n So it was through a seemingly random " +
                         "\n series of capricious coincidences that"+
                         "\n you found yourself in seriptitiously" +
                         "\n subtle synchronicity with the weakest" +
                         "\n links that forge the chains of cause" +
                         "\n and effect in our universe.\n" +
                         "\n It was for this reason that you came" +
                         "\n to Denver International Airport," +
                         "\n leaving behind your once blissful " +
                         "\n ignorance for this abysmal certainty...\n" +
                         "\n There must be an answer, out there," +
                         "\n somewhere...\n");

                         Conspiracy.TA_MainOutput.append(
                         "\n Click \"GO\" to continue.\n\n");
                         INTRO_CutScene++;
                         break;

                  case 2: Conspiracy.TA_MainOutput.setText(
                           "\n Nothing could have prepared you for" +
                           "\n the oddities that soon became an" +
                           "\n every-day occurence. People whom" +
                           "\n you had never met before began to" +
                           "\n to show up in your life daily, " +
                           "\n seemingly in possession of" +
                           "\n knowledge of intimate personal" +
                           "\n details that you had shared with" +
                           "\n no one else. These individuals" +
                           "\n seemed to constantly hint at and" +
                           "\n make references to private" +
                           "\n converstations they should have" +
                           "\n had no knowledge of - even subtle" +
                           "\n comments you had mentioned only" +
                           "\n to yourself in times of inner" +
                           "\n reflection.\n" +
                           "\n Could they actually read your" +
                           "\n mind? Who were they? And why" +
                           "\n the constant, disturbing" +
                           "\n feelings of \"De ja vu\"? The" +
                           "\n incessant confusion? Hours of" +
                           "\n missing time? Entire days that" +
                           "\n could not be accounted for in" +
                           "\n your memory?\n");

                           Conspiracy.TA_MainOutput.append(
                           "\n Click \"GO\" to continue.\n\n");
                           INTRO_CutScene++;
                           break;

                  case 3: Conspiracy.TA_MainOutput.setText(
                          "\n What was so important about" +
                          "\n the endless trivialities of" +
                          "\n your banal and mundane" +
                          "\n existence that seemed to" +
                          "\n utterly fascinate them?" +
                          "\n Was it a joke, a ruse, a" +
                          "\n clever game played by an" +
                          "\n esoteric elite who enjoyed" +
                          "\n toying with the \"common " +
                          "\n folk\" or manipulating the" +
                          "\n masses? Who has that much" +
                          "\n time on their hands?\n" +
                          "\n Did they really have nothing" +
                          "\n better to do? Or had you" +
                          "\n stumbled onto a secret they" +
                          "\n thought you simply could not" +
                          "\n keep? If so, why hadn't they" +
                          "\n simply snuffed you out?" +
                          "\n They had an infinite number" +
                          "\n of opportunities to do so" +
                          "\n and the obvious resources" +
                          "\n necessary to make it look" +
                          "\n like an accident...\n");

                           Conspiracy.TA_MainOutput.append(
                           "\n Click \"GO\" to continue.\n\n");
                           INTRO_CutScene++;
                           break;

                  case 4: Conspiracy.TA_MainOutput.setText(
                          "\n Here you were, trying to jump" + 
                          "\n ahead and make an unexpected" +
                          "\n move. Had you truly been" +
                          "\n unpredictable, or were you" + 
                          "\n merely playing into their" +
                          "\n assortment of pre-determined" +
                          "\n possibilities and patterns" +
                          "\n for individuals pertaining" +
                          "\n to a particular profile?\n");

                           Conspiracy.TA_MainOutput.append(
                           "\n Click \"GO\" to continue.\n\n");
                           INTRO_CutScene++;
                           break;

                  case 5: Conspiracy.TA_MainOutput.setText(
                          "\n You took the \"red pill\"... " + 
                          "\n left your job, your home," +
                          "\n your family and friends" +
                          "\n - all behind you now. " + 
                          "\n Fading into the distance," +
                          "\n your past seemed more and" +
                          "\n more a fabricated existence" +
                          "\n with each passing day." +
                          "\n Sacrificing everything to" +
                          "\n search out the ultimate" +
                          "\n truth. There was nothing" +
                          "\n left for you now but to" +
                          "\n seek it...\n");

                          Conspiracy.TA_MainOutput.append(
                          "\n Click \"GO\" to continue.\n\n");
                          INTRO_CutScene++;
                          break;

                  case 6: GF.LOCATION = JeppesenTerminal;
                          GF.ROW = 2;
                          GF.COLUMN = 3;
                          Conspiracy.EnableAllButtons();
                          TEST();
                          SwitchBoard();
                          break;

              }//close switch

       }//close function

//-----------------------------------------------------------------------------

public void Security_Office()
{
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Security_Office] You find" +
           "\n yourself standing in the midst" +
           "\n of the Denver International" +
           "\n Airport's main security" +
           "\n headquarters.\n" + 
           "\n The office is surrounded by" +
           "\n cubicles, computers, phones" +
           "\n and locker facilities.\n" +
           "\n As you look around the room," +
           "\n no one seems to be \"home\"" +
           "\n today.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the office");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/SecurityOffice_Center.jpg"));
           Conspiracy.ComputerSound1.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = JeppesenTerminal;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n': Conspiracy.TA_MainOutput.setText(
                          "\n You see several computer terminals" +
                          "\n and switch devices with multiple" +
                          "\n connection LEDs blinking.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_North.jpg"));
                          Conspiracy.ComputerSound2.play();
                          //Note: break left off on purpose
               case '~' : Security_FoundAmmo =
                          GF.FIND("Super MEGA ammo clip","Glock Ammo",Security_FoundAmmo,200);
                          GF.CHOICE = "~";
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n You see colorless, gray" +
                          "\n cubicles surrounding you" +
                          "\n in all directions.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_South.jpg"));
                          break;
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n You see several computers" +
                          "\n with \"Die Hard\" the movie" +
                          "\n screen savers running in" +
                          "\n the background.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_East.jpg"));
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n Just a gray concrete wall," +
                          "\n but hastily scribbled onto" +
                          "\n one of those lockers in red," +
                          "\n permanent ink is a phrase. It" +
                          "\n reads:\n" +
                          "\n \"If you truly are AWARE" +
                          "\n  guide your actions to PREPARE," +
                          "\n  for those who truly SEE" +
                          "\n  it is the end of you and ME\"\n");
                          Conspiracy.TA_Achievements.append(
                          "\n\n Found\nSecurity\nOffice\nCode\non Wall");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/WallClue2.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Security Office option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void Staff_Room()
{
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Staff_Room] You enter into" +
           "\n a strange, oddly-shaped room" +
           "\n gleaming with an alien," +
           "\n irredescent light.\n" + 
           "\n All around you on every" +
           "\n side exists technology that" +
           "\n simply can not be of" +
           "\n this earth!\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the Staff Room");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/StaffRoom_Center.jpg"));
           Conspiracy.ElectronicHum.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = JeppesenTerminal;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n': Conspiracy.TA_MainOutput.setText(
                          "\n You see technology! Everywhere" +
                          "\n you look are servers, computers," +
                          "\n blinking lights and machines!");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/StaffRoom_North.jpg"));
                          Conspiracy.ComputerSound1.play();
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n You survey a plethora" +
                          "\n of bio-mechanical devices -" +
                          "\n all aglow with other-worldly" +
                          "\n light.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/StaffRoom_South.jpg"));
                          Conspiracy.ComputerSound2.play();
                          break;
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n Your gaze is obfuscated by" +
                          "\n a cornucopia of alien" +
                          "\n technology.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/StaffRoom_East.jpg"));
                          Conspiracy.KeyPadPressing.play();
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You spy what appears to be" +
                          "\n pillars leaning against the" +
                          "\n west wall.");
                          //Note: break left off on purpose
               case '^' : if(!StaffRoom_FoundStaff)
                          {
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/PowerStaff.jpg"));
                          }
                          else
                          {
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/StaffRoom_West.jpg"));
                          }
                          StaffRoom_FoundStaff =
                          GF.FIND("Alien Power Staff",
                          "Titanium Staff",
                          StaffRoom_FoundStaff,0);
                          GF.CHOICE = "^";
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void Closet_With_StaffRoom_Key()
{
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Closet] You find yourself" +
           "\n standing in a dark closet." +
           "\n To your north sits a blue" +
           "\n elecronic safe with a keypad.\n" +
           "\n A large, multi-line LCD" +
           "\n display and keypad are on" +
           "\n the front of the safe.");

           Conspiracy.TA_MainOutput.append(
           "\n\n You may: " +
           "\n E(x)it the Closet" +
           "\n (T)ouch the keypad" +
           "\n (O)pen the safe");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/Safe1.jpg"));
           Conspiracy.FootSteps.play();

           Conspiracy.B_ALT.setText("EXIT");
           GF.DIALOGUE = "";
        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = FrontierMidwest;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 't' : if(GF.DIALOGUE.isEmpty() && !ClosetPassPhrase)
                          {
                             Conspiracy.DisableNavigation();
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/LED_Display.jpg"));
                             Conspiracy.ComputerSound1.play();

                             Conspiracy.TA_MainOutput.setText(
                             "\n You touch the number pad " +
                             "\n and it lights up.\n" + 
                             "\n On the green LCD display" +
                             "\n some text appears. It says:\n" +
                             "\n  \"");

                             GF.IMPROBABILITY = new Random();
                             PassPhrase =
                             GF.IMPROBABILITY.nextInt(4) + 1;

                             switch(PassPhrase)
                             {
                               case 1: Conspiracy.TA_MainOutput.append(
                                       "Enter part 1 of pass phrase.\"");
                                       break;
                               case 2: Conspiracy.TA_MainOutput.append(
                                       "Enter part 2 of pass phrase.\"");
                                       break;
                               case 3: Conspiracy.TA_MainOutput.append(
                                       "Enter part 3 of pass phrase.\"");
                                       break;
                               case 4: Conspiracy.TA_MainOutput.append(
                                       "Enter part 4 of pass phrase.\"");
                                       break;
                             }

                              Conspiracy.TA_MainOutput.append(
                             "\n\n Click \"GO\" when finished.");
                          }
                          else if(!ClosetPassPhrase)
                          {
                             Conspiracy.KeyPadPressing.play();
                             GF.DIALOGUE =
                             GF.DIALOGUE.toLowerCase();

                             switch(PassPhrase)
                             {
                               case 1: if(GF.DIALOGUE.equals(
                                       "if you truly are aware"))
                                       { ClosetPassPhrase = true; }
                                       break;
                               case 2: if(GF.DIALOGUE.equals(
                                       "guide your actions to prepare"))
                                       { ClosetPassPhrase = true; }
                                       break;
                               case 3: if(GF.DIALOGUE.equals(
                                       "for those who truly see"))
                                       { ClosetPassPhrase = true; }
                                       break;
                               case 4: if(GF.DIALOGUE.equals(
                                       "it is the end of you and me"))
                                       { ClosetPassPhrase = true; }
                                       break;
                             }

                             if(ClosetPassPhrase)
                             {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You did it! You entered part " +
                                  PassPhrase +
                                  "\n of the pass phrase correctly.\n" +
                                  "\n Looks like reading the grafitti" +
                                  "\n in the security office really" +
                                  "\n paid off! Good 'ole graffiti!\n" +
                                  "\n The LCD display flashes with" +
                                  "\n the message \"ACCESS GRANTED\"" +
                                  "\n and you hear a distinct click.\n" +
                                  "\n Click \"GO\" when finished.");
                                  Conspiracy.Door_Unlock.play();
                                  GF.DIALOGUE = "";
                             }
                             else
                             {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n Your phrase was not accepted -" +
                                  "\n nothing happened.\n" +
                                  "\n Perhaps there is a pass" +
                                  "\n phrase hidden somewhere" +
                                  "\n around the airport...\n" +
                                  "\n Click \"GO\" when finished.");
                                  Conspiracy.Telephone_Busy.play();
                                  GF.CHOICE = "";
                                  Conspiracy.TF_Input.setText("");
                             }
                             Conspiracy.EnableNavigation();
                          }
                          else
                          {
                             Conspiracy.TA_MainOutput.setText(
                             "\n The LCD display over the safe" +
                             "\n reads \"PHRASE ACCEPTED\".\n" +
                             "\n It has been stored from" +
                             "\n the last time you entered it.\n" +
                             "\n Click \"GO\" when finished.");
                             Conspiracy.EnableNavigation();
                             Conspiracy.ComputerSound1.play();
                          }
                          break;
               case 'o' : if(!ClosetPassPhrase)
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n You try to open the safe," +
                              "\n but the LCD display reads:\n" +
                              "\n     \"LOCKED!\"\n" +
                              "\n An alarm buzzes. Maybe you" +
                              "\n should try entering a code?");
                              Conspiracy.Telephone_Busy.play();
                              Conspiracy.TA_MainOutput.append(
                             "\n\n Click \"GO\" to continue.");
                              break;
                          }
                          
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/Safe1.jpg"));
                          Conspiracy.TF_Input.setText("");
                          //Note: break left off on purpose
               case '^' : if(!Closet_GotStaffKey)
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n Inside the safe is a solitary" +
                              "\n key with a tag labeled as" +
                              "\n \"Staff Room\".");
                          }
                          else
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n The safe is empty, as you" +
                              "\n left it when you took the key.");
                          }

                          Closet_GotStaffKey =
                          GF.FIND("Staff Room Key",
                          "Key StaffRoom",
                          Closet_GotStaffKey,0);
                          GF.CHOICE = "^";
                          break;
               case 'n' :
               case 's' :
               case 'e' :
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a small, walk-in closet" +
                          "\n with plain concrete walls.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/Wall2.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void CovertOps_Room()
{
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [CovertOps_Room] You enter a large," +
           "\n dimly lit operational center. It" +
           "\n contains many computers, monitors" +
           "\n and displays that output the feed" +
           "\n from covert surveillance cameras" +
           "\n strategically placed throughout" +
           "\n the airport and its concourses.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may: E(x)it the Key Room");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/SecurityOffice_Center.jpg"));
           Conspiracy.ComputerSound1.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = JeppesenTerminal;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n' : Conspiracy.TA_MainOutput.setText(
                          "\n You see gray, drab, plain," +
                          "\n boring, completely uninteresting," +
                          "\n mind-numbingly regular walls.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_North.jpg"));
                          Conspiracy.FootSteps.play();
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n Against this wall a hidden" +
                          "\n mural is painted. The world" +
                          "\n emerges from a major paradigm" +
                          "\n shift or cataclysm - scathed" +
                          "\n and weary...");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/Mural_Peace.jpg"));
                          break; 
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n A shelf attached to the wall" +
                          "\n holds several notbooks and" +
                          "\n cleaning supplies.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_East.jpg"));
                          Conspiracy.FootSteps.play();
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n A small table with a coffee" +
                          "\n pot sits pushed against this" +
                          "\n western wall.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_West.jpg"));
                          Conspiracy.TF_Input.setText("");
                          //Note: break left off on purpose
               case '^' : if(!GotKeyCard)
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n On a table sits the KeyCard." +
                              "\n At last what you need to" +
                              "\n escape this chaos!");
                          }
                          else
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n The table is empty, as you" +
                              "\n left it when you took the key.");
                          }

                          GotKeyCard =
                          GF.FIND("Main Key Card",
                          "KeyCard",
                          GotKeyCard,0);
                          GF.CHOICE = "^";
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void Key_Room()
{
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Key_Room] You enter a," +
           "\n bright silver-metallic room.\n" +
           "\n In the center is a podium.\n" +
           "\n On the podium sits a large" +
           "\n brown book.\n");

           if(!KeyRoom_FoundLockerKey)
           {
               Conspiracy.TA_MainOutput.append(
               "\n To the north lies a simple table" +
               "\n with some sort of shiny metal" +
               "\n object resting on it.");
           }
           else
           {
              Conspiracy.TA_MainOutput.append(
              "\n To your north lies an empty table.");
           }

           Conspiracy.TA_MainOutput.append(
           "\n\n You may: E(x)it the Key Card Room");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/KeyCardRoom.jpg"));
           Conspiracy.FootSteps.play();

           Conspiracy.B_ALT.setText("EXIT");

        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = JeppesenTerminal;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'n' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a table against the" +
                          "\n north wall.");
                          //Note: break left off on purpose
               case '^' : if(!KeyRoom_FoundLockerKey)
                          {
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Table2_Keys.jpg"));

                              Conspiracy.TA_MainOutput.setText(
                              "\n On the table lies a set of" +
                              "\n keys marked \"Locker 13\".");
                          }
                          else
                          {
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Table1.jpg"));

                              Conspiracy.TA_MainOutput.setText(
                              "\n The table is empty, as you" +
                              "\n left it when you took the keys.");
                          }
                          KeyRoom_FoundLockerKey =
                          GF.FIND("Locker 13 Key","Key Locker",
                          KeyRoom_FoundLockerKey,0);
                          GF.CHOICE = "^";
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n Several consoles, electronic" +
                          "\n equipment and computer" +
                          "\n paraphenalia.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/SecurityOffice_South.jpg"));
                          break;
               case 'e' : Conspiracy.TA_MainOutput.setText(
                          "\n A gray concrete wall and" +
                          "\n several notebooks and" +
                          "\n cleaning supplies.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/Wall1.jpg"));
                          break;
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n On the gray concrete wall" +
                          "\n you see a passphrase incscribed:\n" +
                          "\n I guard. I serve. I seek.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/WallMasonMotto.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Staff Room option...");

           }//close switch

       }//close else
}

//-----------------------------------------------------------------------------

public void Old_Lady()
{    
       Conspiracy.B_ALT.setText("EXIT");

       if(GF.CHOICE.isEmpty() && !JT_01_FoundSuitCase)
       {
          Conspiracy.CurrentView =
          INTERFACE.getImage(Get_Location(
          "../Images/Old_Lady.jpg"));
          Conspiracy.OldLadyHello.play();

          Conspiracy.B_Look.setText("CHAT");

          Conspiracy.TA_MainOutput.setText(
          "\n [Old Lady] You walk up to the" +
          "\n old lady sitting in the train" +
          "\n terminal. She smiles at you and" +
          "\n simply says:\n" +
          "\n     \"Hello!\"");

           TRAIN_9_TalkedToLady = true;

           Conspiracy.TA_MainOutput.append(
           "\n\n You may:" + 
           "\n E(x)it back to the Train Terminal" +
           "\n (C)hat with the lady some more.");
        }

        else if(!JT_01_FoundSuitCase)
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = TRAIN;
                          GF.CHOICE = "";
                          Conspiracy.B_Look.setText("LOOK");
                          SwitchBoard();
                          break;
               case 'c': Conspiracy.OldLadyHello.play();
                         Conspiracy.TA_MainOutput.setText(
                         "\n The lady looks at you with" +
                         "\n a stately measure of kindness" +
                         "\n and wisdom and says:\n\n  \"");

                         GF.IMPROBABILITY = new Random();
                         int WhatToSay =
                         GF.IMPROBABILITY.nextInt(5) + 1;

                         switch(WhatToSay)
                         {
                           case 1: Conspiracy.TA_MainOutput.append(
                           "You're a nice young person!\"");
                           break;
                           case 2: Conspiracy.TA_MainOutput.append(
                           "Where did I leave my suitcase?\"");
                           break;
                           case 3: Conspiracy.TA_MainOutput.append(
                           "If only I could remember...\"");
                           break;
                           case 4: Conspiracy.TA_MainOutput.append(
                           "Have you seen my suitcase?\"");
                           break;
                           case 5: Conspiracy.TA_MainOutput.append(
                           "I seem to have lost my luggage.\"");
                           break;
                         }
                         break;
               default: Conspiracy.TA_MainOutput.setText(
                        "\n Not an option with the old lady...");
           }//close switch

        }//close else
       
       else if(JT_01_FoundSuitCase && !JT_01_GivenSuitCase)
       {
            if(GF.DIALOGUE.isEmpty())
            {
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/Old_Lady.jpg"));
              Conspiracy.OldLadyWheeDoggy.play();

              Conspiracy.DisableNavigation();
              Conspiracy.TA_MainOutput.setText(
              "\n The old lady looks at you " +
              "\n gleefully and exclaims:\n" +
              "\n  \"Wheee Doggy! You found" +
              "\n  my suitcase! Thank you!\"\n" +
              "\n Will you give it to her?" +
              "\n (y)es or (n)o");
            }
            else
            {
               switch(GF.DIALOGUE.charAt(0))
               {
                  case 'y' : JT_01_GivenSuitCase = true;
                             TRAIN_9_TookMoney = true;
                             GF.PLAYER.SetMoney(
                             GF.PLAYER.GetMoney() + 2.13);
                             GF.PLAYER.SHOW();
                             Conspiracy.Victory.play();
                             Conspiracy.TA_MainOutput.setText(
                             "\n You give the lady her suitcase" +
                             "\n and she turns to you and says:" +
                             "\n\n \"What a nice young person!\"\n" +        
                             "\n She pulls $2.13 out of her purse" +
                             "\n and hands it to you, saying:\n" +
                             "\n \"Thank you! Take this...\"\n" +
                             "\n Nicely done goody-two-shoes!" +
                             "\n Now click \"GO\" to move on...");
                             Conspiracy.TA_Achievements.append(
                             "\n\n Received\n $2.13!");

                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/213_Coins.jpg"));
                             Conspiracy.Cash.play();

                             Conspiracy.EnableNavigation();
                             GF.LOCATION = TRAIN;
                             GF.CHOICE = "";
                             break;
                  case 'n' : Conspiracy.TA_MainOutput.setText(
                             "\n You decide not to give her" +
                             "\n the suitcase and walk away." +
                             "\n Why? She's such a sweet old" +
                             "\n lady who needs your help...\n" +
                             "\n How do you sleep at night?\n" +
                             "\n Well, if your conscience is" +
                             "\n completely dead click \"GO\"" +
                             "\n to return from whence you came.\n" +
                             "\n Should you have a change of heart," +
                             "\n or KARMA, feel free to return and" +
                             "\n do the RIGHT thing for a change.");
                             Conspiracy.EnableNavigation();
                             GF.LOCATION = TRAIN;
                             GF.CHOICE = "";
                             break;           
                  default: Conspiracy.TA_MainOutput.setText(
                           "\n Not an option...");
                           break;
              }//close switch
            }
       }
       else
       {
           Conspiracy.TA_MainOutput.setText(
           "\n You return to the spot where " +
           "\n you originally gave the lady" +
           "\n her suitcase but she has since" +
           "\n departed.\n" +
           "\n Click \"GO\" to continue.");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/TrainBench.jpg"));
           Conspiracy.TrainEngine.play();
           
           GF.LOCATION = TRAIN;
           GF.CHOICE = "";
       }
}

//-----------------------------------------------------------------------------

public void Burger_King()
{
       Conspiracy.B_ALT.setText("EXIT");

       if(GF.CHOICE.isEmpty() && !SW_10_GotBurger)
       {
          Conspiracy.CurrentView =
          INTERFACE.getImage(Get_Location(
          "../Images/BurgerKingGuy.jpg"));
          Conspiracy.CanIHelpYou.play();

          Conspiracy.B_Look.setText("CHAT");

          Conspiracy.TA_MainOutput.setText(
          "\n [Burger King] You walk up to the" +
          "\n counter at the Burger King stand" +
          "\n at the north-west end of the " +
          "\n Southwest concourse. An attendant" +
          "\n greets you from the counter and" +
          "\n says:\n\n  \"Can I help you?\"");

           Conspiracy.TA_MainOutput.append(
           "\n\n You may:\n" +
           "\n E(x)it to the Southwest concourse" +
           "\n (P)urchase a delicious Whopper" +
           "\n (C)hat with the attendant some more.");
        }

        else if(!SW_10_GotBurger &&
                GF.PLAYER.GetMoney() < 2.13)
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = SouthWest;
                          GF.CHOICE = "";
                          Conspiracy.B_Look.setText("LOOK");
                          SwitchBoard();
                          break;
               case 'p':  Conspiracy.TA_MainOutput.setText(
                          "\n\n You don't have enough money to" +
                          "\n buy a super-delicious BK" +
                          "\n Whopper.\n" +
                          "\n If only you had 2 dollars" +
                          "\n and 13 cents...\n" +
                          "\n You may:" +
                          "\n E(x)it to the Southwest concourse.");
                          Conspiracy.NoWay.play();
                          break;
               case 'c': /* CHAT */ GF.CHOICE = "";
                         SwitchBoard();
                         break;
               default: Conspiracy.TA_MainOutput.setText(
                        "\n Not an option at Burger King!");
           }//close switch

        }//close else

       else if(!SW_10_GotBurger && GF.PLAYER.GetMoney() >= 2.13)
       {
            if(GF.DIALOGUE.isEmpty())
            {
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/BurgerKingGuy.jpg"));
              Conspiracy.Excellent.play();

              Conspiracy.DisableNavigation();
              Conspiracy.TA_MainOutput.setText(
              "\n The attendant looks at you " +
              "\n exclaiming \"EXCELLENT!\"\n" +
              "\n I can see you have the change." +
              "\n Do you wish to purchase a" +
              "\n delicious Whopper?\n" +
              "\n (y)es or (n)o");
            }
            else
            {
               switch(GF.DIALOGUE.charAt(0))
               {
                  case 'y' : SW_10_GotBurger = true;
                             Conspiracy.Victory.play();
                             Conspiracy.Cash.play();
                             Conspiracy.TA_MainOutput.setText(
                             "\n You give the attendant $2.13" +
                             "\n and he gives you a tasty" +
                             "\n flame-broiled Whopper in" +
                             "\n exchange.\n" +
                             "\n To return to the Southwest" +
                             "\n concourse, you only need to" +
                             "\n click \"GO\".");
                             Conspiracy.TA_Achievements.append(
                             "\n\n Purchased\n Whopper!");
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/Whopper.jpg"));
                             GF.PLAYER.SetMoney(
                             GF.PLAYER.GetMoney() - 2.13);
                             GF.PLAYER.SHOW();
                             Conspiracy.EnableNavigation();
                             GF.LOCATION = SouthWest;
                             GF.CHOICE = "";
                             Conspiracy.B_Look.setText("LOOK");
                             break;
                  case 'n' : Conspiracy.TA_MainOutput.setText(
                             "\n You decide not to give the" +
                             "\n attendant your hard-earned" +
                             "\n money. As a result, you walk" +
                             "\n away from the establishment" +
                             "\n without a delicious Whopper.\n" +
                             "\n Should you feel the need to" +
                             "\n acquire a sumptuous sandwhich," +
                             "\n you could always return as" +
                             "\n long as you still have the cash.\n" +
                             "\n To return to the Southwest" +
                             "\n concourse, you only need to" +
                             "\n click \"GO\".");
                             Conspiracy.EnableNavigation();
                             GF.LOCATION = SouthWest;
                             GF.CHOICE = "";
                             break;
                  default: Conspiracy.TA_MainOutput.setText(
                           "\n Not an option...");
                           break;
              }//close switch
            }
       }
       else
       {
           Conspiracy.TA_MainOutput.setText(
           "\n You return to the counter where " +
           "\n you originally met the BK" +
           "\n attendant - only to find he" +
           "\n is no longer there.\n" +
           "\n You learn that he has gone" +
           "\n on break and been replaced" +
           "\n by another attendant." +
           "\n She is wearing only BK body" +
           "\n paint and looks at you" +
           "\n maniacally and says:\n" +
           "\n   \"Are you crazy? Go away!" +
           "\n    We don't serve YOUR" +
           "\n    kind here any more!\"\n" +
           "\n Click \"GO\" to continue.");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/BurgerKingGirl.jpg"));
           Conspiracy.AreYouCrazy.play();

           GF.LOCATION = SouthWest;
           GF.CHOICE = "";
       }
}

//-----------------------------------------------------------------------------

public void Grey_Encounter()
{
       Conspiracy.B_ALT.setText("EXIT");

       if(GF.CHOICE.isEmpty() && !FM_01_GaveGreyBurger)
       {
          Conspiracy.CurrentView =
          INTERFACE.getImage(Get_Location(
          "../Images/PurpleHairGirl.jpg"));
          Conspiracy.CanIAskYouAQuestion.play();

          Conspiracy.B_Look.setText("CHAT");

          Conspiracy.TA_MainOutput.setText(
          "\n [Grey Encounter] You walk up to the" +
          "\n purple-haired girl that was motioning" +
          "\n towards you from the North wall of" +
          "\n the Frontier Midwest concourse." +
          "\n She turns her unearthly gaze towards" +
          "\n you and says:" +
          "\n\n  \"Can I ask you a question?" +
          "\n   I'm so hungry. For something" +
          "\n   to eat I might tell you" +
          "\n   who I REALLY am. Do you" +
          "\n   have any food on you?\"\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may:" +
           "\n E(x)it to Frontier Midwest concourse" +
           "\n (G)ive her something to eat" +
           "\n (C)hat with the purple-haired girl");
        }

        else if(!FM_01_GaveGreyBurger && !SW_10_GotBurger)
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = FrontierMidwest;
                          GF.CHOICE = "";
                          Conspiracy.B_Look.setText("LOOK");
                          SwitchBoard();
                          break;
               case 'g':  Conspiracy.TA_MainOutput.setText(
                          "\n You can't give the purple-" +
                          "\n haired girl anything to eat" +
                          "\n because you don't have" +
                          "\n anything to eat!\n" +
                          "\n If only there was somewhere" +
                          "\n you could BUY something to eat.\n" +
                          "\n As if to press the situation" +
                          "\n further, she looks at you with" +
                          "\n an encouraging glance and says\n" +
                          "\n    \"Don't give up now!\"\n" +
                          "\n You may:" +
                          "\n E(x)it to the Southwest concourse.");
                          Conspiracy.DontGiveUpNow.play();
                          break;
               case 'c': Conspiracy.TA_MainOutput.setText(
                         "\n You attempt to strike up a" +
                         "\n conversation with the girl." +
                         "\n In turn, she looks at you and" +
                         "\n responds with:\n\n  \"");

                         GF.IMPROBABILITY = new Random();
                         int WhatToSay =
                         GF.IMPROBABILITY.nextInt(6) + 1;

                         switch(WhatToSay)
                         {
                           case 1: Conspiracy.TA_MainOutput.append(
                                   "Do you think I look attractive?\"");
                                   Conspiracy.BlahBlah.play();
                                   break;
                           case 2: Conspiracy.TA_MainOutput.append(
                                   "I could get used to being human.\"");
                                   Conspiracy.BlahBlahBlah.play();
                                   break;
                           case 3: Conspiracy.TA_MainOutput.append(
                                   "Hair is such a wonderful appendage.\"");
                                   Conspiracy.BlahBlah.play();
                                   break;
                           case 4: Conspiracy.TA_MainOutput.append(
                                   "Endothermic AND fashionable!\"");
                                   Conspiracy.BlahBlahBlah.play();
                                   break;
                           case 5: Conspiracy.TA_MainOutput.append(
                                   "I'm sooo hungry - I feel weak.\"");
                                   Conspiracy.BlahBlah.play();
                                   break;
                           case 6: Conspiracy.TA_MainOutput.append(
                                   "Do you have anything to eat?\"");
                                   Conspiracy.BlahBlahBlah.play();
                                   break;
                         }

                         Conspiracy.TA_MainOutput.append(
                         "\n\n You may:" +
                         "\n E(x)it to Frontier Midwest concourse" +
                         "\n (G)ive her something to eat" +
                         "\n (C)hat some more with the girl");
                         break;
               default: Conspiracy.TA_MainOutput.setText(
                        "\n Not an option with the\n purple-haired girl!");
           }//close switch

        }//close else

       else if(!FM_01_GaveGreyBurger && SW_10_GotBurger)
       {
            if(GF.DIALOGUE.isEmpty())
            {
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/PurpleHairGirl.jpg"));
              Conspiracy.FemalePlease.play();

              Conspiracy.DisableNavigation();
              Conspiracy.TA_MainOutput.setText(
              "\n The strange girl looks at you " +
              "\n with a joyful expression, " + 
              "\n exclaiming \"Yippee!\"\n" +
              "\n You have something to eat!" +
              "\n May I have some of that," +
              "\n PLEASE?\n" +
              "\n (y)es or (n)o");
            }
            else
            {
               switch(GF.DIALOGUE.charAt(0))
               {
                  case 'y' : FM_01_GaveGreyBurger = true;
                             Conspiracy.FemaleGodBlessYou.play();
                             Conspiracy.TA_MainOutput.setText(
                             "\n You give the purple-haired" +
                             "\n girl your delicious Whopper" +
                             "\n and she devours it hungrily.\n" +
                             "\n She looks at you with deep" +
                             "\n gratitude and says:\n" +
                             "\n    \"God bless you! You saved" +
                             "\n     my life! I needed some" +
                             "\n     protein and amino acids" +
                             "\n     so desperately. My body" +
                             "\n     can't store chemical" +
                             "\n     energy for long. I don't" +
                             "\n     have a tangible object" +
                             "\n     to give you in repayment -" +
                             "\n     but I can teach you a skill!\"\n" +
                             "\n The purple-haired girl teaches" +
                             "\n you to ShapeShift.\n" +
                             "\n She demonstrates by changing" +
                             "\n her form and size several" +
                             "\n times. She whispers:\n" +
                             "\n    \"Bet you saw this one on TV" +
                             "\n     huh? Come back to me and" +
                             "\n     I'll show you my true" +
                             "\n     form\" (giggle).\n" +
                             "\n To return to the concourse," +
                             "\n you only need to click \"GO\".\n");
                             Conspiracy.TA_MainOutput.setCaretPosition(0);
                             Conspiracy.TA_Achievements.append(
                             "\n\n Learned\n ShapeShift!");
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/Cameron.jpg"));
                             GF.PLAYER.SetShapeShift(true);
                             GF.PLAYER.SetEnergy(10);
                             GF.PLAYER.SHOW();
                             Conspiracy.EnableNavigation();
                             GF.LOCATION = FrontierMidwest;
                             GF.CHOICE = "";
                             Conspiracy.B_Look.setText("LOOK");
                             break;
                  case 'n' : Conspiracy.TA_MainOutput.setText(
                             "\n You decide not to give the" +
                             "\n purple-haired girl your" +
                             "\n delicious Whopper. She stares" +
                             "\n at you hungrily, her gaze" +
                             "\n burning into you with the immense" +
                             "\n emptiness and vacancy inside" +
                             "\n her, gnawing away at her" +
                             "\n will to live... She turns" +
                             "\n to you and begs\n" +
                             "\n         \"Please?\"\n" +
                             "\n To return to the Southwest" +
                             "\n concourse, you only need to" +
                             "\n click \"GO\".");
                             Conspiracy.FemalePlease.play();
                             Conspiracy.EnableNavigation();
                             GF.LOCATION = FrontierMidwest;
                             GF.CHOICE = "";
                             Conspiracy.B_Look.setText("LOOK");
                             break;
                  default: Conspiracy.TA_MainOutput.setText(
                           "\n Not an option...");
                           break;
              }//close switch
            }
       }
       else
       {
           if(GreyView)
           {
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/GreyAlien.jpg"));
              Conspiracy.FemaleSurprise.play();

              Conspiracy.TA_MainOutput.setText(
              "\n   You return to the north wall" +
              "\n   where you originally met the" +
              "\n   grey. She allows you to see" +
              "\n   her in her true form briefly," +
              "\n   excitedly gushing:\n" +
              "\n      \"Surprise!\"");

              GreyView = false;
           }
           else
           {
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/PurpleHairGirl.jpg"));
              Conspiracy.FemaleHello.play();

              Conspiracy.TA_MainOutput.setText(
              "\n  You return to where you first" +
              "\n  met the grey. She has shape" +
              "\n  shifted herself into a human" +
              "\n  form again. She greets you" +
              "\n  with a friendly:\n" +
              "\n      \"Hello!\"");

              GreyView = true;
           }

           Conspiracy.TA_MainOutput.append(
           "\n\n You may:" +
           "\n (G)o back to Frontier Midwest\n concourse");

           GF.LOCATION = FrontierMidwest;
           GF.CHOICE = "";
           Conspiracy.B_Look.setText("LOOK");
       }
}

//------------------------------------------------------------

public void Locker_Room()
{
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Locker_Room] You enter a dimly" +
           "\n lit locker room. In the very" +
           "\n center to the east sits a" +
           "\n locker labeled only as \"13\".\n" +
           "\n It has a 10-digit numerical" +
           "\n keypad as well as a key-hole to" +
           "\n the right.");

           Conspiracy.TA_MainOutput.append(
           "\n\n You may: " +
           "\n E(x)it the Locker Room" +
           "\n (O)pen Locker 13" +
           "\n (P)unch in a Numerical Code");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/LockerRoom1.jpg"));
           Conspiracy.FootSteps.play();

           Conspiracy.B_ALT.setText("EXIT");
           GF.DIALOGUE = "";
        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = SouthWest;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'p' : if(GF.DIALOGUE.isEmpty() && !LockerCodeEntered)
                          {
                             Conspiracy.DisableNavigation();
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/LockerKeypad.jpg"));
                             Conspiracy.KeyPadPressing.play();

                             Conspiracy.TA_MainOutput.setText(
                             "\n You touch the number pad " +
                             "\n and it lights up. You may" +
                             "\n now enter the code.\n" +
                             "\n Click \"GO\" when finished.");
                          }
                          else if(!LockerCodeEntered)
                          {
                             if(GF.DIALOGUE .equals("12212012"))
                             {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You key in the code 12212012." +
                                  "\n December 21, 2012 - what could" +
                                  "\n it be? What's so significant" +
                                  "\n about that date?\n" +
                                  "\n The keypad flashes with the" +
                                  "\n message \"ACCESS GRANTED\" and" +
                                  "\n you hear a distinct click.\n" +
                                  "\n Click \"GO\" when finished.");
                                  LockerCodeEntered = true;
                                  Conspiracy.Door_Unlock.play();
                                  GF.DIALOGUE = "";
                             }
                             else
                             {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n Your code was not accepted -" +
                                  "\n nothing happened. Perhaps there" +
                                  "\n are clues hidden somewhere" +
                                  "\n around the airport...\n" +
                                  "\n Click \"GO\" when finished.");
                                  Conspiracy.Telephone_Busy.play();
                             }
                             Conspiracy.EnableNavigation();
                          }
                          else
                          {
                             Conspiracy.TA_MainOutput.setText(
                             "\n The display over the keypad" +
                             "\n reads \"CODE ACCEPTED\".\n" +
                             "\n It has been stored from" +
                             "\n the last time you entered it.\n" +
                             "\n Click \"GO\" when finished.");
                             Conspiracy.EnableNavigation();
                             Conspiracy.ComputerSound1.play();
                          }
                          break;
               case 'o' : if(!LockerCodeEntered)
                          {   
                              Conspiracy.TA_MainOutput.setText(
                              "\n You try to open the locker," +
                              "\n but the keypad reads:\n" +
                              "\n     \"Access Denied\"\n" +
                              "\n An alarm buzzes. Maybe you" +
                              "\n should try entering a code?");
                              Conspiracy.TA_MainOutput.append(
                             "\n\n Click \"GO\" to continue.");
                              break;
                          }   
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/LockerRoom2.jpg"));
                          Conspiracy.TF_Input.setText("");
                          //Note: break left off on purpose
               case '^' : if(!LockerRoom_FoundOfficeKey)
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n Inside the locker sits a set" +
                              "\n of keys on a ring with a tag" +
                              "\n marked \"Security Office\".");
                          }
                          else
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n The locker is empty, as you" +
                              "\n left it when you took the keys.");
                          }

                          LockerRoom_FoundOfficeKey =
                          GF.FIND("Security Office Keys",
                          "Key SecurityOffice",
                          LockerRoom_FoundOfficeKey,0);
                          GF.CHOICE = "^";
                          break;
               case 'n' :
               case 's' :
               case 'e' :
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a LOCKER room." +
                          "\n Just a simple LOCKER room.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/LockerRoom2.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Locker Room option...");

           }//close switch

       }//close else
}

//------------------------------------------------------------

public void Pylon_Room()
{

        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [Pylon_Room] You enter " +
           "\n a brightly lit room with a" +
           "\n long, slender pylon rising" +
           "\n in its center.\n");

           if(!PylonRoom_FoundStones)
           {
             Conspiracy.TA_MainOutput.append(
             "\n Within it you see glowing" +
             "\n crystals through a translucent" +
             "\n pane embedded in the pylon." +
             "\n You swing open the door to" +
             "\n its control panel, only to" +
             "\n find that the battery powering" +
             "\n its internal circuitry has" +
             "\n been completely discharged.");
           }

           if(GF.PLAYER.GetStaff() &&
              !PylonBattery_Charged && !PylonRoom_FoundStones)
           {
              Conspiracy.TA_MainOutput.append(
              "\n\n Perhaps you could recharge" +
              "\n it, if you had something" +
              "\n that could discharge" +
              "\n electrical current into it?");
           }
           else if(PylonBattery_Charged && !PylonRoom_FoundStones)
           {
              Conspiracy.TA_MainOutput.append(
              "\n\n The pylon is now glowing" +
              "\n and fully powered up. It" +
              "\n looks as though the control" +
              "\n interface will function now.");
           }

           Conspiracy.TA_MainOutput.append(
           "\n\n You may: " +
           "\n E(x)it the Pylon Room" +
           "\n (T)ake the crystals\n");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/ControlPylon.jpg"));
           Conspiracy.Transformer.play();

           Conspiracy.B_ALT.setText("EXIT");
           GF.DIALOGUE = "";
           Conspiracy.TA_MainOutput.setCaretPosition(0);
        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = SouthWest;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 't' : if(!PylonBattery_Charged && !PylonRoom_FoundStones)
                          {          
                             Conspiracy.TA_MainOutput.setText(
                             "\n You cannot open the box" +
                             "\n surrounding the pylon that" +
                             "\n contains the stones. The" +
                             "\n battery that operates the" +
                             "\n pylon is completely dead.\n" +
                             "\n Click \"GO\" when finished.");
                          }
                          else if(PylonBattery_Charged && !PylonRoom_FoundStones)
                          {
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/Stones.jpg"));

                             Conspiracy.TA_MainOutput.setText(
                             "\n You touch a button on the " +
                             "\n control pad and a panel" +
                             "\n opens, revealing the stones.");
                          }
                          else
                          {
                             Conspiracy.TA_MainOutput.setText(
                             "\n You see an empty pylon.");
                          }
                          Conspiracy.TF_Input.setText("");
                          //Note: break left off on purpose
               case '^' : 
                          if(PylonBattery_Charged)
                          {
                              PylonRoom_FoundStones =
                              GF.FIND("Crystal Power Stones",
                              "Stones",
                              PylonRoom_FoundStones,0);
                              GF.CHOICE = "^";
                          } 
                          break;
               case 'n' :
               case 's' :
               case 'e' :
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see plain gray walls" +
                          "\n encircling the pylon room.");
                          Conspiracy.CurrentView =
                          INTERFACE.getImage(Get_Location(
                          "../Images/Wall2.jpg"));
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Locker Room option...");

           }//close switch

       }//close else

}

//------------------------------------------------------------------------------

public void Mason_Encounter()
{
       if(GF.CHOICE.isEmpty())
       {
           Conspiracy.TA_MainOutput.setText(
           "\n [Mason_Encounter] You meet a man" +
           "\n standing in the middle of the" +
           "\n concourse. He is dressed in the" +
           "\n distinguished regalia of a 33rd" +
           "\n degree Freemason. Why is he here?\n " +
           "\n He looks at the stones you are" +
           "\n carrying and smiles infectiously.\n" +
           "\n He turns to you and" +
           "\n asks the question: \n" +
           "\n   \"What's the passphrase?\"");

           Conspiracy.TA_MainOutput.append(
           "\n\n You may: " +
           "\n E(x)it back to the concourse" +
           "\n (R)epeat the Passphrase" +
           "\n (C)hat with Mr. Mason");

           if(MasonPassPhrase && !MasonGivenRing)
           {
               Conspiracy.TA_MainOutput.append(
               "\n (G)ive the ring\n");
           }

           Conspiracy.TA_MainOutput.append("\n\n");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/MrMason.jpg"));
           Conspiracy.CanIAskYouAQuestion.play();

           Conspiracy.B_ALT.setText("EXIT");
           GF.DIALOGUE = "";
           Conspiracy.TA_MainOutput.setCaretPosition(0);
        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = ContinentalUSAirways;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'r' : if(GF.DIALOGUE.isEmpty() &&
                             !MasonPassPhrase &&
                             !GF.PLAYER.GetSignetRing())
                          {
                             Conspiracy.DisableNavigation();
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/Stones.jpg"));
                             Conspiracy.Excellent.play();

                             Conspiracy.TA_MainOutput.setText(
                             "\n You show him the crystal" +
                             "\n stones you recently acquired.\n" +
                             "\n He nods and looks at you" +
                             "\n expectantly.\n" +
                             "\n He focuses his eyes on yours" +
                             "\n and asks you again:\n" +
                             "\n   \"What's the passphrase?\" \n" +
                             "\n Enter your reply and click \"GO\".");
                          }
                          else if(!MasonPassPhrase &&
                          !GF.PLAYER.GetSignetRing())
                          {
                             GF.DIALOGUE =
                             GF.DIALOGUE.toLowerCase();

                             if(GF.DIALOGUE.equals(
                                "i guard. i serve. i seek."))
                             {
                                  MasonPassPhrase = true;
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You did it! You spoke the " +
                                  "\n mason's pass phrase correctly.\n" +
                                  "\n Looks like reading the walls" +
                                  "\n in the key room paid off!\n" +
                                  "\n The mason looks at you and" +
                                  "\n and says: \n" +
                                  "\n  \"Now this is your QUEST -" +
                                  "\n    a matter of honor. One" +
                                  "\n    who follows no code" +
                                  "\n    has stolen the signet" +
                                  "\n    ring of my order. You" +
                                  "\n    MUST return this ring -" +
                                  "\n    many lives depend on it.\"\n" +
                                  "\n Click \"GO\" when finished.\n\n");

                                  Conspiracy.TA_Achievements.append(
                                  "\n\n Given\n Quest");

                                  Conspiracy.Victory.play();
                                  ReceivedMasonMission = true;
                                  GF.DIALOGUE = "";
                             }
                             else
                             {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n Your phrase was not accepted -" +
                                  "\n nothing happened.\n" +
                                  "\n Perhaps there is a pass" +
                                  "\n phrase hidden somewhere" +
                                  "\n around the airport...\n" +
                                  "\n Click \"GO\" when finished.");
                                  Conspiracy.NoWay.play();
                             }
                             Conspiracy.EnableNavigation();
                          }
                          else
                          {
                             Conspiracy.TA_MainOutput.setText(
                             "\n You already gave the correct" +
                             "\n passphrase to Mr. Mason and" +
                             "\n do not need to do it again.");

                             if(!MasonGivenRing)
                             {
                                 Conspiracy.TA_MainOutput.append(
                                 "\n\n Mr. Mason turns to you and" +
                                 " says:\n" +
                                 "\n   \"The RING! Get the RING!\"");
                             }
                             else
                             {
                                Conspiracy.TA_MainOutput.append(
                                "\n Mr. Mason turns to you and says:\n" +
                                "\n   \"You have the Sword of" +
                                "\n    the Order and I have" +
                                "\n    the ring. What more do" +
                                "\n    you need? Now you must" +
                                "\n    leave this place... " +
                                "\n    Quickly! I fear for" +
                                "\n    your safety...");
                             }

                             Conspiracy.TA_MainOutput.append(
                             "\n\n Click \"GO\" when finished.");
                             Conspiracy.EnableNavigation();
                          }
                          break;
               case 'g' : if(!MasonPassPhrase && !MasonGivenRing)
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n CHEATER! How would you" +
                              "\n know to get and give the" +
                              "\n ring without FIRST speaking" +
                              "\n the passphrase? This menu" +
                              "\n option is not displayed" +
                              "\n until the passphrase has" +
                              "\n been spoken. You MUST" +
                              "\n repeat the passphrase FIRST.");
                              Conspiracy.Telephone_Busy.play();
                              Conspiracy.TA_MainOutput.append(
                             "\n\n Click \"GO\" to continue.");
                              break;
                          }

                          Conspiracy.TF_Input.setText("");
                          //Note: break left off on purpose
               case '^' : if(!MasonGivenRing)
                          {
                              Conspiracy.TA_MainOutput.setText(
                              "\n Mr. Mason turns to you and" +
                              "\n presents the magnificent" +
                              "\n Sword of the Scottish Order!\n" +
                              "\n It seems as though it has" +
                              "\n been crafted with an alien" +
                              "\n metal - the likes of which" +
                              "\n you have never seen. It has" +
                              "\n a great deal of weight for" +
                              "\n for its size and shimmers" +
                              "\n with an unearthly glow.\n" +
                              "\n A slight hum emanates from" +
                              "\n the blade, like the sound" +
                              "\n made by a tuning fork when" +
                              "\n it is struck against a" +
                              "\n solid surface.");

                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Weapons/SwordMasonic.jpg"));
                          }

                          MasonicSword =
                          GF.FIND("Masonic Sword of Omens",
                          "Sword",MasonicSword,0);
                          if(MasonicSword)
                          {
                              MasonGivenRing = true;

                              Conspiracy.TA_MainOutput.append(
                              "\n\n Note: You give the mason" +
                              "\n his order's ring back as you " +
                              "\n graciously accept the sword.");
                              
                              GF.PLAYER.SetSignetRing(false);
                              GF.PLAYER.ShowInventory();
                          }
                          GF.CHOICE = "^";
                          break;
               case 'c' : Conspiracy.TA_MainOutput.setText(
                          "CODE: Turing Engine for CHAT here.");
                          break;
               case 'n' :
               case 's' :
               case 'e' :
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see Mr. Mason!");
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Mason Encounter option...");

           }//close switch

       }//close else
}

//------------------------------------------------------------------------------

public void CIA_Encounter()
{
       if(GF.CHOICE.isEmpty())
       {
           if(!CIA_Agent_Defeated)
           {
              Conspiracy.TA_MainOutput.setText(
              "\n [CIA_Encounter] You meet a man" +
              "\n standing in the middle of the" +
              "\n concourse. He is dressed in a" +
              "\n dark suit and tie. You notice" +
              "\n he is wearin gthe order's signet " +
              "\n ring. He places his hand on his" +
              "\n weapon - concealed but obviously" +
              "\n beneath his jacket.\n" +
              "\n What will you do?");

              Conspiracy.TA_MainOutput.append(
              "\n\n You may: " +
              "\n E(x)it back to the concourse" +
              "\n (C)hat with the agent" +
              "\n (F)ight the CIA agent");
              
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/AgentSmith.jpg"));
           }
           else
           {
              Conspiracy.TA_MainOutput.setText(
              "\n [CIA_Encounter] You see only" +
              "\n the residual remains of the" +
              "\n agent you defeated dissipating" +
              "\n into the misty atmosphere.\n" +
              "\n Something metallic falls off" +
              "\n his decaying finger and rolls" +
              "\n around on the floor at your" +
              "\n feet. It's the ring!");

              GF.PLAYER.SetSignetRing(true);
              GF.PLAYER.ShowInventory();
              Conspiracy.Ring.play();
              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/Ring.jpg"));
              
              Conspiracy.TA_MainOutput.append(
              "\n\n You may: " +
              "\n E(x)it back to the concourse");

              Conspiracy.L_ConspiracyLogo.setIcon(
              new javax.swing.ImageIcon(
              getClass().getResource(
              "../Images/Opponents/AgentSmithDefeated.gif")));
           }

           Conspiracy.B_ALT.setText("EXIT");
           GF.DIALOGUE = "";
           Conspiracy.TA_MainOutput.setCaretPosition(0);
        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = ContinentalUSAirways;
                          GF.CHOICE = "";
                          Conspiracy.L_ConspiracyLogo.setIcon(
                          new javax.swing.ImageIcon(
                          getClass().getResource(
                          "../Images/StickFigure.png")));
                          SwitchBoard();
                          break;
               case 'f' : if(!CIA_Agent_Defeated)
                          {
                             CIA AgentSmith = new CIA("Agent Smith");
                             AgentSmith.SetGender("Male");
                             AgentSmith.SetSpecies("Alien");
                             AgentSmith.SetHealth(200);
                             Conspiracy.L_ConspiracyLogo.setIcon(
                             new javax.swing.ImageIcon(
                             getClass().getResource(
                             "../Images/Opponents/AgentSmith.jpg")));
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/AgentSmithCode.jpg"));
                             GF.Combat(GF.PLAYER,AgentSmith);
                             if(GF.PLAYER.GetHealth() > 0)
                             {  CIA_Agent_Defeated = true; }
                          }
                          break;
               case 'c' : Conspiracy.TA_MainOutput.setText(
                          "CODE: Turing Engine for CHAT here.");
                          break;
               case 'n' :
               case 's' :
               case 'e' :
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a CIA Agent.");
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a CIA Encounter option...");

           }//close switch

       }//close else
}

//------------------------------------------------------------------------------

public void Reptilian_Encounter()
{
       if(GF.CHOICE.isEmpty())
       {
           if(!Reptillian_Defeated)
           {
              Conspiracy.TA_MainOutput.setText(
              "\n [Reptilian_Encounter] You run" +
              "\n into a Reptillian. He seems" +
              "\n agitated and hisses at you in" +
              "\n frustration.\n" +
              "\n What will you do?");

              Conspiracy.TA_MainOutput.append(
              "\n\n You may: " +
              "\n (R)un away from the Reptillian" +
              "\n (F)ight the Reptillian");

              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/Reptillian.jpg"));
           }
           else
           {
              Conspiracy.TA_MainOutput.setText(
              "\n [Reptilian_Encounter] You see the" +
              "\n decaying carcass of the sinister" +
              "\n Reptillian you previously" +
              "\n defeated in battle.\n");

              Conspiracy.TA_MainOutput.append(
              "\n\n You may: " +
              "\n E(x)it back to the concourse");

              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/Opponents/ReptillianDead.jpg"));
           }

           Conspiracy.B_ALT.setText("EXIT");
           GF.DIALOGUE = "";
           Conspiracy.TA_MainOutput.setCaretPosition(0);
        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'x' : GF.LOCATION = SouthWest;
                          GF.CHOICE = "";
                          Conspiracy.L_ConspiracyLogo.setIcon(
                          new javax.swing.ImageIcon(
                          getClass().getResource(
                          "../Images/StickFigure.png")));
                          SwitchBoard();
                          break;
               case 'f' : if(!Reptillian_Defeated)
                          {
                             Reptilian SLYTHE = new Reptilian("SLYTHE");
                             SLYTHE.SetGender("Male");
                             SLYTHE.SetSpecies("Alien");
                             SLYTHE.SetHealth(200);
                             SLYTHE.SetMaxDamage(50); //BOSS = 2x normal damage
                             Conspiracy.L_ConspiracyLogo.setIcon(
                             new javax.swing.ImageIcon(
                             getClass().getResource(
                             "../Images/Opponents/Reptillian.jpg")));
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/Reptillian.jpg"));
                             GF.Combat(GF.PLAYER,SLYTHE);
                             if(GF.PLAYER.GetHealth() > 0)
                             {  Reptillian_Defeated = true; }
                          }
                          break;
               case 'r' : Conspiracy.TA_MainOutput.setText(
                          "\n You intelligently decide to" +
                          "\n run away...");
               
                          GF.IMPROBABILITY = new Random();
                          int PENALTY = GF.IMPROBABILITY.nextInt(50) + 1;

                          Conspiracy.TA_MainOutput.setText(
                          "\n While you are fleeing the" +
                          "\n Reptillian swings at you" +
                          "\n from behind. It catches" +
                          "\n you off guard and inflicts" +
                          "\n " + PENALTY + " points of damage.");

                          if(GF.PLAYER.GetHealth() - PENALTY > 0)
                          {
                             GF.PLAYER.SetHealth(
                             GF.PLAYER.GetHealth() - PENALTY);
                             GF.LOCATION = SouthWest;
                             Conspiracy.TA_MainOutput.append(
                             "\n\n Click \"GO\" to continue.");
                          }
                          else
                          {
                               GF.PLAYER.SetHealth(0);
                               Conspiracy.TA_MainOutput.setText(
                               "\n  You died!" +
                               "\n  GAME OVER.");

                               Conspiracy.DisableNavigation();
                               Conspiracy.B_Go.setEnabled(false);
                          }
                          GF.PLAYER.Display();
                          Conspiracy.L_ConspiracyLogo.setIcon(
                          new javax.swing.ImageIcon(
                          getClass().getResource(
                          "../Images/StickFigure.png")));
                          break;
               case 'n' :
               case 's' :
               case 'e' :
               case 'w' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a Reptillian!");
                          break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a Reptillian Encounter option...");

           }//close switch

       }//close else
}
//------------------------------------------------------------------------------
//********************** Jeppesen Terminal Sectors *****************************
//------------------------------------------------------------------------------

 public void JT_00()
 {
        if(GF.CHOICE.isEmpty())
        {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_00] You are standing in" +
            "\n the north-west corner of" +
            "\n Jeppesen Terminal. To the " +
            "\n south is the Masonic panel.\n" +
            "\n To your east a marble floor." +
            "\n To the west a disturbing" +
            "\n mural of cataclysm and death.\n" +
            "\n To your north you see a" +
            "\n black metal door.\n" +
            "\n Inset within the door to your" +
            "\n north is a smaller opening.\n");

            if(!KeyRoom_DoorUnlocked)
            {
               Conspiracy.TA_MainOutput.append(
               "\n If only you were the size of," +
               "\n like, a MOUSE, you could just" +
               "\n walk right in there.\n" +
               "\n (Yeah, like THAT could happen...)\n");
            }

            if(!KeyRoom_DoorUnlocked &&
               GF.PLAYER.GetShapeShift())
            {
               Conspiracy.TA_MainOutput.append(
               "\n You ponder what the grey taught" +
               "\n you how to do. Would it be" +
               "\n possible to shift your shape" +
               "\n into something smaller?\n");
            }

            Conspiracy.TA_MainOutput.append(
            "\n You may go: (e)ast or (s)outh\n");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/JeppesenTerminal.jpg"));
            Conspiracy.AirportAnnounce1.play();
        }

        else
        {
            switch(GF.CHOICE.charAt(0))
            {
                case 'n' : Conspiracy.TA_MainOutput.setText(
                           "\n You see a tiny door at the bottom," +
                           "\n large enough for, perhaps a mouse?" + 
                           "\n However, concerning the large door:");
                          //Note: break left off here on purpose
                case '#': if(!KeyRoom_DoorUnlocked)
                          {
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/SteelDoor3.jpg"));

                             KeyRoom_DoorUnlocked =
                             GF.Room_Access(
                             "tiny, mouse-sized",
                             KeyRoom_DoorUnlocked,
                             GF.PLAYER.GetSize() < 3);

                             if(KeyRoom_DoorUnlocked)
                             {
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/SteelOpen.jpg"));
                             }
                           }
                           else
                           {
                              GF.LOCATION = KeyRoom;
                              GF.CHOICE = "";
                              SwitchBoard();
                           }
                           GF.CHOICE = "#";
                           break;
                case 's' : GF.ROW++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : GF.COLUMN++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : Conspiracy.TA_MainOutput.setText(
                           "\n You see a grotesque mural" +
                           "\n on the wall. Children are in" +
                           "\n coffins and the world burns!");
                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Mural_CasketFire.jpg"));
                           //Note: break left off on purpose
                case '^' : JT_00_FoundGrenades =
                           GF.FIND("Fragmentation Grenades",
                           "Grenade",JT_00_FoundGrenades,2);
                           GF.CHOICE = "^";
                           break;
                case '~' : Conspiracy.TA_MainOutput.setText(
                           "\n Cheater! Cheater! " +
                           "\n Pumpkin eater...\n");
                           GF.PLAYER.CHEAT();
                           break;
                default:  Conspiracy.TA_MainOutput.setText(
                          "\n That does not apply here...");

            }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_01()
 {
        if(GF.CHOICE.isEmpty())
        {
           if(TRAIN_9_TalkedToLady && !JT_01_FoundSuitCase)
           {
              Conspiracy.TA_MainOutput.setText(
              "\n [JT_01] To your west the shiny" +
              "\n marble floor sprawls onward...\n" +
              "\n You see a pink and sequin-studded" +
              "\n suitcase - it must be the one that" +
              "\n belongs to the lady! Will you pick" +
              "\n it up? (y)es or (n)o");

              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/PinkSuitcase.jpg"));
              Conspiracy.Victory2.play();

              GF.CHOICE = "WaitForIt";
              Conspiracy.DisableNavigation();
           }
           else
           {
              Conspiracy.TA_MainOutput.setText(
              "\n [JT_01] You are standing " +
              "\n against the north wall of " +
              "\n Jeppesen Terminal. To the" +
              "\n south is the room's center.\n" +
              "\n You notice a large apocalyptic" +
              "\n mural painted against the north" +
              "\n wall.\n" +
              "\n To your west is the marble" +
              "\n floor sprawls onward...\n" +
              "\n To your north you see an other-" +
              "\n wise unremarkable wooden door.\n");

              Conspiracy.TA_MainOutput.append(
              "\n You may go:" +
              "\n (e)ast, (s)outh or (w)est");

              Conspiracy.CurrentView =
              INTERFACE.getImage(Get_Location(
              "../Images/Mural_FloorShot1.jpg"));
              Conspiracy.FootSteps.play();
           }

        }

        else if(!Conspiracy.Navigation_Lock)
        {
            switch(GF.CHOICE.charAt(0))
            {
                case 'n' : Conspiracy.TA_MainOutput.setText(
                           "\n A mural spread itself against" +
                           "\n the wall. Who is wearing the" +
                           "\n gas mask? Is it DEATH? Is it" +
                           "\n a global dictator? Is it" +
                           "\n of war or pestilence?");
                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Mural_GasMask.jpg"));
                           break;
                case 's' : GF.ROW++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : GF.COLUMN++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : GF.COLUMN--;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                default: Conspiracy.TA_MainOutput.setText(
                         "\n Just not an option...");

             }//close switch

         }//close else if

        else
        {
            switch(GF.DIALOGUE.charAt(0))
            {
                case 'y': JT_01_FoundSuitCase = true;
                          Conspiracy.TA_Achievements.append(
                          "\n Found the\n Suitcase!");
                          Conspiracy.TA_MainOutput.setText(
                          "\n\n O.k., you got the suitcase." +
                          "\n Now go find that lady!");
                          Conspiracy.Victory2.play();
                          Conspiracy.TF_Input.setText("");
                          Conspiracy.EnableNavigation();
                          break;
                case 'n': Conspiracy.TA_MainOutput.setText(
                          "\n O.k., for whatever reason" +
                          "\n you decide to leave it.");
                          Conspiracy.TF_Input.setText("");
                          Conspiracy.EnableNavigation();
                         break;
                default: Conspiracy.TA_MainOutput.setText(
                         "\n That's not an answer.");
                         break;
            }
        }

 }//close function

//-----------------------------------------------------------------------------

 public void JT_02()
 {
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_02] You are standing" +
           "\n against the north wall of" +
           "\n Jeppesen Terminal. To the" +
           "\n south is theroom's center.\n" +
           "\n To your east is the marble" +
           "\n floor that leads to the" +
           "\n north-east corner of the" +
           "\n Great Hall.\n" +
           "\n To your north you see an" +
           "\n electronic sliding door.\n" +
           "\n You notice a blade-shaped" +
           "\n indentation protruding from" +
           "\n the wall that runs " +
           "\n perpendicular to a gilded" +
           "\n sword behind it.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:\n" +
           " (e)ast, (s)outh or (w)est\n");

           if(!JT_02_CrossedSwords)
           {
              Conspiracy.TA_MainOutput.append(
              "\n You may also try to:\n" +
              " (c)ross the swords\n\n");
           }

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.Crowd.play();
           Conspiracy.TA_MainOutput.setCaretPosition(0);
        }
        else
        {
            switch(GF.CHOICE.charAt(0))
            {
                case 'n' : Conspiracy.TA_MainOutput.setText(
                           "\n You see an entrance way to some" +
                           "\n sort of security facility...");
                          //Note: break left off here on purpose
                case '#': if(!CovertOps_DoorUnlocked)
                          {
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/SteelDoor3.jpg"));

                             CovertOps_DoorUnlocked =
                             GF.Room_Access("Red Steel Blast",
                             CovertOps_DoorUnlocked,
                             JT_02_CrossedSwords);

                             if(CovertOps_DoorUnlocked)
                             {
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/SteelOpen.jpg"));
                             }
                           }
                           else
                           {
                              GF.LOCATION = CovertOpsRoom;
                              GF.CHOICE = "";
                              SwitchBoard();
                           }
                           GF.CHOICE = "#";
                           break;
                case 's' : GF.ROW++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : GF.COLUMN++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : GF.COLUMN--;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'c':  if(GF.PLAYER.GetSword())
                           {
                              Conspiracy.TA_MainOutput.setText(
                              "\n You take your sword and cross" +
                              "\n it over the blade embedded in" +
                              "\n the wall in a perpindicular" +
                              "\n fashion.\n" +
                              "\n You hear a click behind the" +
                              "\n door. Perhaps you should try" +
                              "\n the door now...");
                              JT_02_CrossedSwords = true;
                              Conspiracy.Door_Unlock.play();
                           }
                           else
                           {
                              Conspiracy.TA_MainOutput.setText(
                              "\n You do not have a sword" +
                              "\n with which to attempt a" +
                              "\n perpindicular alignment.\n" +
                              "\n Might there be one, somewhere?");
                           }
                           break;
                default: Conspiracy.TA_MainOutput.setText(
                         "\n Not an option at this time...");

             }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_03()
 {
        if(GF.CHOICE.isEmpty())
        {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_03] You are standing in the" +
            "\n north-east corner of Jeppesen" +
            "\n Terminal. Far to the south is" +
            "\n is the door in front of which" +
            "\n you first started.\n" +
            "\n Against the north wall you see" +
            "\n another disturbing mural.\n" +
            "\n To your west the shiny marble" +
            "\n floor edges along.\n" +
            "\n To your east you see a giant LETTER" +
            "\n with some sort of MESSAGE painted" +
            "\n against the concrete wall.\n");

            Conspiracy.TA_MainOutput.append(
            "\n You may go: " +
            "(w)est or (s)outh\n");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/Mural_FloorShot2.jpg"));
            Conspiracy.FootSteps.play();
        }

        else
        {
            switch(GF.CHOICE.charAt(0))
            {
                 case 'n' : Conspiracy.TA_MainOutput.setText(
                            "\n You examine the disturbing" +
                            "\n murals further. A global" +
                            "\n dictator lies dead amidst" +
                            "\n the ruins, finally peace is" +
                            "\n victorious.");
                            Conspiracy.CurrentView =
                            INTERFACE.getImage(Get_Location(
                            "../Images/Mural_Peace.jpg"));
                            break;
                 case 's' : GF.ROW++;
                            GF.CHOICE = "";
                            SwitchBoard();
                            break;
                 case 'e' : Conspiracy.TA_MainOutput.setText(
                            "\n Against the east wall a mural is" +
                            "\n painted of a letter written by a" +
                            "\n child while in a WWII Nazi" +
                            "\n concentration camp. It reads:\n" +
                            "\n       \"I was once a little child" +
                            "\n       who longed for other worlds." +
                            "\n       But I am no more a child" +
                            "\n       for I have known fear." +
                            "\n       I have learned to hate..." +
                            "\n       How trajic, then, is youth" +
                            "\n       which lives with enemies,"+
                            "\n       with gallows ropes." +
                            "\n       Yet, I still believe" +
                            "\n       I only sleep today," +
                            "\n       that I'll wake up," +
                            "\n       a child again, and" +
                            "\n       start to laugh" +
                            "\n       and play.\"");
                            Conspiracy.TA_MainOutput.setCaretPosition(0);
                            Conspiracy.CurrentView =
                            INTERFACE.getImage(Get_Location(
                            "../Images/Mural_LetterConctCamp.jpg"));
                            //Note: break left off on purpose
                 case '^' : JT_03_FoundJackKnife =
                            GF.FIND("shiny metal object","Jack Knife",
                            JT_03_FoundJackKnife,0);
                            GF.CHOICE = "^";
                            break;
                 case 'w' : GF.COLUMN--;
                            GF.CHOICE = "";
                            SwitchBoard();
                            break;
                 default: Conspiracy.TA_MainOutput.setText(
                          "\n\tNot a valid option...");

            }//close switch

      }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_10()
 {
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_10] You are standing in " +
           "\n the center of the the far west" +
           "\n wall of Jeppesen Terminal." +
           "\n There in front of you is the" +
           "\n Masonic panel. It has the" +
           "\n Masonic seal and several " +
           "\n symbols and ruins which you" +
           "\n do not recognize." +
           "\n Perhaps they are ancient" +
           "\n egyptian. The panel seems" +
           "\n hewn from something like" +
           "\n obsidian and mounted on a" +
           "\n slab of granite.\n" +
           "\n Further to the north lies" +
           "\n the north-west corner of the" +
           "\n great hall and what looks like" +
           "\n a red metal door in the " +
           "\n distance. In front of you sits" +
           "\n the Masonic panel doing nothing.\n" +
           "\n To the south lies the south-west" +
           "\n corner.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (e)ast, (n)orth or (s)outh\n");

           Conspiracy.TA_MainOutput.setCaretPosition(0);

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/Capsule_Keypad.jpg"));
           Conspiracy.AirportAnnounce2.play();
        }

        else
        {
           switch(GF.CHOICE.charAt(0))
           {
                case 'n' : GF.ROW--;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 's' : GF.ROW++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'e' : GF.COLUMN++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : Conspiracy.TA_MainOutput.setText(
                           "\n The Masonic panel captures your" +
                           "\n gaze. It is glossy and shiny but" +
                           "\n does not appear to do anything" +
                           "\n interesting at this time.\n");

                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Capstone.jpg"));

                           break;
               default: Conspiracy.TA_MainOutput.setText(
                        "\n Not a valid option...");

           }//close switch

     }//close else

 }//close

//-----------------------------------------------------------------------------

 public void JT_11()
 {
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_11]. You step into the" +
           "\n western center of \"The" +
           "\n Great Hall\".\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (n)orth, (s)outh, (e)ast, (w)est\n");

           GF.RandomCombat();

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.FootSteps.play();
        }
        else
        {
                     switch(GF.CHOICE.charAt(0))
                     {
                         case 'n' : GF.ROW--;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 's' : GF.ROW++;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 'e' : GF.COLUMN++;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 'w' : GF.COLUMN--;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         default: Conspiracy.TA_MainOutput.setText(
                                  "\n Not a valid option...");

                     }//close switch

         }//close else
               
 }//close function


//-----------------------------------------------------------------------------

 public void JT_12()
 {
        if(GF.CHOICE.isEmpty())
        {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_12]. You step into the" +
            "\n eastern center of:" +
            "\n \"The Great Hall\".\n");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/JeppesenTerminal.jpg"));
            Conspiracy.Crowd.play();

            if(!Conspiracy.Navigation_Lock)
            {
                Conspiracy.TA_MainOutput.append(
                "\n You may go:" +
                "\n (n)orth, (s)outh, (e)ast, (w)est\n");
            }

            JT_12_FoundAmmo =
            GF.FIND("unused ammo clip","Glock Ammo",JT_12_FoundAmmo,7);

        }
        else
        {
             switch(GF.CHOICE.charAt(0))
             {
                  case 'n' : GF.ROW--;
                             GF.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 's' : GF.ROW++;
                             GF.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 'e' : GF.COLUMN++;
                             GF.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 'w' : GF.COLUMN--;
                             GF.CHOICE = "";
                             SwitchBoard();
                             break;
                  default: Conspiracy.TA_MainOutput.setText(
                           "\n Not a valid option...");

                    }//close switch

        }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_13()
 {
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_13]. You are standing in the" +
           "\n center of the eastern wall of" +
           "\n Jeppesen Terminal. To your east" +
           "\n you see an escalator leading down" +
           "\n to a subterranean tunnel. A sign" +
           "\n hangs over it marked \"Train\"." +
           "\n To your north in the distance you" +
           "\n see a metalic red door. To the" +
           "\n south in the distance lies a " +
           "\n silver door.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (n)orth, (s)outh or (w)est\n" +
           "\n Or, Take the escalator to" +
           "\n (G)o underground.\n");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/TrainsUpper.jpg"));
           Conspiracy.FootSteps.play();
       }
       else
       {
           switch(GF.CHOICE.charAt(0))
           {
              case 'n' : GF.ROW--;
                         GF.CHOICE = "";
                         SwitchBoard();
                         break;
              case 's' : GF.ROW++;
                         GF.CHOICE = "";
                         SwitchBoard();
                         break;
              case 'e' : Conspiracy.TA_MainOutput.setText(
                         "\n You see a concrete wall.");
                         break;
              case 'w' : GF.COLUMN--;
                         GF.CHOICE = "";
                         SwitchBoard();
                         break;
              case 'g' : GF.ROW = 0;
                         GF.COLUMN = 0;
                         GF.LOCATION = TRAIN;
                         GF.CHOICE = "";
                         SwitchBoard();
                         break;
              default: System.out.print("\n\tNot a valid option...");

           }//close switch

      }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_20()
 {
        if(GF.CHOICE.isEmpty())
        {
           Conspiracy.TA_MainOutput.setText(
           "\n [JT_20] You are standing in the" +
           "\n south-west corner of Jeppesen" +
           "\n Terminal. Directly north is the" +
           "\n Masonic panel. To your east -" + 
           "\n a shiny marble floor tiles" +
           "\n towards the center of the" +
           "\n Great Hall.\n" +
           "\n To the west - a disturbing mural.\n" +
           "\n South of where you stand lies " +
           "\n another mural and a metal door.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go: (e)ast or (n)orth");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.AirportAnnounce3.play();

        }
        else
        {
           switch(GF.CHOICE.charAt(0))
           {
               case 'n' : GF.ROW--;
                          GF.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : Conspiracy.TA_MainOutput.setText(
                          "\n You see a wall with grotesque," +
                          "\n apocalyptic murals. In the" +
                          "\n mural children of various" +
                          "\n nationalities are laid out" +
                          "\n neatly in coffins and fire" +
                          "\n burns up the earth.\n");
                          //Note: break left off here on purpose
                case '^':  if(!SecurityOffice_DoorUnlocked)
                           {
                                Conspiracy.CurrentView =
                                INTERFACE.getImage(Get_Location(
                                "../Images/SteelDoor3.jpg"));

                                SecurityOffice_DoorUnlocked =
                                GF.Room_Access("Silver Security Office",
                                SecurityOffice_DoorUnlocked,
                                GF.PLAYER.GetKeySecurityOffice());

                                if(SecurityOffice_DoorUnlocked)
                                {
                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/SteelOpen.jpg"));
                                }
                             }
                             else
                             {
                                  GF.LOCATION = SecurityOffice;
                                  GF.CHOICE = "";
                                  SwitchBoard();
                             }
                             GF.CHOICE = "^";
                             break;
                  case 'e' : GF.COLUMN++;
                             GF.CHOICE = "";
                             SwitchBoard();
                             break;
                  case 'w' : if(JT_20_FoundAmmo)
                             {
                                Conspiracy.TA_MainOutput.setText(
                                "\n You see another apocalyptic" +
                                "\n mural. In this one, a giant" +
                                "\n soldier wears a bio-hazard" +
                                "\n suit and a gas mask. He holds" +
                                "\n a sword in his hand and he is" +
                                "\n ramming its point into the " +
                                "\n dove of peace.");
                                Conspiracy.CurrentView =
                                INTERFACE.getImage(Get_Location(
                                "../Images/Mural_GasMask.jpg"));
                                break;
                             }
                             //Note: break left off on purpose
                  case '~' : JT_20_FoundAmmo =
                             GF.FIND("unused ammo clip","Glock Ammo",JT_20_FoundAmmo,13);
                             GF.CHOICE = "~";
                             break;
              default: Conspiracy.TA_MainOutput.setText(
                       "\n Not a valid option...");

           }//close switch

       }//close else

 }//close function

//-----------------------------------------------------------------------------

 public void JT_21()
 {
        if(GF.CHOICE.isEmpty())
        {

           Conspiracy.TA_MainOutput.setText(
           "\n [JT_21] You are standing along" +
           "\n the side of the south wall of" +
           "\n Jeppesen Terminal. To the north" +
           "\n is the room's center. To your" +
           "\n east the marble floor leads to" +
           "\n the south-east corner of the" +
           "\n Great Hall. To the west is the" +
           "\n opposite corner.\n" +
           "\n To your south you see another " +
           "\n disturbing mural.\n");

           Conspiracy.TA_MainOutput.append(
           "\n You may go:" +
           "\n (e)ast, (w)est or (n)orth");

           Conspiracy.CurrentView =
           INTERFACE.getImage(Get_Location(
           "../Images/JeppesenTerminal.jpg"));
           Conspiracy.FootSteps.play();
        }

        else
        {
                     switch(GF.CHOICE.charAt(0))
                     {
                         case 'n' : GF.ROW--;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 's' : Conspiracy.TA_MainOutput.setText(
                                    "\n You see an odd, grotesque mural." +
                                    "\n Painted in this mural, colorful" +
                                    "\n mosaics depicting what might be" +
                                    "\n the artist's prediction of WWIII" +
                                    "\n and dark visions of concentration" +
                                    "\n camps tell the story of man's" +
                                    "\n cruelty upon himself and his" +
                                    "\n destructive legacy.");
                                    Conspiracy.CurrentView =
                                    INTERFACE.getImage(Get_Location(
                                    "../Images/Mural_CasketFire.jpg"));
                                    break;
                         case 'e' : GF.COLUMN++;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         case 'w' : GF.COLUMN--;
                                    GF.CHOICE = "";
                                    SwitchBoard();
                                    break;
                         default: Conspiracy.TA_MainOutput.setText(
                                  "\n Not a valid option...");

                     }//close switch

         }//close else

 }//close function


//-----------------------------------------------------------------------------

  public void JT_22()
 {
         if(GF.CHOICE.isEmpty())
         {
            Conspiracy.TA_MainOutput.setText(
            "\n [JT_22] You are standing against" +
            "\n the south wall of Jeppesen Terminal." +
            "\n To the north is the room's center." +
            "\n To your east the marble floor leads" +
            "\n to the south-east corner of this" +
            "\n Great Hall. To the west is the" +
            "\n opposite corner.\n");

            Conspiracy.TA_MainOutput.append(
            "\n South of your position a macabre," +
            "\n cataclysmic mural is painted" +
            "\n against an otherwise uninteresting" +
            "\n wall. In it lies a young girl" +
            "\n lieing within a coffin.\n" +
            "\n You may go: " +
            "\n (n)orth, (e)ast or (w)est");

            Conspiracy.CurrentView =
            INTERFACE.getImage(Get_Location(
            "../Images/JeppesenTerminal.jpg"));
            Conspiracy.Crowd.play();

        }

        else
        {
            switch(GF.CHOICE.charAt(0))
            {
                case 'n' : GF.ROW--;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 's' : Conspiracy.TA_MainOutput.setText(
                           "\n You see a colorful mosaic " +
                           "\n depicting a deceased child" +
                           "\n placed peacefully into her" +
                           "\n coffin - obviously meandering" +
                           "\n from the darkest recesses of" +
                           "\n the artist's very worst and" +
                           "\n darkest nightmares...\n");
                           Conspiracy.CurrentView =
                           INTERFACE.getImage(Get_Location(
                           "../Images/Mural_Casket.jpg"));
                           break;
                case 'e' : GF.COLUMN++;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                case 'w' : GF.COLUMN--;
                           GF.CHOICE = "";
                           SwitchBoard();
                           break;
                default: Conspiracy.TA_MainOutput.append(
                         "\n Not a valid option...");

              }//close switch

         }//close else

 }//close function

//-----------------------------------------------------------------------------

       public void JT_23()
       {
              if(GF.CHOICE.isEmpty())
              {
                   Conspiracy.TA_MainOutput.setText(
                   "\n [JT_23] You find yourself standing" +
                   "\n in the south-east corner of the" +
                   "\n Jeppensen Terminal at the Denver" +
                   "\n International Airport. You see odd," +
                   "\n colorful, apocalyptic murals running" +
                   "\n parallel to the entrance.\n" + 
                   "\n At a distance in this huge room," +
                   "\n near the center of the far western" +
                   "\n wall of the \"Great Hall\" in which" +
                   "\n you are standing is an odd stone" +
                   "\n panel, composed of something" +
                   "\n like granite and bearing the symbol" +
                   "\n and seal of one of the ancient" +
                   "\n and mysterious masonic orders.\n" +
                   "\n What is that odd image to your EAST?\n");

                   Conspiracy.TA_MainOutput.append(
                   "\n You may go: (n)orth or (w)est\n\n");

                   Conspiracy.TA_MainOutput.setCaretPosition(0);

                   Conspiracy.CurrentView =
                   INTERFACE.getImage(Get_Location(
                   "../Images/JeppesenTerminal.jpg"));
                   Conspiracy.FootSteps.play();

              }

              else
              {
                   switch(GF.CHOICE.charAt(0))
                   {
                      case 'n' : GF.ROW--;
                                 GF.CHOICE = "";
                                 SwitchBoard();
                                 break;
                      case 's' : Conspiracy.TA_MainOutput.setText(
                                 "\n You see a wall with grotesque," +
                                 "\n apocalyptic murals. In the" +
                                 "\n mural children of various" +
                                 "\n nationalities are laid out" +
                                 "\n neatly in coffins and fire" +
                                 "\n burns up the earth.\n");
                                 //Note: break left off here on purpose
                      case '^':  if(!StaffRoom_DoorUnlocked)
                                 {
                                    Conspiracy.CurrentView =
                                    INTERFACE.getImage(Get_Location(
                                    "../Images/SteelDoor3.jpg"));

                                    StaffRoom_DoorUnlocked =
                                    GF.Room_Access("Silver Metallic Staff",
                                    StaffRoom_DoorUnlocked,GF.PLAYER.GetKeyStaffRoom());
                                    
                                    if(StaffRoom_DoorUnlocked)
                                    {
                                        Conspiracy.CurrentView =
                                        INTERFACE.getImage(Get_Location(
                                        "../Images/SteelOpen.jpg"));
                                    }
                                 }
                                 else
                                 {
                                     GF.LOCATION = StaffRoom;
                                     GF.CHOICE = "";
                                     SwitchBoard();
                                 }
                                 GF.CHOICE = "^";
                                 break;
                      case 'e' : Conspiracy.TA_MainOutput.setText(
                                 "\n You see a mural covered wall..." +
                                 "\n The aliens have landed!");
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/Mural_ALien.jpg"));
                                 break;
                      case 'w' : GF.COLUMN--;
                                 GF.CHOICE = "";
                                 SwitchBoard();
                                 break;
                      default: Conspiracy.TA_MainOutput.append(
                               "\n Not a valid option...");

                  }//close switch

              }//close else

       }//close function

//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//*********************** FrontierMidwest Sectors *****************************
//------------------------------------------------------------------------------
     

       public void FM_00()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_00] You are inside the" +
               "\n Frontier Midwest concourse...\n" +
               "\n To your north another eerie mural." +
               "\n To your west is yet another...\n" );

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh and (e)ast");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket.jpg"));
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Maybe there is hope...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Peace.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_01()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_01] You are inside the" +
               "\n Frontier Midwest concourse and" +
               "\n standing beside Auntie Anne's" +
               "\n scrumptious pretzel shop.\n" +
               "\n Peering into a glass case, you" +
               "\n see row upon row of fresh-baked" +
               "\n pretzels glistening with butter" +
               "\n and salt.\n");

               if(!FM_01_GaveGreyBurger)
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n To your north, an unusual" +
                  "\n girl with shiny purple hair" +
                  "\n is beckoning you to come over" +
                  "\n to where she is standing.\n");
               }
               else
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n The girl with the purple hair" +
                  "\n winks at you from the north" +
                  "\n wall of where you are standing.\n");
               }

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (w)est (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_AuntiAnnesSoftPretzels1.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.LOCATION = GreyEncounter;
                              Conspiracy.B_Up.setText("UP");
                              Conspiracy.B_Down.setText("DOWN");
                              GF.CHOICE = "";
                              GF.DIALOGUE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_02()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_02] You are standing in the" +
               "\n north-eastern most corner of" +
               "\n the Frontier Midwest concourse...\n" +
               "\n To the north and east are yet more" +
               "\n strange images...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh or (w)est");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Uber-Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket2.jpg"));
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Like the angel of death...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_GasMask.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

       public void FM_10()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_10] Walking inside the" +
               "\n Frontier Midwest concourse" +
               "\n you stumble upon a solitary" +
               "\n Burger King - beloved bastion" +
               "\n of blessed burger benevolence!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BurgerKing.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : if(!SprungTrap_FM_10)
                              { 
                                  GF.TRAP();
                                  SprungTrap_FM_10 = true;
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n This is the spot where you" +
                                  "\n previously sprung the trip mine.");
                              }
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_11()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_11] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_12()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_12] You are against the" +
               "\n eastern wall of the Frontier" +
               "\n Midwest concourse...\n" +
               "\n The delicious smell of sizzling" +
               "\n fajitas wafts from the Cantina" +
               "\n Grill to your east...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CantinaGrill.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n You spy a bonita chicita almost" + 
                              "\n finita with her pocita Fajita!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CantinaGrill.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_20()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_20] You are inside the" +
               "\n Frontier Midwest concourse where" +
               "\n to your west is the Islamic" +
               "\n Prayer Hall and Chapel.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast \n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
               Conspiracy.AirportAnnounce2.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Feeling penitent, are we?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_21()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_21] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_22()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_22] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.LOCATION = Closet;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_30()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_30] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Gazing out the concourse window," +
                              "\n you see a jet lining up on the" + 
                              "\n Tarmac.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Window1.jpg"));
                              Conspiracy.TrainEngine.play();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_31()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_31] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_32()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_32] You are inside the" +
               "\n Frontier Midwest concourse.\n" +
               "\n To the east lies a veritable" +
               "\n oasis - Colorado Sports Bar!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ColoradoSportsBar.jpg"));
               Conspiracy.AirportAnnounce1.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Sure could use a drink...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ColoradoSportsBar.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_40()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_40] You are inside the" +
               "\n Frontier Midwest concourse.\n" +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'g' : GF.ROW = 0;
                              GF.COLUMN = 4;
                              GF.CHOICE = "";
                              GF.LOCATION = TRAIN;
                              SwitchBoard();
                              break;
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_41()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_41] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_42()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_42] You are inside the Frontier" +
               "\n Midwest concourse and standing" +
               "\n against the eastern wall. Below you" +
               "\n an escalator descends into a" +
               "\n subterranean tunnel where a sign" +
               "\n hangs marked \"Train\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n" +
               "\n Or, Take the escalator to" +
               "\n (G)o underground.\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              //Note: break left off here on purpose
                   case '^':  FM_42_FoundCoffeePellets =
                              GF.FIND("Toasted Coffee Beans",
                                     "Coffee Pellet",FM_42_FoundCoffeePellets,5);
                              GF.CHOICE = "^";
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'g' : GF.ROW = 0;
                              GF.COLUMN = 5;
                              GF.LOCATION = TRAIN;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_50()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_50] You stand within the" +
               "\n Frontier Midwest concourse.\n" +
               "\n Directly to your east you smell" +
               "\n the sweet, malty musk of micro-" +
               "\n brewed beverages from the swanky" +
               "\n Boulder Beer Tap House.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BoulderBeerTapHouse.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Ice cold... WooHoo!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BoulderBeerTapHouse.jpg"));
                              //Note: break left off here on purpose
                   case '^':  FM_50_FoundAmmo =
                              GF.FIND("unused ammo clip",
                                     "Glock Ammo",FM_50_FoundAmmo,25);
                              GF.CHOICE = "^";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_51()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_51] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_52()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_52] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void FM_60()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_60] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_61()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_61] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_62()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_62] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_70()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_70] You are inside the" +
               "\n Frontier Midwest concourse" +
               "\n where, best of all possible" +
               "\n blessings, a Ben and Jerry's" +
               "\n presides over the eastern" +
               "\n wall of the concourse.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys1.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Brain freeze!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_71()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_71] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_72()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_72] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee4.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : if(!FM_72_TookCoffee)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n A young, pale \"Caribou Coffee\"" +
                                 "\n associate with shoulder-length" +
                                 "\n auburn-crimson hair and large, deep," +
                                 "\n inquisitive green eyes directs her" +
                                 "\n captivating gaze towards your" +
                                 "\n direction.\n" +
                                 "\n The moment she realizes she has" +
                                 "\n caught your eye she walks over" +
                                 "\n to your right. Clad in a red blouse" +
                                 "\n and a green, ankle-length skirt - she" +
                                 "\n permeates the surrounding atmosphere" +
                                 "\n with the faint anticipation of" +
                                 "\n some seasonal holiday that eludes" +
                                 "\n your memory at present.\n" +
                                 "\n She looks piercingly into your eyes" +
                                 "\n and says:\n" +
                                 "\n   \"I made this. It is very good." +
                                 "\n   Would you like some, stranger?\"\n" +
                                 "\n Will you accept her gracious offer?");

                                 Conspiracy.TA_MainOutput.setCaretPosition(0);

                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/CoffeeGirl3.jpg"));

                                 Conspiracy.FemaleGodBlessYou.play();
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You have returned to where you" +
                                  "\n met the hauntingly beautiful" +
                                  "\n red-haired attendant.\n" +
                                  "\n However, the shop is currently" +
                                  "\n closed down and the lights are" +
                                  "\n off on all its signs.");

                                  Conspiracy.CurrentView =
                                  INTERFACE.getImage(Get_Location(
                                  "../Images/Shop_CaribouCoffee3.jpg"));

                                  Conspiracy.Crowd.play();

                                  break;
                              }
                              //Note: break left off here on purpose
                    case '~' : FM_72_TookCoffee =
                               GF.FIND("DELICIOUS coffee","Coffee",FM_72_TookCoffee,0);
                               GF.CHOICE = "~";
                               break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void FM_80()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_80] You are inside the" +
               "\n Frontier Midwest concourse" +
               "\n and completely enveloped in" +
               "\n the Ben and Jerry's goodness" +
               "\n consuming the eastern wall.\n" +
               "\n In contrast to these icy" +
               "\n offerings, the fires of HELL" +
               "\n burn mercilessly to the south.");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (n)orth or (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys2.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : if(!SprungTrap_FM_80)
                              {
                                  GF.TRAP();
                                  SprungTrap_FM_80 = true;
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n This is the spot where you" +
                                  "\n previously sprung the trip mine.");
                              }
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A dark and disturbing mural.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_CasketFire2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_81()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_81] You are inside the" +
               "\n Frontier Midwest concourse.\n" +
               "\n Against the south wall is yet" +
               "\n another mosaic nightmare...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_FloorShot1.jpg"));
                              //Note: break left off on purpose
                   case '~' : FM_81_FoundGlock =
                              GF.FIND("Black Metal-Plastic Gun","Glock",FM_81_FoundGlock,0);
                              GF.CHOICE = "~";
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void FM_82()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [FM_82] You are inside the" +
               "\n Frontier Midwest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee1.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Smells like heaven...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//****************** ContinentalUSAirways Terminal Sectors *********************
//------------------------------------------------------------------------------

       public void CU_00()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_00] You are inside the" +
               "\n Continental US Airways concourse...\n" +
               "\n To your north another eerie mural." +
               "\n To your west is yet another...\n" );

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh and (e)ast");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket.jpg"));
                             //Note: break left off here on purpose
                   case '^':  CU_00_FoundAmmo =
                              GF.FIND("unused ammo clip",
                                     "Glock Ammo",CU_00_FoundAmmo,25);
                              GF.CHOICE = "^";
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Maybe there is hope...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Peace.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_01()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_01] You are inside the" +
               "\n Continental US Airways concourse and" +
               "\n standing beside Auntie Anne's" +
               "\n scrumptious pretzel shop.\n" +
               "\n Peering into a glass case, you" +
               "\n see row upon row of fresh-baked" +
               "\n pretzels glistening with butter" +
               "\n and salt.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (w)est (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_AuntiAnnesSoftPretzels1.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Wow! Those pretzels smell great!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_AuntiAnnesSoftPretzels2.jpg"));
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_02()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_02] You are standing in the" +
               "\n north-eastern most corner of" +
               "\n the Continental US Airways concourse...\n" +
               "\n To the north and east are yet more" +
               "\n strange images...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh or (w)est");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Uber-Creepy!\n");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket2.jpg"));
                              if(!SprungTrap_CU_02)
                              {
                                  GF.TRAP();
                                  SprungTrap_CU_02 = true;
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.append(
                                  "\n This is the spot where you" +
                                  "\n previously sprung the trip mine.");
                              }
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Like the angel of death...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_GasMask.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

       public void CU_10()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_10] Walking inside the" +
               "\n Continental US Airways concourse" +
               "\n you stumble upon a solitary" +
               "\n Burger King - beloved bastion" +
               "\n of blessed burger benevolence!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BurgerKing.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Mr. BK king sits here...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BurgerKing.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_11()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_11] You are inside the" +
               "\n Continental US Airways concourse...\n");

               if(GF.PLAYER.GetStones())
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n You see a man dressed in masonic" +
                  "\n regalia motioning to you from" +
                  "\n the center of the northern end" +
                  "\n of the concourse.\n");
               }

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               if(GF.PLAYER.GetStones())
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n You may also:" +
                  "\n (A)pproach the mason");
               }

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'a' : if(GF.PLAYER.GetStones())
                              {
                                 GF.LOCATION = MasonEncounter;
                                 GF.CHOICE = "";
                                 SwitchBoard();
                                 break;
                              }
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_12()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_12] You are against the" +
               "\n eastern wall of the Frontier" +
               "\n Midwest concourse...\n" +
               "\n The dilicous smell of sizzling" +
               "\n fajitas wafts from the Cantina" +
               "\n Grill to your east...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CantinaGrill.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n You spy a bonita chicita almost" +
                              "\n finita with her pocita Fajita!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CantinaGrill.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_20()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_20] You are inside the" +
               "\n Continental US Airways concourse" +
               "\n where meandering to your west is" +
               "\n the Islamic Prayer Hall and Chapel.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast \n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
               Conspiracy.AirportAnnounce2.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Feeling penitent, are we?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_21()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_21] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_22()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_22] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_30()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_30] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n You look out the concourse window," +
                              "\n and see a jet parking next to a" +
                              "\n boarding extension module.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Window1.jpg"));
                              Conspiracy.TrainEngine.play();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_31()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_31] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_32()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_32] You are inside the" +
               "\n Continental US Airways concourse.\n" +
               "\n To the east lies a veritable" +
               "\n oasis - Colorado Sports Bar!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ColoradoSportsBar.jpg"));
               Conspiracy.AirportAnnounce1.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Sure could use a drink...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ColoradoSportsBar.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_40()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_40] You are inside the" +
               "\n Continental US Airways concourse." +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'g' : GF.ROW = 0;
                              GF.COLUMN = 9;
                              GF.CHOICE = "";
                              GF.LOCATION = TRAIN;
                              SwitchBoard();
                              break;
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_41()
       {
           if(GF.CHOICE.isEmpty())
           {
               if(!SprungTrap_CU_41)
               {
                   GF.TRAP();
                   SprungTrap_CU_41 = true;
               }
               else
               {
                   Conspiracy.TA_MainOutput.setText(
                   "\n This is the spot where you" +
                   "\n previously sprung the trip mine.\n");
               }

               Conspiracy.TA_MainOutput.append(
               "\n [CU_41] You are inside the" +
               "\n Continental US Airways concourse...\n");

               if(!Conspiracy.Navigation_Lock)
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n You may go:" +
                  "\n (n)orth, (s)outh, (e)ast, (w)est");
               }

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();

               CU_41_FoundGrenade = GF.FIND("Fragmentation Grenade",
                                 "Grenade",CU_41_FoundGrenade,1);
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_42()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_42] You are inside the" +
               "\n Continental US Airways concourse.\n" +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                  case 'g' : GF.ROW = 0;
                             GF.COLUMN = 10;
                             GF.CHOICE = "";
                             GF.LOCATION = TRAIN;
                             SwitchBoard();
                             break;
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_50()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_50] You stand within the" +
               "\n Continental US Airways concourse.\n" +
               "\n On the east side the Boulder" +
               "\n Beer Tap House is open for" +
               "\n business!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BoulderBeerTapHouse.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Ice cold... WooHoo!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BoulderBeerTapHouse.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_51()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_51] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_52()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_52] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              //Note: break left off here on purpose
                   case '^':  CU_52_FoundCoffeePellets =
                              GF.FIND("Toasted Coffee Beans",
                                     "Coffee Pellet",CU_52_FoundCoffeePellets,10);
                              GF.CHOICE = "^";
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void CU_60()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_60] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Peering at a gray concrete wall," +
                              "\n you notice some grafitti etched" +
                              "\n into the paint. It reads:\n" +
                              "\n    \"December 21st, 2012" +
                              "\n     Doom is NEAR!" +
                              "\n     Go under---\n" + 
                              "\n The text trails off, unfinished.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/WallClue1.jpg"));
                              //Note: break left off here on purpose
                   case '^':  CU_60_FoundAmmo =
                              GF.FIND("unused ammo clip",
                                     "Glock Ammo",CU_60_FoundAmmo,25);
                              GF.CHOICE = "^";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_61()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_61] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_62()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_62] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_70()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_70] You are inside the" +
               "\n Continental US Airways concourse" +
               "\n where, best of all possible" +
               "\n blessings, a Ben and Jerry's" +
               "\n presides over the eastern" +
               "\n wall of the concourse.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys1.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Brain freeze!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_71()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));

               Conspiracy.TA_MainOutput.setText(
               "\n [CU_71] You are inside the" +
               "\n Continental US Airways concourse...\n");

               if(ReceivedMasonMission)
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n You see a sharply-dressed agent," +
                  "\n most probably CIA, dressed in a" +
                  "\n dark suit and tie.\n");
               }

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               if(ReceivedMasonMission && !CIA_Agent_Defeated)
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n You may also:" +
                  "\n (A)pproach the CIA Agent");
               }
               else if(ReceivedMasonMission && CIA_Agent_Defeated)
               {
                  Conspiracy.TA_MainOutput.append(
                  "\n The residual remains of the" +
                  "\n agent you defeated have" +
                  "\n completely dissipated into" +
                  "\n the surrounding atmosphere.");
               }

               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'a' : if(ReceivedMasonMission && !CIA_Agent_Defeated)
                              {
                                 GF.LOCATION = CIAEncounter;
                                 GF.CHOICE = "";
                                 SwitchBoard();
                                 break;
                              }
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_72()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_72] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee4.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : if(!CU_72_TookCoffee)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n An elderly \"Caribou Coffee\"" +
                                 "\n clerk with silver hair and pale," +
                                 "\n skin waves to you. You can't be" +
                                 "\n sure, but for a split second you" +
                                 "\n think you notice something" +
                                 "\n reptillian about his eyes.\n" +
                                 "\n As you glance away and then look" +
                                 "\n back his eyes seem to shift into" +
                                 "\n a more convincingly human projection." +
                                 "\n He cracks a smile in a serpentine" +
                                 "\n fashion and asks seripticiously:\n" +
                                  "\n   \"Would you like a cup of" +
                                  "\n   coffee? It is on the house," +
                                  "\n   as you say...\"\n" +
                                  "\n Will you accept his generosity?");

                                 Conspiracy.TA_MainOutput.setCaretPosition(0);

                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/Caribou_Coffee_Man.jpg"));

                                 Conspiracy.CanIHelpYou.play();
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n Here you are again where once" +
                                  "\n before you met that creepy, " +
                                  "\n reptillian Caribou attendant.\n" +
                                  "\n Even so, he offered you FREE" +
                                  "\n coffee, so he couldn't be all" +
                                  "\n that bad...");

                                  Conspiracy.CurrentView =
                                  INTERFACE.getImage(Get_Location(
                                  "../Images/Shop_CaribouCoffee3.jpg"));

                                  Conspiracy.Crowd.play();
                                  break;
                              } 
                              //Note: break left off here on purpose
                    case '~' : CU_72_TookCoffee =
                               GF.FIND("DELICIOUS coffee","Coffee",CU_72_TookCoffee,0);
                               GF.CHOICE = "~";
                               break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void CU_80()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_80] You are inside the" +
               "\n Continental US Airways concourse" +
               "\n and completely enveloped in" +
               "\n the Ben and Jerry's goodness" +
               "\n consuming the eastern wall.\n" +
               "\n In contrast to these icy" +
               "\n offerings, the fires of HELL" +
               "\n burn mercilessly to the south.");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (n)orth or (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys2.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A dark and disturbing mural.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_CasketFire2.jpg"));
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n How many delicous flavors?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys1.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_81()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_81] You are inside the" +
               "\n Continental US Airways concourse.\n" +
               "\n Against the south wall is yet" +
               "\n another mosaic nightmare...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_FloorShot1.jpg"));
                              //Note: break left off on purpose
                   case '~' : CU_81_FoundVest =
                              GF.FIND("FBI Kevlar Vest","Vest",CU_81_FoundVest,0);
                              GF.CHOICE = "~";
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void CU_82()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [CU_82] You are inside the" +
               "\n Continental US Airways concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee1.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Smells like heaven...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CaribouCoffee3.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//*********************** Southwest Terminal Sectors ***************************
//------------------------------------------------------------------------------


       public void SW_00()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_00] You are inside the" +
               "\n SouthWest concourse...\n" +
               "\n To your north another eerie mural." +
               "\n To your west is yet another...\n" );

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh and (e)ast");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket.jpg"));
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Maybe there is hope...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Peace.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_01()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_01] You are inside the" +
               "\n SouthWest concourse and" +
               "\n standing beside Auntie Anne's" +
               "\n scrumptious pretzel shop.\n" +
               "\n Peering into a glass case, you" +
               "\n see row upon row of fresh-baked" +
               "\n pretzels glistening with butter" +
               "\n and salt.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (w)est (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_AuntiAnnesSoftPretzels1.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Wow! Those pretzels smell great!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_AuntiAnnesSoftPretzels2.jpg"));
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_02()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_02] You are standing in the" +
               "\n north-eastern most corner of" +
               "\n the SouthWest concourse...\n" +
               "\n To the north are yet more" +
               "\n strange images...\n" +
               "\n To your east is a metallic door" +
               "\n with the sign \"LOCKER ROOM\"" +
               "\n in bold print upon its surface.");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (s)outh or (w)est");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : Conspiracy.TA_MainOutput.setText(
                              "\n Uber-Creepy!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_Casket2.jpg"));
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : if(GF.PLAYER.GetKeyLocker())
                              {
                              GF.LOCATION = Locker;
                              GF.CHOICE = "";
                              SwitchBoard();
                              }
                              else
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n You cannot open the door to" +
                                 "\n the locker room. It is locked!");
                              }
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//----------------------------------------------------------------------------

       public void SW_10()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_10] Walking inside the" +
               "\n SouthWest concourse" +
               "\n you stumble upon a solitary" +
               "\n Burger King - beloved bastion" +
               "\n of blessed burger benevolence!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BurgerKing.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w': GF.LOCATION = BurgerKing;
                             Conspiracy.B_Up.setText("UP");
                             Conspiracy.B_Down.setText("DOWN");
                             GF.CHOICE = "";
                             GF.DIALOGUE = "";
                             SwitchBoard();
                             break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_11()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_11] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_12()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_12] You are against the" +
               "\n eastern wall of the Frontier" +
               "\n Midwest concourse...\n" +
               "\n The dilicous smell of sizzling" +
               "\n fajitas wafts from the Cantina" +
               "\n Grill to your east...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CantinaGrill.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n You spy a bonita chicita almost" +
                              "\n finita with her pocita Fajita!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_CantinaGrill.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_20()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_20] You are inside the" +
               "\n SouthWest concourse where" +
               "\n to your west is the Islamic" +
               "\n Prayer Hall and Chapel.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast \n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
               Conspiracy.AirportAnnounce2.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Feeling penitent, are we?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ChapelIslamicPrayerHall.jpg"));
                              //Note: break left off on purpose
                   case '~' : SW_10_FoundAmmo  =
                              GF.FIND(
                              "un-used ammo clip","Glock Ammo",
                              SW_10_FoundAmmo ,15);
                              GF.CHOICE = "~";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_21()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_21] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_22()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_22] You are inside the" +
               "\n SouthWest concourse...\n" +
               "\n To your east is a small room" +
               "\n with an odd electronic pylon" +
               "\n in the center.");

               Conspiracy.TA_MainOutput.append(
               "\n\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.LOCATION = PylonRoom;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_30()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_30] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n You see a jet departing the" +
                              "\n concourse and preparing to taxi" +
                              "\n down the runway.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Window1.jpg"));
                              Conspiracy.TrainEngine.play();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_31()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_31] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               GF.RandomCombat();

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_32()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_32] You are inside the" +
               "\n SouthWest concourse.\n" +
               "\n To the east lies a veritable" +
               "\n oasis - Colorado Sports Bar!\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_ColoradoSportsBar.jpg"));
               Conspiracy.AirportAnnounce1.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n Sure could use a drink...");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_ColoradoSportsBar.jpg"));
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_40()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_40] You are inside the" +
               "\n SouthWest concourse.\n" +
               "\n There is an escalator here" +
               "\n descending into underground" +
               "\n levels with a sign hanging" +
               "\n  over it marked \"TRAIN\".\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may also:" +
               "\n (G)o DOWN the escalator\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/TrainsUpper.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'g' : GF.ROW = 0;
                              GF.COLUMN = 14;
                              GF.CHOICE = "";
                              GF.LOCATION = TRAIN;
                              SwitchBoard();
                              break;
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_41()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_41] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_42()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_42] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_50()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_50] You stand within the" +
               "\n SouthWest concourse." +
               "\n On the east side the Boulder" +
               "\n Beer Tap House is open for" +
               "\n business.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BoulderBeerTapHouse.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Ice cold... WooHoo!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BoulderBeerTapHouse.jpg"));
                              //Note: break left off here on purpose
                   case '^':  SW_50_FoundCoffeePellets =
                              GF.FIND("Toasted Coffee Beans",
                                     "Coffee Pellet",SW_50_FoundCoffeePellets,10);
                              GF.CHOICE = "^";
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_51()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_51] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_52()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_52] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : if(!SprungTrap_SW_52)
                              {
                                  GF.TRAP();
                                  SprungTrap_SW_52 = true;
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.append(
                                  "\n This is the spot where you" +
                                  "\n previously sprung the trip mine.");
                              }
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void SW_60()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_60] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A security gate blocks your" +
                              "\n path. To your east you see" +
                              "\n an entrance way through the." +
                              "\n gate.");
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_61()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_61] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.AirportAnnounce3.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : if(!GF.PLAYER.GetKeyCard())
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n The gate is locked. To the" +
                                  "\n south you notice a control" +
                                  "\n box that accepts key cards.\n" +
                                  "\n If only you had a key card...");
                                  break;
                              }
                              //Note: break left off here on purpose
                case '#': if(!SW_61_GateUnlocked)
                          {
                             Conspiracy.CurrentView =
                             INTERFACE.getImage(Get_Location(
                             "../Images/SteelDoor3.jpg"));

                             SW_61_GateUnlocked =
                             GF.Room_Access(
                             "Steel Security Gate",
                             SW_61_GateUnlocked,
                             GF.PLAYER.GetKeyCard());

                             if(SW_61_GateUnlocked)
                             {
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/SteelOpen.jpg"));
                             }

                             GF.CHOICE = "#";
                           }
                           else
                           {
                                 GF.ROW++;
                                 GF.CHOICE = "";
                                 SwitchBoard();
                                 break;
                           }
                           break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_62()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_62] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A security gate blocks your" +
                              "\n path. To your west you see" +
                              "\n an entrance way through the." +
                              "\n gate.");
                              break;
                   case 'e' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_70()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_70] You are inside the" +
               "\n SouthWest concourse where," +
               "\n best of all possible blessings" +
               "\n a Ben and Jerry's has been set" +
               "\n up on the south-eastern side" +
               "\n of the concourse.\n" +
               "\n As you look to the south, the" +
               "\n unquenchable fire of Hell on" +
               "\n Earth burns in a mural.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys1.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n Brain freeze!");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys2.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_71()
       {
           if(GF.CHOICE.isEmpty())
           {
               if(!Reptillian_Defeated)
               {
                   Conspiracy.TA_MainOutput.setText(
                   "\n [SW_71] You are inside the" +
                   "\n SouthWest concourse...\n" +
                   "\n Directly in front of you" +
                   "\n an odd-looking person is" +
                   "\n motioning for you to walk" +
                   "\n over to where he is standing.\n");

                   Conspiracy.TA_MainOutput.append(
                   "\n You may: " +
                   "\n (a)pproach the strange person\n");
               }
               else
               {
                   Conspiracy.TA_MainOutput.setText(
                   "\n [SW_71] You are standing in" +
                   "\n the SouthWest concourse.\n" +
                   "\n You step over the dead" +
                   "\n carcass of the Reptilian" +
                   "\n you recently defeated.\n");
               }

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'a' : GF.LOCATION = ReptilianEncounter;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_72()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_72] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (s)outh (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee4.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : GF.ROW++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'e' : if(!SW_72_TookCoffee)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n A beautiful \"Caribou Coffee\" server" +
                                 "\n with dark almond skin and gorgeous," +
                                 "\n soft brown eyes looks at you. She is" +
                                 "\n wearing a khaki, knee-length skirt and" +
                                 "\n a dull purple blouse.\n" +
                                 "\n Long locks of bead-braided jet-black" +
                                 "\n tresses fall down across her narrow," +
                                 "\n graceful shoulders.\n" +
                                 "\n Through moistened lips of cholcolate" +
                                 "\n meringue she calls to you like a" +
                                 "\n mythological siren:\n" +
                                 "\n   \"Would you like a fresh, hot" +
                                 "\n   cup of Caribou coffee? It was" +
                                 "\n   brewed only a minute ago!\"\n" +
                                 "\n Will you accept her delicious offer?");

                                 Conspiracy.TA_MainOutput.setCaretPosition(0);

                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/CoffeeGirl1.jpg"));

                                 Conspiracy.DontGiveUpNow.play();
                              }
                              else
                              {
                                  Conspiracy.TA_MainOutput.setText(
                                  "\n You return to the spot where you" +
                                  "\n once accepted that divine nectar" +
                                  "\n from the hands of a goddess...\n" +
                                  "\n Your heart pines within you," +
                                  "\n smitten with unbearable sorrow.\n" +
                                  "\n The coffee shop is empty. Against" +
                                  "\n the register is a sign that reads:\n" +
                                  "\n     \"Gone for the day. But" +
                                  "\n      I'll be back tomorrow!\"\n" +
                                  "\n Dare you return once again?");

                                  Conspiracy.CurrentView =
                                  INTERFACE.getImage(Get_Location(
                                  "../Images/Shop_CaribouCoffee3.jpg"));

                                  Conspiracy.Crowd.play();
                                  break;
                              }                            
                              //Note: break left off here on purpose
                    case '~' : SW_72_TookCoffee =
                               GF.FIND("DELICIOUS coffee","Coffee",SW_72_TookCoffee,0);
                               GF.CHOICE = "~";
                               break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------


       public void SW_80()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_80] You are inside the" +
               "\n SouthWest concourse" +
               "\n and completely enveloped in" +
               "\n the Ben and Jerry's goodness" +
               "\n consuming the eastern wall.\n" +
               "\n In contrast to these icy" +
               "\n offerings, the fires of HELL" +
               "\n burn mercilessly to the south.\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go: (n)orth or (e)ast\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_BenAndJerrys2.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A dark and disturbing mural.");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Mural_CasketFire2.jpg"));
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : Conspiracy.TA_MainOutput.setText(
                              "\n How many delicous flavors?");
                              Conspiracy.CurrentView =
                              INTERFACE.getImage(Get_Location(
                              "../Images/Shop_BenAndJerrys1.jpg"));
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_81()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_81] You are inside the" +
               "\n SouthWest concourse.\n" +
               "\n Against the south wall is yet" +
               "\n another mosaic nightmare...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (e)ast (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/ConcourseB.jpg"));
               Conspiracy.Crowd.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : if(!Reptillian_Defeated)
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n A gray concrete wall!");

                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/Mural_FloorShot1.jpg"));

                                 break;
                              }
                              //Note: break left off on purpose
                   case '~' : SW_81_FoundKeystone =
                              GF.FIND("Shimmering Crystal KeyStone","KeyStone",SW_81_FoundKeystone,0);
                              GF.CHOICE = "~";
                              if(SW_81_FoundKeystone)
                              {
                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/KeyStone.jpg"));
                              }
                              break;
                   case 'e' : GF.COLUMN++;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

       public void SW_82()
       {
           if(GF.CHOICE.isEmpty())
           {
               Conspiracy.TA_MainOutput.setText(
               "\n [SW_82] You are inside the" +
               "\n SouthWest concourse...\n");

               Conspiracy.TA_MainOutput.append(
               "\n You may go:" +
               "\n (n)orth (w)est\n");

               Conspiracy.CurrentView =
               INTERFACE.getImage(Get_Location(
               "../Images/Shop_CaribouCoffee1.jpg"));
               Conspiracy.FootSteps.play();
           }

           else
           {
               switch(GF.CHOICE.charAt(0))
               {
                   case 'n' : GF.ROW--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   case 's' : Conspiracy.TA_MainOutput.setText(
                              "\n A gray concrete wall!");
                              break;
                   case 'e' : if(!GF.PLAYER.GetKeyStone())
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n You see two large, metallic" +
                                 "\n blast doors. You are certain" +
                                 "\n that whatever is behind these" +
                                 "\n doors leads away from the" +
                                 "\n airport.\n" +
                                 "\n They seem so completely" +
                                 "\n heavy and thick you doubt" +
                                 "\n that even a nuclear blast" +
                                 "\n could open them. Yet to the" +
                                 "\n side of the doors, mounted" +
                                 "\n flush against the same wall" +
                                 "\n to which the blast doors" +
                                 "\n attach sits a control pylon.\n" +
                                 "\n It possesses a hollow " +
                                 "\n indentation in its center" +
                                 "\n that accepts what appears to" +
                                 "\n be a large hexagonal crystal.\n" +
                                 "\n Where would you find something" + 
                                 "\n like that?\n\n\n");
                                 
                                 Conspiracy.TA_MainOutput.setCaretPosition(0);

                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/BlastClosed.jpg"));
                              }
                              else
                              {
                                 Conspiracy.TA_MainOutput.setText(
                                 "\n You did it! You unlocked the" +
                                 "\n blast doors. You managed to" +
                                 "\n obtain the KeyStone to open" +
                                 "\n the passage and exit to the" +
                                 "\n next level.\n" +
                                 "\n Congradulations on surviving" +
                                 "\n LEVEL 1 - your first trip" +
                                 "\n into the rabbit hole. But" +
                                 "\n the search for truth must" +
                                 "\n continue. The mysteries get" +
                                 "\n deeper and deeper, nothing" +
                                 "\n is ever what it seems...\n" +
                                 "\n Such a tangled web THEY" +
                                 "\n weave...");

                                 Conspiracy.CurrentView =
                                 INTERFACE.getImage(Get_Location(
                                 "../Images/BlastOpen.jpg"));

                                 Conspiracy.DisableNavigation();
                                 Conspiracy.B_Go.setEnabled(false);
                              }
                              break;
                   case 'w' : GF.COLUMN--;
                              GF.CHOICE = "";
                              SwitchBoard();
                              break;
                   default:  Conspiracy.TA_MainOutput.setText(
                             "\n That does not apply here...");

               }//close switch

          }//close else

       }//close function

//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//******************************* TRAIN Sectors ********************************
//------------------------------------------------------------------------------

       public void TRAIN_0()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_0] Coming down the escalator," +
                 "\n from Jeppesen Terminal above," +
                 "\n you arrive at the boarding area" +
                 "\n to enter and exit the underground" +
                 "\n train system. An east-bound train" +
                 "\n is resting at this location. You" +
                 "\n look around and notice there are" +
                 "\n neither passengers nor an operator.\n" +
                 "\n Looking ahead you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. A long lever rests in" +
                 "\n the middle position between slots " +
                 "\n marked \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may: (G)o UP the escalator\n" +
                 "\n You may also enter the train and:" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever\n" +
                 "\n You may also explore the directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'g' : GF.ROW = 1;
                               GF.COLUMN = 3;
                               GF.LOCATION = JeppesenTerminal;
                               GF.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : Conspiracy.TA_MainOutput.setText(
                               "\n You press the lever backward." +
                               "\n Brakes hiss and a red panel" +
                               "\n indicator marked \"ERROR\"" +
                               "\n lights up on the console in" +
                               "\n front of you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               Conspiracy.Telephone_Busy.play();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You see the entry-way whereby" +
                               "\n passengers enter and leave" +
                               "\n trains that run between the." +
                               "\n concourses.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainsLower.jpg"));
                               Conspiracy.TrainDoor2.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you lies row upon" +
                               "\n row of people in seats laid out" +
                               "\n in neat little rows - it's a" +
                               "\n waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_2.jpg"));
                               Conspiracy.Crowd.play();
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.FootSteps.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see a public restroom" +
                               "\n facility behind some weary" +
                               "\n travelers resting in chairs" +
                               "\n in the waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_1.jpg"));
                               break;
                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_1()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_1] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of Jeppesen Terminal.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore in directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");


                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left several metalic" +
                               "\n panels with indicators blinking" +
                               "\n first RED and then GREEN.\n"+
                               "\n There are several locked storage" +
                               "\n compartments holding " +
                               "\n miscellaneous equipment.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, a large glass" +
                               "\n window crisscrossed with" +
                               "\n reinforcement safety wires" +
                               "\n looks out into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. The darkness" +
                               "\n outside is intermittently" +
                               "\n broken into dim flashes of" +
                               "\n silver tracks illuminated by" +
                               "\n the occasional sparks emanating" +
                               "\n from beneath you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n It has many panels and blinking" +
                               "\n lights. In the center is a large" +
                               "\n control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you at the" +
                               "\n rear wall of the car you are in." +
                               "\n A small window allows you to" +
                               "\n peer backwards into other cars" +
                               "\n on the empty train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Not as many options to" +
                                              "\n choose from here. Should" +
                                              "\n be easier for you to enter" +
                                              "\n something that makes sense," +
                                              "\n huh?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_2()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_2] You are riding the DIA" +
                 "\n underground train - midway" +
                 "\n between Fronteir Midwest and" +
                 "\n Jeppesen Terminal.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left you peer out" +
                               "\n the window and notice a" +
                               "\n section of tunnel under"+
                               "\n construction. It projects far" +
                               "\n away from the concourse towards" +
                               "\n what appears to be 5 large" +
                               "\n underground buildings.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, the window port" +
                               "\n overlooks anbother underground" +
                               "\n section under construction..." +
                               "\n It's leading AWAY from the" +
                               "\n airport concourses!. Why?\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_4.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n A blue light is flashing and" +
                               "\n a radio hisses. In the center," +
                               "\n a large control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind through the" +
                               "\n central small window but your" +
                               "\n view is mostly obscured by the" +
                               "\n curvature of the tunnels behind" +
                               "\n you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Inside_Back2.jpg"));
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_3()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_3] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of Frontier Midwest.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore towards the:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n To your left, as you gaze out" +
                               "\n the window, you watch an " +
                               "\n auxilliary access tunnel as it" +
                               "\n trails towards a hidden nook" +
                               "\n that appears to be a secluded," +
                               "\n underground base obfuscated" +
                               "\n by a painted facade...");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_1.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n You look out the south " +
                               "\n window into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. Beneath you" +
                               "\n sparks flying from the tracks" +
                               "\n cast shadows and sillohuetes" +
                               "\n against the dark concrete" +
                               "\n walls of the train tunnel.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front is the train's" +
                               "\n directional control panel.\n" +
                               "\n It has several controls and" +
                               "\n blinking lights. In the" +
                               "\n center - a large control" +
                               "\n stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you through the" +
                               "\n small port window of the rear door" +
                               "\n of the car you are traveling in.\n" +
                               "\n Through a small window you see" +
                               "\n flickering flourescent lights in" +
                               "\n the cars behind you on the empty" +
                               "\n train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Please choose an option that" +
                                              "\n is meaningful. O.k.?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_4()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_4] Near the escalator, from" +
                 "\n the Frontier Midwest concourse" +
                 "\n above, you arrive at the boarding" +
                 "\n to enter and exit the underground" +
                 "\n train system. A west-bound" +
                 "\n train is resting at this location." +
                 "\n You see that there are neither" +
                 "\n passengers nor an operator" +
                 "\n anywhere in sight. \n" +
                 "\n Looking around you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. You step inside the car." +
                 "\n As you stand in front of the " +
                 "\n console you are facing WEST." +
                 "\n In front of you a long lever" +
                 "\n sits flipped in the middle position" +
                 "\n between \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (G)o UP the escalator" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore your:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'g' : GF.ROW = 4;
                               GF.COLUMN = 0;
                               GF.LOCATION = FrontierMidwest;
                               GF.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You admire a MAGNIFICENT" +
                               "\n Brittish Airways logo" +
                               "\n emblazoned upon the otherwise" +
                               "\n drab and utliitarian concrete" +
                               "\n slabs that wall this underground" +
                               "\n abyss like a tomb.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BrittishAirways.jpg"));
                               Conspiracy.AirportAnnounce1.play();
                               break;
                    case 's' : if(!TRAIN_4_TookCoffee)
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n A glorious \"Caribou Coffee\" stand" +
                                   "\n lies before you emitting an" +
                                   "\n irresistible aroma that tingles" +
                                   "\n with savory roasty-toasty goodness." +
                                   "\n Oh - sweet nectar of the gods!\n");

                                   Conspiracy.TA_MainOutput.append(
                                   "\n While you are gawking, two " +
                                   "\n attendants ask you:\n" +
                                   "\n   \"Would you like a complimentary" +
                                   "\n   cup of Caribou coffee, sir? You" +
                                   "\n   seem like such a weary traveler!\"\n" +
                                   "\n Will you accept their kind offer?");

                                   Conspiracy.TA_MainOutput.setCaretPosition(0);

                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/CaribouCoffeeMen.jpg"));

                                   Conspiracy.Crowd.play();
                               }
                               else
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n\n The attendants who previously gave " +
                                   "\n you the coffee are gone. In their" +
                                   "\n place at the counter is a harried" +
                                   "\n lady that tersely responds:\n" +
                                   "\n     \"Only ONE complimentary cup" +
                                   "\n      per patron please. Oh weary" +
                                   "\n      traveler - this means you!\"");

                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/CaribouCoffeeGirlMean.jpg"));

                                   Conspiracy.BlahBlahBlah.play();

                                   break;
                               }
                               //Note: break left off here on purpose
                    case '~' : TRAIN_4_TookCoffee =
                               GF.FIND("DELICIOUS coffee","Coffee",TRAIN_4_TookCoffee,0);
                               GF.CHOICE = "~";
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n Nothing but a few benches, an" +
                               "\n abandoned concession stand and" +
                               "\n an obscure business center.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BusinessCenter.jpg"));
                               Conspiracy.KeyPadPressing.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.TrainDoor1.play();
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_5()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_5] Coming down the escalator," +
                 "\n from the FrontierMidwest concourse" +
                 "\n above, you arrive at a boarding area" +
                 "\n to enter and exit the underground" +
                 "\n train system. An east-bound train" +
                 "\n is resting at this location. You" +
                 "\n look around and notice there are" +
                 "\n neither passengers nor an operator.\n" +
                 "\n Looking ahead you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. A long lever rests in" +
                 "\n the middle position between slots " +
                 "\n marked \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may: (G)o UP the escalator\n" +
                 "\n You may also enter the train and:" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever\n" +
                 "\n You may also explore the directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'g' : GF.ROW = 4;
                               GF.COLUMN = 2;
                               GF.LOCATION = FrontierMidwest;
                               GF.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You see the entry-way whereby" +
                               "\n passengers enter and leave" +
                               "\n trains that run between the." +
                               "\n concourses.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainsLower.jpg"));
                               Conspiracy.TrainDoor2.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you lies row upon" +
                               "\n row of people in seats laid out" +
                               "\n in neat little rows - it's a" +
                               "\n waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_2.jpg"));
                               Conspiracy.Crowd.play();
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.FootSteps.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see a public restroom" +
                               "\n facility behind some weary" +
                               "\n travelers resting in chairs" +
                               "\n in the waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_1.jpg"));
                               break;
                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_6()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_6] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of Frontier Midwest concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore in directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");


                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left several metalic" +
                               "\n panels with indicators blinking" +
                               "\n first RED and then GREEN.\n"+
                               "\n There are several locked storage" +
                               "\n compartments holding " +
                               "\n miscellaneous equipment.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, a large glass" +
                               "\n window crisscrossed with" +
                               "\n reinforcement safety wires" +
                               "\n looks out into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. The darkness" +
                               "\n outside is intermittently" +
                               "\n broken into dim flashes of" +
                               "\n silver tracks illuminated by" +
                               "\n the occasional sparks emanating" +
                               "\n from beneath you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n It has many panels and blinking" +
                               "\n lights. In the center is a large" +
                               "\n control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you at the" +
                               "\n rear wall of the car you are in." +
                               "\n A small window allows you to" +
                               "\n peer backwards into other cars" +
                               "\n on the empty train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Not as many options to" +
                                              "\n choose from here. Should" +
                                              "\n be easier for you to enter" +
                                              "\n something that makes sense," +
                                              "\n huh?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_7()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_7] You are riding the DIA" +
                 "\n underground train - midway" +
                 "\n between the Fronteir Midwest and" +
                 "\n Continental US Airways concourses.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left you peer out" +
                               "\n the window and notice a" +
                               "\n section of tunnel under"+
                               "\n construction. It projects far" +
                               "\n away from the concourse towards" +
                               "\n what appears to be 5 large" +
                               "\n underground buildings.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, the window port" +
                               "\n overlooks anbother underground" +
                               "\n section under construction..." +
                               "\n It's leading AWAY from the" +
                               "\n airport concourses!. Why?\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_4.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n A blue light is flashing and" +
                               "\n a radio hisses. In the center," +
                               "\n a large control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind through the" +
                               "\n central small window but your" +
                               "\n view is mostly obscured by the" +
                               "\n curvature of the tunnels behind" +
                               "\n you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Inside_Back2.jpg"));
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_8()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_8] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of the Continental US Airways" +
                 "\n concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore towards the:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n To your left, as you gaze out" +
                               "\n the window, you watch an " +
                               "\n auxilliary access tunnel as it" +
                               "\n trails towards a hidden nook" +
                               "\n that appears to be a secluded," +
                               "\n underground base obfuscated" +
                               "\n by a painted facade...");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_1.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n You look out the south " +
                               "\n window into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. Beneath you" +
                               "\n sparks flying from the tracks" +
                               "\n cast shadows and sillohuetes" +
                               "\n against the dark concrete" +
                               "\n walls of the train tunnel.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front is the train's" +
                               "\n directional control panel.\n" +
                               "\n It has several controls and" +
                               "\n blinking lights. In the" +
                               "\n center - a large control" +
                               "\n stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you through the" +
                               "\n small port window of the rear door" +
                               "\n of the car you are traveling in.\n" +
                               "\n Through a small window you see" +
                               "\n flickering flourescent lights in" +
                               "\n the cars behind you on the empty" +
                               "\n train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Please choose an option that" +
                                              "\n is meaningful. O.k.?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_9()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_9] Near the escalator, from" +
                 "\n the Continental US Airways" +
                 "\n concourse ascending above, you" +
                 "\n arrive at a boarding area" +
                 "\n to enter and exit the underground" +
                 "\n train system. A passenger" +
                 "\n train is resting at this location." +
                 "\n You see several passengers" +
                 "\n waiting for the next stop but" +
                 "\n no operator.\n");

                 if(!TRAIN_9_TookMoney)
                 {
                    Conspiracy.TA_MainOutput.append(
                    "\n Looking around you notice a" +
                    "\n distraught elderly woman to your" +
                    "\n north motioning to you.\n");
                 }
                 else
                 {
                    Conspiracy.TA_MainOutput.append(
                    "\n To the north you only see an" +
                    "\n empty bench in the terminal" +
                    "\n complex.\n");
                 }

                 Conspiracy.TA_MainOutput.append(
                 "\n You can also see the empty" +
                 "\n train control cab.\n" +
                 "\n In front of you a long lever" +
                 "\n sits flipped in the middle position" +
                 "\n between \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (G)o UP the escalator" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore your:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'g' : GF.ROW = 4;
                               GF.COLUMN = 0;
                               GF.LOCATION = ContinentalUSAirways;
                               GF.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : GF.LOCATION = OldLady;
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               GF.CHOICE = "";
                               GF.DIALOGUE = "";
                               SwitchBoard();
                               break;
                    case 's' : if(!TRAIN_9_TookCoffee)
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n A \"Caribou Coffee\" shop packed" +
                                   "\n full of patrons sprawls out in" +
                                   "\n front of you. Standing at the" +
                                   "\n counter, a lady in her early" +
                                   "\n twenties beckons to you with a" +
                                   "\n subtle, inviting gesture.\n" +
                                   "\n She wears her silky blond strands" +
                                   "\n tied in a tight pony tail behind" +
                                   "\n her where stray whisps around her" +
                                   "\n bangs accentuate her large, moist" +
                                   "\n bright blue eyes.\n" +
                                   "\n Beneath her green apron, a" +
                                   "\n lavender blouse and grey skirt" +
                                   "\n fall loosely across her petite" +
                                   "\n frame.\n" +
                                   "\n She winks at you and hands you a" +
                                   "\n cup of Caribou Coffee. Will you" +
                                   "\n accept this divine nectar of the" + 
                                   "\n gods from her trembling, gracious" +
                                   "\n hands?");

                                   Conspiracy.TA_MainOutput.setCaretPosition(0);

                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/Caribou_Coffee_Girl_Blond.jpg"));

                                   Conspiracy.FemaleSurprise.play();
                               }
                               else
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n You return but the lady who gave" +
                                   "\n you the cup of coffee at this" +
                                   "\n particular spot has gone.\n" + 
                                   "\n In fact, the coffee shop is" +
                                   "\n now completely empty.");

                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/Shop_CaribouCoffee3.jpg"));

                                   Conspiracy.Crowd.play();

                                   break;
                               }
                               //Note: break left off here on purpose
                    case '~' : TRAIN_9_TookCoffee =
                               GF.FIND("DELICIOUS coffee","Coffee",TRAIN_9_TookCoffee,0);
                               GF.CHOICE = "~";
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n Nothing but a few benches, an" +
                               "\n abandoned concession stand and" +
                               "\n an obscure business center.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BusinessCenter.jpg"));
                               Conspiracy.KeyPadPressing.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.TrainDoor1.play();
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_10()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_10] Above you looms the chrome," +
                 "\n escalator ascending to the" +
                 "\n Continental-US Airways concourse." +
                 "\n You arrive at the boarding area used" +
                 "\n to enter and exit the underground" +
                 "\n train system. An east-bound train" +
                 "\n is resting at this location. You" +
                 "\n look around and notice there are" +
                 "\n neither passengers nor an operator.\n" +
                 "\n Looking ahead you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. A long lever rests in" +
                 "\n the middle position between slots " +
                 "\n marked \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may: (G)o UP the escalator\n" +
                 "\n You may also enter the train and:" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever\n" +
                 "\n You may also explore the directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'g' : GF.ROW = 4;
                               GF.COLUMN = 2;
                               GF.LOCATION = ContinentalUSAirways;
                               GF.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You see the entry-way whereby" +
                               "\n passengers enter and leave" +
                               "\n trains that run between the." +
                               "\n concourses.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainsLower.jpg"));
                               Conspiracy.TrainDoor2.play();
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you lies row upon" +
                               "\n row of people in seats laid out" +
                               "\n in neat little rows - it's a" +
                               "\n waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_2.jpg"));
                               Conspiracy.Crowd.play();
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.FootSteps.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see a public restroom" +
                               "\n facility behind some weary" +
                               "\n travelers resting in chairs" +
                               "\n in the waiting area.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_WaitingArea_1.jpg"));
                               break;
                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_11()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_11] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of the Continental-US Airways" +
                 "\n concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore in directions:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");


                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left several metalic" +
                               "\n panels with indicators blinking" +
                               "\n first RED and then GREEN.\n"+
                               "\n There are several locked storage" +
                               "\n compartments holding " +
                               "\n miscellaneous equipment.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, a large glass" +
                               "\n window crisscrossed with" +
                               "\n reinforcement safety wires" +
                               "\n looks out into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. The darkness" +
                               "\n outside is intermittently" +
                               "\n broken into dim flashes of" +
                               "\n silver tracks illuminated by" +
                               "\n the occasional sparks emanating" +
                               "\n from beneath you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n It has many panels and blinking" +
                               "\n lights. In the center is a large" +
                               "\n control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you at the" +
                               "\n rear wall of the car you are in." +
                               "\n A small window allows you to" +
                               "\n peer backwards into other cars" +
                               "\n on the empty train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Not as many options to" +
                                              "\n choose from here. Should" +
                                              "\n be easier for you to enter" +
                                              "\n something that makes sense," +
                                              "\n huh?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_12()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_12] You are riding the DIA" +
                 "\n underground train - midway" +
                 "\n between the Continental-US" +
                 "\n Airways concourse and the" +
                 "\n Southwest concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n On your left you peer out" +
                               "\n the window and notice a" +
                               "\n section of tunnel under"+
                               "\n construction. It projects far" +
                               "\n away from the concourse towards" +
                               "\n what appears to be 5 large" +
                               "\n underground buildings.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_3.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n To your right, the window port" +
                               "\n overlooks anbother underground" +
                               "\n section under construction..." +
                               "\n It's leading AWAY from the" +
                               "\n airport concourses!. Why?\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_4.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front of you is the" +
                               "\n control panel for the train." +
                               "\n A blue light is flashing and" +
                               "\n a radio hisses. In the center," +
                               "\n a large control stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind through the" +
                               "\n central small window but your" +
                               "\n view is mostly obscured by the" +
                               "\n curvature of the tunnels behind" +
                               "\n you.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Inside_Back2.jpg"));
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_13()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_13] You are riding the DIA" +
                 "\n underground train - close to" +
                 "\n the boarding area at the bottom" +
                 "\n of the Southwest concourse.");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may explore towards the:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/Train_Engine_Inside_2.jpg"));
                 Conspiracy.TrainInside.play();
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'f' : GF.COLUMN++;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n To your left, as you gaze out" +
                               "\n the window, you watch an " +
                               "\n auxilliary access tunnel as it" +
                               "\n trails towards a hidden nook" +
                               "\n that appears to be a secluded," +
                               "\n underground base obfuscated" +
                               "\n by a painted facade...");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_1.jpg"));
                               break;
                    case 's' : Conspiracy.TA_MainOutput.setText(
                               "\n You look out the south " +
                               "\n window into the darkness" +
                               "\n of the tunnel in which you" +
                               "\n are traveling. Beneath you" +
                               "\n sparks flying from the tracks" +
                               "\n cast shadows and sillohuetes" +
                               "\n against the dark concrete" +
                               "\n walls of the train tunnel.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Tunnel_2.jpg"));
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n In front is the train's" +
                               "\n directional control panel.\n" +
                               "\n It has several controls and" +
                               "\n blinking lights. In the" +
                               "\n center - a large control" +
                               "\n stick.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_ControlPanel.jpg"));
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You look behind you through the" +
                               "\n small port window of the rear door" +
                               "\n of the car you are traveling in.\n" +
                               "\n Through a small window you see" +
                               "\n flickering flourescent lights in" +
                               "\n the cars behind you on the empty" +
                               "\n train.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Back_Door.jpg"));
                               break;
                    default: System.out.print("\n Please choose an option that" +
                                              "\n is meaningful. O.k.?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

       public void TRAIN_14()
       {
              if(GF.CHOICE.isEmpty())
              {
                 Conspiracy.TA_MainOutput.setText(
                 "\n [T_14] You stand at the boarding" +
                 "\n area of the Southwest concourse" +
                 "\n in the underground terminal of the" +
                 "\n DIA train system. Another train" +
                 "\n passes departing west for Jeppesen" +
                 "\n Terminal. You see a few scattered" +
                 "\n passengers chatting and an engineer" +
                 "\n checking something in the distance. \n" +
                 "\n Looking around you notice that the" +
                 "\n front control compartment of the" +
                 "\n train is open and the keycard" +
                 "\n inserted. You step inside the car." +
                 "\n As you stand in front of the " +
                 "\n console you are facing WEST." +
                 "\n In front of you a long lever" +
                 "\n sits flipped in the middle position" +
                 "\n between \"FORWARD\" and \"REVERSE\".");

                 Conspiracy.TA_MainOutput.append(
                 "\n\n You may:\n" +
                 "\n (G)o UP the escalator" +
                 "\n (F)orward press the lever" +
                 "\n (B)ackward press the lever" +
                 "\n\n You may also explore your:" +
                 "\n (N)orth, (S)outh, (E)ast, (W)est\n\n");

                 Conspiracy.CurrentView =
                 INTERFACE.getImage(Get_Location(
                 "../Images/TrainsLower.jpg"));
                 Conspiracy.TrainOutside.play();

                 Conspiracy.B_ALT.setText("GO UP");
                 Conspiracy.B_Up.setText("FORW");
                 Conspiracy.B_Down.setText("BACK");

                 Conspiracy.TA_MainOutput.setCaretPosition(0);
             }
             else
             {
                 switch(GF.CHOICE.charAt(0))
                 {
                    case 'g' : GF.ROW = 4;
                               GF.COLUMN = 0;
                               GF.LOCATION = SouthWest;
                               GF.CHOICE = "";
                               Conspiracy.B_Up.setText("UP");
                               Conspiracy.B_Down.setText("DOWN");
                               SwitchBoard();
                               break;
                    case 'f' : Conspiracy.TA_MainOutput.setText(
                               "\n You press the lever forward." +
                               "\n Brakes hiss and a panel" +
                               "\n indicator marked:" +
                               "\n \"END of the line!\"" +
                               "\n lights up on the console in" +
                               "\n front of you.\n");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Train_Engine_Inside_3.jpg"));
                               Conspiracy.Telephone_Busy.play();
                               break;
                    case 'b' : GF.COLUMN--;
                               GF.CHOICE = "";
                               Conspiracy.TrainDoor1.play();
                               Conspiracy.B_ALT.setText("ALT");
                               SwitchBoard();
                               break;
                    case 'n' : Conspiracy.TA_MainOutput.setText(
                               "\n You admire a MAGNIFICENT" +
                               "\n Brittish Airways logo" +
                               "\n emblazoned upon the otherwise" +
                               "\n drab and utliitarian concrete" +
                               "\n slabs that wall this underground" +
                               "\n abyss like a tomb.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BrittishAirways.jpg"));
                               Conspiracy.AirportAnnounce1.play();
                               break;
                    case 's' : if(!TRAIN_14_TookCoffee)
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n A \"Caribou Coffee\" stand lies" +
                                   "\n completely empty. On a table outside" +
                                   "\n the shop sits a solitary cup" +
                                   "\n of coffee. Beneath it is a sign" +
                                   "\n marked \"Free Samples!\"");

                                   Conspiracy.TA_MainOutput.setCaretPosition(0);

                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/CaribouCoffeeTable.jpg"));

                                   Conspiracy.Crowd.play();
                               }
                               else
                               {
                                   Conspiracy.TA_MainOutput.setText(
                                   "\n You find the shop is still closed.\n" +
                                   "\n The table from which you took the" +
                                   "\n coffee is still there, but no" +
                                   "\n samples have been replenished.");

                                   Conspiracy.CurrentView =
                                   INTERFACE.getImage(Get_Location(
                                   "../Images/Shop_CaribouCoffee1.jpg"));

                                   Conspiracy.AirportAnnounce2.play();

                                   break;
                               }
                               //Note: break left off here on purpose
                    case '~' : TRAIN_14_TookCoffee =
                               GF.FIND("DELICIOUS coffee","Coffee",TRAIN_14_TookCoffee,0);
                               GF.CHOICE = "~";
                               break;
                    case 'e' : Conspiracy.TA_MainOutput.setText(
                               "\n Nothing but a few benches, an" +
                               "\n abandoned concession stand and" +
                               "\n an obscure business center.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/Shop_BusinessCenter.jpg"));
                               Conspiracy.KeyPadPressing.play();
                               break;
                    case 'w' : Conspiracy.TA_MainOutput.setText(
                               "\n You see silver-metallic doors" +
                               "\n and people entering and leaving" +
                               "\n the train system.");
                               Conspiracy.CurrentView =
                               INTERFACE.getImage(Get_Location(
                               "../Images/TrainDoors.jpg"));
                               Conspiracy.TrainDoor1.play();
                               break;

                    default: System.out.print("\n So many valid options to" +
                                              "\n choose from here. Why enter" +
                                              "\n something non-sensical?");

           }//close switch

      }//close else

    }//close function

//----------------------------------------------------------------------------

}//close Level 1 class


/*

To Do:
A. Add 3D, Animation and Video
B. Add MP3 support

*/