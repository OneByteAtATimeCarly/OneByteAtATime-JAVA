package GameFunctions;

//FileFilter for Conspiracy Objects, for use with JFileChooser

import java.io.*;

class ConspiracyFilter extends javax.swing.filechooser.FileFilter {

      public boolean accept(File f)
      {
        return f.isDirectory() || f.getName().toLowerCase().endsWith(".conspire");
      }

      public String getDescription()
      {
        return ".conspire files";
      }
}
