//Game Functions helper class - for the most part static and therefore
//not requiring instantiation. The contructor is overloaded to take
//a pointer to the interface and then pass it to the level classes
//when they are created so they can manipulate the interface VIEW.

package GameFunctions;
import Interface.*;
import Characters.*;
import Levels.*;
import java.awt.Color;
import java.awt.Font;
import java.io.*;
import java.util.Random;
import javax.swing.*;

public class GF
{
       //Global pointer to Interface for Images and paint()
       public static JApplet INTERFACE;

       //Globals
       public static Entity PLAYER;
       public static boolean PLAYERSTURN = false;
       public static L01_DenverAirport GAME;
       public static Random IMPROBABILITY;

       //Location Tracking
       public static int LOCATION = 0;
       public static int PickUp_Location = 0;
       public static int ROW = 0;
       public static int COLUMN = 0;
       public static int CombatRound = 1;

       public static boolean NEWGAME = true;
       public static int SEQ_CreateCharacter = 1;
       public static String CHOICE = " ";
       public static String DIALOGUE = " ";

//-----------------------------------------------------------------
       //Overloaded Constructors
       public GF()
       { System.out.print("\n\tBuilding a GameFunctions object."); }

//-----------------------------------------------------------------

       public GF(JApplet X)
       {
           System.out.print("\n\tBuilding a GameFunctions object.");
           INTERFACE = X; //pass interface pointer to global
       }

//-----------------------------------------------------------------

public static void SEQUENCE()
{
       if(NEWGAME)
       {
           CreateCharacter();
       }
       else
       {
          GAME.SwitchBoard();
       }
}

//-----------------------------------------------------------------

public static void CreateCharacter()
{
        switch(SEQ_CreateCharacter)
        {
            case 1:
            Conspiracy.TA_MainOutput.setText(
            "\n-------- Create Your Character: --------\n");
            Conspiracy.TA_MainOutput.append("\n (O)rdinary Civilian");
            Conspiracy.TA_MainOutput.append("\n (B)enevolent Mason");
            Conspiracy.TA_MainOutput.append("\n (F)BI Agent");
            Conspiracy.TA_MainOutput.append("\n (C)IA Agent");
            Conspiracy.TA_MainOutput.append("\n (N)SA Agent");
            Conspiracy.TA_MainOutput.append("\n (M)ajestic Agent");
            Conspiracy.TA_MainOutput.append("\n\n Enter your choice in the" +
                       "\n input field below and click" +
                       "\n the \"GO\" button to continue.");
           SEQ_CreateCharacter++;
           break;

            case 2: if(CHOICE.isEmpty())
                    {
                        Conspiracy.TA_MainOutput.setText(
                        "\n\n You need to CHOOSE\n something here!");
                        SEQ_CreateCharacter--;
                    }
                    else
                    {
                        Conspiracy.TA_MainOutput.setText("\n\n");
                        CHOICE = CHOICE.toLowerCase();
                        switch(CHOICE.charAt(0))
                        {
                           case 'o' : PLAYER = new Civilian();
                                      SEQ_CreateCharacter++;
                                      break;
                           case 'b' : PLAYER = new FreeMasonBenevolent();
                                      SEQ_CreateCharacter++;
                                      break;
                           case 'f' : PLAYER = new FBI();
                                      SEQ_CreateCharacter++;
                                      break;
                           case 'c' : PLAYER = new CIA();
                                      SEQ_CreateCharacter++;
                                      break;
                           case 'n' : PLAYER = new NSA();
                                      SEQ_CreateCharacter++;
                                      break;
                           case 'm' : PLAYER = new Majestic();
                                      SEQ_CreateCharacter++;
                                      break;
                           default : Conspiracy.TA_MainOutput.setText(
                                     "\n Not on the menu today!");
                                     SEQ_CreateCharacter--;
                                     break;
                         }//close inner switch
                   }

                   Conspiracy.TA_MainOutput.append(
                              "\n\n Click \"GO\" to continue.");
                   break;

            case 3: Conspiracy.TA_MainOutput.setText(
                    "\n What will you name your character? ");
                    Conspiracy.TA_MainOutput.append(
                    "\n\n Enter the name in the" +
                    "\n input field below and click" +
                    "\n the \"GO\" button to continue.");
                    SEQ_CreateCharacter++;
                    break;

            case 4: if(CHOICE.isEmpty()) 
                    { 
                        Conspiracy.TA_MainOutput.setText(
                        "\n\n Surely you can think of" + 
                        "\n a better name than NOTHING!");
                        SEQ_CreateCharacter--;
                    }
                    else
                    {
                        PLAYER.SetName(CHOICE);
                        Conspiracy.TA_MainOutput.setText(
                        "\n\n Name set to \"" + PLAYER.GetName() + "\".");
                        SEQ_CreateCharacter++;
                    }

                    Conspiracy.TA_MainOutput.append(
                    "\n\n Click \"GO\" to continue.");
                    break;

            case 5: Conspiracy.TA_MainOutput.setText(
                    "\n Will your character be:\n" +
                    "\n (A)ndrogenous\n (F)emale\n (M)ale\n");
                    Conspiracy.TA_MainOutput.append(
                            "\n Enter your choice in the" +
                            "\n input field below and click" +
                            "\n the \"GO\" button to continue.");
                    SEQ_CreateCharacter++;
                    break;

            case 6: if(CHOICE.isEmpty()) { CHOICE = "IT"; }
                    CHOICE = CHOICE.toLowerCase();
                    switch(CHOICE.charAt(0))
                    {
                       case 'a' : PLAYER.SetGender("a");
                                  SEQ_CreateCharacter++;
                                  break;
                       case 'f' : PLAYER.SetGender("f");
                                  SEQ_CreateCharacter++;
                                  break;
                       case 'm' : PLAYER.SetGender("m");
                                  SEQ_CreateCharacter++;
                                  break;  
                       default : Conspiracy.TA_MainOutput.setText(
                                 "\n Surely one of the THREE" +
                                 "\n options will suffice here.");
                                 SEQ_CreateCharacter--;
                                 break;
                    }//close inner switch

                    Conspiracy.TA_MainOutput.append(
                    "\n\n Gender set to \"" + PLAYER.GetGender() + "\".");

                    Conspiracy.TA_MainOutput.append(
                              "\n\n Click \"GO\" to continue.");
                    break;

            case 7 : Conspiracy.TA_MainOutput.setText(
                     "\n\n Pick your species. Note"
                     + "\n that different species have" +
                     "\n different abilities and weapons.\n" +
                     "\n (A)lien" +
                     "\n (H)uman" +
                     "\n (P)olymorphic Hybrid");
                     Conspiracy.TA_MainOutput.append(
                              "\n\n Click \"GO\" to continue.");
                     SEQ_CreateCharacter++;
                     break;

            case 8 : if(CHOICE.isEmpty()) { CHOICE = "IT"; }
                     CHOICE = CHOICE.toLowerCase();
                     switch(CHOICE.charAt(0))
                     {
                       case 'a' : PLAYER.SetSpecies("a");
                                  SEQ_CreateCharacter++;
                                  break;
                       case 'h' : PLAYER.SetSpecies("h");
                                  SEQ_CreateCharacter++;
                                  break;
                       case 'p' : PLAYER.SetSpecies("p");
                                  SEQ_CreateCharacter++;
                                  break;
                       default : Conspiracy.TA_MainOutput.setText(
                                 "\n Please choose:" + 
                                 "\n ALIEN, HUMAN or HYBRID.");
                                 SEQ_CreateCharacter--;
                                 break;
                    }//close inner switch

                    Conspiracy.TA_MainOutput.append(
                    "\n\n Species set to \"" + PLAYER.GetSpecies() + "\".");

                    Conspiracy.TA_MainOutput.append(
                              "\n\n Click \"GO\" to continue.");
                    break;

            case 9: Conspiracy.TA_MainOutput.setText(
                    "\n Choose an AVATAR image to" +
                    "\n represent " + PLAYER.GetName() + "." +
                    "\n\n Use the buttons to the right" +
                    "\n and click \"SELECT\" when done.");
                    Conspiracy.B_Go.setEnabled(false);
                    Conspiracy.B_AvatarSelect.setEnabled(true);
                    Conspiracy.B_AvatarPrevious.setEnabled(true);
                    Conspiracy.B_AvatarNext.setEnabled(true);
                    SEQ_CreateCharacter++;
                    break;

            case 10 : Conspiracy.TA_MainOutput.setText(
                              "\n\n Rolling dice for random" +
                              "\n character STATS and ratios...");

                     Random APPLE = new Random();

                     //RANDOMIZE 10 points total to assign for ATK and DEF
                     int TEMP = APPLE.nextInt(10) + 1;
                     if(TEMP < 10)
                     {
                         PLAYER.SetAtk(TEMP);
                         PLAYER.SetDef(10 - TEMP);
                     }
                     else
                     {
                         PLAYER.SetAtk(TEMP-1);
                         PLAYER.SetDef(1);
                     }

                     //SET SPECIFIC 10 point ratio for the chosen class
                     if(PLAYER.GetCharacterClass().equals("Ordinary Civilian"))
                     {
                          PLAYER.SetMass(3);
                          PLAYER.SetSpeed(7);
                     }

                     if(PLAYER.GetCharacterClass().equals("Benevolent Mason"))
                     {
                          PLAYER.SetMass(6);
                          PLAYER.SetSpeed(4);
                     }

                     if(PLAYER.GetCharacterClass().equals("FBI"))
                     {
                          PLAYER.SetMass(5);
                          PLAYER.SetSpeed(5);
                     }

                     if(PLAYER.GetCharacterClass().equals("CIA"))
                     {
                          PLAYER.SetMass(7);
                          PLAYER.SetSpeed(3);
                     }

                     if(PLAYER.GetCharacterClass().equals("NSA"))
                     {
                          PLAYER.SetMass(2);
                          PLAYER.SetSpeed(8);
                     }

                     if(PLAYER.GetCharacterClass().equals("Majestic"))
                     {
                          PLAYER.SetMass(8);
                          PLAYER.SetSpeed(2);
                     }

                     PLAYER.SetPlayerObject(true);

                     Conspiracy.TA_MainOutput.append(
                     "\n\n Character creation completed!" +
                      "\n\n Click \"GO\" to continue.");
                     PLAYER.SHOW();
                     SEQ_CreateCharacter++;
                     break;

                    case 11 : PlayGame();

       }//close outer switch

}

//-----------------------------------------------------------------

public static void PlayGame()
{
       NEWGAME = false;
       GAME = new L01_DenverAirport(INTERFACE);
       Conspiracy.TA_MainOutput.setText("\n Click \"GO\" to continue.");
}

//-----------------------------------------------------------------

       public static String INPUT()
       {
           String temp = " ";
           LineNumberReader BANANA =
           new LineNumberReader(new InputStreamReader(System.in));
           try { temp = BANANA.readLine(); }
           catch(IOException X) {  }
           if(temp.isEmpty()) { temp = " ";}
           return temp;
       }

//-----------------------------------------------------------------


       public static void PAUSE()
       {
              String choice = "q";
              System.out.print("\n\tHit ENTER to continue.");
              choice = INPUT();
       }

//-----------------------------------------------------------------
//FIND = pass in 0 if not a quantity item, otherwise use AMT
public static boolean FIND(
       String WhatPlayerSees, String Item, boolean FoundItem, int AMT)
{
       CHOICE = Conspiracy.TF_Input.getText();

       if(CHOICE.isEmpty() && !FoundItem)
       {
           Conspiracy.DisableNavigation();

           Conspiracy.TA_MainOutput.append(
           "\n\n You see a(n)/the " + WhatPlayerSees + "." +
           "\n Do you want to pick it/them up?\n" +
           "\n Enter (y)es or (n)o.\n\n");
       }

       else if(CHOICE.isEmpty() && FoundItem)
       {
             Conspiracy.TA_MainOutput.append(
             "\n\n Here is where you previously"+
             "\n found the " + Item + ".\n\n");
             //Conspiracy.Navigation_Lock = true;
       }

       else
       {
             switch(GF.CHOICE.toLowerCase().charAt(0))
             {
                  case 'y' : if(AMT < 2)
                             {
                                Conspiracy.TA_MainOutput.setText(
                                "\n\n You found the " + Item + "!");
                             }
                             else
                             {
                                Conspiracy.TA_MainOutput.setText(
                                "\n\n You found " + AMT + " " + Item + "s!");
                             }

                  //Boolean Inventory Items
                  if(Item.equals("Jack Knife"))
                  { 
                      PLAYER.SetJackKnife(true);
                      Conspiracy.RB_JackKnife.setEnabled(true);

                      Conspiracy.CurrentView =
                      INTERFACE.getImage(GAME.Get_Location(
                      "../Images/Weapons/JackKnife.jpg"));
                  }
                  if(Item.equals("Glock"))
                  {
                      PLAYER.SetGlock(true);
                      Conspiracy.RB_Glock.setEnabled(true);
                  }
                  if(Item.equals("Titanium Staff"))
                  { 
                      PLAYER.SetStaff(true);
                      Conspiracy.RB_Staff.setEnabled(true);
                  }
                  if(Item.equals("Sword"))
                  {
                      PLAYER.SetSword(true);
                      Conspiracy.RB_Sword.setEnabled(true);
                  }

                  if(Item.equals("Vest"))
                  { PLAYER.SetVest(true); }

                  if(Item.equals("Stones"))
                  {
                      GF.PLAYER.SetStones(true);
                  }

                  if(Item.equals("Coffee Pellet"))
                  {
                      GF.PLAYER.SetCoffeePellet(
                      GF.PLAYER.GetCoffeePellet() + AMT);
                  }

                  if(Item.equals("Key Locker"))
                  { PLAYER.SetKeyLocker(true); }
                  
                  if(Item.equals("Key SecurityOffice"))
                  { PLAYER.SetKeySecurityOffice(true); }
                  
                  if(Item.equals("Key StaffRoom"))
                  { PLAYER.SetKeyStaffRoom(true); }

                  if(Item.equals("KeyCard"))
                  { PLAYER.SetKeyCard(true); }
                  
                  if(Item.equals("KeyStone"))
                  { PLAYER.SetKeyStone(true); }

                  //Quantity Inventory Items
                  if(Item.equals("Glock Ammo"))
                  {
                     PLAYER.SetGlockAmmo(PLAYER.GetGlockAmmo() + AMT);
                     Conspiracy.TA_MainOutput.append(
                     "\n I mean, in the clip are " + AMT + " bullets.");
                     
                     Conspiracy.CurrentView =
                     INTERFACE.getImage(GAME.Get_Location(
                     "../Images/Weapons/AmmoClip.jpg"));
                  }
                  if(Item.equals("Grenade"))
                  {
                      PLAYER.SetGrenade(PLAYER.GetGrenade() + AMT);
                      Conspiracy.CurrentView =
                      INTERFACE.getImage(GAME.Get_Location(
                      "../Images/Weapons/Grenade.jpg"));
                  }

                  if(Item.equals("Flash Grenade"))
                  { PLAYER.SetFlashGrenade(PLAYER.GetFlashGrenade() + AMT); }

                  //ReSpawning Items
                  if(Item.equals("Coffee"))
                  {
                      Conspiracy.TA_MainOutput.append(
                      "\n\n Ahh! It revives you - augmenting" +
                      "\n your health by 10 points!\n");

                      PLAYER.SetHealth(PLAYER.GetHealth() + 10);

                      Conspiracy.CurrentView =
                      INTERFACE.getImage(GAME.Get_Location(
                      "../Images/Caribou_Coffee.jpg"));
                  }

                  FoundItem = true;
                  PLAYER.ShowInventory();
                  Conspiracy.Victory.play();
                  Conspiracy.TA_MainOutput.append(
                  "\n\n Click \"GO\" to continue.");
                  break;

                  case 'n' : Conspiracy.TA_MainOutput.setText(
                             "\n O.k., you decide to leave it be.\n");
                             Conspiracy.TA_MainOutput.append(
                             "\n\n Choose a direction.");
                             break;
                  default: Conspiracy.TA_MainOutput.append(
                           "\n Not an option. YES or NO.");
                 }
             
                 Conspiracy.TF_Input.setText("");
                 Conspiracy.EnableNavigation();
             }
       
          Conspiracy.TF_Input.requestFocus();
          
          return FoundItem;

}//close function

//-----------------------------------------------------------------

       //Lock, UnLock and Check Doors
public static boolean Room_Access(
       String WhatPlayerSees, boolean DoorIsUnlocked, boolean PlayerHasKey)
{
       CHOICE = Conspiracy.TF_Input.getText();

       if(CHOICE.isEmpty() && DoorIsUnlocked)
       {
             Conspiracy.TA_MainOutput.append(
             "\n\n The door is unlocked now. You "+
             "\n may enter the next room.");
             Conspiracy.Door_Open.play();
       }

       else if(CHOICE.isEmpty() && !DoorIsUnlocked && !PlayerHasKey)
       {
             Conspiracy.TA_MainOutput.append(
             "\n\n The door is locked. It will not"+
             "\n budge. If only you had a key...");
             Conspiracy.AirportAnnounce2.play();
       }

       else if(CHOICE.isEmpty() && !DoorIsUnlocked && PlayerHasKey)
       {
           Conspiracy.DisableNavigation();

           Conspiracy.TA_MainOutput.append(
           "\n\n You are standing in front of a\n "
           + WhatPlayerSees + " door. It " +
           "\n looks as though one of the keys" +
           "\n you have will fit the lock.\n" +
           "\n Do you want to try it?" +
           "\n Enter (y)es or (n)o.");
       }

       else
       {
             switch(GF.CHOICE.toLowerCase().charAt(0))
             {
                  case 'y' : Conspiracy.TA_MainOutput.setText(
                             "\n\n You insert the key with anticipation.");
                             Conspiracy.Door_Unlock.play();
                             JOptionPane.showMessageDialog(null,"Click!");
                             DoorIsUnlocked = true;
                             Conspiracy.TA_MainOutput.append(
                             "\n The door opens!\n" +
                             "\n Click \"GO\" to continue.");
                             Conspiracy.Door_Open.play();
                             break;

                  case 'n' : Conspiracy.TA_MainOutput.setText(
                             "\n O.k., you decide not to try it.\n");
                             Conspiracy.TA_MainOutput.append(
                             "\n\n Choose a direction.");
                             break;

                  default: Conspiracy.TA_MainOutput.append(
                           "\n Not even an option.");
             }
             
                 Conspiracy.TF_Input.setText("");
                 Conspiracy.EnableNavigation();
             }
       
          Conspiracy.TF_Input.requestFocus();
          
          return DoorIsUnlocked;

       }

//-----------------------------------------------------------------

public static void Save_Conspiracy()
{
        //Basic process for FILE Access:
        //1. import java.io.*;
        //2. Make file object
        //3. Male FileOutputStream, pass the File object in
        //4. Make PrintStream object, pass the FileOutputStream object

        Conspiracy.TA_MainOutput.append("\n\n  Saving Game...");

        try
        {
           File GameFile = new File(PLAYER.GetName() + ".conspire");
           FileOutputStream OUTPUT = new FileOutputStream(GameFile);
           PrintStream OUT = new PrintStream(OUTPUT);

           //-------------Save-CHARACTER-Data-------------

           //Character Attributes
           OUT.println(PLAYER.GetCharacterClass());
           OUT.println(PLAYER.GetMaxHealth());
           OUT.println(PLAYER.GetMaxDamage());
           OUT.println(PLAYER.GetHealth());
           OUT.println(PLAYER.GetSize());
           OUT.println(PLAYER.GetMass());
           OUT.println(PLAYER.GetAtk());
           OUT.println(PLAYER.GetDef());
           OUT.println(PLAYER.GetSpeed());
           OUT.println(PLAYER.GetExperience());
           OUT.println(PLAYER.GetLevel());
           OUT.println(PLAYER.GetScore());
           OUT.println(PLAYER.GetMoney());
           OUT.println(PLAYER.GetName());
           OUT.println(PLAYER.GetSpecies());
           OUT.println(PLAYER.GetGender());
           OUT.println(PLAYER.GetCharacterClass());
           OUT.println(PLAYER.GetPlayerObject());
           OUT.println(PLAYER.GetAvatarImage());

           //Character Inventory
           OUT.println(PLAYER.GetJackKnife());
           OUT.println(PLAYER.GetSword());
           OUT.println(PLAYER.GetGlock());
           OUT.println(PLAYER.GetStones());
           OUT.println(PLAYER.GetStaff());
           OUT.println(PLAYER.GetVest());
           OUT.println(PLAYER.GetKeyStone());
           OUT.println(PLAYER.GetGlockAmmo());
           OUT.println(PLAYER.GetGrenade());
           OUT.println(PLAYER.GetFlashGrenade());
           OUT.println(PLAYER.GetCoffeePellet());
           OUT.println(PLAYER.GetKeyCard());
           OUT.println(PLAYER.GetKeyLocker());
           OUT.println(PLAYER.GetKeySecurityOffice());
           OUT.println(PLAYER.GetKeyStaffRoom());
           OUT.println(PLAYER.GetSignetRing());

           //Character Weapon Usage
           OUT.println(PLAYER.GetUseFists());
           OUT.println(PLAYER.GetUseKnife());
           OUT.println(PLAYER.GetUseSword());
           OUT.println(PLAYER.GetUseGlock());
           OUT.println(PLAYER.GetUseStaff());
           OUT.println(PLAYER.GetUseGrenade());

           //Character Abilities
           OUT.println(PLAYER.GetShapeShift());
           OUT.println(PLAYER.GetSpaceShift());
           OUT.println(PLAYER.GetTimeShift());
           OUT.println(PLAYER.GetRegenerate());
           OUT.println(PLAYER.GetElectromagnetism());
           OUT.println(PLAYER.GetGravityBend());
           OUT.println(PLAYER.GetSingularity());
           OUT.println(PLAYER.GetEnergy());
           
           //----------------Save-LOCATION-Data----------------
           OUT.println(LOCATION);
           OUT.println(ROW);
           OUT.println(COLUMN);

           //----------------Save-LEVEL-Data----------------
           OUT.println(PLAYERSTURN);
           OUT.println(GAME.GotKeyCard);
           OUT.println(GAME.CIA_Agent_Defeated);
           OUT.println(GAME.Reptillian_Defeated);
           OUT.println(GAME.MasonPassPhrase);
           OUT.println(GAME.ReceivedMasonMission);
           OUT.println(GAME.MasonGivenRing);
           OUT.println(GAME.MasonicSword);
           OUT.println(GAME.KeyRoom_FoundLockerKey);
           OUT.println(GAME.LockerRoom_FoundOfficeKey);
           OUT.println(GAME.LockerCodeEntered);
           OUT.println(GAME.ClosetPassPhrase);
           OUT.println(GAME.Closet_GotStaffKey);
           OUT.println(GAME.PylonBattery_Charged);
           OUT.println(GAME.PylonRoom_FoundStones);
           OUT.println(GAME.Security_FoundAmmo);
           OUT.println(GAME.StaffRoom_FoundStaff);
           OUT.println(GAME.GreyView);
           OUT.println(GAME.JT_00_FoundGrenades);
           OUT.println(GAME.JT_01_FoundSuitCase);
           OUT.println(GAME.JT_01_GivenSuitCase);
           OUT.println(GAME.JT_02_CrossedSwords);
           OUT.println(GAME.JT_03_FoundJackKnife);
           OUT.println(GAME.JT_12_FoundAmmo);
           OUT.println(GAME.JT_20_FoundAmmo);
           OUT.println(GAME.FM_01_GaveGreyBurger);
           OUT.println(GAME.FM_22_FoundKey);
           OUT.println(GAME.FM_42_FoundCoffeePellets);
           OUT.println(GAME.FM_50_FoundAmmo);
           OUT.println(GAME.FM_72_TookCoffee);
           OUT.println(GAME.FM_81_FoundGlock);
           OUT.println(GAME.CU_00_FoundAmmo);
           OUT.println(GAME.CU_41_FoundGrenade);
           OUT.println(GAME.CU_52_FoundCoffeePellets);
           OUT.println(GAME.CU_60_FoundAmmo);
           OUT.println(GAME.CU_72_TookCoffee);
           OUT.println(GAME.CU_81_FoundVest);
           OUT.println(GAME.SW_10_FoundAmmo);
           OUT.println(GAME.SW_10_GotBurger);
           OUT.println(GAME.SW_50_FoundCoffeePellets);
           OUT.println(GAME.SW_61_GateUnlocked);
           OUT.println(GAME.SW_72_TookCoffee);
           OUT.println(GAME.SW_81_FoundKeystone);
           OUT.println(GAME.TRAIN_4_TookCoffee);
           OUT.println(GAME.TRAIN_9_TookCoffee);
           OUT.println(GAME.TRAIN_9_TalkedToLady);
           OUT.println(GAME.TRAIN_9_TookMoney);
           OUT.println(GAME.TRAIN_14_TookCoffee);

           //LEVEL Door and Room Access
           OUT.println(GAME.StaffRoom_DoorUnlocked);
           OUT.println(GAME.SecurityOffice_DoorUnlocked);
           OUT.println(GAME.KeyRoom_DoorUnlocked);
           OUT.println(GAME.CovertOps_DoorUnlocked);
           OUT.println(GAME.Locker_DoorUnlocked);

           //LEVEL Traps
           OUT.println(GAME.SprungTrap_FM_10);
           OUT.println(GAME.SprungTrap_FM_80);
           OUT.println(GAME.SprungTrap_CU_02);
           OUT.println(GAME.SprungTrap_CU_41);
           OUT.println(GAME.SprungTrap_SW_52);

           OUT.close();
           Conspiracy.TA_MainOutput.append(
           "\n  Game Saved Successfully!");
        }

        catch(IOException x)
        {
            Conspiracy.TA_MainOutput.append(
            "\n\n Write Error!" + "\n Can not save game.\n");
        }
}

//-----------------------------------------------------------------

public static void Load_Conspiracy()
{
       String CharacterClass = "UNKNOWN";
       File Conspiracy_File;
       Conspiracy.The_Chooser.setDialogTitle(
       "Conspiracy! - 2010 - Charles Germany:  " +
       "Load a saved Conspiracy!");

       Conspiracy.The_Chooser.setApproveButtonText("Load Conspiracy!");
       Conspiracy.The_Chooser.setBackground(new java.awt.Color(255,255,255));
       Conspiracy.The_Chooser.setForeground(new java.awt.Color(0,0,0));
       Conspiracy.The_Chooser.setFileFilter(new ConspiracyFilter());

       int returnVal = Conspiracy.The_Chooser.showOpenDialog(INTERFACE);

       if(returnVal == JFileChooser.APPROVE_OPTION)
       {
          Conspiracy_File = Conspiracy.The_Chooser.getSelectedFile();
          Conspiracy.TA_MainOutput.setText(
          "Loading " + Conspiracy_File.getName() + "...");

          try
          {
             FileInputStream LF_FIS = new FileInputStream(Conspiracy_File);
             InputStreamReader LF_ISR = new InputStreamReader(LF_FIS);
             BufferedReader LF_BR = new BufferedReader(LF_ISR);

             CharacterClass = LF_BR.readLine();

             switch(CharacterClass.toLowerCase().charAt(0))
             {
                  case 'o' : PLAYER = new Civilian(); break;
                  case 'b' : PLAYER = new FreeMasonBenevolent(); break;
                  case 'f' : PLAYER = new FBI(); break;
                  case 'c' : PLAYER = new CIA(); break;
                  case 'n' : PLAYER = new NSA(); break;
                  case 'm' : PLAYER = new Majestic(); break;
                  default : Conspiracy.TA_MainOutput.append(
                            "\n Invalid species data!"); break;
             }//close inner switch

             //Character Attributes-----------------------------------
             PLAYER.SetMaxHealth(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetMaxDamage(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetHealth(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetSize(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetMass(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetAtk(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetDef(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetSpeed(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetExperience(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetLevel(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetScore(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetMoney(Double.parseDouble(LF_BR.readLine()));
             PLAYER.SetName(LF_BR.readLine());
             PLAYER.SetSpecies(LF_BR.readLine());
             PLAYER.SetGender(LF_BR.readLine());
             PLAYER.SetCharacterClass(LF_BR.readLine());
             PLAYER.SetPlayerObject(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetAvatarImage(Integer.parseInt(LF_BR.readLine()));

             //Character Inventory--------------------------------------
             PLAYER.SetJackKnife(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetSword(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetGlock(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetStones(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetStaff(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetVest(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetKeyStone(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetGlockAmmo(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetGrenade(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetFlashGrenade(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetCoffeePellet(Integer.parseInt(LF_BR.readLine()));
             PLAYER.SetKeyCard(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetKeyLocker(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetKeySecurityOffice(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetKeyStaffRoom(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetSignetRing(Boolean.parseBoolean(LF_BR.readLine()));

             //Character Weapon Usage-----------------------------------
             PLAYER.SetUseFists(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetUseKnife(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetUseSword(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetUseGlock(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetUseStaff(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetUseGrenade(Boolean.parseBoolean(LF_BR.readLine()));

             //Character Abilities--------------------------------------
             PLAYER.SetShapeShift(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetSpaceShift(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetTimeShift(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetRegenerate(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetElectromagnetism(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetGravityBend(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetSingularity(Boolean.parseBoolean(LF_BR.readLine()));
             PLAYER.SetEnergy(Integer.parseInt(LF_BR.readLine()));

             //Initialize LEVEL
             PlayGame();

             //----------LOCATION DATA----------
             LOCATION = Integer.parseInt(LF_BR.readLine());
             ROW = Integer.parseInt(LF_BR.readLine());
             COLUMN = Integer.parseInt(LF_BR.readLine());


             //---------------------LEVEL-Data---------------------
             PLAYERSTURN = Boolean.parseBoolean(LF_BR.readLine());
             GAME.GotKeyCard = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CIA_Agent_Defeated = Boolean.parseBoolean(LF_BR.readLine());
             GAME.Reptillian_Defeated = Boolean.parseBoolean(LF_BR.readLine());
             GAME.MasonPassPhrase = Boolean.parseBoolean(LF_BR.readLine());
             GAME.ReceivedMasonMission = Boolean.parseBoolean(LF_BR.readLine());
             GAME.MasonGivenRing = Boolean.parseBoolean(LF_BR.readLine());
             GAME.MasonicSword = Boolean.parseBoolean(LF_BR.readLine());
             GAME.KeyRoom_FoundLockerKey = Boolean.parseBoolean(LF_BR.readLine());
             GAME.LockerRoom_FoundOfficeKey = Boolean.parseBoolean(LF_BR.readLine());
             GAME.LockerCodeEntered = Boolean.parseBoolean(LF_BR.readLine());
             GAME.ClosetPassPhrase = Boolean.parseBoolean(LF_BR.readLine());
             GAME.Closet_GotStaffKey = Boolean.parseBoolean(LF_BR.readLine());
             GAME.PylonBattery_Charged = Boolean.parseBoolean(LF_BR.readLine());
             GAME.PylonRoom_FoundStones = Boolean.parseBoolean(LF_BR.readLine());
             GAME.Security_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.StaffRoom_FoundStaff = Boolean.parseBoolean(LF_BR.readLine());
             GAME.GreyView = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_00_FoundGrenades = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_01_FoundSuitCase = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_01_GivenSuitCase = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_02_CrossedSwords = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_03_FoundJackKnife = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_12_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.JT_20_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.FM_01_GaveGreyBurger = Boolean.parseBoolean(LF_BR.readLine());
             GAME.FM_22_FoundKey = Boolean.parseBoolean(LF_BR.readLine());
             GAME.FM_42_FoundCoffeePellets = Boolean.parseBoolean(LF_BR.readLine());
             GAME.FM_50_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.FM_72_TookCoffee = Boolean.parseBoolean(LF_BR.readLine());
             GAME.FM_81_FoundGlock = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CU_00_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CU_41_FoundGrenade = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CU_52_FoundCoffeePellets = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CU_60_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CU_72_TookCoffee = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CU_81_FoundVest = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SW_10_FoundAmmo = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SW_10_GotBurger = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SW_50_FoundCoffeePellets = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SW_61_GateUnlocked = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SW_72_TookCoffee = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SW_81_FoundKeystone = Boolean.parseBoolean(LF_BR.readLine());
             GAME.TRAIN_4_TookCoffee = Boolean.parseBoolean(LF_BR.readLine());
             GAME.TRAIN_9_TookCoffee = Boolean.parseBoolean(LF_BR.readLine());
             GAME.TRAIN_9_TalkedToLady = Boolean.parseBoolean(LF_BR.readLine());
             GAME.TRAIN_9_TookMoney = Boolean.parseBoolean(LF_BR.readLine());
             GAME.TRAIN_14_TookCoffee = Boolean.parseBoolean(LF_BR.readLine());

             //LEVEL Door and Room Access------------------------------------
             GAME.StaffRoom_DoorUnlocked = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SecurityOffice_DoorUnlocked = Boolean.parseBoolean(LF_BR.readLine());
             GAME.KeyRoom_DoorUnlocked = Boolean.parseBoolean(LF_BR.readLine());
             GAME.CovertOps_DoorUnlocked = Boolean.parseBoolean(LF_BR.readLine());
             GAME.Locker_DoorUnlocked = Boolean.parseBoolean(LF_BR.readLine());

             //LEVEL Traps---------------------------------------------------
             GAME.SprungTrap_FM_10 = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SprungTrap_FM_80 = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SprungTrap_CU_02 = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SprungTrap_CU_41 = Boolean.parseBoolean(LF_BR.readLine());
             GAME.SprungTrap_SW_52 = Boolean.parseBoolean(LF_BR.readLine());

             Conspiracy.TA_MainOutput.append(
             "\n  Character was successfully loaded!");

             Conspiracy.EnableAllButtons();
             Conspiracy.SelectedAvatar = PLAYER.GetAvatarImage();
             PLAYER.SHOW();
             SEQUENCE();
          }
          catch(IOException e)
          {
                JOptionPane.showMessageDialog(null,"IO ERROR!");
                Conspiracy.TA_MainOutput.setText(
                "\n\n\n  Error loading file!" +
                "\n  Click the load button to try again. ");
                e.printStackTrace();
          }
       }

       else
       {
          Conspiracy.TA_MainOutput.setText(
          "Open command cancelled by user.");
       }

}//close save function

//--------------------------------------------------------------

public static void Combat(final Entity Opponent1, final Entity Opponent2)
{
       //Necessary for multiple threads and Applet refresh
       SwingWorker worker = new SwingWorker()
       {
            public Object construct()
            {
                   CombatRound = 1;
                   Conspiracy.MortalKombat.loop();
                   Conspiracy.Engaged_In_Combat = true;
                   BattleSequence(Opponent1, Opponent2);
                   return 0;
            }

            public void finished()
            {
                   if(Opponent1.GetHealth() > 0)
                      {
                          Opponent1.SetScore(Opponent1.GetScore() + 100);
                          Opponent1.SetExperience(Opponent1.GetExperience() + 1000);
                          Conspiracy.TA_MainOutput.setText(
                          "\n\n    The winner of this battle is:\n    " +
                          Opponent1.GetName() + "!\n\n    " +
                          Opponent2.GetName() + " suffers" + 
                          "\n    humiliating defeat..."      );
                      }

                      else
                      {
                          Opponent2.SetScore(Opponent2.GetScore() + 100);
                          Opponent2.SetExperience(Opponent2.GetExperience() + 1000);
                          Conspiracy.TA_MainOutput.setText(
                          "\n\n    The winner of this battle is:\n    " +
                          Opponent2.GetName() + "!\n\n    " +
                          Opponent1.GetName() + " suffers" +
                          "\n    humiliating defeat..."      );
                      }

                      Conspiracy.MortalKombat.stop();
                      Conspiracy.KungFuFighting.play();
                      PLAYER.SHOW();

                      if(GF.PLAYER.GetHealth() < 1)
                      {
                         Conspiracy.TA_MainOutput.append(
                         "\n\n  You did not survive." +
                         "\n\n  GAME OVER!");
                         Conspiracy.DisableNavigation();
                         Conspiracy.B_Go.setEnabled(false);
                      }
                      else
                      {
                          Conspiracy.L_ConspiracyLogo.setIcon(
                          new javax.swing.ImageIcon(
                          getClass().getResource(
                          "../Images/StickFigure.png")));

                          Conspiracy.TA_MainOutput.append(
                         "\n\n  Click \"GO\" or \"LOOK\"" +
                         "\n  to continue...");
                      }

                      Conspiracy.Engaged_In_Combat = false;
                      INTERFACE.repaint();
                      GF.WAIT(5);
            }
            };

            worker.start();
}

//--------------------------------------------------------------

    public static void BattleSequence(Entity Opponent1, Entity Opponent2)
    {
           IMPROBABILITY = new Random();
           int FirstAttack = 0;

           Conspiracy.TA_MainOutput.setBackground(
           new java.awt.Color(0, 0, 0));

           while(Opponent1.GetHealth() > 0 && Opponent2.GetHealth() > 0)
           {
                 Conspiracy.TA_MainOutput.setFont(
                 new Font("Chiller", Font.PLAIN, 50));
                 Conspiracy.TA_MainOutput.setForeground(Color.red);
                 
                 Conspiracy.TA_MainOutput.setText(
                 "\n   Total " +
                 "\n   Mortal" +
                 "\n   Combat!" +
                 "\n   Round " +
                 CombatRound + "!\n");

                 WAIT(3);

                 FirstAttack = IMPROBABILITY.nextInt(10) + 1;

                 if(Opponent1.GetSpeed() > Opponent2.GetSpeed())
                 { FirstAttack = FirstAttack + 2; }
                 else { FirstAttack = FirstAttack - 2; }

                 Conspiracy.TA_MainOutput.setFont(
                 new Font("Tahoma", Font.PLAIN, 30));
                 Conspiracy.TA_MainOutput.setForeground(Color.orange);

                 if(FirstAttack > 5)
                 {
                      Conspiracy.TA_MainOutput.setText(
                      "  Due to a" +
                      "\n  combination" +
                      "\n  of SPEED and" +
                      "\n  CHANCE:\n  " +
                      Opponent1.GetName() +
                      "\n  makes the" +
                      "\n  FIRST\n  ATTACK!");

                      WAIT(4);

                      Conspiracy.TA_MainOutput.setFont(
                      new Font("Comic Sans MS", Font.PLAIN, 13));
                      Conspiracy.TA_MainOutput.setForeground(Color.white);

                      if(Opponent1.GetHealth() > 0)
                      {
                         if(Opponent1.GetPlayerObject())
                         { PLAYERSTURN = true; }
                         Opponent1.Attack(Opponent2);
                         INTERFACE.repaint();
                         PLAYERSTURN = false;
                         WAIT(2);
                      }

                      if(Opponent2.GetHealth() > 0)
                      {
                         Conspiracy.TA_MainOutput.setFont(
                         new Font("Tahoma", Font.PLAIN, 30));
                         Conspiracy.TA_MainOutput.setForeground(Color.orange);

                         Conspiracy.TA_MainOutput.setText(
                         "\n  " + Opponent2.GetName() +
                         "\n  survives the" +
                         "\n  ONSLAUGHT\n  and" +
                         "\n  COUNTER\n  ATTACKS!");

                         WAIT(3);

                         Conspiracy.TA_MainOutput.setFont(
                         new Font("Comic Sans MS", Font.PLAIN, 13));
                         Conspiracy.TA_MainOutput.setForeground(Color.white);

                         if(Opponent2.GetPlayerObject())
                         { PLAYERSTURN = true; }
                         Opponent2.Attack(Opponent1);
                         INTERFACE.repaint();
                         PLAYERSTURN = false;
                         WAIT(2);
                      }

                 }
                 else
                 {
                      Conspiracy.TA_MainOutput.setText(
                      "  Due to a" +
                      "\n  combination" +
                      "\n  of SPEED and" +
                      "\n  CHANCE:\n  " +
                      Opponent2.GetName() +
                      "\n  makes the" +
                      "\n  FIRST\n  ATTACK!");

                      WAIT(4);

                      Conspiracy.TA_MainOutput.setFont(
                      new Font("Comic Sans MS", Font.PLAIN, 13));
                      Conspiracy.TA_MainOutput.setForeground(Color.white);

                      if(Opponent2.GetHealth() > 0)
                      {
                         if(Opponent2.GetPlayerObject())
                         { PLAYERSTURN = true; }
                         Opponent2.Attack(Opponent1);
                         INTERFACE.repaint();
                         PLAYERSTURN = false;
                         WAIT(2);
                      }

                       if(Opponent1.GetHealth() > 0)
                       {
                         Conspiracy.TA_MainOutput.setFont(
                         new Font("Tahoma", Font.PLAIN, 34));
                         Conspiracy.TA_MainOutput.setForeground(Color.orange);

                         Conspiracy.TA_MainOutput.setText(
                         "\n  " + Opponent1.GetName() +
                         "\n  survives the" +
                         "\n  ONSLAUGHT\n  and" +
                         "\n  COUNTER\n  ATTACKS!");

                         WAIT(3);

                         Conspiracy.TA_MainOutput.setFont(
                         new Font("Comic Sans MS", Font.PLAIN, 13));
                         Conspiracy.TA_MainOutput.setForeground(Color.white);

                         if(Opponent1.GetPlayerObject())
                         { PLAYERSTURN = true; }
                         Opponent1.Attack(Opponent2);
                         INTERFACE.repaint();
                         PLAYERSTURN = false;
                         WAIT(2);
                       }

                   }

                 CombatRound++;
             }

             Conspiracy.TA_MainOutput.setForeground(
             new java.awt.Color(0, 0, 0));
             Conspiracy.TA_MainOutput.setBackground(
             new java.awt.Color(255, 255, 255));
    }

//--------------------------------------------------------------

public static void WAIT(int SECONDS)
{
       try { Thread.sleep(SECONDS * 1000); }
       catch(Exception e) {
       Conspiracy.TA_MainOutput.setText("WAIT problem."); }
}

//--------------------------------------------------------------

public static void AUTOSCROLL()
{
   Conspiracy.TA_MainOutput.setCaretPosition(
   Conspiracy.TA_MainOutput.getDocument().getLength());
}

//--------------------------------------------------------------

public static void TRAP()
{
       //Necessary for multiple threads and Applet refresh
       SwingWorker worker = new SwingWorker()
       {
            public Object construct()
            {
                   Trap_Sequence();
                   return 0;
            }

            public void finished()
            {    }
            };

            worker.start();
}

//--------------------------------------------------------------

public static void Trap_Sequence()
{
       int BLAST = 0;
       int BlastDamage = 0;

       Conspiracy.TA_MainOutput.setText(
       "\n You step onto a trip" +
       "\n mine. It activates...\n");

       Conspiracy.Ticking.play();
       
       WAIT(2);
       
       IMPROBABILITY = new Random();

       BLAST = IMPROBABILITY.nextInt(10) + 1;

       if(BLAST < 4)
       {
           Conspiracy.TA_MainOutput.append(
           "\n Somehow, by pure blind luck" +
           "\n you manage to avoid blast" +
           "\n damage...");
       }
       else
       {
           Conspiracy.TA_MainOutput.append(
           "\n Shrapnel bursts into the" +
           "\n air and tears through your" +
           "\n quivering flesh!\n");

           Conspiracy.GrenadeSound.play();

           WAIT(2);

           BlastDamage = IMPROBABILITY.nextInt(50) + 1;

           if(PLAYER.GetHealth() - BlastDamage > 0)
           {
              Conspiracy.TA_MainOutput.append(
              "\n The resulting trauma" +
              "\n inflicts " + BlastDamage +
              " points of damage" +
              "\n to your health!");

              PLAYER.SetHealth(PLAYER.GetHealth() - BlastDamage);
              PLAYER.Display();
           }
           else
           {
              Conspiracy.TA_MainOutput.append(
              "\n\n  You did not survive." +
              "\n\n  GAME OVER!");
              Conspiracy.DisableNavigation();
              Conspiracy.B_Go.setEnabled(false);
           }

       }
}

//--------------------------------------------------------------

public static void RandomCombat()
{
       //Necessary for multiple threads and Applet refresh
       SwingWorker worker = new SwingWorker()
       {
            public Object construct()
            {
                   Random_Combat_Sequence();
                   return 0;
            }

            public void finished()
            {    }
            };

            worker.start();
}

//--------------------------------------------------------------

public static void Random_Combat_Sequence()
{
       IMPROBABILITY = new Random();
       Entity HOSTILE = new Entity();

       Conspiracy.TA_MainOutput.append(
       "\n\n You encounter a random combatant!\n");

       WAIT(3);

       int LUCK = IMPROBABILITY.nextInt(2) + 1;

       if(LUCK < 2)
       {
           LUCK = IMPROBABILITY.nextInt(5) + 1;

           switch(LUCK)
           {
               case 1: Conspiracy.TA_MainOutput.append(
                       "\n It's a hostile grey!");
                       HOSTILE = new Gray();
                       break;
               case 2: Conspiracy.TA_MainOutput.append(
                       "\n It's an angry Reptilian!");
                       HOSTILE = new Reptilian();
                       break;
               case 3: Conspiracy.TA_MainOutput.append(
                       "\n It's an evil Luciferian!");
                       HOSTILE = new Luciferian();
                       break;
               case 4: Conspiracy.TA_MainOutput.append(
                       "\n It's a diabolical Illuminati!");
                       HOSTILE = new Illuminati();
                       break;
               case 5: Conspiracy.TA_MainOutput.append(
                       "\n It's an eerie Abductor!");
                       HOSTILE = new Abductor();
                       break;
           }

           HOSTILE.SetName("Hostile");
           HOSTILE.SetGender("Male");
           HOSTILE.SetHealth(50);
           
           WAIT(5);

           Combat(PLAYER,HOSTILE);
       }
       else
       {
           Conspiracy.TA_MainOutput.append(
           "\n Your opponent flees the scene...");
       }
}

}//close class
