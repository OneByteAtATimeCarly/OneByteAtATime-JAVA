package GameFunctions;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JLabel;

public class HYPERLINK extends JLabel implements MouseListener {

	private static final long serialVersionUID = 1L;
	private URI uri = null;

	public HYPERLINK( String text, String uri ) {

		this.setText( "<html><u>" + text + "</u></html>" );

		try {

			this.uri = new URI( uri );

		} catch (URISyntaxException e) {

			e.printStackTrace();

		}

		initialize();

	} // end constructor

	public URI getURI() {

		return uri;

	} // end method getURI

	private void initialize() {

		this.setForeground( Color.RED );
                this.setFont(new java.awt.Font("Comic Sans MS", 0, 14));
		this.setOpaque( false );
		this.setToolTipText( getURI().toString() );
		this.addMouseListener( this );

	} // end method initialize

	@Override
	public void mouseClicked(MouseEvent e) {

		if ( e.getClickCount() > 0 ) {

			if ( Desktop.isDesktopSupported() ) {

				Desktop desktop = Desktop.getDesktop();

				try {

					desktop.browse( getURI() );

				} catch ( IOException ex ) {

					ex.printStackTrace();

				}

			}

		}

	} // end method mouseClicked

	@Override
	public void mouseEntered(MouseEvent arg0) {

		this.setCursor( Cursor.getPredefinedCursor( Cursor.HAND_CURSOR ) );

	} // end method mouseEntered

	@Override
	public void mouseExited(MouseEvent arg0) {

		this.setCursor( Cursor.getPredefinedCursor( Cursor.DEFAULT_CURSOR ) );

	} // end method mouseExited

	@Override
	public void mousePressed(MouseEvent arg0) {

		this.setForeground( Color.RED );
		this.setCursor( Cursor.getPredefinedCursor( Cursor.WAIT_CURSOR ) );

	} // end method mousePressed

	@Override
	public void mouseReleased(MouseEvent arg0) {

		this.setForeground( Color.BLUE );
		this.setCursor( Cursor.getPredefinedCursor( Cursor.DEFAULT_CURSOR ) );

	} // end method mouseReleased

} // end class JHyperlink
