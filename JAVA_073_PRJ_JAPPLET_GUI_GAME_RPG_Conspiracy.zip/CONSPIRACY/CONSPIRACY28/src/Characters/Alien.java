package Characters;
import Interface.*;

//ADT - extends Entity

public class Alien extends Entity
{
       public Alien()
       { Conspiracy.TA_MainOutput.append("\n\tCreating an Alien."); }
}
