package Characters;
import Interface.*;

public class Government extends Human
{
       public Government()
       { Conspiracy.TA_MainOutput.append("\n Building a Government."); }
}
