package Characters;
import Interface.*;

public class Majestic extends Government
{
       public Majestic()
       {
           Conspiracy.TA_MainOutput.append("\n Creating a Majestic object.");
           SetCharacterClass("Majestic");
       }
}