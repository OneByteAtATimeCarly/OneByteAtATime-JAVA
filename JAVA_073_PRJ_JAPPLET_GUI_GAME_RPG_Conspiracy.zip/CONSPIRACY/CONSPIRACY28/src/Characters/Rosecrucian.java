package Characters;
import Interface.*;

//Object class extends FreeMasonMalevolent

public class Rosecrucian extends FreeMasonMalevolent
{
       public Rosecrucian()
       { 
           Conspiracy.TA_MainOutput.append("\n\tBuilding a Malevolent Masonic Rosecrucian.");
           SetCharacterClass("Rosecrucian");
       }
}
