package Characters;
import Interface.*;

//Object extends Abductor

public class Reptilian extends AlienMalevolent
{
       public Reptilian()
       { 
           Conspiracy.TA_MainOutput.append("\n\tCreating an Alien Reptilian.");
           SetCharacterClass("Reptilian");
       }

       public Reptilian(String NAME)
       {
           Conspiracy.TA_MainOutput.append("\n Creating a Reptilian object.");
           SetCharacterClass("Reptilian");
           SetName(NAME);
       }
}