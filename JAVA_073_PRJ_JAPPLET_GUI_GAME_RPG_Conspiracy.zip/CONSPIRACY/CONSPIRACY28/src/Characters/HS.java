package Characters;
import Interface.*;


public class HS extends Government
{
       public HS()
       {
           Conspiracy.TA_MainOutput.append("\n\tCreating a HomelandSecurity object.");
           SetCharacterClass("Homeland Security");
       }
}
