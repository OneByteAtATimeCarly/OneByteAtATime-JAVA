package Characters;
import Interface.*;

//ADT - extends Entity

public class FreeMason extends Entity
{
       public FreeMason()
       { Conspiracy.TA_MainOutput.append("\n Creating an FreeMason."); }
}