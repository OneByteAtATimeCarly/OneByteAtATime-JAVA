package Characters;
import Interface.*;

//Object extends Military

public class Area51 extends Government
{
       public void Area51()
       { 
           Conspiracy.TA_MainOutput.append("\n\tCreating an Area51 scientist.");
           SetCharacterClass("Area51");
       }
}