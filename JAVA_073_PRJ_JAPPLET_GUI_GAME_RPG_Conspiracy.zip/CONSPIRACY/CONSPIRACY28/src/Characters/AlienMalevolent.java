package Characters;
import Interface.*;

//ADT - extends Alien

public class AlienMalevolent extends Alien
{
       public AlienMalevolent()
       { Conspiracy.TA_MainOutput.append("\n\tCreating an AlienMalevolent."); }
}