package Characters;
import Interface.*;

//Object class extends FreeMasonBenevolent

public class Watcher extends FreeMasonBenevolent
{
       public Watcher()
       { 
           Conspiracy.TA_MainOutput.append("\n\tBuilding a Benevolent Masonic Watcher.");
           SetCharacterClass("Watcher");
       }
}
