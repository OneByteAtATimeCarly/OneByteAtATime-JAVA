package Characters;
import Interface.*;

//ADT extends AlienMalevolent

public class Abductor extends AlienMalevolent
{
       public Abductor()
       { Conspiracy.TA_MainOutput.append("\n\tCreating an Abductor."); }
}
