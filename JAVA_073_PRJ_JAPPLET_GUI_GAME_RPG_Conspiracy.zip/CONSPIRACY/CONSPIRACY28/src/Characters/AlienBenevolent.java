package Characters;
import Interface.*;

//ADT - extends Alien

public class AlienBenevolent extends Alien
{
       public AlienBenevolent()
       { Conspiracy.TA_MainOutput.append("\n\tCreating an AlienBenevolent."); }
}
