//ADT superclass for all object in hiearchy

package Characters;

import GameFunctions.GF;
import Interface.*;
import java.util.Random;

public class Entity
{
       //Globals
       public static final int GrenadeDamage = 75;
       public boolean Wearing = false;
       public int damage = 0;
       public boolean AttackWindow = false;

       //OVERLOADED constructors
//------------------------------------------------------------
       public Entity()
       {
              Conspiracy.TA_MainOutput.append("\n Building a superclass ADT Entity.");
              Initialize();
              NAME = "Anonymous Entity";
       }
//------------------------------------------------------------
       public Entity(String x)
       {
              Conspiracy.TA_MainOutput.append("\n Building a superclass ADT Entity\n  object.");
              Initialize();
              NAME = x;
       }
//------------------------------------------------------------

       public Entity(String n, int h, int a, int d)
       {
              Conspiracy.TA_MainOutput.append("\n Building a superclass ADT Entity\n  object.");
              Initialize();
              NAME = n;
              health = h;
              atk = a;
              def = d;
       }

//------------------------------------------------------------
       public void Initialize()
       {
              PlayerObject = false;

              //Stats
              MaxHealth = 100;
              MaxDamage = 25;
              health = MaxHealth;
              size = 10;
              mass = 10;
              atk = 1;
              def = 1;
              speed = 5;
              experience = 0;
              score = 0;
              level = 1;
              money = 0.0;
              species = "Undefined Entity";
              gender = "Udefined Sex";
              characterclass = "Undefined Class";

              //Inventory
              JackKnife = false;      
              Glock = false;
              GlockAmmo = 0;
              TitaniumStaff = false;
              Sword = false;
              Grenade = 0;
              FlashGrenade = 0;
              CoffeePellets = 0;
              KevlarVest = false;
              Stones = false;
              KeyStone = false;              
              Key_Card = false;
              Key_Locker = false;
              Key_SecurityOffice = false;
              Key_StaffRoom = false;
              SignetRing = false;

              //Weapons Use
              UseFists = true;
              UseKnife = false;
              UseGlock = false;
              UseStaff = false;
              UseSword = false;
              UseGrenade = false;

              //Abilities
              Shape_Shift = false;
              Space_Shift = false;
              Time_Shift = false;
              Regenerate = false;
              Electromagnetism = false;
              GravityBend = false;
              Singularity = false;
              ENERGY = 0;
              AvatarImage = 0;
       }

//------------------------------------------------------------

       public void CHEAT()
       {
              Conspiracy.TA_MainOutput.append("\n Activating Cheat!");

              //Stats
              health = 1000;
              size = 10;
              mass = 10;
              atk = 10;
              def = 10;
              speed = 50;
              experience = 10000;
              score = 10000;
              level = 10;
              money = 1000000.0;
              species = "Super Being";
              characterclass = "Hero";

              //Inventory
              JackKnife = true;
              Glock = true;
              GlockAmmo = 1000;
              TitaniumStaff = true;
              Sword = true;
              Grenade = 1000;
              FlashGrenade = 1000;
              CoffeePellets = 1000;
              KevlarVest = true;
              Stones = true;
              KeyStone = true;          
              Key_Card = true;
              Key_Locker = true;
              Key_SecurityOffice = true;
              Key_StaffRoom = true;
              SignetRing = true;

              //Abilities
              Shape_Shift = true;
              Space_Shift = true;
              Time_Shift = true;
              Regenerate = true;
              Electromagnetism = true;
              GravityBend = true;
              Singularity = true;
              ENERGY = 10000;

              Conspiracy.RB_Fists.setEnabled(true);
              Conspiracy.RB_JackKnife.setEnabled(true);
              Conspiracy.RB_Glock.setEnabled(true);
              Conspiracy.RB_Sword.setEnabled(true);
              Conspiracy.RB_Staff.setEnabled(true);

              SHOW();
       }

//------------------------------------------------------------

       public void LEVEL()
       {
              if(experience < 1000) { level = 1; }
              else if(experience > 999 && experience < 2000) {level = 2;}
              else if(experience > 1999 && experience < 3000) {level = 3;}
              else if(experience > 2999 && experience < 4000) {level = 4;}
              else if(experience > 3999 && experience < 5000) {level = 5;}
              else if(experience > 4999 && experience < 6000) {level = 6;}
              else if(experience > 5999 && experience < 7000) {level = 7;}
              else if(experience > 6999 && experience < 8000) {level = 8;}
              else if(experience > 7999 && experience < 9000) {level = 9;}
              else if(experience > 8999 && experience < 10000) {level = 10;}
       }

//------------------------------------------------------------

       public void SHOW()
       {
              Display();
              ShowInventory();
              ShowWeapons();
              ShowAbilities();
       }

//------------------------------------------------------------

       public void Display()
       {
              Conspiracy.L_NameBox.setText(NAME);
              Conspiracy.L_GenderBox.setText(gender);
              Conspiracy.L_SpeciesBox.setText(species);
              Conspiracy.L_ClassBox.setText(characterclass);
              Conspiracy.L_SizeBox.setText(Integer.toString(size));
              Conspiracy.L_HealthBox.setText(Integer.toString(health));
              Conspiracy.JPB_HealthBar.setValue(health);
              Conspiracy.L_AttackBox.setText(Integer.toString(atk));
              Conspiracy.L_DefenseBox.setText(Integer.toString(def));
              Conspiracy.L_SpeedBox.setText(Integer.toString(speed));
              Conspiracy.L_MassBox.setText(Integer.toString(mass));
              Conspiracy.L_LevelBox.setText(Integer.toString(level));
              Conspiracy.L_ExperienceBox.setText(Integer.toString(experience));
              Conspiracy.L_MoneyBox.setText(Double.toString(money));
              Conspiracy.L_ScoreBox.setText(Integer.toString(score));
              Conspiracy.L_EnergyBox.setText(Integer.toString(ENERGY));
       }

//------------------------------------------------------------

public void ShowInventory()
{                         
       String[] INVENTORY =
   //0    1   2   3   4   5   6   7   8   9  10  11  12   13   14  15 
   {" "," "," "," "," "," "," "," "," "," "," "," "," ", " ", " ", " "};

       int x = 0;

       if(!JackKnife && !Sword && !Glock && !Glock && !Stones &&
          !TitaniumStaff && !KevlarVest && !KeyStone && !Key_Card &&
          !Key_Locker && !KeyStone && (GlockAmmo < 1) && (Grenade < 1) &&
          (FlashGrenade < 1))
       {
          INVENTORY[x] = "No Items Yet!";
       }
       else
       {
          if(JackKnife)
          {   INVENTORY[x] = (x+1) + ". Jack Knife"; x++; }

          if(Sword)
          {   INVENTORY[x] = (x+1) + ". Sword"; x++; }

          if(Glock)
          {   INVENTORY[x] = (x+1) + ". Glock"; x++; }

          if(GlockAmmo > 0)
          {   INVENTORY[x] = (x+1) + ". G Ammo: " + GlockAmmo; x++; }

          if(TitaniumStaff)
          {   INVENTORY[x] = (x+1) + ". Power Staff"; x++; }

          if(Grenade > 0)
          {   INVENTORY[x] = (x+1) + ". Grenades: " + Grenade; x++; }

          if(FlashGrenade > 0)
          {   INVENTORY[x] = (x+1) + ". Flash Bang: " + FlashGrenade; x++; }

          if(CoffeePellets > 0)
          {   INVENTORY[x] = (x+1) + ". Coffee Plts: " + CoffeePellets; x++; }

          if(KevlarVest)
          {   INVENTORY[x] = (x+1) + ". Kevlar Armor"; x++; }

          if(Stones)
          {   INVENTORY[x] = (x+1) + ". Power Stones"; x++; }

          if(SignetRing)
          {   INVENTORY[x] = (x+1) + ". Signet Ring"; x++; }

          if(KeyStone)
          {   INVENTORY[x] = (x+1) + ". Key Stone"; x++; }

          if(Key_Card)
          {   INVENTORY[x] = (x+1) + ". Key Card"; x++; }

          if(Key_Locker)
          {   INVENTORY[x] = (x+1) + ". Key = Locker"; x++; }

          if(Key_SecurityOffice)
          {   INVENTORY[x] = (x+1) + ". Key = SecOff"; x++; }

          if(Key_StaffRoom)
          {   INVENTORY[x] = (x+1) + ". Key = StaffRm"; x++; }
         
       }

       Conspiracy.L_AmmoBox.setText(Integer.toString(GlockAmmo));
       Conspiracy.JL_Inventory.setListData(INVENTORY);
       Conspiracy.JL_Inventory.setSelectedIndex(0);
}

//------------------------------------------------------------

       public void ShowWeapons()
       {
              Conspiracy.RB_Fists.setEnabled(true); //always

              if(JackKnife) { Conspiracy.RB_JackKnife.setEnabled(true); }
              else { Conspiracy.RB_JackKnife.setEnabled(false); }

              if(Glock) { Conspiracy.RB_Glock.setEnabled(true); }
              else { Conspiracy.RB_Glock.setEnabled(false); }

              if(TitaniumStaff) { Conspiracy.RB_Staff.setEnabled(true); }
              else { Conspiracy.RB_Staff.setEnabled(false); }

              if(Sword) { Conspiracy.RB_Sword.setEnabled(true); }
              else { Conspiracy.RB_Sword.setEnabled(false); }
       }

//------------------------------------------------------------

public void ShowAbilities()
{
       int x = 0;

       Conspiracy.CB_Abilities.removeAllItems();

       if(!Shape_Shift && !Space_Shift && !Time_Shift && !Regenerate &&
          !Electromagnetism && !GravityBend && !Singularity)
       {
           Conspiracy.CB_Abilities.addItem("No Abilities");
       }
       else
       {
          Conspiracy.CB_Abilities.addItem("Abilities");

          if(Shape_Shift)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Shape Shift"); x++; }

          if(Space_Shift)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Space Shift"); x++; }

          if(Time_Shift)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Time Shift"); x++; }

          if(Regenerate)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Regenerate"); x++; }

          if(Electromagnetism)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Electromagnetism"); x++; }

          if(GravityBend)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Gravity Bend"); x++; }

          if(Singularity)
          { Conspiracy.CB_Abilities.addItem((x+1) + ". Singularity"); x++; }
    }

          Conspiracy.L_EnergyBox.setText(Integer.toString(ENERGY));

          Conspiracy.JL_Inventory.setSelectedIndex(0);
}

//------------------------------------------------------------

       //Functions
       public void Eat() {  Conspiracy.TA_MainOutput.append("\n Eating..."); }

//------------------------------------------------------------

       public void PureLuck()
       {
              int LUCKY = GF.IMPROBABILITY.nextInt(2) + 1;
              if(LUCKY == 1)
              { AttackWindow = true; }
              GF.WAIT(1);
              AttackWindow = false;
       }


       public void Attack(Entity x)
       {
              SHOW();
              Conspiracy.TA_MainOutput.setText(
              "\n " + NAME + " attacks " + x.GetName() + "!\n");
              Conspiracy.TA_MainOutput.append(
              "\n -------------Before Attack-------------");
              Conspiracy.TA_MainOutput.append(
              "\n " + NAME + ": " + health);
              Conspiracy.TA_MainOutput.append(
              "\n " + x.GetName() + ": " + x.GetHealth());
              Conspiracy.TA_MainOutput.append(
              "\n ------------------------------------------");

              GF.AUTOSCROLL(); GF.WAIT(3);
   
              damage = GF.IMPROBABILITY.nextInt(MaxDamage) + 1;

              Conspiracy.TA_MainOutput.append(
              "\n\n Damage generated by blind chance"
              + "\n and wavering circumstance = "
              + damage + ".\n");
              GF.AUTOSCROLL(); GF.WAIT(1);

              PureLuck();

              //Add strength of attacker
              Conspiracy.TA_MainOutput.append(
              "\n Adding " + atk + " to damage due to\n " +
              NAME + "'s ATK skill.");
              damage = damage + atk;
              GF.AUTOSCROLL(); GF.WAIT(1);

              PureLuck();

              //Subtract defense of Attackee
              Conspiracy.TA_MainOutput.append(
              "\n\n Subtracting " + x.GetDef() +
              " from damage due to\n " + x.GetName() +
              "'s DEF skill.\n");
              damage = damage - x.GetDef();
              GF.AUTOSCROLL(); GF.WAIT(1);

              PureLuck();

              damage = UseWeapons(damage);
              UseAbilities();
              GF.AUTOSCROLL(); GF.WAIT(2);

              PureLuck();

              //Incorporate mass with chance attack of greater damage
              int HeavyBlow = GF.IMPROBABILITY.nextInt(mass) + 1;
              if(HeavyBlow > 4)
              {
                  Conspiracy.TA_MainOutput.append(
                  "\n\n Heavy Attack due to mass!");
                  HeavyBlow = GF.IMPROBABILITY.nextInt(mass) + 1;
                  Conspiracy.TA_MainOutput.append(
                  "\n Mass increases damage by " + HeavyBlow + ".");
                  damage = damage + HeavyBlow;
                  GF.AUTOSCROLL(); GF.WAIT(1);
              }

              PureLuck();

              //Incorporate speed into damage
              int ExtraAttack = GF.IMPROBABILITY.nextInt(speed) + 1;
              if(ExtraAttack > 4)
              {
                  Conspiracy.TA_MainOutput.append(
                  "\n\n Due to speed, " +
                  NAME + "\n makes a sneak attack!");
                  ExtraAttack = GF.IMPROBABILITY.nextInt(speed) + 1;
                  Conspiracy.TA_MainOutput.append(
                  "\n\n The sneak attack inflicts\n " +
                  ExtraAttack + " more damage.");
                  damage = damage + ExtraAttack;
                  GF.AUTOSCROLL(); GF.WAIT(1);
              }

              PureLuck();

              Conspiracy.TA_MainOutput.append(
              "\n\n Final damage inflicted = \n " +
              damage + " points!");
              GF.AUTOSCROLL(); GF.WAIT(1);

              PureLuck();

              //Subtract damage from health
              if(x.GetHealth() - damage > 0)
              { x.SetHealth(x.GetHealth() - damage); }
              else { x.SetHealth(0); }

              Conspiracy.TA_MainOutput.append(
              "\n\n -------------After Attack-------------");
              Conspiracy.TA_MainOutput.append(
              "\n " + NAME + ": " + health);
              Conspiracy.TA_MainOutput.append(
              "\n " + x.GetName() + ": " + x.GetHealth());
              Conspiracy.TA_MainOutput.append(
              "\n -----------------------------------------");

              Conspiracy.L_HealthBox.setText(Integer.toString(health));
              Conspiracy.JPB_HealthBar.setValue(health);
              GF.AUTOSCROLL(); GF.WAIT(2);
       }

//------------------------------------------------------------

       public int UseWeapons(int damage)
       {
              if(UseFists)
              { 
                  Conspiracy.TA_MainOutput.append(
                  "\n " + NAME + " attacks with" + 
                  "\n FISTS of FURY!");
                  damage = damage + 1;
                  Conspiracy.Punch.play();
              }

              if(UseKnife)
              { 
                 Conspiracy.TA_MainOutput.append(
                 "\n " + NAME + " stabs with the" +
                 "\n KNIFE! The supple blade" +
                 "\n slices into flesh adding" +
                 "\n 2 points of damage.");
                 damage = damage + 2;
                 Conspiracy.Stab.play();
              }

              if(UseGlock)
              {
                 if(GlockAmmo > 0)
                 {
                    Conspiracy.TA_MainOutput.append(
                    "\n " + NAME + " fires the GLOCK!" +
                    "\n Bullets tear through flesh" +
                    "\n adding 4 points of damage.");
                    damage = damage + 4;
                    GlockAmmo = GlockAmmo - 1;
                    Conspiracy.GlockFire.play();
                 }
                 else
                 {
                    Conspiracy.TA_MainOutput.append(
                    "\n " + NAME + " fires the GLOCK" +
                    "\n but has no ammo and must" +
                    "\n resort to hand to hand combat!");
                 }
              }

              if(UseStaff)
              {
                 Conspiracy.TA_MainOutput.append(
                 "\n " + NAME + " uses the Power" +
                 "\n Staff! A bright flash" +
                 "\n vaporizes the atmosphere" +
                 "\n adding 6 points of damage.");
                 damage = damage + 6;
                 Conspiracy.StaffFire.play();
              }

              if(UseSword)
              {
                 Conspiracy.TA_MainOutput.append(
                 "\n " + NAME + " attacks with the" +
                 "\n Sword of Omens! A quivering" +
                 "\n blade slices into the air" +
                 "\n adding 8 points of damage.");
                 damage = damage + 8;
                 Conspiracy.SwordSwish.play();
              }

              if(UseGrenade)
              {
                 Conspiracy.TA_MainOutput.append(
                 "\n Boom! " + NAME + " tosses" +
                 "\n a fragmentation grenade" +
                 "\n into the fray! Total mayhem" +
                 "\n adding 75 points of damage.");
                 damage = damage + 75;
                 Conspiracy.GrenadeSound.play();
              }

              return damage;
       }

 //------------------------------------------------------------

       public void UseAbilities()
       {
              String CHOICE = " ";
              Object TEMP = Conspiracy.CB_Abilities.getSelectedItem();
              if(TEMP != null) 
              {
                  CHOICE = TEMP.toString();
                  CHOICE = CHOICE.substring(3);
              }
              else { CHOICE = " "; }

              if(CHOICE.equals("Shape Shift"))
              {  //Check ENERGY cost
                 if(ENERGY > 1)
                 {
                    Conspiracy.TA_MainOutput.append(
                    "\n " + NAME + " summons the power\n to Shape Shift!");
                
                    if(size < 3)
                    {
                      Conspiracy.TA_MainOutput.append(
                      "\n You return yourself to\n your normal size.");
                      size = 10;
                    }
                    else
                    {
                      Conspiracy.TA_MainOutput.append(
                      "\n You shrink yourself to\n the size of a mouse.");
                      size = 2;
                    }

                    ENERGY = ENERGY - 2;
                    Conspiracy.ShapeShiftSound.play();
                  }
                  else
                  {
                     Conspiracy.TA_MainOutput.append(
                     "\n Although you possess the ability," +
                     "\n you do not have enough energy" +
                     "\n ShapeShift. You revert to your" +
                     "\n natural form.");
                     size = 10;
                  }
              }

              if(CHOICE.equals("Space Shift"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME +
                " summons the power\n to Space Shift!"); }

              if(CHOICE.equals("Time Shift"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME +
              " summons the power\n to Time Shift!"); }

              if(CHOICE.equals("Regenerate"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME +
              " summons the power\n to Regenerate!"); }

              if(CHOICE.equals("Electromagnetism"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME +
              " summons the power\n of Electromagnetism!"); }

              if(CHOICE.equals("Gravity Bend"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME +
              " summons the power\n to Bend Gravity!"); }

              if(CHOICE.equals("Singularity"))
              { Conspiracy.TA_MainOutput.append("\n " + NAME +
              " summons the power\n to create a Singularity!"); }

              Display();
       }

 //------------------------------------------------------------
       
       public void UseInventory()
       {
              String CHOICE = "";
              Object TEMP = Conspiracy.JL_Inventory.getSelectedValue();

              //BulletProofing...
              if(TEMP != null) { CHOICE = TEMP.toString(); }
              if(CHOICE.length() > 3) { CHOICE = CHOICE.substring(3); }
              
          //-------------------------------------------
              if(CHOICE.equals("Jack Knife"))
              {
                  Conspiracy.TA_MainOutput.append(
                  "\n\n You equip yourself with the" +
                  "\n incredibly long Jack Knife.");
                  Conspiracy.RB_JackKnife.setEnabled(true);
                  //Conspiracy.RB_JackKnife.setSelected(true);
                  Conspiracy.RB_JackKnife.doClick();
              }
          //-------------------------------------------
              if(CHOICE.equals("Sword"))
              {
                  Conspiracy.TA_MainOutput.append(
                  "\n\n You equip yourself with the" +
                  "\n Sword of Omens!");
                  Conspiracy.RB_Sword.setEnabled(true);
                  Conspiracy.RB_Sword.doClick();
              }
          //-------------------------------------------
              if(CHOICE.equals("Glock"))
              {
                  Conspiracy.TA_MainOutput.append(
                  "\n\n You equip yourself with the" +
                  "\n stealthy black Glock.");
                  Conspiracy.RB_JackKnife.setSelected(true);
                  Conspiracy.RB_Glock.setEnabled(true);
                  Conspiracy.RB_Glock.doClick();
              }
          //-------------------------------------------
              if(CHOICE.equals("Power Staff"))
              {
                  Conspiracy.TA_MainOutput.append(
                  "\n\n You equip yourself with the" +
                  "\n amazing alien POWER staff!");
                  Conspiracy.RB_Staff.setEnabled(true);
                  Conspiracy.RB_Staff.doClick();
              }
          //-------------------------------------------
              if(CHOICE.equals("Kevlar Armor"))
              {
                  if(!Wearing)
                  {
                      Conspiracy.TA_MainOutput.append(
                      "\n You put on the Kevlar vest.");
                      def = def + 4;
                      Wearing = true;
                      Display();
                  }
                  else
                  {
                     Conspiracy.TA_MainOutput.append(
                      "\n You take off the Kevlar vest.");
                      def = def - 4;
                      Wearing = false;
                      Display();
                  }
              }
          //-------------------------------------------
              if(CHOICE.contains("Coffee Plts"))
              {
                  if(health < MaxHealth)
                  {
                     if(health + 10 < MaxHealth)
                     { health = health + 10; }
                     else { health = MaxHealth;}
                     Conspiracy.TA_MainOutput.append(
                     "\n\n You consume a delicious coffee" +
                     "\n pellet restoring 10 health!");
                     CoffeePellets = CoffeePellets - 1;
                     ShowInventory();
                     Display();
                  }
                  else
                  {
                     Conspiracy.TA_MainOutput.append(
                     "\n\n Health already at MAX -" +
                     "\n you don't need a coffee pellet!");
                  }
              }
         //-------------------------------------------
              if(CHOICE.contains("Grenades"))
              {
                 Conspiracy.TA_MainOutput.append(
                 "\n\n You equip yourself with a " +
                 "\n concussion grenade.");
                 Conspiracy.B_Attack.setText("TOSS");
              }
         //-------------------------------------------
              if(CHOICE.contains("Power Stones"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n You equip yourself with the\n crystal power stones."); }
         //-------------------------------------------
              if(CHOICE.contains("Key Stone"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping the Key Stone."); }
         //-------------------------------------------
              if(CHOICE.contains("Key Card"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping Key Card."); }
         //-------------------------------------------
              if(CHOICE.contains("Key = Locker"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping Locker Key."); }
         //-------------------------------------------
              if(CHOICE.contains("Key = SecOff"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping Security Office Key."); }
         //-------------------------------------------
              if(CHOICE.contains("Key = StaffRm"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping Staff Room Key."); }
         //-------------------------------------------
              if(CHOICE.contains("Key = CovrtOps"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping Covert Ops Key."); }
         //-------------------------------------------
              if(CHOICE.contains("Signet Ring"))
              { Conspiracy.TA_MainOutput.append(
              "\n\n Equipping Masonic Signet Ring."); }
         //-------------------------------------------

       }
 //------------------------------------------------------------

       public void Rest() { Conspiracy.TA_MainOutput.append("\n\tResting..."); }
       public void Die() { Conspiracy.TA_MainOutput.append("\n\tDieing..."); }
       public void Reproduce() { Conspiracy.TA_MainOutput.append("\n\tReproducing..."); }

       //Character Data------------------------------------------------------
       private int MaxHealth;
       private int MaxDamage;
       private int health;
       private int size;
       private int mass;
       private int atk;
       private int def;
       private int speed;
       private int experience;
       private int level;
       private int score;
       private double money;
       private String NAME;
       private String gender;
       private String species;
       private String characterclass;
       private boolean PlayerObject;
       private int AvatarImage;

       //Character Data Accessors -------------------------------------------
       public int GetMaxDamage() { return MaxDamage; }
       public void SetMaxDamage(int x) { MaxDamage = x; }
       public int GetMaxHealth() { return MaxHealth; }
       public void SetMaxHealth(int x) { MaxHealth = x; }
       public int GetHealth() { return health; }
       public void SetHealth(int x) { health = x; }
       public int GetSize() { return size; }
       public void SetSize(int x) { size = x; }
       public int GetMass() { return mass; }
       public void SetMass(int x) { mass = x; }
       public int GetAtk() { return atk; }
       public void SetAtk(int x) { atk = x; }
       public int GetDef() { return def; }
       public void SetDef(int x) { def = x; }
       public int GetSpeed() { return speed; }
       public void SetSpeed(int x) { speed = x; }
       public int GetExperience() { return experience; }
       public void SetExperience(int x) { experience = x; LEVEL();}
       public int GetLevel() { return level; }
       public void SetLevel(int x) { level = x; }
       public int GetScore() { return score; }
       public void SetScore(int x) { score = x; }
       public double GetMoney() { return money; }
       public void SetMoney(double x) { money = x; }
       public String GetName() { return NAME; }
       public void SetName(String x) { NAME = x; }
       public String GetGender() { return gender; }
       public void SetGender(String x)
       {
           switch(x.toLowerCase().charAt(0))
           {
               case 'a' : gender = "Androgenous"; break;
               case 'f' : gender = "Female"; break;
               case 'm' : gender = "Male"; break;
           }
       }
       public String GetSpecies() { return species; }
       public void SetSpecies(String x)
       {
           switch(x.toLowerCase().charAt(0))
           {
               case 'a' : species = "Alien"; break;
               case 'h' : species = "Human"; break;
               case 'p' : species = "Hybrid"; break;
           }
       }
       public void SetCharacterClass(String x) { characterclass = x; }
       public String GetCharacterClass() { return characterclass; }
       public boolean GetPlayerObject() { return PlayerObject; }
       public void SetPlayerObject(boolean x) { PlayerObject = x; }
       public void SetAvatarImage(int X) { AvatarImage = X; };
       public int GetAvatarImage() { return AvatarImage; }

       //Inventory ---------------------------------------------------------
       private boolean JackKnife;
       private boolean Sword;
       private boolean Glock;
       private boolean Stones;
       private boolean TitaniumStaff;
       private boolean KevlarVest;
       private boolean KeyStone;
       private int GlockAmmo;
       private int Grenade;
       private int FlashGrenade;
       private int CoffeePellets;
       private boolean Key_Card;
       private boolean Key_Locker;
       private boolean Key_SecurityOffice;
       private boolean Key_StaffRoom;
       private boolean SignetRing;
       
       //Inventory Accessors----------------------------------------------
       public boolean GetJackKnife() { return JackKnife; }
       public void SetJackKnife(boolean x) { JackKnife = x; }
       public boolean GetSword() { return Sword; }
       public void SetSword(boolean x) { Sword = x; }
       public boolean GetGlock() { return Glock; }
       public void SetGlock(boolean x) { Glock = x; }
       public boolean GetStones() { return Stones; }
       public void SetStones(boolean x) { Stones = x; }
       public boolean GetVest() { return KevlarVest; }
       public void SetVest(boolean x) { KevlarVest = x; }
       public boolean GetStaff() { return TitaniumStaff; }
       public void SetStaff(boolean x) { TitaniumStaff = x; }
       public boolean GetKeyStone() { return KeyStone; }
       public void SetKeyStone(boolean x) { KeyStone = x; }
       public int GetGlockAmmo() { return GlockAmmo; }
       public void SetGlockAmmo(int x) { GlockAmmo = x; }
       public int GetGrenade() { return Grenade; }
       public void SetGrenade(int x) { Grenade = x; }
       public int GetFlashGrenade() { return FlashGrenade; }
       public void SetFlashGrenade(int x) { FlashGrenade = x; }
       public int GetCoffeePellet() { return CoffeePellets; }
       public void SetCoffeePellet(int x) { CoffeePellets = x; }
       public boolean GetKeyCard() { return Key_Card; }
       public void SetKeyCard(boolean x) { Key_Card = x; }
       public boolean GetKeyLocker() { return Key_Locker; }
       public void SetKeyLocker(boolean x) { Key_Locker = x; }
       public boolean GetKeySecurityOffice() { return Key_SecurityOffice; }
       public void SetKeySecurityOffice(boolean x) { Key_SecurityOffice = x; }
       public boolean GetKeyStaffRoom() { return Key_StaffRoom; }
       public void SetKeyStaffRoom(boolean x) { Key_StaffRoom = x; }
       public boolean GetSignetRing() { return SignetRing; }
       public void SetSignetRing(boolean x) { SignetRing = x; }

       //Weapon Use Booleans for Entities
       private boolean UseFists;
       private boolean UseKnife;
       private boolean UseSword;
       private boolean UseGlock;
       private boolean UseStaff;
       private boolean UseGrenade;

       //Weapon Use Accessors for Entities
       public boolean GetUseFists() { return UseFists; }
       public void SetUseFists(boolean x) { UseFists = x; }
       public boolean GetUseKnife() { return UseKnife; }
       public void SetUseKnife(boolean x) { UseKnife = x; }
       public boolean GetUseSword() { return UseSword; }
       public void SetUseSword(boolean x) { UseSword = x; }
       public boolean GetUseGlock() { return UseGlock; }
       public void SetUseGlock(boolean x) { UseGlock = x; }
       public boolean GetUseStaff() { return UseStaff; }
       public void SetUseStaff(boolean x) { UseStaff = x; }
       public boolean GetUseGrenade() { return UseGrenade; }
       public void SetUseGrenade(boolean x) { UseGrenade = x; }

       //Abilities -----------------------------------------------------
       private boolean Shape_Shift;
       private boolean Space_Shift;
       private boolean Time_Shift;
       private boolean Regenerate;
       private boolean Electromagnetism;
       private boolean GravityBend;
       private boolean Singularity;
       public int ENERGY;

       //Ability Accessors----------------------------------------------
       public boolean GetShapeShift() { return Shape_Shift; }
       public void SetShapeShift(boolean x) { Shape_Shift = x; }
       public boolean GetSpaceShift() { return Space_Shift; }
       public void SetSpaceShift(boolean x) { Space_Shift = x; }
       public boolean GetTimeShift() { return Time_Shift; }
       public void SetTimeShift(boolean x) { Time_Shift = x; }
       public boolean GetRegenerate() { return Regenerate; }
       public void SetRegenerate(boolean x) { Regenerate = x; }
       public boolean GetElectromagnetism() { return Electromagnetism; }
       public void SetElectromagnetism(boolean x) { Electromagnetism = x; }
       public boolean GetGravityBend() { return GravityBend; }
       public void SetGravityBend(boolean x) { GravityBend = x; }
       public boolean GetSingularity() { return Singularity; }
       public void SetSingularity(boolean x) { Singularity = x; }
       public int GetEnergy() { return ENERGY; }
       public void SetEnergy(int x) { ENERGY = x; }
}
