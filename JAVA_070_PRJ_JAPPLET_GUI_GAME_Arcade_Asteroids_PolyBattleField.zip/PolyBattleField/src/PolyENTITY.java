//Pirate Areana ADT Superclass for Graphical Polygon Objects 

import java.awt.Color;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;

public class PolyENTITY 
{ 
       //Globals
       public static final int OCTAGON = 0;
       public static final int RECTANGLE = 1;
       public static final int RECTANGLETINY = 2;
       public static final int TRIANGLEWIDE = 3;
       public static final int TRIANGLENARROW = 4;
       public static final int TRIANGLETINY = 5;
       public static final int BOWTIE = 6;
       public static final int STAR = 7;
       public static final int ODDPOLYGON = 8;
       public static final int SPIRAL = 9;
       public static final int HEXASTAR = 10;
       public static final int NumShapes = 11;
       
       public static boolean CALCULATEDPOLYGON = false;
       public static Polygon TEMP_POLYGON = new Polygon();
    
//-----------------------------------------------------------------------------
       //Constructor
       public PolyENTITY() 
       {
              Set_Shape(null);
              Set_Active(false);
              Set_X(0.0);
              Set_Y(0.0);
              Set_X_Velocity(0.0);
              Set_Y_Velocity(0.0);
              Set_Move_Angle(0.0);
              Set_Face_Angle(0.0);
              EntityColor = Color.LIGHT_GRAY;
       } 
//-----------------------------------------------------------------------------
//Member Methods
              //-----Increase X and Y Position----------
       public void Increase_X(double AMT) { this.X += AMT; }
       public void Increase_Y(double AMT) { this.Y += AMT; }
       public void Decrease_X(double AMT) { this.X -= AMT; }
       public void Decrease_Y(double AMT) { this.Y -= AMT; }       

       public void Increase_X_Velocity(double AMT) { this.X_Velocity += AMT; }
       public void Increase_Y_Velocity(double AMT) { this.Y_Velocity += AMT; }
    
       public void Increase_Face_Angle(double AMT) { this.FaceAngle += AMT; }
       public void Increase_Move_Angle(double AMT) { this.MoveAngle += AMT; }
       
       //Member Methods - Collision Geometry
       public Rectangle Get_Collision_Geometry() 
       {
              RANGE = new Rectangle(
              (int)Get_X() - COLWIDTH/2, (int)Get_Y() - COLWIDTH/2, COLWIDTH,COLWIDTH);
              return RANGE;
       }

       public void Set_Collision_Geometry(int X) 
       { COLWIDTH = X; }       
//-----------------------------------------------------------------------------    
//Public Accessor Methods
       
           //-----X and Y Coordinate Position----------
    public double Get_X() { return X; }
    public void Set_X(double XPOS) { this.X = XPOS; }
    public double Get_Y() { return Y; }
    public void Set_Y(double YPOS) { this.Y = YPOS; }
           //-----Velocity-----------------------------
    public double Get_X_Velocity() { return X_Velocity; }
    public void Set_X_Velocity(double XVELOCITY) {this.X_Velocity = XVELOCITY;}
    public double Get_Y_Velocity() { return Y_Velocity; }
    public void Set_Y_Velocity(double YVELOCITY) {this.Y_Velocity = YVELOCITY;}
           //-----Move Angle and Face Angle------------
    public double Get_Move_Angle() { return MoveAngle; }
    public void Set_Move_Angle(double ANGLE) { this.MoveAngle = ANGLE; }
    public double Get_Face_Angle() { return FaceAngle; }
    public void Set_Face_Angle(double ANGLE) { this.FaceAngle = ANGLE; }
    public double Get_Rotation_Velocity() { return RotationVelocity; }
    public void Set_Rotation_Velocity(double VEL) { RotationVelocity = VEL; }
    
           //-----PolyENTITY Attributes--------------
    public Shape Get_Shape() { return EntityShape; }
    
           //Overloaded Set_Shape function
    public void Set_Shape(Shape BLOB) { this.EntityShape = BLOB; }
    public void Set_Shape(int TYPE) 
    {      
           switch(TYPE)
           {
               case OCTAGON : 
                        POLY_X = new int[] {-10,  5, 15, 15,  5, -10, -20, -20};
                        POLY_Y = new int[] {-10,-10,  0, 15, 25,  25,  15,   0};
                        COLWIDTH = 40;
                        CALCULATEDPOLYGON = false;
                        break;
                   
               case RECTANGLE : 
                        POLY_X = new int[] {-20, 15,15,-20,-20};
                        POLY_Y = new int[] {-10,-10,15, 15,-10};
                        COLWIDTH = 50;
                        CALCULATEDPOLYGON = false;
                        break;
                   
               case RECTANGLETINY : 
                        POLY_X = new int[] {0,2,2,0};
                        POLY_Y = new int[] {0,0,2,2};
                        COLWIDTH = 4;
                        CALCULATEDPOLYGON = false;
                        break;    
                   
               case TRIANGLEWIDE : 
                        POLY_X = new int[] {-20, 10,40,-20};
                        POLY_Y = new int[] { 10,-10,10, 10};
                        COLWIDTH = 30;
                        CALCULATEDPOLYGON = false;
                        break;
                   
               case TRIANGLENARROW : 
                        POLY_X = new int[] {-20,  -5, 0, -20};
                        POLY_Y = new int[] {10,  -20, 10,10};
                        COLWIDTH = 30;
                        CALCULATEDPOLYGON = false;
                        break;
                   
               case TRIANGLETINY : 
                        POLY_X = new int[] {-6,-3,0,3,6, 0};
                        POLY_Y = new int[] { 6, 7,7,7,6,-7};
                        COLWIDTH = 12;
                        CALCULATEDPOLYGON = false;
                        break;                   
                   
               case BOWTIE : 
                        POLY_X = new int[] {-20, 40, -20, 40};
                        POLY_Y = new int[] {-20, 10, 10, -20};
                        COLWIDTH = 40;
                        CALCULATEDPOLYGON = false;
                        break;
                   
               case STAR : //X = +140, -120, +50, +40 
                           //Y = +0, +70, -100, +100
                        POLY_X = new int[] {-35, 15, -25, -10, 10};
                        POLY_Y = new int[] {-5, -5, 30, -20, 30};
                        COLWIDTH = 45;
                        CALCULATEDPOLYGON = false;
                        break;        
                   
               case ODDPOLYGON : 
                        POLY_X = new int[] {-20,-13, 0,20,22, 20, 12,  2,-10,-22,-16};
                        POLY_Y = new int[] { 20, 23,17,20,16,-20,-22,-14,-17,-20, -5};
                        COLWIDTH = 40;
                        CALCULATEDPOLYGON = false;
                        break;
                   
               case SPIRAL : TEMP_POLYGON = new Polygon();       
                             for(int i = 0; i < 360; i++)
                             {
                                double t = i / 360.0;
                                TEMP_POLYGON.addPoint(
                                (int) (5 + 25 * t * Math.cos(8 * t * Math.PI)),
                                (int) (5 + 25 * t * Math.sin(8 * t * Math.PI)));
                             }
                             CALCULATEDPOLYGON = true;
                             COLWIDTH = 50;
                             X = 0.0;
                             Y = 0.0;
                             break;
                   
               case HEXASTAR : POLY_X = new int[] {-25, -5, 5, 15, 35, 15, 5, -5};
                              POLY_Y = new int[] {5, -5, -25, -5, 5, 15, 35, 15};
                              COLWIDTH = 40;
                              CALCULATEDPOLYGON = false;
                              break;    
           }
           
           if(CALCULATEDPOLYGON)
           {   
               EntityShape = TEMP_POLYGON;
           }
           else 
           { EntityShape = new Polygon(POLY_X, POLY_Y, POLY_X.length); }
           
           Set_Collision_Geometry(COLWIDTH);
    }

    public Color Get_Color() { return EntityColor; }
    public void Set_Color(Color C) { this.EntityColor = C; }   
    public boolean Get_Active() { return ACTIVE; }
    public void Set_Active(boolean active) { this.ACTIVE = active; }
    public boolean Get_Firing() { return FIRING; }
    public void Set_Firing(boolean F) { this.FIRING = F; }
//-----------------------------------------------------------------------------    
//Private Data
    private double X = 0.0;
    private double Y = 0.0;
    private double X_Velocity = 0.0;
    private double Y_Velocity = 0.0;
    private double MoveAngle = 0.0;
    private double FaceAngle = 0.0;
    private double RotationVelocity;
    private Shape EntityShape;
    private Color EntityColor = Color.LIGHT_GRAY;
    private boolean ACTIVE = false;
    private int[] POLY_X;
    private int[] POLY_Y;
    private int COLWIDTH = 0;
    private Rectangle RANGE;
    private boolean FIRING = false;
}