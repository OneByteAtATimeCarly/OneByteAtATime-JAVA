//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package GameFunctions;

import Characters.*;
import Levels.*;
import java.io.*;
import java.util.Random;
import javax.swing.*;

public class F
{
       //Globals
       public static Entity PLAYER;
       public static L01_DenverAirport GAME;

       //Location Tracking
       public static  int LOCATION = 0;
       public static  int ROW = 0;
       public static  int COLUMN = 0;

//-----------------------------------------------------------------

       public F()
       { System.out.print("\n\tBuilding a GameFunctions object."); }

//-----------------------------------------------------------------

public  static void MainMenu()
{  
              String choice = " ";

              while(!choice.equals("q"))
              {
                   System.out.print("\n\n\n\t---------- Conspiracy! Main Menu ----------");
                   System.out.print("\n\t(C)reate Character");
                   System.out.print("\n\t(P)lay Game");
                   System.out.print("\n\t(L)oad Game");
                   System.out.print("\n\t(S)ave Game");
                   System.out.print("\n\t(Q)uit\n\n\t");

                   choice = INPUT().toLowerCase();

                   switch(choice.charAt(0))
                   {
                       case 'c' : CreateCharacter(); break;
                       case 'p' : PlayGame(); break;
                       case 'l' : LoadGame(); break;
                       case 's' : SaveGame(); break;
                       case 'q' : System.out.print("\n\tExiting main menu"); break;
                       default : System.out.print("\n\tNot on the menu today!"); break;
                   }
              }
}

//-----------------------------------------------------------------

public  static void Options()
{
              String choice = " ";

              while(!choice.equals("q"))
              {
                   System.out.print("\n\n\n\t---------- Conspiracy! Options Menu ----------");
                   System.out.print("\n\t(L)oad Game");
                   System.out.print("\n\t(S)ave Game");
                   System.out.print("\n\t(I)nventory");
                   System.out.print("\n\t(D)isplay Stats");
                   System.out.print("\n\t(C)heat");
                   System.out.print("\n\tE(x)it Game");
                   System.out.print("\n\t(Q)uit Options Menu\n\n\t");

                   choice = INPUT().toLowerCase();

                   switch(choice.charAt(0))
                   {
                       case 'l' : LoadGame(); break;
                       case 's' : SaveGame(); break;
                       case 'i' : PLAYER.Inventory(); break;
                       case 'd' : PLAYER.Display(); break;
                       case 'c' : PLAYER.CHEAT(); break;
                       case 'x' : LOCATION = GAME.QUIT; GAME.SwitchBoard(); break;
                       case 'q' : System.out.print("\n\tExiting options menu"); break;
                       default : System.out.print("\n\tNot on the menu today!"); break;
                   }
              }
}

//-----------------------------------------------------------------

public  static void CreateCharacter()
{
              System.out.print("\n\tBuild yourself a new Character:");

              String choice = " ";

              while(!choice.equals("q"))
              {
                   System.out.print("\n\t---------- Create Your Character: ----------");
                   System.out.print("\n\t(O)rdinary Civilian");
                   System.out.print("\n\t(F)BI");
                   System.out.print("\n\t(C)IA");
                   System.out.print("\n\t(Q)uit\n\n\t");

                   choice = INPUT().toLowerCase();

                   //Allocate MAX of 10 points per LifeForm between speed/mass
                   //Allocate MAX of 10 points per LifeForm between atk/def

                   System.out.print("\n\tWhat will you name your LifeForm? ");

                   switch(choice.charAt(0))
                   {
                       case 'o' : PLAYER = new Civilian();
                                  choice = "q";
                                  break;
                       case 'f' : PLAYER = new FBI();
                                  choice = "q";
                                  break;
                       case 'c' : PLAYER = new CIA();
                                  choice = "q";
                                  break;
                       case 'q' : System.out.print("\n\tExiting main menu"); break;
                       default : System.out.print("\n\tNot on the menu today!"); break;
                   }
              }

              CustomizePlayer();
              
              PLAYER.Display();

}

//-----------------------------------------------------------------

public static void CustomizePlayer()
{
       System.out.print("\n\tWhat will you name your character? ");
       PLAYER.SetName(INPUT());
       
       while(PLAYER.GetGender().charAt(0) != 'M' &&
             PLAYER.GetGender().charAt(0) != 'F')
       {
           System.out.print("\tWill your character be male or female? ");
           PLAYER.SetGender(INPUT());
       }

       while(PLAYER.GetSpecies().charAt(0) != 'H' &&
             PLAYER.GetSpecies().charAt(0) != 'A')
       {
           System.out.print("\tWill your character be human or alien? ");
           PLAYER.SetSpecies(INPUT());
       }

       Random APPLE = new Random();

       //10 points total to assign randomly
       int TEMP = APPLE.nextInt(10) + 1;
       if(TEMP < 10)
       {
           PLAYER.SetAtk(TEMP);
           PLAYER.SetDef(10 - TEMP);
       }
       else
       {
           PLAYER.SetAtk(TEMP-1);
           PLAYER.SetDef(1);
       }

       if(PLAYER.GetCharacterClass().equals("FBI"))
       {

            PLAYER.SetMass(5);
            PLAYER.SetSpeed(5);
       }

       if(PLAYER.GetCharacterClass().equals("CIA"))
       {
            PLAYER.SetMass(7);
            PLAYER.SetSpeed(3);
       }

       if(PLAYER.GetCharacterClass().equals("Civilian"))
       {
            PLAYER.SetMass(3);
            PLAYER.SetSpeed(7);
       }
}

//-----------------------------------------------------------------

public static void PlayGame()
{
       GAME = new L01_DenverAirport();
       GAME.SwitchBoard();
}

//-----------------------------------------------------------------


       public static String INPUT()
       {
           String temp = " ";
           LineNumberReader BANANA = new LineNumberReader(new InputStreamReader(System.in));
           try { temp = BANANA.readLine(); }
           catch(IOException X) {  }
           if(temp.isEmpty()) { temp = " ";}
           return temp;
       }

//-----------------------------------------------------------------

       public static void SaveGame()
       {
              //1. import java.io.*;
              //2. Make file object
              //3. Male FileOutputStream, pass the File object in
              //4. Make PrintStream object, pass the FileOutputStream object to it
              System.out.print("\n\tSaving Game...");

              try
              {

                File GameFile = new File(PLAYER.GetName());
                FileOutputStream OUTPUT = new FileOutputStream(GameFile);
                PrintStream OUT = new PrintStream(OUTPUT);

                //Save Character Data
                OUT.println(PLAYER.GetName());
                OUT.println(PLAYER.GetHealth());
                OUT.println(PLAYER.GetSize());
                OUT.println(PLAYER.GetMass());
                OUT.println(PLAYER.GetAtk());
                OUT.println(PLAYER.GetDef());
                OUT.println(PLAYER.GetSpeed());
                OUT.println(PLAYER.GetGender());
                OUT.println(PLAYER.GetSpecies());
                OUT.println(PLAYER.GetCharacterClass());

                //Save Inventory Data
                OUT.println(PLAYER.GetJackKnife());
                OUT.println(PLAYER.GetGlock());
                OUT.println(PLAYER.GetStaff());
                OUT.println(PLAYER.GetVest());
                OUT.println(PLAYER.GetKeyCard());
                OUT.println(PLAYER.GetKey());
                OUT.println(PLAYER.GetKeyStone());
                OUT.println(PLAYER.GetGlockAmmo());
                OUT.println(PLAYER.GetGrenade());
                OUT.println(PLAYER.GetFlashGrenade());

                //Save Location Data
                OUT.println(LOCATION);
                OUT.println(ROW);
                OUT.println(COLUMN);

                //Save Specific Level Data
                OUT.println(GAME.JT_03_FoundJackKnife);
                OUT.println(GAME.JT_20_FoundAmmo);
                OUT.println(GAME.JT_12_FoundAmmo);

                OUT.close();
                System.out.print("\n\tGame Saved Successfully!");
              }

              catch(IOException x)
              { System.out.print("\n\tError"); }
       }

//-----------------------------------------------------------------

       public static void LoadGame()
       {
              System.out.print("\n\tLoad Game.");
              //1. import java.io.*;
              //2. Make file object
              //3. Male FileOutputStream, pass the File object in
              //4. Make PrintStream object, pass the FileOutputStream object to it

              System.out.print("\n\tEnter name of character to load: ");

              String NAME = INPUT();

              try
              {
                GAME = new L01_DenverAirport();
                PLAYER = new FBI();
                
                File GameFile = new File(NAME);
                FileInputStream INPUT = new FileInputStream(GameFile);
                InputStreamReader IN = new InputStreamReader(INPUT);
                BufferedReader INNIE = new BufferedReader(IN);

                //Load Character Data
                PLAYER.SetName(INNIE.readLine());
                PLAYER.SetHealth(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetSize(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetMass(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetAtk(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetDef(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetSpeed(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetGender(INNIE.readLine());
                PLAYER.SetSpecies(INNIE.readLine());
                PLAYER.SetCharacterClass(INNIE.readLine());

                //Load Inventory Data
                PLAYER.SetJackKnife(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetGlock(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetStaff(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetVest(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetKeyCard(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetKey(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetKeyStone(TrueOrFalse(INNIE.readLine()));
                PLAYER.SetGlockAmmo(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetGrenade(Integer.parseInt(INNIE.readLine()));
                PLAYER.SetFlashGrenade(Integer.parseInt(INNIE.readLine()));

                //Read Location Data
                LOCATION = Integer.parseInt(INNIE.readLine());
                ROW = Integer.parseInt(INNIE.readLine());
                COLUMN = Integer.parseInt(INNIE.readLine());

                //Save Specific Level Data
                GAME.JT_03_FoundJackKnife = TrueOrFalse(INNIE.readLine());
                GAME.JT_20_FoundAmmo = TrueOrFalse(INNIE.readLine());
                GAME.JT_12_FoundAmmo = TrueOrFalse(INNIE.readLine());

                INNIE.close();

                PLAYER.Display();
                PLAYER.Inventory();
                LOCATION = GAME.JeppesenTerminal;
                ROW = 2;
                COLUMN = 0;
                GAME.SwitchBoard();
              }

              catch(IOException x)
              { System.out.print("\n\tError"); }

       }
//-----------------------------------------------------------------


       public static void PAUSE()
       {
              String choice = "q";
              System.out.print("\n\tHit ENTER to continue.");
              choice = INPUT();
       }

//-----------------------------------------------------------------
//FIND = pass in 0 if not a quantity item, otherwise use AMT
public static boolean FIND(String WhatPlayerSees, String Item, boolean FoundItem, int AMT)
{
       if(!FoundItem)
       {
           String temp = " ";

           while(temp.charAt(0) != 'y' && temp.charAt(0) != 'n')
           {
                 System.out.print("\n\n\tYou see a(n)" + WhatPlayerSees + "." +
                                  "\n\tDo you want to pick it up? (y)es or (n)o ");

                 temp = INPUT();

                 switch(temp.charAt(0))
                 {
                        case 'y' : System.out.print("\n\tYou found the "
                                   + Item + "!");

                        //Possible Inventory Accessors
                        if(Item.equals("Jack Knife")) { PLAYER.SetJackKnife(true); }
                        if(Item.equals("Glock")) { PLAYER.SetGlock(true); }
                        if(Item.equals("Titanium Staff")) { PLAYER.SetStaff(true); }
                        if(Item.equals("Kevlar Vest")) { PLAYER.SetVest(true); }
                        if(Item.equals("Key Card")) { PLAYER.SetKeyCard(true); }
                        if(Item.equals("Key")) { PLAYER.SetKey(true); }
                        if(Item.equals("Key Stone")) { PLAYER.SetKeyStone(true); }

                        //Quantity Items
                        if(Item.equals("Glock Ammo"))
                        { 
                            PLAYER.SetGlockAmmo(PLAYER.GetGlockAmmo() + AMT);
                            System.out.print(" In the clip are " + AMT + " bullets.");
                        }
                        if(Item.equals("Grenade"))
                        { PLAYER.SetGrenade(PLAYER.GetGrenade() + AMT); }
                        if(Item.equals("Flash Grenade"))
                        { PLAYER.SetFlashGrenade(PLAYER.GetFlashGrenade() + AMT); }

                        FoundItem = true;
                        PLAYER.Inventory();
                        break;

                        case 'n' : break;
                        default: System.out.print("\n\tNot an option.");
                 }
             }
          }
          else
          {
              System.out.print("\n\n\tYou return to the spot where"+
                               "\n\tyou previously found the " + Item + ".\n\n");
          }

          return FoundItem;

}//close function

//-----------------------------------------------------------------

       public static boolean TrueOrFalse(String x)
       {
              if(x.equals("true"))
              { return true; }
              else { return false; }

       }

//-----------------------------------------------------------------

}//close class
