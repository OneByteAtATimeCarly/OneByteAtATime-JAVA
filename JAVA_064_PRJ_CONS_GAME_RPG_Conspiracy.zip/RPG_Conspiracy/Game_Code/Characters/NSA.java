//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

public class NSA extends Government
{
       public NSA()
       { 
           System.out.print("\n\tCreating an NSA agent.");
           SetCharacterClass("NSA");
       }
}
