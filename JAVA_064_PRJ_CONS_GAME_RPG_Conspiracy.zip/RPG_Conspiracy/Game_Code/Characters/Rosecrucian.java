//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object class extends FreeMasonMalevolent

public class Rosecrucian extends FreeMasonMalevolent
{
       public Rosecrucian()
       { 
           System.out.print("\n\tBuilding a Malevolent Masonic Rosecrucian.");
           SetCharacterClass("Rosecrucian");
       }
}
