//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

public class Civilian extends Human
{
       public Civilian()
       {
           System.out.print("\n\tBuilding a Civilian.");
           SetCharacterClass("Civilian");
       }
}
