//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT - extends FreeMason

public class FreeMasonMalevolent extends FreeMason
{
       public FreeMasonMalevolent()
       { System.out.print("\n\tCreating an FreeMasonMalevolent."); }
}
