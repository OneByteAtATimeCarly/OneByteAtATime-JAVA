//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object extends Military

public class Majestic extends Government
{
       public void Majestic()
       { 
           System.out.print("\n\tCreating a Majestic agent.");
           SetCharacterClass("Majestic");
       }
}
