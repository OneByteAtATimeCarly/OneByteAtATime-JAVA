//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

public class CIA extends Government
{
       public CIA()
       {
           System.out.print("\n\tCreating a CIA object.");
           SetCharacterClass("CIA");
       }
}
