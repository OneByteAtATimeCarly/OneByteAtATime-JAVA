//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT - extends Alien

public class AlienBenevolent extends Alien
{
       public AlienBenevolent()
       { System.out.print("\n\tCreating an AlienBenevolent."); }
}
