//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

public class FBI extends Government
{
       public FBI()
       { 
           System.out.print("\n\tCreating an FBI object.");
           SetCharacterClass("FBI");
       }
}
