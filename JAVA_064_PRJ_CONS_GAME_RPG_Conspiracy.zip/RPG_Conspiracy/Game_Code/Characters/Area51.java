//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object extends Military

public class Area51 extends Government
{
       public void Area51()
       { 
           System.out.print("\n\tCreating an Area51 scientist.");
           SetCharacterClass("Area51");
       }
}