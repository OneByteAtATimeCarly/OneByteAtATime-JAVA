//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object extends Abductor

public class Gray extends AlienMalevolent
{
       public Gray()
       { 
           System.out.print("\n\tCreating an Gray.");
           SetCharacterClass("Alien - Gray");
       }
}