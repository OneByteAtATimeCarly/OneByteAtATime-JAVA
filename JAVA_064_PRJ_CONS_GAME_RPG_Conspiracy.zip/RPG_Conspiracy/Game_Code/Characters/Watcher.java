//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object class extends FreeMasonBenevolent

public class Watcher extends FreeMasonBenevolent
{
       public Watcher()
       { 
           System.out.print("\n\tBuilding a Benevolent Masonic Watcher.");
           SetCharacterClass("Watcher");
       }
}
