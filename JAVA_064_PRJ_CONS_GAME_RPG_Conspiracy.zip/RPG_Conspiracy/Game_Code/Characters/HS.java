//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

public class HS extends Government
{
       public HS()
       {
           System.out.print("\n\tCreating a HomelandSecurity object.");
           SetCharacterClass("Homeland Security");
       }
}
