//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT superclass for all object in hiearchy

//imported packages
import java.util.Random;

public class Entity
{
       //Globals
       public final int MaxDamage = 25;

       //OVERLOADED constructors
//------------------------------------------------------------
       public Entity()
       {
              System.out.print("\n\tBuiding a superclass ADT Entity object.");
              Initialize();
              NAME = "Anonymous Entity";
       }
//------------------------------------------------------------
       public Entity(String x)
       {
              System.out.print("\n\tBuiding a superclass ADT Entity object.");
              Initialize();
              NAME = x;
       }
//------------------------------------------------------------

       public Entity(String n, int h, int a, int d)
       {
              System.out.print("\n\tBuiding a superclass ADT Entity object.");
              Initialize();
              NAME = n;
              health = h;
              atk = a;
              def = d;
       }

//------------------------------------------------------------
       public void Initialize()
       {
              health = 100;
              size = 5;
              mass = 10;
              atk = 1;
              def = 1;
              speed = 5;
              species = "Undefined Entity";
              gender = "Androgenous IT";
              characterclass = "Undefined Class";

              JackKnife = false;
              Glock = false;
              TitaniumStaff = false;
              KevlarVest = false;
              KeyCard = false;
              Key = false;
              KeyStone = false;
              GlockAmmo = 0;
              Grenade = 0;
              FlashGrenade = 0;
       }

//------------------------------------------------------------

       public void CHEAT()
       {
              System.out.print("\n\tActivating Cheat!");
              health = 1000;
              size = 5;
              mass = 10;
              atk = 10;
              def = 10;
              speed = 50;
              species = "Super Being";
              characterclass = "Hero";

              JackKnife = true;
              Glock = true;
              TitaniumStaff = true;
              KevlarVest = true;
              KeyCard = true;
              Key = true;
              KeyStone = true;
              GlockAmmo = 1000;
              Grenade = 1000;
              FlashGrenade = 1000;
       }

//------------------------------------------------------------

       public void Display()
       {
              System.out.print("\n\t----------------- " + NAME + "'s Stats -----------------\n\t");
              System.out.print("Spc:" + species);
              System.out.print("   Sex:" + gender);
              System.out.print("   Class:" + characterclass);
              System.out.print("   Health:" + health);
              System.out.print("   Mass:" + mass);
              System.out.print("   Speed:" + speed);
              System.out.print("   Atk:" + atk);
              System.out.print("   Def:" + def);
       }

//------------------------------------------------------------

public void Inventory()
{
       int x = 1;

       System.out.print("\n\n\t----------Current Inventory-----------");

       if(JackKnife)
       {
           System.out.print("\n\t" + (x++) + ". Jack Knife");
       }

       if(Glock)
       {
           System.out.print("\n\t" + (x++) + ". Glock (NSA issue)");
       }

       if(GlockAmmo > 0)
       {
           System.out.print("\n\t" + (x++) + ". Glock Ammo: " + GlockAmmo);
       }

       if(TitaniumStaff)
       {
           System.out.print("\n\t" + (x++) + ". Titanium Staff");
       }

       if(Grenade > 0)
       {
           System.out.print("\n\t" + (x++) + ". Concussion Grenade: " + Grenade);
       }

       if(FlashGrenade > 0)
       {
           System.out.print("\n\t" + (x++) + ". Flash Grenade: " + FlashGrenade);
       }

       if(KevlarVest)
       {
           System.out.print("\n\t" + (x++) + ". Kevlar Vest");
       }

       if(KeyCard)
       {
           System.out.print("\n\t" + (x++) + ". Key Card");
       }

       if(Key)
       {
           System.out.print("\n\t" + (x++) + ". Key Card");
       }

       if(KeyStone)
       {
           System.out.print("\n\t" + (x++) + ". Key Stone");
       }

       System.out.print("\n");
}

/*
       private int Grenade;
       private int FlashGrenade;
 */

//------------------------------------------------------------

       //Functions
       public void Eat() {  System.out.print("\n\tEating..."); }

       public void Attack(Entity x)
       {
              System.out.print("\n\t--------------Before Attack--------------");
              System.out.print("\n\t" + NAME + ": " + health);
              System.out.print("\n\t" + x.GetName() + ": " + x.GetHealth());
              System.out.print("\n\t" + NAME + " attacks " + x.GetName() + "!");


              Random DAM = new Random();
              int damage = DAM.nextInt(MaxDamage) + 1;

              //Add strength of attacker
              damage = damage + atk;

              //Subtract defense of Attackee
              damage = damage - x.GetDef();

              //Incorporate mass with chance attack of greater damage
              int HeavyBlow = DAM.nextInt(mass) + 1;
              if(HeavyBlow > 4)
              {
                  System.out.print("\n\tHeavy Attack due to mass!");
                  HeavyBlow = DAM.nextInt(mass) + 1;
                  System.out.print("\n\tMass increases damage by " + HeavyBlow + ".");
                  damage = damage + HeavyBlow;
              }

              //Incorporate speed into damage
              int ExtraAttack = DAM.nextInt(speed) + 1;
              if(ExtraAttack > 4)
              {
                  System.out.print("\n\tDue to speed, " + NAME + " makes a sneak attack!");
                  ExtraAttack = DAM.nextInt(speed) + 1;
                  System.out.print("\n\tThe sneak attack inflicts " + ExtraAttack + " more damage.");
                  damage = damage + ExtraAttack;
              }

              //Subtract damage from health
              if(x.GetHealth() - damage > 0)
              { x.SetHealth(x.GetHealth() - damage); }
              else { x.SetHealth(0); }

              System.out.print("\n\t--------------After Attack--------------");
              System.out.print("\n\t" + NAME + ": " + health);
              System.out.print("\n\t" + x.GetName() + ": " + x.GetHealth());
       }

       public void Rest() { System.out.print("\n\tResting..."); }
       public void Die() { System.out.print("\n\tDieing..."); }
       public void Reproduce() { System.out.print("\n\tReproducing..."); }

       //Character Data Accessors -------------------------------------------
       public int GetHealth() { return health; }
       public void SetHealth(int x) { health = x; }
       public int GetSize() { return size; }
       public void SetSize(int x) { size = x; }
       public int GetMass() { return mass; }
       public void SetMass(int x) { mass = x; }
       public int GetAtk() { return atk; }
       public void SetAtk(int x) { atk = x; }
       public int GetDef() { return def; }
       public void SetDef(int x) { def = x; }
       public int GetSpeed() { return speed; }
       public void SetSpeed(int x) { speed = x; }
       public String GetName() { return NAME; }
       public void SetName(String x) { NAME = x; }
       public String GetGender() { return gender; }
       public void SetGender(String x)
       {
           switch(x.toLowerCase().charAt(0))
           {
               case 'm' : gender = "Male"; break;
               case 'f' : gender = "Female"; break;
           }
       }
       public String GetSpecies() { return species; }
       public void SetSpecies(String x)
       {
           switch(x.toLowerCase().charAt(0))
           {
               case 'a' : species = "Alien"; break;
               case 'h' : species = "Human"; break;
           }
       }
       public void SetCharacterClass(String x) { characterclass = x; }
       public String GetCharacterClass() { return characterclass; }
    
       //Character Data------------------------------------------------------
       private int health;
       private int size;
       private int mass;
       private int atk;
       private int def;
       private int speed;
       private String NAME;
       private String gender;
       private String species;
       private String characterclass;

       //Inventory Accessors----------------------------------------------
       public boolean GetJackKnife() { return JackKnife; }
       public void SetJackKnife(boolean x) { JackKnife = x; }
       public boolean GetGlock() { return Glock; }
       public void SetGlock(boolean x) { Glock = x; }
       public boolean GetVest() { return KevlarVest; }
       public void SetVest(boolean x) { KevlarVest = x; }
       public boolean GetStaff() { return TitaniumStaff; }
       public void SetStaff(boolean x) { TitaniumStaff = x; }
       public boolean GetKeyCard() { return KeyCard; }
       public void SetKeyCard(boolean x) { KeyCard = x; }
       public boolean GetKey() { return Key; }
       public void SetKey(boolean x) { Key = x; }
       public boolean GetKeyStone() { return KeyStone; }
       public void SetKeyStone(boolean x) { KeyStone = x; }
       public int GetGlockAmmo() { return GlockAmmo; }
       public void SetGlockAmmo(int x) { GlockAmmo = x; }
       public int GetGrenade() { return Grenade; }
       public void SetGrenade(int x) { Grenade = x; }
       public int GetFlashGrenade() { return FlashGrenade; }
       public void SetFlashGrenade(int x) { FlashGrenade = x; }

       //Inventory ---------------------------------------------------------
       private boolean JackKnife;
       private boolean Glock;
       private boolean TitaniumStaff;
       private boolean KevlarVest;
       private boolean KeyCard;
       private boolean Key;
       private boolean KeyStone;
       private int GlockAmmo;
       private int Grenade;
       private int FlashGrenade;
}
