//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT - extends Entity

public class FreeMason extends Entity
{
       public FreeMason()
       { System.out.print("\n\tCreating an FreeMason."); }
}