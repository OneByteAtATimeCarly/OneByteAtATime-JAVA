//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

public class Government extends Human
{
       public Government()
       { System.out.print("\n\tBuilding a Government."); }
}
