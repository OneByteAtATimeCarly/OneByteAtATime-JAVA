//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT - extends Entity

public class Alien extends Entity
{
       public Alien()
       { System.out.print("\n\tCreating an Alien."); }
}
