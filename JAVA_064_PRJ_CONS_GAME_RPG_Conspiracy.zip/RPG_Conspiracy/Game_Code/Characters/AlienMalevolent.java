//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT - extends Alien

public class AlienMalevolent extends Alien
{
       public AlienMalevolent()
       { System.out.print("\n\tCreating an AlienMalevolent."); }
}