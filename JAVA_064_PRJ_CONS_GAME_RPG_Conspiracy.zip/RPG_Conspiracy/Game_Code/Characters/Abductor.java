//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT extends AlienMalevolent

public class Abductor extends AlienMalevolent
{
       public Abductor()
       { System.out.print("\n\tCreating an Abductor."); }
}
