//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object class extends FreeMasonMalevolent

public class Illuminati extends FreeMasonMalevolent
{
       public Illuminati()
       {
           System.out.print("\n\tBuilding an Illuminati.");
           SetCharacterClass("Illuminati");
       }
}
