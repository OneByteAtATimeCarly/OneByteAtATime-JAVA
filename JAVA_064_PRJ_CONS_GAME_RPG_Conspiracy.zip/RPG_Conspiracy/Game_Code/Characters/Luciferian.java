//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germanypackage Characters;

//Object class extends FreeMasonMalevolent

public class Luciferian extends FreeMasonMalevolent
{
       public Luciferian()
       { 
           System.out.print("\n\tBuilding a Malevolent Masonic Luciferian.");
           SetCharacterClass("Luciferian");
       }
}
