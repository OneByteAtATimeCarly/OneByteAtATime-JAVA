//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//ADT - extends Entity

public class Human extends Entity
{
       public Human() 
       { System.out.print("\n\tCreating an Human."); }
}
