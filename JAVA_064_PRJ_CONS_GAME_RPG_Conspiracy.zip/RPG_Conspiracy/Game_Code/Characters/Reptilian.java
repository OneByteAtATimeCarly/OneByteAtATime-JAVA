//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Characters;

//Object extends Abductor

public class Reptilian extends AlienMalevolent
{
       public Reptilian()
       { 
           System.out.print("\n\tCreating an Alien Reptilian.");
           SetCharacterClass("Reptilian");
       }
}