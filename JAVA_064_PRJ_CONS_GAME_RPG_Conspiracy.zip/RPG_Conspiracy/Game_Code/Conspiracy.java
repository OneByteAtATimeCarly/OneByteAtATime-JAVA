//06/18/2010 Carly Salali Germany - Console Protoype for CONSPIRACY RPG Game

//Main game class

import GameFunctions.*;

public class Conspiracy
{
       //Globals
       public static F F;

    public static void main(String[] args)
    {
           System.out.print("\n\tLauching Conspiracy! 1.0");
           F = new F();
           F.MainMenu();

    }//close main

}//close class
