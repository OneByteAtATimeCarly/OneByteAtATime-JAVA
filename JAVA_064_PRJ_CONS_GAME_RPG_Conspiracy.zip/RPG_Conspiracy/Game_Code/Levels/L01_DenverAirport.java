//Project: Conspiracy RPG Game - 06/18/2010 Carly Salali Germany

package Levels;

import GameFunctions.*;
import java.io.*;

public class L01_DenverAirport
{
       //Boolean Items Found in Level 1
       public boolean JT_03_FoundJackKnife = false;
       public boolean JT_20_FoundAmmo = false;
       public boolean JT_12_FoundAmmo = false;

       //Example of using array to break large room into sectors
       public int[][] JT_SECTORS = {  {00,01,02,03},
                                      {10,11,12,13},
                                      {20,21,22,23}  };
       //Rooms
       public final int QUIT = 0;
       public final int INTRO = 1;
       public final int JeppesenTerminal = 2;
       public final int Frontier = 3;
       public final int Continental = 4;
       public final int SouthWest = 5;
       public final int Train_Tunnel = 6;

//------------------------------------------------------------

       public L01_DenverAirport()
       { 
           System.out.print("\n\tBuilding Level 1 - The Denver Airport.");
           F.LOCATION = INTRO;
       }

//------------------------------------------------------------

public void SwitchBoard()
{
      F.PLAYER.Display();
      
      switch(F.LOCATION)
      {
          case QUIT : System.out.print("\n\tExiting game..."); break;
          case INTRO : Intro(); break;

          case JeppesenTerminal : switch(JT_SECTORS[F.ROW][F.COLUMN])
                                  {
                                     case 00 : JT_00(); break;
                                     case 01 : JT_01(); break;
                                     case 02 : JT_02(); break;
                                     case 03 : JT_03(); break;
                                     case 10 : JT_10(); break;
                                     case 11 : JT_11(); break;
                                     case 12 : JT_12(); break;
                                     case 13 : JT_13(); break;
                                     case 20 : JT_20(); break;
                                     case 21 : JT_21(); break;
                                     case 22 : JT_22(); break;
                                     case 23 : JT_23(); break;
                                  }
                                  break;
          //Rooms to add later...
          case Frontier : break;
          case Continental : break;
          case SouthWest : break;
          case Train_Tunnel : break;

          default : System.out.print("\n\tSomething went wrong! Navigation error.");

      }
}

//------------------------------------------------------------

       public void Intro()
       {
               System.out.print(
               "\n\n\n\tImagine... What if all those \"conspiracy theories\" you hear" +
               "\n\tabout on the internet were somehow true? What if? Sometimes the" +
               "\n\ttruth IS stranger than fiction, and actual historical events" +
               "\n\tbecome more macbre and surreal than the grizzliest urban legend..." +
                "\n\n\tSo it was through a seemingly random series of capricious "+
                "\n\tcoincidences that you found yourself in seriptitious synchronicity" +
                "\n\twith the weakest links that forge the chains of cause and effect." +
                "\n\tIt was for this reason that you came to Denver International Airport"+
                "\n\tand left your once blissful life behind. There must be an explanation," +
                "\n\tthere must be an answer, somewhere...\n");

               F.PAUSE();

               System.out.print(
               "\n\n\n\tNothing could have prepared you for the oddities that soon became" +
               "\n\tan every-day occurence. People whom you had never met before began" +
               "\n\tto show up in your life daily, seemingly in possession of knowledge of" +
               "\n\tintimate personal details that you had shared with no one else." +
               "\n\tThese individuals seemed to constantly hint at and make references to " +
               "\n\tprivate converstations they should have had no knowledge of - even subtle" +
               "\n\tcomments you had mentioned only to yourself in times of inner reflection.\n" +
               "\n\tCould they actually read your mind? Who were they? And why the constant," +
               "\n\tdisturbing feelings of \"De ja vu\"? The incessant confusion? Hours of" +
               "\n\tmissing time? Entire days that could not be accounted for in your memory?\n");


               F.PAUSE();

               System.out.print(
               "\n\n\n\tWhat was so important about the endless trivialities of your" +
               "\n\tbanal and mundane existence that seemed to utterly fascinate them?" +
               "\n\tWas it a joke, a ruse, a clever game played by an esoteric elite" +
               "\n\twho enjoyed toying with the \"common folk\" or manipulating the masses?\n" +
               "\n\tWho has that much time on their hands? Did they really have nothing" +
               "\n\tbetter to do? Or had you stumbled onto a secret they thought you simply" +
               "\n\tcould not keep? If so, why hadn't they simply snuffed you out?" +
               "\n\tThey has an infinite number of opportunities to do so and the" +
               "\n\tobvious resources necessary to make it look like an accident...\n");

               F.PAUSE();

               System.out.print(
               "\n\n\n\tHere you were, trying to jump ahead and make an unexpected move." +
               "\n\tHad you truly been unpredictable, or were you merely playing into" +
               "\n\ttheir assortment of pre-determined possibilities and patterns for" +
               "\n\tindividuals pertaining to a particular profile?\n");

               F.PAUSE();
               
               System.out.print(
               "\n\n\n\tYou took the \"red pill\"... left your job, your home, your" +
               "\n\tfamily and friends - all behind you now. Fading into the distance," +
               "\n\tyour past seemed more and more a fabricated existence with each" + 
               "\n\tpassing day. Sacrificing everything to search out the ultimate truth." +
               "\n\tThere was nothing left for you now but to seek it...\n");
               
               F.PAUSE();

               F.LOCATION = JeppesenTerminal;
               F.ROW = 2; F.COLUMN = 3;
               SwitchBoard();          
       }

//------------------------------------------------------------

//Jeppesen Terminal Sectors

 public void JT_00()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_00] You are standing in the north-west" +
                         "\n\tcorner of Jeppesen Terminal. To the south is" +
                         "\n\tthe Masonic panel. To your east a shiny marble " +
                         "\n\tfloor tiles towards the center of the Great Hall.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see a black metal door." +
                                      "\n\tTo the west you see a wall mural." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (e)ast or (s)outh\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : System.out.print(
                                    "\n\tYou can't open the black metal door. " +
                                    "\n\tIt's locked.\n");
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : System.out.print(
                                    "\n\tYou see a grotesque mural on the wall.\n");
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

 public void JT_01()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_01] You are standing against the north wall of" +
                         "\n\tJeppesen Terminal. To the south is the room's center." +
                         "\n\tTo your west is the marble floor leads to the " +
                         "\n\tnorth-west corner of the Great Hall.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see a wooden door." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (e)ast or (s)outh or (w)est\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : System.out.print(
                                    "\n\tYou can't open the wooden door. It's jammed.\n");
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }


//------------------------------------------------------------
 public void JT_02()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_02] You are standing against the north wall of" +
                         "\n\tJeppesen Terminal. To the south is the room's center." +
                         "\n\tTo your east is the marble floor leads to the " +
                         "\n\tnorth-east corner of the Great Hall.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see an electronic sliding door." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (e)ast or (s)outh or (w)est\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : System.out.print(
                                    "\n\tYou can't open the sliding electronic door." +
                                    "\n\tIt appears there is no power to operate it.\n");
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

 public void JT_03()
 {
         String choice = " ";

         System.out.print("\n\n\n\t[JT_03] You are standing in the north-east" +
                         "\n\tcorner of Jeppesen Terminal. Far to the south is" +
                         "\n\tis the door in front of which you first started." +
                         "\n\tTo your west a shiny marble floor edges along" +
                         "\n\tthe north wall of the Great Hall.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see an red metal door." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (w)est or (s)outh\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : System.out.print(
                                    "\n\tYou can't open the red metal door. " +
                                    "\n\tIt's locked.\n");
                                    JT_03_FoundJackKnife =
                                    F.FIND("shiny metal object","Jack Knife",JT_03_FoundJackKnife,0);
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : System.out.print(
                                    "\n\tYou notice the colorful yet DARK murals painted" +
                                    "\n\tin pastels and mosaics along the wall.\n");
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }
//------------------------------------------------------------

 public void JT_10()
 {
         String choice = " ";

         System.out.print("\n\n\n\t[JT_10] You are standing in the center of the" +
                          "\n\tthe far west wall of Jeppesen Terminal. There in front" +
                          "\n\tof you is the Masonic panel. It has the Masonic seal" +
                          "\n\tand several symbols and ruins which you do not recognize." +
                          "\n\tPerhaps they are ancient egyptian. The panel seems to be" +
                          "\n\thewn from something like obsidian and mounted on a slab" +
                          "\n\tof granite.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tFurther to the north lies the north-west" +
                                      "\n\tcorner of the great hall and what looks like" +
                                      "\n\ta red metal door in the distance. In front" +
                                      "\n\tof you sits the Masonic panel doing nothing." +
                                      "\n\tTo the south lies the south-west corner." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (e)ast or (n)orth or (s)outh\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : System.out.print(
                                    "\n\tThe Masonic panel captures your gaze. It" +
                                    "\n\tis glossy and shiny but does not appear to" +
                                    "\n\tdo anything interesting at this time.\n");
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

 public void JT_11()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_11]. You step into the western center" +
                         "\n\tof \"The Great Hall\".\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tYou may use: (o)ptions" +
                             "\n\tYou may go: (n)orth, (s)outh, (e)ast, (w)est\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }


//------------------------------------------------------------
 public void JT_12()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_12]. You step into the eastern center" +
                         "\n\tof \"The Great Hall\".\n");

               JT_12_FoundAmmo =
               F.FIND("unused ammo clip","Glock Ammo",JT_12_FoundAmmo,7);

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tYou may use: (o)ptions" +
                             "\n\tYou may go: (n)orth, (s)outh, (e)ast, (w)est\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

 public void JT_13()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_13]. You are standing in the center of the" +
                         "\n\teastern wall of Jeppesen Terminal. To your east you" +
                         "\n\tsee an escalator leading down to a subterranean " +
                         "\n\ttunnel. I sign hangs over it marked \"Train\". To" +
                         "\n\tyour north in the distance you see a metalic red" +
                         "\n\tdoor. To the south in the distance lies a silver door.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (n)orth or (s)outh or (w)est" +
                                      "\n\tOr, (t)ake the escalator down to the tunnel.\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : F.ROW++;
                                    SwitchBoard();
                                    break;
                         case 'e' : System.out.print("\n\tYou see a concrete wall.");
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 't' : System.out.print("\n\tThe path to the tunnel is " +
                                    "locked for now.\n\tMore to CODE later...\n");
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

 public void JT_20()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_20] You are standing in the south-west" +
                         "\n\tcorner of Jeppesen Terminal. To the noth is" +
                         "\n\tthe Masonic panel. To your east a shiny marble " +
                         "\n\tfloor tiles towards the center of the Great Hall.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see a black metal door." +
                                      "\n\tTo the west you see a wall mural." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (e)ast or (n)orth\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : System.out.print(
                                    "\n\tYou see a wall with grotesque, apocalyptic murals." +
                                    "\n\tIn the mural children of various nationalities are" +
                                    "\n\tare laid out neatly in coffins and fire burns the" +
                                    "\n\tearth.\n");
                                    break;
                         case 'e' : F.COLUMN++;;
                                    SwitchBoard();
                                    break;
                         case 'w' : System.out.print(
                                    "\n\tYou see another apocalyptic mural. In this one," +
                                    "\n\ta giant soldier wheres a bio-hazard suit and a" +
                                    "\n\tgas mask. He holds a sword in his hand and he is" +
                                    "\n\tramming its point into the dove of peace.");

                                    JT_20_FoundAmmo =
                                    F.FIND("unused ammo clip","Glock Ammo",JT_20_FoundAmmo,13); break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

 public void JT_21()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_21] You are standing against the south wall of" +
                         "\n\tJeppesen Terminal. To the north is the room's center." +
                         "\n\tTo your east the marble floor leads to the " +
                         "\n\tsouth-east corner of the Great Hall. To the west" +
                         "\n\tis the opposite corner.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see a black metal door." +
                                      "\n\tTo the west you see a wall mural." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (e)ast or (w)est or (n)orth\n\n\t");
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : System.out.print(
                                    "\n\tYou see an odd, grotesque mural. Painted in this" +
                                    "\n\tmural, colorful mosaics depicting what might be " +
                                    "\n\tthe artist's prediction of WWIII and dark visions" +
                                    "\n\tof concentration camps tell the story of man's cruelty" +
                                    "\n\tupon himself and his destructive legacy. In the corner" +
                                    "\n\tof the mural is a letter with words written by a child" +
                                    "\n\twho perished in a WWII concentraion camp.\n");
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

  public void JT_22()
 {
        String choice = " ";

        System.out.print("\n\n\n\t[JT_22] You are standing against the south wall of" +
                         "\n\tJeppesen Terminal. To the north is the room's center." +
                         "\n\tTo your east the marble floor leads to the " +
                         "\n\tsouth-east corner of the Great Hall. To the west" +
                         "\n\tis the opposite corner.\n");

               while(!choice.equals("q"))
               {
                     System.out.print("\n\tTo your north you see a black metal door." +
                                      "\n\tTo the west you see a wall mural." +
                                      "\n\tYou may use: (o)ptions" +
                                      "\n\tYou may go: (n)orth or (e)ast or (w)est\n\n\t");
                                      
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : System.out.print(
                                    "\n\tYou see a colorful mosaic depicting macabre scenes" +
                                    "\n\tof abstract horror from the darkest recesses of"+
                                    "\n\t the artist's very worst nightmares...\n");
                                    break;
                         case 'e' : F.COLUMN++;
                                    SwitchBoard();
                                    break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }
               }
 }

//------------------------------------------------------------

       public void JT_23()
       {
              String choice = " ";

              System.out.print("\n\n\n\t[JT_23] You find yourself standing in" +
                               "\n\tthe south-east corner of the Jeppensen Terminal" +
                               "\n\tat the Denver International Airport. You see" +
                               "\n\todd, colorful, apocalyptic murals running parallel" +
                               "\n\tto the entrance. In the distance, near the center" +
                               "\n\tof the far western wall of the \"Great Hall\" in" +
                               "\n\twhich you are standing is an odd stone panel," +
                               "\n\tcomposed of something like granite and bearing the" +
                               "\n\tsymbol and seal of one of the masonic orders.\n");
              
               while(!choice.equals("q"))
               { 
                     System.out.print("\n\tYou may use: (o)ptions" +
                             "\n\tYou may go: (n)orth or (w)est\n\n\t");
                     
                     choice = F.INPUT();

                     switch(choice.charAt(0))
                     {
                         case 'n' : F.ROW--;
                                    SwitchBoard();
                                    break;
                         case 's' : System.out.print("\n\tA locked door.\n"); break;
                         case 'e' : System.out.print("\n\tYou see a wall.\n"); break;
                         case 'w' : F.COLUMN--;
                                    SwitchBoard();
                                    break;
                         case 'o' : F.Options(); break;
                         default: System.out.print("\n\tNot a valid option...");
                     }

               }    
       }

//------------------------------------------------------------
           
}//close Level 1 class
