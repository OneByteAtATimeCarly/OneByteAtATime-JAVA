//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class Snabbit extends HYBRID
{
       Snabbit(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating an Snabbit = Snake + Rabbit...");
           SetAttitude(4);
           SetSpecies("Snabbit");
           SetSpcAtk("Venom");
           SetSpcDef("Bunny Hop");
           SetSpeed(8);
           SetSize(2);
           FUNCTIONS = X;
       }

       //Functions
       void Hop()
       { System.out.print("\n\tSnabbit hopping..."); }

       void Slither()
       { System.out.print("\n\tSnabbit slithering..."); }
}
