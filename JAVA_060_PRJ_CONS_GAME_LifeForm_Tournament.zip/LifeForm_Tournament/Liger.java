//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class Liger extends HYBRID
{
       Liger(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating an Liger = Lion + Tiger...");
           SetAttitude(3);
           SetSpecies("Liger");
           SetSpcAtk("Claws");
           SetSpcDef("Dexterity");
           SetSpeed(3);
           SetSize(7);
           FUNCTIONS = X;
       }

       //Functions
       void Pace()
       { System.out.print("\n\tLiger pacing..."); }

       void Twitch()
       { System.out.print("\n\tLiger twitching..."); }
}
