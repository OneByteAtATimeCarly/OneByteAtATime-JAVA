//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class Gippo extends HYBRID
{
       Gippo(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating a Gippo = Giraffe + Hippo...");
           SetAttitude(1);
           SetSpecies("Gippo");
           SetSpcAtk("Neck Ram");
           SetSpcDef("Blubber Bounce");
           SetSpeed(1);
           SetSize(9);
           FUNCTIONS = X;
       }
       
       //Functions
       void Squash() { System.out.print("\n\tGippo squashing..."); }
}
