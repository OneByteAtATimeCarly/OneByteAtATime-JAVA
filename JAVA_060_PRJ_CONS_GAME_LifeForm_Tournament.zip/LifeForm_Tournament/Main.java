//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

//Main game class

import java.io.*;

public class Main
{
       public static LineNumberReader INPUT =
               new LineNumberReader(new InputStreamReader(System.in));

       public static boolean CreatedLifeForms = false;

    public static void main(String[] args)
    {
           String CHOICE = " ";
           LifeFormFunctions GAME = new LifeFormFunctions();

           System.out.print("\n\tWelcome to LifeForm 1.0!");

           while(CHOICE.charAt(0) !='q')
           {
               System.out.print("\n\t**********Main Menu**********");
               System.out.print("\n\t*                           *");
               System.out.print("\n\t*     (C)reate LifeForm     *");
               System.out.print("\n\t*     (L)oad LifeForm       *");
               System.out.print("\n\t*     (S)ave LifeForm       *");
               System.out.print("\n\t*     (P)lay Game           *");
               System.out.print("\n\t*     (D)isplay LifeForms   *");
               System.out.print("\n\t*     (T)ournament          *");
               System.out.print("\n\t*     (Q)uit                *");
               System.out.print("\n\t*                           *");
               System.out.print("\n\t*****************************\n\n\t");

               try { CHOICE = INPUT.readLine(); }
               catch(IOException X) { System.out.print("\n\tError."); }

               CHOICE = CHOICE.toLowerCase();

               switch(CHOICE.charAt(0))
               {
                   case 'c' : GAME.Create_2_LifeForms();
                              CreatedLifeForms = true;
                              break;
                   case 'l' : break;
                   case 's' : break;
                   case 'p' : break;
                   case 't' : if(CreatedLifeForms)
                              { GAME.Tournament(); }
                              else
                              {
                                 System.out.print(
                                 "\n\tNeed to create LifeForms first.\n");
                              }
                              break;
                   case 'd' : if(CreatedLifeForms)
                              {  GAME.DisplayCritters(); }
                              else
                              {
                                 System.out.print(
                                 "\n\tNeed to create LifeForms first.\n");
                              }
                              break;
                   case 'q' : break;
                   default : System.out.print("\n\tInvalid input.");
                             break;
               }
           }

           System.out.print("\n\n\tExiting LifeForm 1.0...\n\n");
    }

}
