//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

//ADT - Base Class

public class Animal extends LifeForm
{
       Animal() { System.out.print("\n\tCreating an Animal..."); }
}


