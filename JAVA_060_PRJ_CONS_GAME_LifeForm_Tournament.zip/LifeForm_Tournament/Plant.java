//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

//ADT - Plant

public class Plant extends LifeForm
{
       Plant() { System.out.print("\n\tCreating a PLANT..."); }
}
