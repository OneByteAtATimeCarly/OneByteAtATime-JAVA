//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

//ADT = Base class and parent for all other objects

import java.util.Random;

public class LifeForm
{

       public LifeFormFunctions FUNCTIONS;
       int MaxDamage = 70;

       LifeForm()
       { System.out.print("\n\tCreating a LifeForm."); }

       //Overloading
       LifeForm(LifeFormFunctions APPLE)
       {
           System.out.print("\n\tCreating a LifeForm.");
           FUNCTIONS = APPLE;
       }

       //Functions
       public void DisplayLifeForm()
       {
              System.out.print("\n\n\t---------LifeForm Stats:---------");
              System.out.print("\n\tName: " + NAME);
              System.out.print("\n\tSpecies: " + SPECIES);
              System.out.print("\n\tHealth: " + HEALTH);
              System.out.print("\n\tAttitude: ");

              switch(Attitude)
              {
                  case 1 : System.out.print("HAPPY"); break;
                  case 2 : System.out.print("O.K."); break;
                  case 3 : System.out.print("ANNOYED"); break;
                  case 4 : System.out.print("ANGRY"); break;
                  case 5 : System.out.print("ENRAGED"); break;
              }

              System.out.print("\n\tSpeed: " + SPEED);
              System.out.print("\n\tSize: " + SIZE);
              System.out.print("\n\tDef: " + DEF);
              System.out.print("\n\tAtk: " + ATK);
              System.out.print("\n\tSpc Energy: " + SPC_ENERGY);
              System.out.print("\n\tSpc Atk: " + SPC_ATK);
              System.out.print("\n\tSpc Def: " + SPC_DEF);
              System.out.print("\n\t---------------------------------\n");

       }

       public void Attack(LifeForm OPPONENT) 
       {
           System.out.print("\n\n\t" + NAME + " the " + SPECIES
                            + " attacks " + OPPONENT.GetName()
                            + " the " + OPPONENT.GetSpecies() 
                            + ".");

           System.out.print("\n\n\tBEFORE ATTACK: " +
                            NAME + " HEALTH = " + HEALTH 
                            + "    " + OPPONENT.GetName()
                            + " HEALTH = " +
                            OPPONENT.GetHealth());

          int DAMAGE = FUNCTIONS.RN(MaxDamage);

          if(OPPONENT.GetHealth() - DAMAGE > 0)
          {
             OPPONENT.SetHealth(OPPONENT.GetHealth() - DAMAGE );
          }
          else
          {
             OPPONENT.SetHealth(0);
          }

          System.out.print("\n\n\t" + NAME + " inflicts " + DAMAGE
                           + " points of DAMAGE to" +
                           OPPONENT.GetName() + "!");

          System.out.print("\n\tAFTER ATTACK: " +
                            NAME + " HEALTH = " + HEALTH
                            + "    " + OPPONENT.GetName()
                            +  " HEALTH = " +
                            OPPONENT.GetHealth());
           
       }


       public void Talk() { System.out.print("\n\tSpeaking..."); }
       public void Eat() { System.out.print("\n\tEating..."); }
       public void Reproduce() { System.out.print("\n\tReproducing..."); }

       //Public Accessor Methods
       public int GetHealth() { return HEALTH; }
       public void SetHealth(int X) { HEALTH = X; }
       public int GetAtk() { return ATK; }
       public void SetAtk(int X) { ATK = X; }
       public int GetDef() { return DEF; }
       public void SetDef(int X) { DEF = X; }
       public int GetSpcEnergy() { return SPC_ENERGY; }
       public void SetSpcEnergy(int X) { SPC_ENERGY = X; }
       public int GetSpeed() { return SPEED; }
       public void SetSpeed(int X) { SPEED = X; }
       public int GetSize() { return SIZE; }
       public void SetSize(int X) { SIZE = X; }
       public int GetAttitude() { return Attitude; }
       public void SetAttitude(int X) { Attitude = X; }
       public String GetName() { return NAME; }
       public void SetName(String X ) { NAME = X; }
       public String GetSpcAtk() { return SPC_ATK; }
       public void SetSpcAtk(String X ) { SPC_ATK = X; }
       public String GetSpcDef() { return SPC_DEF; }
       public void SetSpcDef(String X ) { SPC_DEF = X; }
       public String GetSpecies() { return SPECIES; }
       public void SetSpecies(String X ) { SPECIES = X; }

       //Private Data
       private int HEALTH = 100;
       private int ATK = 1;
       private int DEF = 1;
       private int SPC_ENERGY = 10;
       private int SPEED = 1;
       public int SIZE = 1;
       private int Attitude = 1;
       private String NAME = "Anonymous LifeForm";
       private String SPC_ATK = "Generic Attack";
       private String SPC_DEF = "Generic Defense";
       private String SPECIES = "Generic LifeForm";

}//close LifeForm class

//---------------------------------------------------------------------------

