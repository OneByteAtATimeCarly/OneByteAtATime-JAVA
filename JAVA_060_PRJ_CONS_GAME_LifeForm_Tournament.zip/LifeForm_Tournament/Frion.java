//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class Frion extends HYBRID
{
       Frion(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating an Frion = Frog + Lion...");
           SetAttitude(2);
           SetSpecies("Frion");
           SetSpcAtk("Claws");
           SetSpcDef("Water Breathing");
           SetSpeed(4);
           SetSize(6);
           FUNCTIONS = X;
       }

       //Functions
       void PAD()
       { System.out.print("\n\tFrion walking on wall..."); }
}
