//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

import java.io.*;
import java.util.Random;

public class LifeFormFunctions
{
       //Globals
       public static LineNumberReader INPUT =
                  new LineNumberReader(new InputStreamReader(System.in));

       public Random RAN = new Random();

       public static LifeForm LifeForm_ONE;
       public static LifeForm LifeForm_TWO;

       //Constructor
       LifeFormFunctions()
       { System.out.print("\n\tCreating a LifeFormFunctions object."); }

//---------------------------------------------------------------------------

       public String IN()
       {
              String BANANA = "ERROR";
              try{BANANA = INPUT.readLine(); }
              catch(IOException KIWI) { System.out.print("\n\tError!"); }
              return BANANA;
       }

//---------------------------------------------------------------------------

       public int RN(int X)
       {
              int RandomNumber = RAN.nextInt(X) + 1;
              return RandomNumber;
       }

//---------------------------------------------------------------------------

       public void Create_2_LifeForms()
       {
              System.out.print("\n\n\tPlease Create LifeForm One: ");
              LifeForm_ONE = Create_A_LifeForm();
              System.out.print("\n\n\tPlease Create LifeForm Two: ");
              LifeForm_TWO = Create_A_LifeForm();      
       }
//---------------------------------------------------------------------------

       public LifeForm Create_A_LifeForm()
       {
              LifeForm X = new LifeForm();
              String N = "";
              int M = 1;
              boolean Made_LifeForm = false;

              while(!Made_LifeForm)
              {
                   System.out.print(
                   "\n\n\tWhat type of LifeForm will you create? ");
                   System.out.print("\n\tYou may make a new:");
                   System.out.print("\n\t1. (C)hiHuaHua");
                   System.out.print("\n\t2. (O)ctoRat");
                   System.out.print("\n\t3. (S)nabbit");
                   System.out.print("\n\t4. (L)iger");
                   System.out.print("\n\t5. (F)rion");
                   System.out.print("\n\t6. (G)ippo");
                   System.out.print("\n\t7. (J)onkey\n\n\t");
              
                   N = IN();
                   N = N.toLowerCase();
              
                   switch(N.charAt(0))
                   {
                       case 'c' : X = new ChiHuaHua(this);
                                  Made_LifeForm = true;
                                  break;
                       case 'o' : X = new OctoRat(this);
                                  Made_LifeForm = true;
                                  break; 
                       case 's' : X = new Snabbit(this);
                                  Made_LifeForm = true;
                                  break;
                       case 'l' : X = new Liger(this);
                                  Made_LifeForm = true;
                                  break;
                       case 'f' : X = new Frion(this);
                                  Made_LifeForm = true;
                                  break;
                       case 'g' : X = new Gippo(this);
                                  Made_LifeForm = true;
                                  break;
                       case 'j' : X = new Jonkey(this);
                                  Made_LifeForm = true;
                                  break;
                       default : System.out.print("\n\tInvalid option.");
                       
                   }//close switch
                   
              }//close loop

              System.out.print("\n\n\tWhat will you name your LifeForm? ");
              N = IN();
              X.SetName(N);

              while((X.GetAtk() +  X.GetDef()) != 5)
              {
                  if((X.GetAtk() +  X.GetDef()) > 5)
                     System.out.print(
                     "\n\tAttack and Defense cannot be greater than 5!\n");
                  else
                  {
                     System.out.print(
                     "\n\tAllocate 5 points between Attack and Defense!");
                     System.out.print(
                     "\n\tSo far, points are allocated as follows:");
                     System.out.print("\n\tAttack:" + X.GetAtk());
                     System.out.print("\n\tDefense:" + X.GetDef());
                     System.out.print("\n\n");
                  }

                  System.out.print("\tHow many points for DEF? (5 max) ");
                  N = IN();

                  try { M = Integer.parseInt(N); }
                  catch(NumberFormatException Z)
                  { System.out.print("\n\tNot a number!"); }

                  X.SetDef(M);

                  System.out.print("\tHow many points for ATK? (5 max) ");
                  N = IN();

                  try { M = Integer.parseInt(N); }
                  catch(NumberFormatException Z)
                  { System.out.print("\n\tNot a number!"); }
                  
                  X.SetAtk(M);

             }//close loop
             
             X.DisplayLifeForm();

             return X;

      }//close function

//--------------------------------------------------------------------

       public void DisplayCritters()
       {
              System.out.print("\n\tLifeForm One: ");
              LifeForm_ONE.DisplayLifeForm();
              System.out.print("\n\tLifeForm Two: ");
              LifeForm_TWO.DisplayLifeForm();
       }

//---------------------------------------------------------------------------

public void Tournament()
{
       System.out.print("\n\tTournament!\n");

       int FirstAttack = RN(2);

       if(FirstAttack == 1)
       {
          while(LifeForm_ONE.GetHealth() > 0 && LifeForm_TWO.GetHealth() > 0)
          {
               LifeForm_ONE.Attack(LifeForm_TWO);
               System.out.print("\n");

               try { Thread.sleep(2000); }
               catch(Exception X) { }

               if(LifeForm_TWO.GetHealth() > 0)
               { LifeForm_TWO.Attack(LifeForm_ONE); }
               System.out.print("\n");

               try { Thread.sleep(2000); }
               catch(Exception X) { }
          }
       }
       else
       {
          while(LifeForm_ONE.GetHealth() > 0 && LifeForm_TWO.GetHealth() > 0)
          {
               LifeForm_TWO.Attack(LifeForm_ONE);
               System.out.print("\n");

               try { Thread.sleep(2000); }
               catch(Exception X) { }

               if(LifeForm_ONE.GetHealth() > 0)
               { LifeForm_ONE.Attack(LifeForm_TWO); }
               System.out.print("\n");

               try { Thread.sleep(2000); }
               catch(Exception X) { }
          }                    
       }


       }

}//close LifeFormFunctions class
