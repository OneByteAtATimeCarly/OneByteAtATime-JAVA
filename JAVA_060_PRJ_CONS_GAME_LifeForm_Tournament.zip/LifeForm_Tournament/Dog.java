//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

//Dog class

public class Dog extends Mammal
{
       Dog() { System.out.print("\n\tCreating a Dog object..."); }

       //Public Accessors

}
