//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

//Actual child or derived object

public class ChiHuaHua extends Dog
{
       ChiHuaHua(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating a small, annoying Dog...");
           SetAttitude(5);
           SetSpecies("ChiHuaHua");
           SetSpcAtk("Yap");
           SetSpcDef("Dodge");
           SetSpeed(9);
           SetSize(1);
           FUNCTIONS = X;
       }
       
       //Functions
       void Yap() { System.out.print("\n\tChiHuaHua yapping..."); }

}
