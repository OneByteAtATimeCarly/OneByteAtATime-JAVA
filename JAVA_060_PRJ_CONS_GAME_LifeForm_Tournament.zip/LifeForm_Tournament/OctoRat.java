//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class OctoRat extends HYBRID
{
       OctoRat(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating an OctoRat = Octopus + Rat...");
           SetAttitude(5);
           SetSpecies("OctoRat");
           SetSpcAtk("Tentacle Squeeze");
           SetSpcDef("Super Immunity");
           SetSpeed(9);
           SetSize(1);
           FUNCTIONS = X;
       }

       //Functions
       void Grope()
       { System.out.print("\n\tOctoRat groping with tentacles..."); }

       void Gnaw()
       { System.out.print("\n\tOctoRat gnawing with teeth..."); }
}
