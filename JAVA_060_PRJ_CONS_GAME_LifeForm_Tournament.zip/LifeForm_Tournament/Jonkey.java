//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class Jonkey extends HYBRID
{
       Jonkey(LifeFormFunctions X)
       {
           System.out.print("\n\tCreating an Jonkey = JellyFish + Monkey...");
           SetAttitude(1);
           SetSpecies("Jonkey");
           SetSpcAtk("Venom Blast");
           SetSpcDef("Flip Dodge");
           SetSpeed(8);
           SetSize(2);
           FUNCTIONS = X;
       }

       //Functions
       void Swinging()
       { System.out.print("\n\tJonkey (swinging) oozing from a tree"); }

}
