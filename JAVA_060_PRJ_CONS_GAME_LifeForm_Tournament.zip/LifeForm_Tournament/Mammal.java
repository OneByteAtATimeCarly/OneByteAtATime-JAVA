//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class Mammal extends Animal
{
       Mammal() { System.out.print("\n\tCreating an Animal..."); }
}
