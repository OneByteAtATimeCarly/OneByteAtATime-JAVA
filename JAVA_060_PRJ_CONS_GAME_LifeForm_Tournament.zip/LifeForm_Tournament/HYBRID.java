//Project - LifeForm Tournament Game - 2006 - Carly Salali Germany

public class HYBRID extends LifeForm
{
       HYBRID() { System.out.print("\n\tCreating a HYBRID..."); }
}
