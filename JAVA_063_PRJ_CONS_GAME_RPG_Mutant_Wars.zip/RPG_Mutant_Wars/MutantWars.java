//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Main Game class

//Main Class - Static

import java.io.*;

public class MutantWars
{
       //Pointers to Globals
       public static int LEVEL = 1;

       public static boolean L2WasInitialized = false;
       public static boolean L3WasInitialized = false;                

       public static boolean CONTINUE = true; 
       public static int LastNumber = 0;

       //Level 1 Items (global pointers)
       public static Level1 Level1Events; 
       public static Freezer L1_FreezerMutant;
       public static Civilian L1_HumanGirl;

       //Level 2 Items (global pointers)
       public static Level2 Level2Events;

       //Level 3 Items (global pointers)
       public static Level3 Level3Events;

       //The Player Object
       public static Impath Player = new Impath();

       //Global pointers to File I/O Objects
       public static File PlayerFile;
       public static FileOutputStream PlayerOut;
       public static PrintStream WritePlayer;
       public static FileInputStream PlayerIn;
       public static InputStreamReader ReadPlayer;
       public static BufferedReader StreamPlayer;

//---------------------------------------------------------------------------------------------------

       public static void main(String args[])
       {           
              String OUT = "\n\tStarting Mutant Wars 1.0!";
              System.out.print(OUT); 

              Player.NameLifeForm(); 
   
              Initialize_L1();
              Level1Events.Intro();


              while(CONTINUE == true && (Player.GetHit() > 0))
              {
                  //Don't instantiate levels and use resources until needed!
                  if(LEVEL == 2 && L2WasInitialized == false) {  Initialize_L2(); }
                  if(LEVEL == 3 && L3WasInitialized == false) {  Initialize_L3(); }

                  switch(LEVEL)
                  {
                      case 1 : Level1Events.Switchboard(); break;
                      case 2 : Level2Events.Switchboard(); break;
                      case 3 : Level3Events.Switchboard(); break;
                  }
              }


              boolean successful = Functions.SaveHighScores(Player);

              if(successful)
              { OUT = "\n\tScore saved to \"highscores.txt\".\n\n"; }
              else { OUT = "\n\tError. Score could not be saved!\n\n"; }


              OUT = OUT + "\tExiting Mutant Wars...\n\n";
              System.out.print(OUT);
       }
//-----------------------------------------------------------------------------------------------------

       public static void Initialize_L1()
       {
              String OUT = "\n\t--------- Creating and Initializing Level 1 Objects ---------";
              System.out.print(OUT);
              Level1Events = new Level1();
              L1_FreezerMutant = new Freezer("ICE",200);
              L1_HumanGirl = new Civilian("Trillian");
              Functions.PAUSE();
       }

       public static void Initialize_L2()
       {
              String OUT = "\n\t--------- Creating and Initializing Level 2 Objects ---------";
              System.out.print(OUT);
              Level2Events = new Level2();
              L2WasInitialized = true;
              Functions.PAUSE();
       }

       public static void Initialize_L3()
       {
              String OUT = "\n\t--------- Creating and Initializing Level 3 Objects ---------";
              System.out.print(OUT);
              Level3Events = new Level3();
              L3WasInitialized = true;
              Functions.PAUSE();
       }
}






//-----------------------------------------------------------------------------------------------------------
/*Note: The DOS CLS function to clear the screen supported in C++ is not supported in Java.
  The reason is platform independence. "CLS" clears a Windows console, "clear" clear a \     
  Linux console. In order for Java to be platform independent, we should just print a number
  of lines to clear the screen. This way our console programs will run on Windows or Linux
  without a hitch or modifications. If however, you simply must have a "CLS", realize that it
  will cost you independence. If this is acceptable to you, you may implement is one of 2 ways:

  Method 1 (ANSI codes):

  //Step 1 -> Add the following to the Java file ad compile
  char ESC = 27; 
  String CLS = ESC + "[2J"; 
  System.out.print(CLS);

  //Step 2 -> Add this line to the config.sys file in the Windows root directory and reboot:
  device=c:\windows\command\ansi.sys


  Method 2 (Create a .dll file to call the console "CLS" command):

  //Step 1 -> Create a a JNI header class in Java that Uses a C++ .dll file.
  //       -> Compile it with "javac" to make the byte code. Example:  "javac ClearScreen.java"
  //       -> Convert your new class with the "javah" command like:  "javah ClearScreen".
  //       -> This creates a C++ header file called "ClearScreen.h"

  class ClearScreen 
  {
        public native void cls();

        public static final short BACKGROUND_BLUE  = 0x10;
        public static final short BACKGROUND_GREEN = 0x20;
        public static final short BACKGROUND_RED   = 0x40;
        public static final short BACKGROUND_INTENSITY = 0x80;

        public static final short TEXT_BLACK = 0x0;
        public static final short TEXT_BLUE  = 0x1;
        public static final short TEXT_GREEN = 0x2;
        public static final short TEXT_RED   = 0x4;
        public static final short TEXT_WHITE = 0x7;
        public static final short TEXT_INTENSITY = 0x8;

        public native void setCursorPosition(short x, short y);
        public native void keepColors();
        public native void restoreColors();
        public native void setColor(short test, short background);

        static { System.loadLibrary("jni3"); }
  }


  //Step 2 -> Create a .dll file in C++ to access System("CLS").
  //       -> Save it in the same directory as your java class files.

  #include "stdafx.h"
  #include <stdlib.h>
  #include "ClearScreen.h"


  int originalColors;

  BOOL APIENTRY DllMain(HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
  { return TRUE; }


  JNIEXPORT void JNICALL Java_ClearScreen_cls(JNIEnv *env, jobject obj) 
  {
    
      HANDLE hConsole;
      unsigned long * hWrittenChars = 0;
      CONSOLE_SCREEN_BUFFER_INFO strConsoleInfo;
      COORD Home;
      static unsigned char EMPTY = 32;

      Home.X = 0;
      Home.Y = 0;
      hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
      GetConsoleScreenBufferInfo(hConsole, &strConsoleInfo);

      FillConsoleOutputCharacter(hConsole, EMPTY, 
                                 strConsoleInfo.dwSize.X * strConsoleInfo.dwSize.X, 
                                 Home, hWrittenChars);

      SetConsoleCursorPosition(hConsole, Home);
      //system("cls");  will do the same as the above!
  }

  JNIEXPORT void JNICALL Java_ClearScreen_setCursorPosition
  (JNIEnv *env, jobject obj, jshort x, jshort y) {

      HANDLE hConsole;
      COORD coordScreen;  

      hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
      coordScreen.X = x;
      coordScreen.Y = y;
      SetConsoleCursorPosition( hConsole, coordScreen );
 
  }

  JNIEXPORT void JNICALL Java_ClearScreen_setColor
  (JNIEnv *env, jobject obj, jshort foreground, jshort background) 
  {
       HANDLE hConsole;
       hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
       SetConsoleTextAttribute(hConsole, foreground + background);
  }

  JNIEXPORT void JNICALL Java_ClearScreen_keepColors(JNIEnv *env, jobject obj) 
  {
       HANDLE hConsole;
       CONSOLE_SCREEN_BUFFER_INFO ConsoleInfo;
       hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
       GetConsoleScreenBufferInfo(hConsole, &ConsoleInfo);
       originalColors = ConsoleInfo.wAttributes;
  }

  JNIEXPORT void JNICALL Java_ClearScreen_restoreColors(JNIEnv *env, jobject obj) 
  {
       HANDLE hConsole;
       hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
       SetConsoleTextAttribute(hConsole, originalColors);
  }

  //Step 3 -> Use the .dll and header file that you created in the previous 2 steps.

  public class TheMainProgram 
  {
         public static void main(String[] args) 
         {
              ClearScreen jht = new ClearScreen();
    
              //Clear screen
              jht.cls();

              //Set color as WHITE on BLUE
              jht.setColor(jht.FOREGROUND_WHITE,jht.BACKGROUND_BLUE);
    
              //Kcurrent colors
              jht.keepColors();
    
              //Restore orginal colors
              jht.restoreColors();

              //set cursor at line 10 column 20
              jht.setCursorPosition((short)20,(short)10);
              System.out.print("Real's HowTo");
    
              //Set cursor at line 15 column 20
              jht.setCursorPosition((short)20,(short)15); 
  
              //Set cursor at line 20 column 0
              jht.setCursorPosition((short)0,(short)20);
         }

  }

*/