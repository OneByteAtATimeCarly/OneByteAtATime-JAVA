//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 33 lines of code

import javax.swing.*;
import java.io.*;

public class Healer extends Mutant
{
       public Healer() 
       {  
              String OUT = "\n\tCreating a Healer mutant.";
              System.out.print(OUT);
       }

       public Healer(String x)
       { 
              String OUT = "\n\tCreating a Healer mutant.";
              System.out.print(OUT);
              SetName(x);
       } 

       //Functions
       public void Heal() 
       {
              String OUT = "\n\tHealing...";
              System.out.print(OUT);
       }
       //Public Accesors
       

       //Private Data
}
