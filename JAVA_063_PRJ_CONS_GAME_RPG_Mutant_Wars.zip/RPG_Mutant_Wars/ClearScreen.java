//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007

  class ClearScreen 
  {
        public native void cls();

        public static final short BACKGROUND_BLUE  = 0x10;
        public static final short BACKGROUND_GREEN = 0x20;
        public static final short BACKGROUND_RED   = 0x40;
        public static final short BACKGROUND_INTENSITY = 0x80;

        public static final short TEXT_BLACK = 0x0;
        public static final short TEXT_BLUE  = 0x1;
        public static final short TEXT_GREEN = 0x2;
        public static final short TEXT_RED   = 0x4;
        public static final short TEXT_WHITE = 0x7;
        public static final short TEXT_INTENSITY = 0x8;

        public native void setCursorPosition(short x, short y);
        public native void keepColors();
        public native void restoreColors();
        public native void setColor(short test, short background);

        static { System.loadLibrary("jni3"); }
  }

