//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Level 3
//Class for Future Level 3 Events. This will modularize level design.
//16 lines of code

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Level3
{
       public Level3() {  }   
    
       public void Switchboard() 
       {

       }   
}