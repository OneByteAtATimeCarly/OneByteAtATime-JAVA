//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class Flyer extends Mutant
{
       public Flyer() 
       {  
              String OUT = "\n\tCreating a Flyer mutant.";
              System.out.print(OUT);
       }

       public Flyer(String x)
       { 
              String OUT = "\n\tCreating a Flyer mutant.";
              System.out.print(OUT);
              SetName(x);
       }  
 
       //Functions
       public void Fly() 
       { 
              String OUT = "\n\tFlying...";
              System.out.print(OUT); 
       }

       //Public Accesors
       

       //Private Data
}
