//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class

//Derived Class

//Class = 28 lines of code

import javax.swing.*;
import java.io.*;

public class Assassin extends Human
{    
       public Assassin() 
       {
              String OUT = "\n\tCreating a Assassin human.";
              System.out.print(OUT);
              SetCharClass("Assassin");
       }

       public Assassin(String x)
       {
              String OUT = "\n\tCreating an Assassin human.";
              System.out.print(OUT);
              SetName(x);
              SetCharClass("Assassin");
       }   

       //Human Functions


       //Public Accesor Methods


       //Private Data     

}
