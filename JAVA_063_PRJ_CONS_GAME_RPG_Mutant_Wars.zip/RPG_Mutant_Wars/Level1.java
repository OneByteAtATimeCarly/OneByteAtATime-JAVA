//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Level 1
//First Two Rings of Level 1 Completed.    
//2223 lines of code for this class.  This class is 1 of 18 used in this game.
//Events shell for class objects

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Level1
{
       String OUT = "";

//---------------------- Level 1 Location Tracking Globals-------------------

       //Location Tracking Constants
       public static final int QUIT = 0;
       public static final int C1 = 1;
       public static final int C1Roof = 2;
       public static final int C1Basement = 3;
       public static final int N1 = 4;
       public static final int S1 = 5;
       public static final int E1 = 6;
       public static final int E1Closet = 7;
       public static final int W1 = 8;
       public static final int N2 = 9;
       public static final int N2Garage = 10;
       public static final int N2Service = 11;
       public static final int S2 = 12;
       public static final int E2 = 13;
       public static final int W2 = 14;
       public static final int Surface = 15;
       public static final int BOSSFIGHT_L1 = 16;

       public static int LOCATION = C1; //starts here

//--------- Level 1 GLOBALS --------------------------

       //Declare and Initialize Event Data
       public final int KeyCode = 777;
       public boolean C1FirstTime = true;
       public boolean DataCrystalTaken = false;
       public boolean Found9mmAmmo = false;
       public boolean Found9mmAmmoBox = false;
       public boolean CardReaderActivated = false;
       public boolean Center1BasementFirstTime = true;
       public boolean DrankSoda = false;
       public boolean AteSandwhich = false;
       public boolean FoundMachete = false;
       public boolean FoundSyringe = false;
       public boolean FoundMatches = false;
       public boolean FoundFramePack = false;
       public boolean FoundMedKit = false;
       public boolean FoundMRERations = false;
       public boolean FoundSterno = false;
       public boolean N2FirstTime = true;
       public boolean FoundJacket = false;
       public boolean ExplodedTripBomb = false;
       public boolean FoundGun = false;
       public boolean FoundKeyCard = false;
       public boolean SwipedKeyCard = false;
       public boolean SurfaceDoorsLocked = true;
       public boolean East2FirstTime = true;
       public boolean West2FirstTime = true;
       public boolean FoughtFreezerMutant = false;
       public boolean RanAwayFromFreezerMutant = false;
       public boolean FoundKey = false;
       public boolean SafeFirstTime = true;
       public boolean SafeUnlocked = false;
       public boolean KEYinserted = false;
       public boolean FoundL1_HumanGirl = false;
       public boolean FromAtrium = false;

//-------------------------------------------------------------------------------

       public void Switchboard()
       {
              switch(LOCATION)
              {
                   case C1 : Center1(); break;
                   case C1Roof : Center1Roof(); break;
                   case C1Basement : Center1Basement(); break;
                   case N1 : North1(); break;
                   case S1 : South1(); break;
                   case E1 : East1(); break;
                   case E1Closet : East1Closet(); break;
                   case W1 : West1(); break;
                   case N2 : North2(); break;
                   case N2Garage : North2Garage(); break;
                   case N2Service : N2ServiceCorridor(); break;
                   case S2 : South2(); break;
                   case E2 : East2(); break;
                   case W2 : West2(); break;
                   case Surface : SurfaceAccess(); break;
                   case BOSSFIGHT_L1 : FinalBossFight(); break;
                   case QUIT : MutantWars.CONTINUE = false; break;
                   default : OUT = OUT + "Invalid input from switchboard...";
                             System.out.print(OUT);
                             break;
              }

       }

//-------------------------------------------------------------------------------

       void InitializeGlobals()
       {
            MutantWars.Player.InitializeInventory();

            C1FirstTime = true;
            DataCrystalTaken = false;
            Found9mmAmmo = false;
            Found9mmAmmoBox = false;
            CardReaderActivated = false;
            Center1BasementFirstTime = true;
            DrankSoda = false;
            AteSandwhich = false;
            FoundMachete = false;
            FoundSyringe = false;
            FoundMatches = false;
            FoundFramePack = false;
            FoundMedKit = false; 
            FoundMRERations = false;
            FoundSterno = false;
            N2FirstTime = true;
            FoundJacket = false;
            ExplodedTripBomb = false;
            FoundGun = false;
            FoundKeyCard = false;
            SwipedKeyCard = false;
            SurfaceDoorsLocked = true;
            East2FirstTime = true;
            West2FirstTime = true;
            FoughtFreezerMutant = true;
            RanAwayFromFreezerMutant = false;
            FoundKey = false;
            SafeFirstTime = true;
            SafeUnlocked = false;
            KEYinserted = false;
            FromAtrium = false;
       }

//-----------------------------------------------------------------------------

       public void Intro()
       {
              Functions.ClearScreen(1);
            
              OUT = 
              "\tMutant Wars for Java - 1.0 - Charles Germany - 2007\n\n\n"
              + "\tIt is the year 2050 - 20 long years since the war between humans\n"
              + "\tand mutants brought unbelieveable devastation to all of earth's\n"
              + "\tinhabitants. Some called it survival of the fittest, a rite of\n"
              + "\tpassage for those who survived and extinction for those who didn't.\n\n"
              + "\tNow, with the exception of a few scattered bands of survivors, mutants\n"
              + "\tare the only inhabitants left upon the earth. Many mutant genes lie\n"
              + "\tdormant until puberty, others manifest themselves at birth. In this\n"
              + "\tpost-apocalyptic world, some mutant traits are obvious to an observer,\n"
              + "\tmanifesting themselves as aberrations of color and physical form.\n"
              + "\tOther mutant traits are concealed, masking abilities beyond\n"
              + "\tcomprehension within an otherwise unremarkable and frail human frame.\n";

              System.out.print(OUT);
              Functions.PAUSE();
              Functions.ClearScreen(1);          

            OUT = 
            "\tAt first, the war was a matter of survival. Humans who did not share\n"
            + "\tthe anomalies of their mutant neighbors felt threatened by what they\n"
            + "\tcould not understand. Eventually, rationality and reason gave way\n"
            + "\tto fear and paranoia. Concentration camps were created to contain\n"
            + "\twhat was seen as an increasing threat and menace to society. Riots\n"
            + "\tand civic unrest ensued and the mutant phenomena was almost\n"
            + "\teradicated completely from the human race.\n\n"
            + "\tAt the brink of annihalation, a lone figure arose among the mutants,\n"
            + "\trallying them together and gathering their will to fight for\n"
            + "\tsurvival. He called himself \"Odyicis\", and led them in a genocidal\n"
            + "\tcampaign to eradicate those who would destroy mutant kind. After\n"
            + "\t15 years, humans made their last stand at a secret compound in White\n"
            + "\tSands, New Mexico. A treaty was signed guaranteeing their survival in\n"
            + "\texchange for unconditonal surrender. They now numbered only a few\n" 
            + "\tthousand and were too small to be any threat to mutant kind.\n";

            System.out.print(OUT);
            Functions.PAUSE();
            Functions.ClearScreen(2);  

            OUT = 
              "\tFor a time there was peace and relative tranquility enveloped the\n"
            + "\tinhabitants of earth, both human and mutant. But while the genetic\n"
            + "\tstructure of humanity had changed, its nature had not. Two powerful\n"
            + "\tclans of mutants arose, both having the capability to acquire the\n"
            + "\tmutant abilities of others. These were the Disectors and Impaths.\n\n"
            + "\tThe Disectors (commonly referred to as Brain Eaters) had an \n"
            + "\tunquenchable thirst for power, and could acquire the abilities\n"
            + "\tof mutants they killed and disected. Once a particular mutant\n"
            + "\tclass's ability was acquired,all other mutants in that class were\n"
            + "\teither enslaved or destroyed as a threat to the Disector clan's\n"
            + "\tpower and domination. Disectors had to defeat their opponents in\n"
            + "\tbattle and kill them before they could acquire a new ability.\n"
            + "\tHowever, once acquired, they mastered the ability instantly.\n";

            System.out.print(OUT);
            Functions.ClearScreen(1);
            Functions.PAUSE();
            Functions.ClearScreen(2);

            OUT =
              "\tThe Impaths had the ability to acquire other mutant's abilities,\n"
            + "\tjust as the Disectors. They key difference was that they could\n"
            + "\tacquire another mutant's abilities just by standing next to them.\n"
            + "\tThey did not have to defeat and kill their opponent in battle, or\n"
            + "\teven let them know that they were abosorbing their abilities. They\n"
            + "\tcould acquire them in \"stealth\" if necessary.\n\n"
            + "\tIn some cases, an advanced Impath could engage another mutant\n"
            + "\tin combat, even a Disector, and almost instantly use their own\n"
            + "\tabilities against them, as well as any other abilities they had\n"
            + "\tpreviously acquired. This was extremely rare, however, and only\n"
            + "\tthe most advanced Impaths were capable of it. Unlike a Disector's\n"
            + "\tinstant mastery of an acquired ability, it took an average Impath\n"
            + "\tmonths, sometimes years to master a newly acquired ability.\n";

            System.out.print(OUT); 
            Functions.ClearScreen(1);
            Functions.PAUSE();
            Functions.ClearScreen(1);

            OUT = 
            "\tYou are a young Impath, aimlessly wandering post-apocalyptic earth\n"
            + "\talone, looking for others like yourself. Your have endured years\n"
            + "\tof solace since the Disectors slaughtered your village and\n"
            + "\tdestroyed your way of life. At one time, Impaths were considered\n"
            + "\tbenign, and lived in relative peace with both other mutants and\n"
            + "\thumans.\n\n"
            + "\tNow there exists great distrust among mutants and humans,and you\n"
            + "\tcan never be sure when you meet a stranger whether they will be\n"
            + "\tyour friend or foe. Pensively reflecting on these fading memories,\n"
            + "\tyour thoughts drift back to your present circumstance.\n";  

            System.out.print(OUT);
            Functions.ClearScreen(3);
            Functions.PAUSE();
            Functions.ClearScreen(1);
       }
       
//-----------------------------------------------------------------------------

       public void Center1()
       {
              char WhatToDo = '#';
               
              if(C1FirstTime)
              { 
                  OUT = "\n\n\n\n\tYou awake. Your head is pounding and you feel groggy - drugged.\n"
                      + "\tIn your mouth you taste the acrid bitterness of some metalic\n"
                      + "\tsalt. Staring at the mildew stains on the ceiling, you slowly\n"
                      + "\tgather your strength and raise yourself up off of a cold and\n"
                      + "\tunforgiving surface. Sitting up, blinking in the partial darkness,\n"
                      + "\tyou slowly become aware of your surroundings.\n";
                 C1FirstTime = false;  
              }
              else
              {
                 OUT = "\n\tYou return to where you originally started, the TREATMENT ROOM.\n";
              }

              OUT = OUT + "\n\tYou see a dimly lit cubicle, larger than a typical living room.\n"
                  + "\tIt is difficult to make out any colors, and the only illumination\n"
                  + "\tthat you can see by appears to be radiating from behind the red\n"
                  + "\ttranslucent letters of two emergency exit signs.\n\n"
                  + "\tYou manage to ferret out six possible exits amidst the shadows. To\n"
                  + "\tthe north-west, you see several steel tables with worn leather\n"
                  + "\trestraints. Behind the tables you see a door with stairs ascending\n"
                  + "\ttowards the west. To the south-east you see another door with stairs\n"
                  + "\tdescending into an erie glowing blue abyss.\n\n";

              System.out.print(OUT);
              Functions.PAUSE();
              Functions.ClearScreen(4);

              OUT = "\tYou look and see four pale-white metal doors leading to the north,\n"
                  + "\tsouth, east and west on each wall of the room. Marked with scratches,\n"
                  + "\teach has a dull gray box mounted on the wall beside it for key card\n"
                  + "\taccess.\n\n";
              OUT = OUT + "\tTo the east, you see several gurnies and a delapidated apparatus that\n"
                  + "\twas most probably used for shock treatment. You can almost hear the \n"
                  + "\tscreams of unwilling participants receiving their \"treatment\" as\n"
                  + "\thaunting echoes from the past.\n";

              if(!DataCrystalTaken) 
              {
                  OUT = OUT + "\n\tOn a shelf over one of the restraint tables a sparkling crystal\n"
                      + "\tcatches your eye. It is next to a spool of twine and some tape.\n";
              }

              System.out.print(OUT);

              while( WhatToDo != 'n' && 
                     WhatToDo != 's' &&
                     WhatToDo != 'e' &&
                     WhatToDo != 'w' &&
                     WhatToDo != 'u' &&
                     WhatToDo != 'd' &&            
                     WhatToDo != 'o' &
                     WhatToDo != 'l')
              {

                     OUT =
                     "\n\n\tWhere will you go: (N)orth  (S)outh  (E)ast  (W)est?\n"
                     + "\tPossibilities: (L)ook  (U)pstairs  (D)ownstairs  ";

                     if(!DataCrystalTaken) { OUT = OUT + "(T)ake crystal"; }

                     OUT = OUT + "\n\tCommands: (O)ptions  (A)bilities  (I)nventory  (B)ioStats"
                           + "\n\n\n\n\n\n\t";

                     System.out.print(OUT);
             
                     WhatToDo = Functions.INPUTchar(); 

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = C1; break;
                       case 'n' : LOCATION = N1; break;
                       case 's' : LOCATION = S1; break;
                       case 'e' : LOCATION = E1; break;
                       case 'w' : LOCATION = W1; break;
                       case 'u' : LOCATION = C1Roof; break;
                       case 'd' : LOCATION = C1Basement; break;
                       case 't' : if(!DataCrystalTaken)
                                  { 
                                    OUT = "\n\tYou lift the crystal and put it in your pocket!";
                                    DataCrystalTaken = true;
                                    MutantWars.Player.SetDataCrystal(true);
                                  }
                                  else
                                  {
                                    OUT = "\n\tNothing else worth taking here.";
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void Center1Roof()
       {
              char WhatToDo = '#';
     
              OUT = "\n\n\tYou climb the stairs to the ROOF. You press against the door\n"
                    + "\tand it swings open. Fresh air, at last! You are surrounded\n"
                    + "\tby walls 25 feet tall and too smoothe to climb on all four\n"
                    + "\tsides. Glancing upwards, you see gray-blue skies and a few\n"
                    + "\trays of pale moonlight filtering through the whispy clouds\n"
                    + "\trefracting the dusky overtones of the rapidly setting sun.\n"
                    + "\tTo the north-east you see a reinforced steel door with the\n"
                    + "\twords \"service corridor\" stenciled above it.\n\n";

              if(!Found9mmAmmoBox)              
              {
                 OUT = OUT + "\tIn the corner to your right you see a large box of 9mm\n"
                           + "\tammunition.\n";
              }
              else
              { OUT = OUT + "\tAgainst the wall to your left you see a large pile of bird dung.\n"; }

              System.out.print(OUT);

              while(WhatToDo != 'd' && WhatToDo != 'o' && WhatToDo != 'l' && WhatToDo != 'c')
              {
                     OUT = "\n\n\tWhere will you go:  (N)orth  (S)outh  (E)ast  (W)est?\n"
                     + "\tPossibilities: (L)ook  (D)ownstairs  (C)orridor  ";
                     if(!Found9mmAmmoBox) { OUT = OUT + "(P)ick Up Ammo"; }
                     OUT = OUT + "\n\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats"
                         + "\n\n\n\n\n\t";

                     System.out.print(OUT);

                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = C1Roof; break;
                       case 'n' : if(!Found9mmAmmo)
                                  {
                                     OUT = "\tYou see a wall, too high and straight to scale.\n"
                                     + "\tBut at its solitary base you find 10 clips of ammo!\n"
                                     + "\tMust have been the ammo in that box you saw...\n";
                                     Found9mmAmmo = true;
                                     MutantWars.Player.Set9mmAmmo(MutantWars.Player.Get9mmAmmo() + 10);
                                  }
                                  else
                                  {
                                     OUT =
                                     "\tOnce again you spy the wall, too high and straight to scale,\n"
                                     + "\tbut at its base you step upon a sharp and rusty nail!\n"
                                     + "\tInsatiable, your putrid GREED has caused you here to fail,\n"
                                     + "\tlimping you continue on, no faster than a snail...\n"
                                     + "\tYou loose 2 life points...\n";
                                     MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 2);
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'e' : OUT ="\tYou brush against cold, hard concrete.\n";
                                  System.out.print(OUT);
                                  break;
                       case 's' : OUT ="\tExploring the south wall, you are apprehensive about\n"
                                  + "\ttouching it as it is covered with a thick, green, slimy moss.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'w' : OUT =
                                  "\tLooking closer at the west wall, you notice fresh blood\n"
                                  + "\tstains along the south-west corner. A shiver goes up\n"
                                  + "\tyour spine. Someone or something recently met its demise here.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'c' : LOCATION = N2Service; break;
                       case 'd' : LOCATION = C1; break;
                       case 'o' : Functions.Options(); break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'p' : if(!Found9mmAmmoBox)
                                  {
                                     OUT = "\n\tYou pick up the box of ammo. Nifty. But "
                                     + "there's no ammo inside it.\n\tDisgusted, you throw "
                                     + "it up into the air and over the wall.\n";
                                     Found9mmAmmoBox = true;
                                  }
                                  else
                                  { OUT = "\n\tEeew! You get a hand full of bird poo.\n"; }
                                  System.out.print(OUT);
                                  break;
                       default : OUT = "\n\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void Center1Basement()
       {
              char WhatToDo = '#';

              if(Center1BasementFirstTime)
              {
                  OUT = "\n\n\tYou descend into the glowing blue abyss to find yourself\n"
                      + "\tstanding in a CONTROL ROOM of sorts.\n\n";
                  Center1BasementFirstTime = false;
              }
              else { OUT = "\n\n\tYou are in the CONTROL ROOM beneath the treatment facility.\n\n"; }

              OUT = OUT +
                  "\tTo the south is a giant LCD display and keyboard. The large display\n"
                  + "\tis projecting a rotating bio-hazzard logo on a blue background\n"
                  + "\tCentered at the bottom of the screen in bold black letters are\n"
                  + "\tthe words \"Data Terminal Access\". You can now see that it is this\n"
                  + "\tlarge display that is producing the eerie iridescence in the room.\n";

              System.out.print(OUT);

              while(WhatToDo != 'u' && WhatToDo != 'o' && WhatToDo != 'a' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities: (L)ook  (D)ata Terminal  (U)pstairs\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n"
                     + "\n\n\n\n\n\t";

                     System.out.print(OUT);

                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = C1Basement; break;
                       case 'n' : OUT = "\tYou see a shelf with disks and storage crystals.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'e' : OUT = "\tWalking to the east end of the room, you disturb a nest\n"
                                  + "\tof spider mites. Scampering in an angry frenzy, they\n"
                                  + "\tpainfully envenomate your left leg. You loose 5 life points!\n";
                                  System.out.print(OUT);
                                  MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 5);
                                  break;
                       case 's' : OUT = "\tAt the south end, a bank of servers humms,\n"
                                  + "\teach one mounted vertically within a rack.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'w' : OUT = "\tAgainst the west wall a gaggle of fiber optics cables winds its\n"
                                  + "\tway down into the racks of servers lined up row after row.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'u' : LOCATION = C1; break;
                       case 'd' : DataTerminalAccess(); break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

       }

//-----------------------------------------------------------------------------
       public void DataTerminalAccess()
       {
              char WhatToDo = '#';

              if(!DataCrystalTaken)
              {
                  OUT = "\n\tYou attempt to access the data terminal. You type a few\n"
                                 + "\tcharacters trying to brute force a password or two, but\n"
                                 + "\tto no avail. All you see at the terminal is "
                                 + "\"Access Denied!\"\n";

                  System.out.print(OUT);
              }
              else
              {
                  OUT = "\n\tYou take the data crystal and insert it into the data\n"
                                 + "\tterminal. The large LCD display in front of you flashes\n"
                                 + "\tfor a brief moment. Sporadically, a menu displays with\n"
                                 + "\tseveral choices blinking in the background.\n";

                  while(WhatToDo != 'e' && WhatToDo != 'o')
                  {
                       OUT =
                       "\n\tYour choices are: \n"
                       + "\n\t(P)atient Bios\n"
                       + "\t(L)og files\n"
                       + "\t(M)edical Inventory\n"
                       + "\t(C)ard Reader Activation\n"
                       + "\t(E)xit Terminal\n\n"
                       + "\n\tCommands: (O)ptions (A)bilities  (I)nventory  (B)ioStats\n\n\t";

                       System.out.print(OUT);

                       WhatToDo = Functions.INPUTchar();

                       switch(WhatToDo)
                       {
                         case 'p' : OUT = "\n\n\tThe display returns the result:\n" +
                                    "\t\"Insufficient Access Privileges!\"\n\n";
                                    System.out.print(OUT);
                                    break;
                         case 'l' : DataTerminalLog(); break;
                         case 'm' : OUT = "\n\n\tThe display returns the result:\n" +
                                    "\t\"Level Two Access Key Required.\"\n\n";
                                    System.out.print(OUT);
                                    break;
                         case 'c' : if(!CardReaderActivated)
                                    {
                                       OUT = "\n\n\tThe display returns the result:\n" +
                                       "\t\"Success! Card Reader is now Active!\"\n\n";
                                       CardReaderActivated = true;
                                    }
                                    else
                                    {
                                       OUT = "\n\n\tThe display returns the result:\n" +
                                       "\t\"Can not comply. Card Reader Already Active!\"\n\n";
                                    }
                                    System.out.print(OUT);
                                    break;
                         case 'e' : OUT = "\n\tExiting terminal...\n\n";
                                    System.out.print(OUT);
                                    break;
                         case 'i' : MutantWars.Player.Inventory(); break;
                         case 'a' : MutantWars.Player.Abilities(); break;
                         case 'b' : MutantWars.Player.DisplayStats(); break;
                         case 'o' : Functions.Options(); break;
                         default :  OUT = "\n\n\tThe display returns the result " +
                                    "\"Security permiter violated. Only limited commands available.\"\n\n";
                                   System.out.print(OUT);
                                   break;

                       }//close switch

                 }//close while

              }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void DataTerminalLog()
       {
              int SayWhat = Functions.GRN(10);
              OUT = "\n\tThe display reads:\n\n"
                  + "\t\"Data timestamps damaged. Attempting to recover.\n"
                  + "\tAccessing internal log files...\"  It pauses a few\n"
                  + "\tseconds for processing and spits out:\n\n";

              switch(SayWhat)
              {
                   case 1 : OUT = OUT + "\t\"10/18/2080 - BrainEaters everywhere. The horror is unbearable.\n" +
                                  "\tI can't endure this hell on earth much longer..." ; break;
                   case 2 : OUT = OUT + "\t\"10/17/2080 - Went out with Jenny tonight. Man is she hot!\n" +
                            "\tHotter than the sun, baby!. Hot mamma. I like big butts.\n"+
                            "\tI can not lie..."; break;
	           case 3 : OUT = OUT + "\t\"10/16/2080 - Working with mutant who has apparent freezing abilities.\n" +
                            "\tHe extracts moisture from the air and absorbs its ambient temperature."; break;
	           case 4 : OUT = OUT + "\t\"10/21/2080 - Safe damaged. Perhaps a heat source will expand\n" +
                                  "\tthe lock mechanism."; break;
	           case 5 : OUT = OUT + "\t\"10/15/2080 - Met a girl at a party the other night.\n" +
                            "\tI can't stop thinking about her. Trying to put her out of my mind."; break;
	           case 6 : OUT = OUT + "\t\"10/14/2080 - Second week in this underground facility. Can't\n" +
                            "\tremember what the sun looks like. I guess it's safer down here."; break;
	           case 7 : OUT = OUT + "\t\"10/19/2080 - The freezer mutant is becoming more powerful.\n" +
                            "\tIt appears it would not be prudent to oppose him without a\n" +
                            "\tweapon or some other sort of tactical advantage..."; break;
                   case 8 : OUT = OUT + "\t\"10/22/2080 - There are only 3 of us left. We are going to try\n" +
                            "\tto make it to the surface. If only the card reader was functioning!"; break;
                   case 9 : OUT = OUT + "\t\"10/03/2080 - Moving facilities underground to an emergency bunker.\n" +
                            "\tWe should be able to carry out our research free of the war above."; break;
                   case 10 : OUT = OUT + "\t\"10/20/2080 - Need to find the key and try to unlock the safe.\n" +
                                  "\tThere is danger everywhere."; break;
	           default : OUT = OUT + "\tUh oh, this should never happen.."; break;
              } //closes switch

            OUT = OUT + "\"\n\n";
            System.out.print(OUT);

       }

//-----------------------------------------------------------------------------

       public void North1()
       {
              char WhatToDo = '#';

              OUT = "\n\n\tYou find yourself in the MAIN OFFICE. It is fairly spacious\n"
                  + "\tand consists of approximately 10 cubicles partitioned off with\n"
                  + "\tfolding dividers. To the east, flush against the wall, is a row\n"
                  + "\tof desks with folder racks, coffee cups, cannisters of pens and\n"
                  + "\tlaptops. To the west you see a small refrigerator about four feet\n"
                  + "\thigh, covered with mildew.\n\n"
                  + "\tTo the north you see a door and what appears to be daylight\n"
                  + "\tcoming through a small window criss-crossed with some metallic\n"
                  + "\tfilament embedded within the door. You can see that the door is\n"
                  + "\tconstructed of heavy steel and that the window it contains is\n"
                  + "\tdesigned to be shatter-proof.\n\n"
                  + "\tFlourescent lights are flickering on and off from fixtures\n"
                  + "\tadjacent to insulating tiles that cover the roof. A small\n"
                  + "\tshelf runs above the door.\n";

              System.out.print(OUT);

              while(WhatToDo != 's' && WhatToDo != 'n' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities: (L)ook  (C)heck Shelves\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n"
                     + "\n\t";

                     System.out.print(OUT);

                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = N1; break;
                       case 'n' : LOCATION = N2; break;
                       case 's' : LOCATION = C1; break;
                       case 'e' : OUT = "\n\tYou walk over to the east side of the room. A row of\n"
                                  + "\tdesks runs in a straight row adjacent to the wall. You\n"
                                  + "\tYou see miscellaneous office supplies. Nothing interesting.";
                                  System.out.print(OUT);
                                  break;
                       case 'c' : if(!FoundMachete)
                                  {
                                     OUT = "\n\tToo high above your head to see, you run your fingers along\n"
                                     + "\tthe shelf and find a trapezoidal object made of canvas. You\n"
                                     + "\tpull it down and see that it is a machete inside a canvas\n"
                                     + "\tsheath. This may come in handy!\n";
                                     FoundMachete = true;
                                     MutantWars.Player.SetMachete(true);
                                  }
                                  else
                                  {
                                     OUT = "\tYou feel along the edge of the shelf were you previously\n"
                                     + "\tfound the machete, hoping to acquire any other useful\n"
                                     + "\tobjects that may be stored there. Instead, you cut your\n"
                                     + "\thand on an abandoned razor blade and loose two points of\n"
                                     + "\tyour precious life. Maybe this is not a good idea...\n";
                                     MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 2);
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'w' : TheFridge(); break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void TheFridge()
       {
              char WhatToDo = '#';

              OUT = "\n\tYou go to the west side of the room. You see a\n"
              + "\trefrigerator and can hear its compressor humming.\n"
              + "\tCurious, you open the door and peer inside. There\n"
              + "\tare some empty vaccine cannisters in the bottom.\n\n";

              if(!DrankSoda)
              { OUT = OUT + "\tOn a shelf up top there is a can of soda.\n"; }
              if(!AteSandwhich)
              { OUT = OUT + "\tOn the middle shelf sits a tuna fish sandwhich.\n"; }

              System.out.print(OUT);

              while(WhatToDo != 'c')
              {
                     OUT = "\n\tYou may:\n\n";
                     if(!DrankSoda) { OUT = OUT + "\t(D)rink the soda\n"; }
                     if(!AteSandwhich) { OUT = OUT + "\t(E)at the tuna sandwhich\n"; }
                     OUT = OUT + "\t(C)lose the refreigerator door\n\n\n\t";

                     System.out.print(OUT);

                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'd' : if(!DrankSoda)
                                  {
                                     OUT = "\tYou drink the soda. Cold and refreshing!"
                                     + "\n\tIt adds 10 points to your life.\n";
                                     MutantWars.Player.SetHit(MutantWars.Player.GetHit() + 10);
                                     DrankSoda = true;
                                  }
                                  else
                                  { OUT = "\tNothing to drink here - you already drank the soda!\n"; }
                                  System.out.print(OUT);
                                  break;
                       case 'e' : if(!AteSandwhich)
                                  {
                                     OUT = "\tYou eat the tuna sandwhich. Rancid mayonaise!!!"
                                     + "\n\tVomiting, you loose 10 points from your queasy life.\n";
                                     MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 10);
                                     AteSandwhich = true;
                                  }
                                  else
                                  { OUT = "\tNo food in this fridge - you already ate the sandwhich!\n"; }
                                  System.out.print(OUT);
                                  break;
                       case 'c' : OUT = "\tYou close the refrigerator door and step back.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.Abilities(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }



       }

//-----------------------------------------------------------------------------

       public void South1()
       {
              char WhatToDo = '#';

              OUT = "\n\n\tYou enter the NURSING STATION. There are white\n"
                  + "\tmedicine cabinets mounted against the walls. They\n"
                  + "\thave glass doors that allow you to see the contents\n"
                  + "\tinside them. Piles of glass from smashed glass bottles\n"
                  + "\tand equipment cover the shelves inside of the cabinets.\n\n"
                  + "\tShattered glass crunches beneath your feet as you walk\n"
                  + "\tacross the blue and gray terazzo floor. To the north is\n"
                  + "\ta door leading to the treatment room. To the south, a\n"
                  + "\ta hallway lined with gurneys appears to lead to an ICU.\n";

              System.out.print(OUT);

              while(WhatToDo != 'n' && WhatToDo != 's' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities:  (L)ook   (C)heck Cabinets\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\n\n\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = S1; break;
                       case 'n' : LOCATION = C1; break;
                       case 's' : LOCATION = S2; break;
                       case 'e' : OUT = "\tYou see a row of LCD monitors displaying patient\n"
                                  + "\trecords, histograms and various vital statistics.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'w' : if(!FoundSyringe)
                                  {
                                     OUT = "\tDigging around in a pile of glass on one of the\n"
                                     + "\tmedical shelves, you find an unused syringe!\n";
                                     FoundSyringe = true;
                                     MutantWars.Player.SetSyringe(true);
                                     MutantWars.Player.SetSyringeCart(1);
                                  }
                                  else
                                  {
                                     OUT = "\tWhere formerly you found the syringe, you\n"
                                     + "\tsee nothing but a pile of broken glass.\n";
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'c' : if(!FoundMedKit)
                                  {
                                     OUT = "\tDigging through piles of broken glass,\n"
                                     + "\tyou find a med kit!\n";
                                     FoundMedKit = true;
                                     MutantWars.Player.SetMedKit(MutantWars.Player.GetMedKit() + 1);
                                  }
                                  else
                                  {
                                     OUT = "\tOuch! In almost the same place where you found the med\n"
                                     + "\tkit, you slice your finger on broken glass!\n";
                                     MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 1);
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void East1()
       {
              char WhatToDo = '#';

              OUT = "\n\n\tYou enter into a large STORAGE ROOM facility. It is\n"
                    + "\tdimly lighted by a few flourescent panels that are\n"
                    + "\tembedded in the baseboard that borders the room. Amidst\n"
                    + "\tthe shadows you see miscellaneous boxes and crates of\n"
                    + "\tsupplies. Shelves line the walls and various boxes of\n"
                    + "\tdifferent sizes and colors are stacked on them.\n\n"
                    + "\tTo the north-east is a small black closet door with a vent\n"
                    + "\tat the bottom. To the east a short hallway leads to another,\n"
                    + "\teven larger storage room with a 20 foot ceiling. The\n"
                    + "\troom to the east appears to be a warehouse of sorts.\n";
                             
              System.out.print(OUT);
              
              while(WhatToDo != 'e' && WhatToDo != 'w' && WhatToDo != 'g'
                    && WhatToDo != 'o' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities:  (L)ook   (G)o Into Closet\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\n\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar(); 

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = E1; break;
                       case 'n' : if(!FoundMatches)
                                  { 
                                     OUT = "\tRaffling through the boxes on the storeage\n"
                                     + "\tshelves, you find a book of matches!\n";
                                     FoundMatches = true;
                                     MutantWars.Player.SetMatches(true);
                                  } 
                                  else 
                                  { 
                                     OUT = "\tWhere formerly you found the book of matches,\n"
                                     + "\tyou see nothing but boxes and crates.\n";
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 's' : OUT = "\tYou see lots of lovely boxes! How Quaint.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'e' : LOCATION = E2; break;
                       case 'w' : LOCATION = C1; break;
                       case 'g' : LOCATION = E1Closet; break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input..."; 
                                 System.out.print(OUT); 
                                 break;
                     }
             }
               
             Functions.ClearScreen(5);    
       }

//-----------------------------------------------------------------------------

       public void East1Closet()
       {
              char WhatToDo = '#';

              OUT = "\n\n\tYou walk into a large CLOSET illuminated by a\n"
                    + "\tlarge singular disk mounted in the center of the\n"
                    + "\tceiling. It appears to be outfitted with expeditionary\n"
                    + "\tsupplies.\n\n"
                    + "\tGuns, GPS units, boots and parkas are all locked inside\n"
                    + "\tvarious cabinets and protected with shatterproof glass.\n"
                    + "\tBoxes of different sizes and colors are stacked on them.\n"
                    + "\tYou can see numerous items transfigured in the shadows\n"
                    + "\tas you glance around the environment.\n\n\n\n\t";

              System.out.print(OUT);
              
              while(WhatToDo != 'c' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities:  (L)ook   (C)ome Out of the Closet ;-) \n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar(); 
             
                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = E1Closet; break;
                       case 'n' : if(!FoundFramePack)
                                  {
                                     OUT = "\tFeeling your way through the darkness,\n"
                                     + "\tyou discover a large steel frame back pack!\n";
                                     FoundFramePack = true;
                                     MutantWars.Player.SetFramePack(true);
                                  } 
                                  else
                                  { 
                                     OUT = "\tYou feel in the darkness where you formerly\n"
                                     + "\tfound the frame pack but find nothing.\n"; 
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 's' : OUT = "\tYou see various firearms mounted in a locked rack.\n"
                                  + "\tIf only you had the key...\n";
                                  System.out.print(OUT);
                                  break;
                       case 'e' : OUT = "\tYou see boots, parkas and camping gear locked\n"
                                  + "\tinside a translucent storage container.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'w' : OUT = "\tYou find a large, locked cabinet. Through the shatter-proof\n"
                                  + "\tglass you can see a copious amount of camera and GPS equipment.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'c' : LOCATION = E1; break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input..."; 
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);                  
       }

//-----------------------------------------------------------------------------

       public void West1()
       {
              char WhatToDo = '#';
     
              OUT = "\n\n\tYou walk into the primary MESS HALL, or Dining Facility.\n"
                  + "\tThis is a large room with a ceiling approximately 15 feet\n"
                  + "\thigh. The room contains ten rows of tables equipped with\n"
                  + "\tnapkin holders, salt and pepper shakers and ketchup and\n"
                  + "\tmusard bottles. Eight white plastic chairs are pushed neatly\n"
                  + "\tunder each black formica table, arranged asymmetrically\n"
                  + "\twithin their rows.\n\n"
                  + "\tThis must have been where the original inhabitants of this\n"
                  + "\tlong abandoned facility took their tmeals. To the south\n"
                  + "\ta long open crate contains several smaller parcels within\n"
                  + "\tit. An empty serving table, like those used for catering,\n"
                  + "\tlines up against the north wall.\n";

              System.out.print(OUT);

              while(WhatToDo != 'e' && WhatToDo != 'w' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilitie: (L)ook\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = W1; break;
                       case 'n' : if(!FoundSterno)
                                  {
                                     OUT = "\tLooking underneath one of the catering tables,\n"
                                         + "\tyou find a full can of high heat STERNO fuel. It\n"
                                         + "\tmust have been used to keep the food warm during\n"
                                         + "\tmeal times.\n";
                                     FoundSterno = true;
                                     MutantWars.Player.SetSterno(true);
                                  }
                                  else
                                  {
                                     OUT = "\tWhere formerly you found the can of STERNO, you see\n"
                                         + "\tnothing but empty shelves smattered with food stains\n"
                                         + "\tand rat droppings underneath the catering tables.\n";
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 's' : if(!FoundMRERations)
                                  {
                                     OUT = "\tFerreting through the box, you unrap one of the\n"
                                         + "\tparcels to read the label printed on it:\n\n"
                                         + "\t\"U.S. Armed Forces. MRE - Meal Ready to Eat\"\n\n"
                                         + "\tYou are filled with relief. There are too many\n"
                                         + "\tunits to take by hand. 10 is as many as you can\n"
                                         + "\thold. If only you had a way to carry them all...\n";
                                     FoundMRERations = true;
                                     MutantWars.Player.SetMRErations(MutantWars.Player.GetMRErations() + 10);
                                  }
                                  else
                                  {
                                     OUT = "\tAgain you see the box or MRE rations, still full, minus\n"
                                         + "\tthe ones you have already taken. You reach in to take another,\n"
                                         + "\tbut are horrified as mutant carnivorous cockroaches come\n"
                                         + "\tstreaming out of the bottom of the box and tear the flesh\n"
                                         + "\tfrom your arm! Screaming in pain and disgust, you back away.\n"
                                         + "\tYou lose 10 life points.\n";
                                     MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 10);
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'e' : LOCATION = C1; break;
                       case 'w' : LOCATION = W2; break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void North2()
       {
              char WhatToDo = '#';

              if(N2FirstTime)
              {
                 OUT = "\n\n\tStepping through the door, you jump back, shielding\n"
                     + "\tyour eyes from the burning sunlight pouring in the shatter-\n"
                     + "\tproof glass panels 25 feet above your head. Seeing the\n"
                     + "\tsurface illuminated so far above you, you now realize\n"
                     + "\tyou have been underground all this time.\n\n"
                     + "\tSurrounded by an increasingly false sense of serenity, you\n"
                     + "\tfind yourself standing in the middle of a beautiful ATRIUM.\n"
                     + "\tAs your eyes begin to adjust to the brightness, you begin to\n"
                     + "\tunderstand the reason you are feeling so jumpy and skittish.\n"
                     + "\n\n\n\n";

                 System.out.print(OUT);
                 OUT = "";
                 N2FirstTime = false;
                 Functions.PAUSE();
                 Functions.ClearScreen(10);

              }
              else { OUT = "\tYou return to the ATRIUM.\n\n"; }

              OUT = OUT + "\tYou are surrounded by tranquility and beauty. There are lush\n"
                  + "\tgreen plants and a Japanese water fountain in the center. You can\n"
                  + "\tsee multi-colored goldfish frozen in the pool of water which the\n"
                  + "\tfountain runs into. Frozen? How is that possible when the ambient\n"
                  + "\ttemperature of the room must be at least 90 degrees Farenheit?\n\n"
                  + "\tYou look to the north and see, to your horror, three corpses frozen\n"
                  + "\tsolid. Their bodies are disfigured in agonizing positions and\n"
                  + "\ta fog surrounds them as if they were composed of dry ice reacting\n"
                  + "\tto the atmosphere. You are unnerved and perplexed about how these\n"
                  + "\tunfortunate souls met their demise. Oddly, to the east, you see an\n"
                  + "\televator. Above the entry way, a sign marked \"Parking - SubLevel 1\"\n"
                  + "\tis inscribed upon the wall. Beneath it, an arrow points downward.\n"
                  + "\tTo the north-west you see a service corridor containing a stairwell.\n";

              System.out.print(OUT);

              while(WhatToDo != 's' && WhatToDo != 'o' && WhatToDo != 'c' 
                    && WhatToDo != 't' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities: (L)ook  (T)ake the Elevator Down  (C)orridor\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar();
             
                     switch(WhatToDo)
                     {
                        case 'l' : LOCATION = N2; break;
                        case 'n' : OUT = "\tYou walk to the north end of the Atrium. Examining the\n"
                                 + "\tthree bodies, you are filled with a macabre sense of\n"
                                 + "\twonder as the light from the glass panes above the Atrium\n"
                                 + "\tsparkles when it is scattered into a thousand prismic rays\n"
                                 + "\tby the ice that has crystallized on the outer surface of\n"
                                 + "\tthe deceased. You wonder who, or better yet what, did this?\n"
                                 + "\n\n\n\t";
                                 System.out.print(OUT);
                                 break;
                        case 's' : LOCATION = N1; break;
                        case 'e' : OUT = "\tYou see vines and the branches of several small trees\n"
                                   + "\tgrowing against the east wall. ";
                                 if(!FoundJacket)
                                 {
                                   OUT = "\tIn the corner you find a canvas straight jacket. The material\n"
                                       + "\tis tough and resistant to tearing. It may also offer some\n"
                                       + "\tprotection from the frigid fate that befell the unfortunate\n"
                                       + "\tfrozen few in this room. You remove the restraining straps\n"
                                       + "\tso you can wear it as you would a normal article of clothing.\n"
                                       + "\tThough not fashionable, it looks as though it might add +2 to\n"
                                       + "\tyour ability to defend yourself.\n";
                                   FoundJacket = true;
                                   MutantWars.Player.SetJacket(true);
                                 }
                                else { OUT = "\tPreviously you found the straight jacket here.\n"; }
                                System.out.print(OUT);
                                break;
                        case 'w' : OUT = "\tNothing too interesting. Thick vines cover the wall\n"
                                   + "\tand a gurney with broken straps sits off in the corner."
                                   + "\n\n\n\n\t";
                                   System.out.print(OUT);
                                   break;
                        case 't' : LOCATION = N2Garage; FromAtrium = true; break;
                        case 'c' : LOCATION = N2Service; FromAtrium = true; break;
                        case 'i' : MutantWars.Player.Inventory(); break;
                        case 'b' : MutantWars.Player.DisplayStats(); break;
                        case 'a' : MutantWars.Player.Abilities(); break;
                        case 'o' : Functions.Options(); break;
                        default : OUT = "\tInvalid input...";
                                  System.out.print(OUT);
                                  break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void North2Garage()
       {
              char WhatToDo = '#';

              if(FromAtrium)
              {
                 OUT = "\n\n\tYou press the button beside the elevator door and it slides\n"
                     + "\topen. You step in and press \"P - SL1\". The button lights and the\n"
                     + "\tdoors close. You grab the rail on the side of the car as it jolts\n"
                     + "\tand begins to descend.  After a few moments, the elevator car stops\n"
                     + "\tand \"dings\" to notify you that you have arrived at your destination\n"
                     + "\tThe doors slide open and a wave of cool, damp air rushes into the.\n"
                     + "\televator car. You take a look at your surroundings...\n\n";
               
                 System.out.print(OUT);
                 FromAtrium = false;
              }
              
                 OUT = "\tYou are in the complex's parking GARAGE underneath the Atrium.\n"
                     + "\tTo the north, you see gray concrete wall with several hydraulic\n"
                     + "\tpipes and hoses running the length of it. To the east are several\n"
                     + "\tvehicles, dammaged almost beyond recognition. To the south you\n"
                     + "\tsee a transport vehicle that appears to be in good condition.\n"
                     + "\tBehind it, against the wall, an eerie red glow emmanates from\n"
                     + "\tthe shadows. To the west of the garage lies a security booth and\n"
                     + "\tan access door that has been welded shut.\n";

              System.out.print(OUT);

              while(WhatToDo != 't' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                   OUT =
                   "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                   + "\tPossibliities: (L)ook  (T)ake the Elevator up to the Atrium  \n"
                   + "\tComands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\t";

                   System.out.print(OUT);
                   WhatToDo = Functions.INPUTchar(); 
             
                   switch(WhatToDo)
                   {
                      case 'l' : LOCATION = N2Garage; break;
                      case 'n' : OUT = "\tHydraulic pipes and hoses. Yippie!\n";
                                 System.out.print(OUT);
                                 break;
                      case 's' : if(!ExplodedTripBomb)
                                 {
                                    OUT = "\tIt's a trap! Boom! A trip bomb explodes, dealing out\n"
                                    + "\tdeadly shrapnel and debris and doing 30 points of dammage.\n";
                                    MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 30);
                                    ExplodedTripBomb = true;
                                 }
                                 else 
                                 { 
                                    OUT = "\tYou return to the area where the trip bomb that almost took\n"
                                        + "\tyour life exploded. You can't believe that you survived\n"
                                        + "\tsuch an ordeal. The transport vehicle has been reduced to\n"
                                        + "\trubble. Bits and pieces of it, thrown by the explosion, are\n"
                                        + "\tstrewn across the underground parking garage.\n";
                                 }
                                 System.out.print(OUT);
                                 break;
                      case 'e' : OUT = "\tYou see rows of vehicles, shattered and pulverized almost\n"
                                 + "\tbeyond recognition. There is definite evidence of sabotage, perhaps\n"
                                 + "\tsome sort of explosive device. Nothing here but smoldering refuse.\n";
                                 System.out.print(OUT);
                                 break;
                      case 'w' : OUT = "\tYou walk to the west of the garage and check out the security\n"
                                 + "\tbooth. It looks as though it has been abandoned for years.\n"
                                 + "\tYou examine the access door. It has been welded and bolted\n"
                                 + "\tshut. You wonder, were they trying to keep someone from\n"
                                 + "\tgetting in or someone or something from getting out?\n";
                                 System.out.print(OUT);
                                 break;
                      case 't' : LOCATION = N2; break;
                      case 'i' : MutantWars.Player.Inventory(); break;
                      case 'a' : MutantWars.Player.Abilities(); break;
                      case 'b' : MutantWars.Player.DisplayStats(); break;
                      case 'o' : Functions.Options(); break;
                      default : OUT = "\tInvalid input...";
                                System.out.print(OUT);
                                break;
                   }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void N2ServiceCorridor()
       {
              char WhatToDo = '#';

              if(FromAtrium)
              {
                 OUT = "\n\n\tYou climb up the stairs in the SERVICE CORRIDOR\n"
                     + "\tfrom the Atrium below.\n\n";
                 FromAtrium = false;
              }
              else { OUT = "\n\n\tYou enter the SERVICE CORRIDOR from the roof.\n\n"; }

              OUT = OUT + "\tYou are in a multi-story concrete block stairwell connecting\n"
                  + "\ttwo floors of the complex. Looking down the stairs you can see\n"
                  + "\tplants and sunlight and hear what appears to be running water.\n"
                  + "\tTo the south is a door labled \"Service Corridor - Roof Access\".\n\n"
                  + "\tTo the north, you see a storage area where some lab coats are\n"
                  + "\thanging on a rack. To the east, you see a reinforced concrete\n"
                  + "\twall where several motion sensors and a camera are mounted. To\n"
                  + "\tthe west, electrical conduit and duct work for the air filtration\n"
                  + "\tsystem run adjacent to the inner wall...\n\n";

              if(!MutantWars.Player.GetHumanGirl())
              {
                  OUT = OUT + "\tSomehow, somewhere close by, you hear someone breathing,\n"
                      + "\tmournfully sobbing in a gentle whisper.";
              }

              System.out.print(OUT);

              while(WhatToDo != 'd' && WhatToDo != 'c' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                   OUT = "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                   + "\tPossibilities: (L)ook  (D)ownstairs  (C)orridor to Roof\n"
                   + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\t";

                   System.out.print(OUT);
                   WhatToDo = Functions.INPUTchar();

                   switch(WhatToDo)
                   {
                      case 'l' : LOCATION = N2Service; break;
                      case 'n' : if(!MutantWars.Player.GetHumanGirl())
                                 {
                                    L1_HumanGirlEncounter();
                                    MutantWars.Player.SetHumanGirl(true);
                                 }
                                 else
                                 {
                                    OUT = "\tYou return to the spot where you first met "
                                    + MutantWars.L1_HumanGirl.GetName() + ". She is standing\n"
                                    + "\tbeside you with a blank expression on her face. Perhaps\n"
                                    + "\tshe is trying to block many painful memories...\n";
                                    System.out.print(OUT);
                                    MutantWars.L1_HumanGirl.Talk();
                                 }
                                 break;
                      case 's' : OUT = "\tYou see a white concrete block wall. That's it.\n";
                                 System.out.print(OUT);
                      case 'e' : OUT = "\tYou see motion sensors and a camera.\n";
                                 System.out.print(OUT);
                                 break;
                      case 'w' : OUT = "\tYou see electrical conduit and duct work.\n";
                                 System.out.print(OUT);
                                 break;
                      case 'c' : LOCATION = C1Roof; break;
                      case 'd' : LOCATION = N2; break;
                      case 'i' : MutantWars.Player.Inventory(); break;
                      case 'a' : MutantWars.Player.Abilities(); break;
                      case 'b' : MutantWars.Player.DisplayStats(); break;
                      case 'o' : Functions.Options(); break;
                      default : OUT = "\tInvalid input...";
                                System.out.print(OUT);
                                break;
                   }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void L1_HumanGirlEncounter()
       {

              OUT = "\n\n"
                  + "\tYou shuffle the lab coats around and find in the corner the source\n"
                  + "\tof the mournful sobs that haunt you in this room. There in the\n"
                  + "\tshadows, almost indistinguishable from the lab coats, a little\n"
                  + "\tgirl is hiding, peering up at you with blue-green eyes. Her\n"
                  + "\tclothes are torn and tattered, and her brown-blond hair obscures\n"
                  + "\tsome of the dirt streaks smudged around the creases of her mouth\n"
                  + "\tand tear-stained cheeks.\n\n"
                  + "\tShe must have been pretty innovative to escape "
                  + MutantWars.L1_FreezerMutant.GetName() + "'s psychotic\n"
                  + "\trampage. She could only be, at the oldest, five or six. You bend\n"
                  + "\tdown to ask her her name, not knowing if she is too deeply \n"
                  + "\tdisturbed to communicate. She is trembling, perhaps from the cold,\n"
                  + "\tperhaps from a state of shock. To your amazement, she answers you,\n"
                  + "\ther eyes still unfocused and vacant. She tells you her name is\n\t"
                  + MutantWars.L1_HumanGirl.GetName() + ".\n\n"
                  + "\tYou wrap a lab coat around her and decide to bring her with you."
                  + "\n\n";

              System.out.print(OUT);
              Functions.PAUSE();
              Functions.ClearScreen(10);

              MutantWars.L1_HumanGirl.Speak("The man in the white coat, " +
                                            "he said seven, but three times...");

              OUT = "\n\tYou try and comfort her, but words are inadequate\n"
                  + "\tin this situation. You sit on the floor beside here,\n"
                  + "\twiping the tears from her eyes, muffling her sobs.\n";
                  
              System.out.print(OUT);

              MutantWars.L1_HumanGirl.Talk();
       }


//-----------------------------------------------------------------------------

       public void South2()
       {
              char WhatToDo = '#';

              OUT = "\n\n\tWalking down the long hallway strewn with gurneys, you enter\n"
                  + "\tthe INTENSIVE CARE UNIT. Above your head flourescent tube lights\n"
                  + "\tflicker, casting their illumination on the white linoleum floor.\n"
                  + "\tTo the east of the room you see several rows of beds, IV equipment,\n"
                  + "\tdefibrillators and oxygen tanks. To the west you see an industrial\n"
                  + "\tsize laudry basket piled high with dirty surgical gowns and sheets.\n\n\n"
                  + "\tTo the south, you see elevator doors and a control mechanism mounted\n"
                  + "\ton the wall. Painted above the doors in stenciled letter are the\n"
                  + "\twords \"Surface Access\".\n";

              System.out.print(OUT);

              while(WhatToDo != 'n' && WhatToDo != 't' && WhatToDo != 'o'
              && WhatToDo != 'l' && WhatToDo != 's')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities: (L)ook  \n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = S2; break;
                       case 'n' : LOCATION = S1; break;
                       case 's' : LOCATION = Surface; break;
                       case 'e' : OUT = "\tYou examine the rows of beds and medical equipment further.\n"
                                  + "\tExhausted, you would love to lay down and take a nap in\n"
                                  + "\tone of those beds. The cool, crisp white sheets seem to call\n"
                                  + "\tto you. But your adrenaline is pumping and you are far too\n"
                                  + "\tcreeped out to snooze.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'w' : if(!FoundGun)
                                  {
                                     OUT = "\tYou walk westward over to the basket of laundry. Although\n"
                                     + "\tdisgusted by the obvious blood and vomit stains on the\n"
                                     + "\tcontents of the basket, as well as the sickening odor of\n"
                                     + "\tdeath emanating from the garments, you decide to root\n"
                                     + "\tthrough the basket. Your curiosity pays off, for after\n"
                                     + "\tferreting through numerous pieces of laundry, you find a\n"
                                     + "\t9mm pistol!\n";
                                     FoundGun = true;
                                     MutantWars.Player.SetGun(true);
                                  }
                                  else
                                  {
                                     OUT = "\tWhere you previously found the gun, you see a pile\n"
                                     + "\tof dirty laundry. Whoopie! Not doing that again...\n";
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void SurfaceAccess()
       {
              char WhatToDo = '#';

              OUT = "\tYou walk towards the control mechanism. It appears to be some\n"
                  + "\tsort of key card reader. There is a slot to the side and an\n"
                  + "\talpha-numeric keypad in the center. Underneath the keypad is\n"
                  + "\ta large button labeled \"Enter\".\n\n"
                  + "\tA name badge lies on top of the reader. In the center above\n"
                  + "\tthe keypad is a small, orange backlit LCD display. What do\n"
                  + "\tyou do?\n\n";

              System.out.print(OUT);

              while(WhatToDo != 'r' && WhatToDo != 'o' && WhatToDo != 'h')
              {
                 OUT = "\n\tYour choices are:\n"
                 + "\t(t)ry a sequence of numbers on the keypad\n"
                 + "\t(s)wipe something through the slot\n"
                 + "\t(h)it the elevator button\n"
                 + "\t(r)eturn to the center of the ICU\n\n\t";

                 System.out.print(OUT);
                 WhatToDo = Functions.INPUTchar();

                 switch(WhatToDo)
                 {
                    case 't' : if(!CardReaderActivated)
                               {
                                  OUT = "\tYou enter a few digits on the keypad and nothing\n"
                                  + "\thappens. On the display the words \"Terminal Inactive\"\n"
                                  + "\tappear and an unpleasant piezzo buzzer sounds an alarm.\n";
                               }
                               else
                               {
                                   if(!SwipedKeyCard)
                                   {
                                      OUT = "\tWhen you touch the orange backlit keypad, it displays the words\n"
                                      + "\t\"Terminal Active - Swipe Key Card\". This is accompanied by a \n"
                                      + "\tpleasant \"ding\". You try to enter a sequence of digits, but to\n"
                                      + "\tno avail. The only thing the reader does is display the blinking\n"
                                      + "\tphrase, \"Key Card Required\" on the LCD display.\n";
                                   }
                                   else
                                   {
                                      OUT = "\tWhen you touch the orange backlit keypad, the words\n"
                                      + "\t\"Terminal Active - Enter Key Code\" appear. The cursor on the\n"
                                      + "\tdisplay is blinking. Enter the access code:  ";

                                      System.out.print(OUT);
                                      int x = Functions.INPUTint();

                                      if(x == KeyCode)
                                      {
                                          OUT = "\n\tThe display changes to \"Surface Access Doors Unlocked\". The\n"
                                              + "\televator button on the reader console glows green and is blinking.\n";
                                          SurfaceDoorsLocked = false;
                                      }
                                      else
                                      {    OUT = "\n\tThe phrase \"Sorry, that was an incorrect code.\" is\n"
                                               + "\tdisplayed on the LCD panel. The display goes blank.\n";
                                      }

                                   }
                               }
                               System.out.print(OUT);
                               break;
                    case 's' : if(!MutantWars.Player.GetKeyCard())
                               {
                                   OUT = "\tYou grab the badge off of the top of the reader and\n"
                                   + "\tswipe it through the slot to your left. Nothing happens.\n"
                                   + "\tIn disgust you place the badge back on top of the reader.\n";
                                   System.out.print(OUT);
                               }
                               else
                               {
                                   WhatToDo = '#';

                                   OUT = "\tWhich card will you swipe, the badge on top of\n"
                                       + "\tthe reader or the card you are now holding?\n";

                                   System.out.print(OUT);

                                   while(WhatToDo != 'b' && WhatToDo != 'c')
                                   {
                                      OUT = "\tYour choices are:\n\n"
                                      + "\tswipe the (b)adge\n\tswipe your (c)ard\n\t";

                                      System.out.print(OUT);
                                      WhatToDo = Functions.INPUTchar();

                                      switch(WhatToDo)
                                      {
                                         case 'b' : OUT = "\n\tThe display reads \"Invalid Card\".\n";
                                                    System.out.print(OUT);
                                                    break;
                                         case 'c' : OUT = "\n\tThe display reads \"Card Accepted\".\n";
                                                    System.out.print(OUT);
                                                    SwipedKeyCard = true;
                                                    break;
                                         default : OUT = "\tInvalid response.\n";
                                                   System.out.print(OUT);
                                                   break;
                                      }
                                   }
                               }
                               break;
                    case 'h' : if(SurfaceDoorsLocked)
                               {
                                  OUT = "\tYou press the elevator button but nothing happens.\n";
                                  System.out.print(OUT);
                               }
                               else
                               {
                                   OUT = "\tYou press the elevator button and the doors swing open. You\n"
                                       + "\tfeel a gigantic sense of relief at the thought of escaping\n"
                                       + "\tthis underground nightmare, but you also feel a knot swell\n"
                                       + "\tin your throat as apprehension builds concerning what you\n"
                                       + "\tmay find on the surface...\n";

                                   System.out.print(OUT);
                                   Functions.PAUSE();
                                   LOCATION = BOSSFIGHT_L1;
                               }
                               break;
                    case 'r' : OUT = "\tYou walk back to the center of the room.\n";
                               System.out.print(OUT);
                               LOCATION = S2;
                               break;
                    case 'i' : MutantWars.Player.Inventory(); break;
                    case 'a' : MutantWars.Player.Abilities(); break;
                    case 'b' : MutantWars.Player.DisplayStats(); break;
                    case 'o' : Functions.Options(); break;
                    default : OUT = "\tInvalid input...";
                              System.out.print(OUT);
                              break;
                 }

              }
       }

//-----------------------------------------------------------------------------

       public void East2()
       {
              char WhatToDo = '#';

              if(RanAwayFromFreezerMutant)
              {
                  OUT = "\tThe freezer mutant you ran away from sees you and charges you!\n";
                  System.out.print(OUT);
                  Functions.PAUSE();
                  L1_FreezerMutantFight();
              }

              System.out.print(OUT);

              if(East2FirstTime)
              {
                 OUT = "\n\n\tYou walk down the dim hallway from the previous storage room\t\n"
                     + "\tinto a much larger room, a WAREHOUSE. It must be at least 20\n"
                     + "\tdegrees colder in in this room than in the previous one. Brrr!\n\n";

                 East2FirstTime = false;
              }
              else
              {
                 OUT = "\n\n\tYou return to the WAREHOUSE and shiver as a blast of\n"
                     + "\tcold air hits you in the face. It's so cold you can see\n"
                     + "\tyour breath in the dim lighting.\n\n";
              }


              OUT = OUT + "\tYou are standing in the middle of an enormous room. The\n"
                  + "\tceiling must be at least 25 feet high and reinforced\n"
                  + "\twith thick steel girders that run the length of the room.\n\n";

              OUT = OUT + "\tTo the west behind you is the previous storage room.\n"
                        + "\tAhead, to your east, as well as to the north and south,\n"
                        + "\tyou see nothing but crates, shipping containers and\n"
                        + "\tboxes. Too far away to make out ay detail, you conclude\n"
                        + "\tthis room warrants further investigation.\n";

              if(FoughtFreezerMutant) { OUT = OUT + "\n\tTo the north lies a dead freezer mutant.\n"; }

              OUT = OUT + "\n";

              System.out.print(OUT);

              while(WhatToDo != 'w' && WhatToDo != 'o' && WhatToDo != 'l' 
                    && RanAwayFromFreezerMutant == false && LOCATION != QUIT)
              {
                    OUT =
                    "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                    + "\tPossibilities: (L)ook \n"
                    + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\n\t";
             
                    System.out.print(OUT);
                    WhatToDo = Functions.INPUTchar();

                    switch(WhatToDo)
                    {
                       case 'l' : LOCATION = E2; break;
                       case 'n' : if(!FoughtFreezerMutant)
                                  {
                                      OUT = "\tYou walk to the north wall of the warehouse and\n"
                                      + "\tspy a pair of bolt cutters!\n\n";

                                      System.out.print(OUT);
                                      WhatToDo = '#';

                                      while(WhatToDo != 'y' && WhatToDo != 'n')
                                      {
                                         OUT = "\tDo you want to pick the bolt cutters up? (y)es or (n)o\n\t";
                                         System.out.print(OUT);

                                         WhatToDo = Functions.INPUTchar();

                                         switch(WhatToDo)
                                         {
                                             case 'y' : L1_FreezerMutantFight(); break;
                                             case 'n' : OUT = "\n\tYou decide to leave them there.\n";
                                                        System.out.print(OUT);
                                                        break;
                                             default : OUT = "\n\tInvalid response...\n";
                                                       System.out.print(OUT);
                                                       break;
                                         }

                                      }

                                  }
                                  else
                                  {
                                     OUT = "\tYou stumble over the corpse of the freezer mutant you killed.\n";
                                     System.out.print(OUT);
                                  }
                                  break;
                       case 's' : OUT = "\tYou walk to the north end of the warehouse. There on a shelf\n"
                                  + "\tat the very back, you find a small black, steel box. It looks\n"
                                  + "\tlike it might hold a key or valuables. If only you could open it!\n"
                                  + "\tIf only there were a pair of bolt cutters around here somewhere...\n";
                                  System.out.print(OUT);
                                  break;
                       case 'e' : OUT = "\tYou walk towards the east about half the length of the warehouse.\n"
                                      + "\tThere appears to be nothing interesting there. Just boxes and\n"
                                      + "\tcrates of perishables that have long since past their due dates.\n"
                                      + "\tYou return to your original location.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'w' : LOCATION = E1; break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
                }        

              Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void L1_FreezerMutantFight()
       {
              char WhatToDo = '#';

              if(!RanAwayFromFreezerMutant)
              {
                 OUT = "\n\tAs you reach for the bolt cutters, the hair on the back of your\n"
                     + "\tneck stands up. Out of the corner of your eye you see a man\n"
                     + "\twalk towards you from the shadows.  \"You can call me "
                     + MutantWars.L1_FreezerMutant.GetName() + "\", he\n"
                     + "\tsays, \"and I hope you like it cold.\"  You gasp for breath as\n"
                     + "\tthe air around you becomes so cold it stings your lungs.\n\n";

                 System.out.print(OUT);
              }

              while(WhatToDo != 'r' && WhatToDo != 'f' && WhatToDo != 'o')
              {
                   OUT = "\tWill you (F)ight the Freezer mutant or (R)un away?\n"
                       +  "\tCommands: (I)nventory  (A)bilities  (B)ioStats\n\n\n\t";

                   System.out.print(OUT);
                   WhatToDo = Functions.INPUTchar();

                   switch(WhatToDo)
                   {
                      case 'f' : Functions.Combat(MutantWars.Player, MutantWars.L1_FreezerMutant);
                                 if(MutantWars.Player.GetHit() > 0)
                                 {
                                    OUT = "\tCongratulations. You survived your ordeal with "
                                    + MutantWars.L1_FreezerMutant.GetName() + ".\n"
                                    + "\tYou notice a metal KEY hanging around your defeated opponent's \n"
                                    + "\tneck. You decide to take it - it must go to something important.\n";
                                    FoundKey = true;
                                    FoughtFreezerMutant = true;
                                    MutantWars.Player.SetKey(true);
                                    MutantWars.Player.SetFREEZE(true);
                                    MutantWars.Player.SetMutantPower(MutantWars.Player.GetMutantPower() + 30);
                                    OUT = "\n\tYou absorb " + MutantWars.L1_FreezerMutant.GetName()
                                    + "'s ability to FREEZE (lower ambient temperature)!\n"
                                    + "\tYou also absorb 30 points of mutant energy.\n";
                                    MutantWars.Player.SetScore(MutantWars.Player.GetScore() + 100);
                                    OUT = OUT + "\tDue to exceptional combat prowess, 100 is added to your score.\n";
                                    System.out.print(OUT);
                                 }
                                 else { LOCATION = QUIT; }
                                 RanAwayFromFreezerMutant = false;
                                 break;
                      case 'r' : OUT = "\tYou decide to run away to save your life. Unfortunately,\n\t"
                                 + MutantWars.L1_FreezerMutant.GetName()
                                 + " is able to land a few chilling blows in your retreat.\n"
                                 + "\t30 points worth! In a panic, you run, not caring where\n"
                                 + "\tyou will end up - just anywhere but here, you think...\n";
                                 MutantWars.Player.SetHit(MutantWars.Player.GetHit() - 30);
                                 RanAwayFromFreezerMutant = true;
                                 System.out.print(OUT);
                                 LOCATION = E1;
                                 Functions.PAUSE();    //Run away to E1 storage room
                                 break;
                      case 'i' : MutantWars.Player.Inventory(); break;
                      case 'a' : MutantWars.Player.Abilities(); break;
                      case 'b' : MutantWars.Player.DisplayStats(); break;
                      default : OUT = "\tInvalid response...\n";
                                System.out.print(OUT);
                                break;
                   }

              }

       }

//-----------------------------------------------------------------------------

       public void West2()
       {
              char WhatToDo = '#';

              if(West2FirstTime)
              {
                 OUT = "\n\n\tYou proceed down the hallway from the dining room\t\n"
                     + "\tand through two steel and glass doors into what\n"
                     + "\tappears to be a Conference Room.\n\n";
                 West2FirstTime = false;
              }
              else
              {
                OUT = "\n\n\tYou return to the Conference Room to find it much as\n"
                    + "\tit was before.\n\n";
              }

              OUT = OUT + "\tA piercing alarm painfully fills your ears. The room is\n"
                  + "\tintermittently illuminated by a flashing strobe light - \n"
                  + "\tpart of the alarm system. In blinks of light amidst the\n"
                  + "\tdarkness, you look to the north and are able to make out a\n"
                  + "\tconference table.\n\n"
                  + "\tTo the south, you can see the outline of a large, heavy steel\n"
                  + "\tbox - perhaps a safe. Towards the west wall a bank of flashing\n"
                  + "\tstrobe lights disorients you.\n";

              System.out.print(OUT);

              while(WhatToDo != 'e' && WhatToDo != 'o' && WhatToDo != 'l')
              {
                     OUT =
                     "\n\n\tWhere will you go:  (N)orth, (S)outh, (E)ast, (W)est?\n"
                     + "\tPossibilities:  (L)ook\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n"
                     + "\n\n\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'l' : LOCATION = W2; break;
                       case 'n' : OUT = "\tYou walk over to the north side of the room. A long\n"
                                      + "\tconference table that could seat approximately 12\n"
                                      + "\tpeople sits adjacent to the wall. It is made of what\n"
                                      + "\tappears to be woodgrain formica and there is a\n"
                                      + "\tconference phone situated in the very middle. \n"
                                      + "\tNot finding anything you can use, you walk\n"
                                      + "\tback to the center of the room.\n";
                                  System.out.print(OUT);
                                  break;
                       case 's' : TheSafe(); break;
                       case 'e' : LOCATION = W1; break;
                       case 'w' : OUT = "\tYou walk over the the west side of the room, blinded\n"
                                      + "\tby the flashing lights. You can hear the capacitors\n"
                                      + "\tdischarge and the clicks of the relays in the strobe's\n"
                                      + "\tcircuitry. Nothing else seems interesting and you are\n"
                                      + "\tgetting a splitting headache so you decide to return\n"
                                      + "\tto the center of the room.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input...";
                                 System.out.print(OUT);
                                 break;
                     }
             }

             Functions.ClearScreen(5);
       }

//-----------------------------------------------------------------------------

       public void TheSafe()
       {
              char WhatToDo = '#';

              if(SafeFirstTime)
              {
                  OUT = "\tYou walk over to the south side of the Conference Room. You\n"
                  + "\tcan definitely tell now, despite all the strobing madness, that the\n"
                  + "\tcubical object you saw was indeed a safe. You can see that it has a\n"
                  + "\thandle for clasping and a slot to insert a metal key.\n";
                  SafeFirstTime = false;
              }
              else { OUT = "\tYou return once again to the safe.\n"; }

              System.out.print(OUT);

              while(WhatToDo != 'r' && WhatToDo != 'o')
              {
                     OUT =
                     "\n\n\tWhat will you try to do? \n"
                     + "\t(P)ull the safe door open\n"
                     + "\t(S)tick something into the key hole\n"
                     + "\t(T)urn the handle\n"
                     + "\t(R)eturn to the center of the room\n"
                     + "\tCommands: (O)ptions  (I)nventory  (A)bilities  (B)ioStats\n\n\t";

                     System.out.print(OUT);
                     WhatToDo = Functions.INPUTchar();

                     switch(WhatToDo)
                     {
                       case 'p' : if(!SafeUnlocked)
                                  {
                                     OUT = "\tYou can not open the safe. It is locked and latched.\n";
                                  }
                                  else
                                  {
                                     if(!FoundKeyCard)
                                     {
                                        OUT = "\tAfter several tries, you open the safe door. Inside you\n"
                                            + "\tfind an electronic key card! This might come in handy...\t";
                                        FoundKeyCard = true;
                                        MutantWars.Player.SetKeyCard(true);
                                     }
                                     else { OUT = "\tThe safe is empty. You already found the key card.\n"; } 
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 's' : if(!FoundKey)
                                  {
                                     OUT = "\tYou have no keys to insert into the safe!\n";
                                  }
                                  else
                                  {
                                     if(!KEYinserted)
                                     { 
                                        OUT = "\tYou insert the KEY you found on the mutant into the safe.\n"
                                            + "\tIt bonds to the surface of the locking mechanism and you\n"
                                            + "\tcan not get it out.\n";
                                        KEYinserted = true;
                                        MutantWars.Player.SetKey(false);
                                     }
                                     else 
                                     { 
                                        OUT = "\tThe key is still there from the last time you inserted\n" 
                                        + "\tit into the locking mechanism. It is stuck.\n";
                                     }
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 't' : if(!KEYinserted)
                                  { 
                                      OUT = "\tYou can't turn the handle. No key is inserted.\n";
                                  }
                                  else  //Key IS Inserted
                                  {
                                      if(!FoundMatches)
                                      {
                                         OUT = "\tWith the key inserted, you turn the handle. Nothing\n"
                                         + "\tHappens. The inner mechanism has been bent and can't release. It\n"
                                         + "\tmust have been "
                                         + MutantWars.L1_FreezerMutant.GetName() + ". "
                                         + "Somehow he damaged the mechanism and froze it\n"
                                         + "\tsolid in a jammed state. The metal handle is so cold it burns you\n"
                                         + "\tto touch it. You try to bend the metal back but it can't be bent.\n"
                                         + "\tYou can see ice crystals along the edge of the handle. It might be\n"
                                         + "\tpossible to release it if you could make the metal more maleable,\n"
                                         + "\tthat is, to somehow thaw it out. If only there were a heat source...\n";
                                      }
                                      else   //Got Matches
                                      {
                                         if(!FoundSterno)
                                         {
                                             OUT = "\tYou have the right idea with the matches, but none of\n"
                                                 + "\tthem will burn long enough to heat the metal to a\n"
                                                 + "\tsufficient temperature. You need a fuel source...\n";
                                         }
                                         else  //Got Sterno
                                         {
                                             OUT = "\tWith the key inserted, you are still unable to turn the\n"
                                                 + "\thandle. Now that you have a fuel source, you take one of\n"
                                                 + "\tyour matches and ignite the can of sterno. You place it\n"
                                                 + "\tunderneath the handle and it slowly heats the metal,\n"
                                                 + "\tcausing it to become more maleable. After a few minutes,\n"
                                                 + "\tyou try to turn the handle again. \"Click!\", it turns.\n"
                                                 + "\tIt's unjammed! The safe is now unlocked.\n";

                                             SafeUnlocked = true;
                                         }

                                      }
                                  }
                                  System.out.print(OUT);
                                  break;
                       case 'r' : OUT = "\tYou walk back to the Conference Room's center.\n";
                                  System.out.print(OUT);
                                  break;
                       case 'i' : MutantWars.Player.Inventory(); break;
                       case 'a' : MutantWars.Player.Abilities(); break;
                       case 'b' : MutantWars.Player.DisplayStats(); break;
                       case 'o' : Functions.Options(); break;
                       default : OUT = "\tInvalid input..."; 
                                 System.out.print(OUT);
                                 break;
                     }
             }              
       }

//-----------------------------------------------------------------------------

       public void FinalBossFight()
       {
              OUT = "\n\tYou enter the elevator and ascend to the surface.\n"
              + "\tWalking outside, you blink in the blinding glow of the burning sun.\n"
              + "\tYour head is pounding as you try to ascertain your surroundings with\n"
              + "\ta narrow squint. Unbearable fear grips you, twisting the knot in\n"
              + "\tyour throat into cruel contortions. There, in standing in the clearing\n"
              + "\tyou have just walked into, stands 7 mutants. They leer at you with a\n"
              + "\tmenacing gaze. Your blood runs cold...\n";

              System.out.print(OUT);

              Freezer[] FreezerSquad = new Freezer[3];
              Pyrotech[] PyroSquad = new Pyrotech[3];
              Telekinetic Movz = new Telekinetic();

              //MutantWars.FreezerSquad[0].Speak("Look what we have here!");
              //MutantWars.PyroSquad[0].Speak("It's a wussy little Impath.");
              //MutantWars.Movz.Speak("Awww, and how are we \"feeling\" today, warm and fuzzy?");

              OUT = "\n\tMovz walks away, mumbling your not worth his time...\n";
              OUT = "\n\tFire and Ice!\n"
                  + "\tThe Freezers and Pyros attack you all at once!\n";

              System.out.print(OUT);

              for(int x = 0; x < 3; x++)
              {
                  FreezerSquad[x] = new Freezer();
                  PyroSquad[x] = new Pyrotech();
                  System.out.print("\tA Freezer attacks you!\n");
                  Functions.Combat(MutantWars.Player, FreezerSquad[x]);
                  System.out.print("\tA Pyrotech attacks you!\n");
                  Functions.Combat(MutantWars.Player, PyroSquad[x]);
              }

              if(MutantWars.Player.GetHit() > 0)
              {
                 OUT = "\n\tMiraculously, you survived.\n"
                 + "\tIf it existed, we would now load level 2...\n";
              }
              else { OUT = "\n\tYou did not survive.\n"; }
              System.out.print(OUT);
              LOCATION = QUIT;
       }

//-----------------------------------------------------------------------------

    public void SaveLevel(String FileName)
    {
           try
           {
               //Open for Append
               MutantWars.PlayerOut = new FileOutputStream(MutantWars.PlayerFile, true);
               MutantWars.WritePlayer = new PrintStream(MutantWars.PlayerOut);

               //Save Event Data
               MutantWars.WritePlayer.println("---- Begin Level 1 Data ----");
               MutantWars.WritePlayer.println(LOCATION);
               MutantWars.WritePlayer.println(C1FirstTime);
               MutantWars.WritePlayer.println(DataCrystalTaken);
               MutantWars.WritePlayer.println(Found9mmAmmo );
               MutantWars.WritePlayer.println(Found9mmAmmoBox);
               MutantWars.WritePlayer.println(CardReaderActivated);
               MutantWars.WritePlayer.println(Center1BasementFirstTime);
               MutantWars.WritePlayer.println(DrankSoda);
               MutantWars.WritePlayer.println(AteSandwhich);
               MutantWars.WritePlayer.println(FoundMachete);
               MutantWars.WritePlayer.println(FoundSyringe);
               MutantWars.WritePlayer.println(FoundMatches);
               MutantWars.WritePlayer.println(FoundFramePack);
               MutantWars.WritePlayer.println(FoundMedKit);
               MutantWars.WritePlayer.println(FoundMRERations);
               MutantWars.WritePlayer.println(FoundSterno);
               MutantWars.WritePlayer.println(N2FirstTime);
               MutantWars.WritePlayer.println(FoundJacket);
               MutantWars.WritePlayer.println(ExplodedTripBomb);
               MutantWars.WritePlayer.println(FoundGun);
               MutantWars.WritePlayer.println(FoundKeyCard);
               MutantWars.WritePlayer.println(SwipedKeyCard);
               MutantWars.WritePlayer.println(SurfaceDoorsLocked);
               MutantWars.WritePlayer.println(East2FirstTime);
               MutantWars.WritePlayer.println(West2FirstTime);
               MutantWars.WritePlayer.println(FoughtFreezerMutant);
               MutantWars.WritePlayer.println(RanAwayFromFreezerMutant);
               MutantWars.WritePlayer.println(FoundKey);
               MutantWars.WritePlayer.println(SafeFirstTime);
               MutantWars.WritePlayer.println(SafeUnlocked);
               MutantWars.WritePlayer.println(KEYinserted);
               MutantWars.WritePlayer.println(MutantWars.Player.GetHumanGirl());
               MutantWars.WritePlayer.println(FromAtrium);
               MutantWars.WritePlayer.println("---- End Level 1 Data ----");
         }

         catch(IOException e) 
         { 
                OUT = "Unable to save level 1 event values";
         }         
    }

    
    public void LoadLevel(String FileName)
    {	          
           try
           {
               //Save Level 1 Event Data
               MutantWars.StreamPlayer.readLine(); //Read empty line for label
               String PlayerLocation = MutantWars.StreamPlayer.readLine();
               String c1firsttime = MutantWars.StreamPlayer.readLine();
               String datacrystaltaken = MutantWars.StreamPlayer.readLine(); 
               String found9mmammo = MutantWars.StreamPlayer.readLine();               
               String found9mmammobox = MutantWars.StreamPlayer.readLine();
               String cardreaderactivated = MutantWars.StreamPlayer.readLine();
               String center1basementfirsttime = MutantWars.StreamPlayer.readLine();
               String dranksoda = MutantWars.StreamPlayer.readLine();
               String atesandwhich = MutantWars.StreamPlayer.readLine();
               String foundmachete = MutantWars.StreamPlayer.readLine();
               String foundsyringe = MutantWars.StreamPlayer.readLine();
               String foundmatches = MutantWars.StreamPlayer.readLine();
               String foundframepack = MutantWars.StreamPlayer.readLine();
               String foundmedkit = MutantWars.StreamPlayer.readLine();
               String foundmrerations = MutantWars.StreamPlayer.readLine();
               String foundsterno = MutantWars.StreamPlayer.readLine();
               String n2firsttime = MutantWars.StreamPlayer.readLine();
               String foundjacket = MutantWars.StreamPlayer.readLine();
               String explodedtripbomb = MutantWars.StreamPlayer.readLine();
               String foundgun = MutantWars.StreamPlayer.readLine();
               String foundkeycard = MutantWars.StreamPlayer.readLine();
               String swipedkeycard = MutantWars.StreamPlayer.readLine();
               String surfacedoorslocked = MutantWars.StreamPlayer.readLine();
               String east2firsttime = MutantWars.StreamPlayer.readLine();
               String west2firsttime = MutantWars.StreamPlayer.readLine();
               String foughtfreezermutant = MutantWars.StreamPlayer.readLine();
               String ranawayfromfreezermutant = MutantWars.StreamPlayer.readLine();
               String foundkey = MutantWars.StreamPlayer.readLine();
               String safefirsttime = MutantWars.StreamPlayer.readLine();
               String safeunlocked = MutantWars.StreamPlayer.readLine();
               String keyinserted = MutantWars.StreamPlayer.readLine();
               String foundL1_humangirl = MutantWars.StreamPlayer.readLine();
               String fromatrium = MutantWars.StreamPlayer.readLine();
               MutantWars.StreamPlayer.readLine(); //Read empty line for label

               //Set player and event data with local function data
               LOCATION = Integer.parseInt(PlayerLocation);
               C1FirstTime = Functions.TrueOrFalse(c1firsttime);
               DataCrystalTaken = Functions.TrueOrFalse(datacrystaltaken);
               Found9mmAmmo = Functions.TrueOrFalse(found9mmammo);
               Found9mmAmmoBox = Functions.TrueOrFalse(found9mmammobox);
               CardReaderActivated = Functions.TrueOrFalse(cardreaderactivated);
               Center1BasementFirstTime = Functions.TrueOrFalse(center1basementfirsttime);
               DrankSoda = Functions.TrueOrFalse(dranksoda);
               AteSandwhich = Functions.TrueOrFalse(atesandwhich);
               FoundMachete = Functions.TrueOrFalse(foundmachete);
               FoundSyringe = Functions.TrueOrFalse(foundsyringe);
               FoundMatches = Functions.TrueOrFalse(foundmatches);
               FoundFramePack = Functions.TrueOrFalse(foundframepack);
               FoundMedKit = Functions.TrueOrFalse(foundmedkit); 
               FoundMRERations = Functions.TrueOrFalse(foundmrerations);
               FoundSterno = Functions.TrueOrFalse(foundsterno);
               N2FirstTime = Functions.TrueOrFalse(n2firsttime);
               FoundJacket = Functions.TrueOrFalse(foundjacket);
               ExplodedTripBomb = Functions.TrueOrFalse(explodedtripbomb);
               FoundGun = Functions.TrueOrFalse(foundgun);
               FoundKeyCard = Functions.TrueOrFalse(foundkeycard);
               SwipedKeyCard = Functions.TrueOrFalse(swipedkeycard);
               SurfaceDoorsLocked = Functions.TrueOrFalse(surfacedoorslocked);
               East2FirstTime = Functions.TrueOrFalse(east2firsttime);
               West2FirstTime = Functions.TrueOrFalse(west2firsttime);
               FoughtFreezerMutant = Functions.TrueOrFalse(foughtfreezermutant);
               RanAwayFromFreezerMutant = Functions.TrueOrFalse(ranawayfromfreezermutant);
               FoundKey = Functions.TrueOrFalse(foundkey);
               SafeFirstTime = Functions.TrueOrFalse(safefirsttime);
               SafeUnlocked = Functions.TrueOrFalse(safeunlocked);
               KEYinserted = Functions.TrueOrFalse(keyinserted);
               MutantWars.Player.SetHumanGirl(Functions.TrueOrFalse(foundL1_humangirl));
               FromAtrium = Functions.TrueOrFalse(fromatrium);
         }

         catch(IOException e)
         {
                OUT = "\tUnable to load level 1 event values.\n";
         }

    }

}//end Events class
