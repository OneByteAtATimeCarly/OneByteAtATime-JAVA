//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - ADT LifeForm class
//ADT Base Class for all game objects
//Class = 520 lines of code

import javax.swing.*;
import java.io.*;

//Base Class ADT
public class LifeForm
{
       //4 Overloaded Constructors 
       public LifeForm()
       { 
              String OUT = "\n\tCreating a base class ADT LifeForm object.";
              System.out.print(OUT);
              hitpoints = 100; atack = 1; defense = 1; NAME="LifeForm";
              InitializeInventory();
       }

       public LifeForm(String n)
       {
              String OUT = "\n\tCreating a base class ADT LifeForm object.";
              System.out.print(OUT);
              hitpoints = 10; atack = 1; defense = 1; NAME = n;
              InitializeInventory();
       }

       public LifeForm(String n, int h)
       {
              String OUT = "\n\tCreating a base class ADT LifeForm object.";
              System.out.print(OUT);
              hitpoints = h; atack = 1; defense = 1; NAME = n;
              InitializeInventory();
       }

       public LifeForm(String n, int h, int a, int d)
       {
              String OUT = "\n\tCreating a base class ADT LifeForm object.";
              System.out.print(OUT);
              hitpoints = h; atack = a; defense = d; NAME = n;
              InitializeInventory();
       }

       //Functions

       public void NameLifeForm()
       {
              String n;
              String OUT = "\n\n\tPlease enter a name for your character:  ";
              System.out.print(OUT);
              n = Functions.INPUTstring();
              NAME = n;

       }

       public void Speak(String x)
       {
              String OUT = "\t" + NAME + " looks at you and says, \n\t\"" + x + "\".\n";
              System.out.print(OUT);
       }

       public void InitializeInventory()
       {
              datacrystal = false;
              Gun = false;
              Ammo9mm = 0;
              Syringe = false;
              SyringeCartridge = 0;
              Machete = false;
              Jacket = false;
              MedKit = 0;
              MRErations = 0;
              FramePack = false;
              Matches = false;
              Sterno = false;
              KeyCard = false;
              Key = false;
              FoundL1_HumanGirl = false;
              WeaponChoice = "UNDECIDED";
       }


       public void Cheat()
       {
              datacrystal = true;
              Gun = true;
              Ammo9mm = 100;
              Syringe = true;
              SyringeCartridge = 10;
              Machete = true;
              Jacket = true;
              MedKit = 25;
              MRErations = 25;
              FramePack = true;
              Matches = true;
              Sterno = true;
              KeyCard = true;
              Key = true;
              FoundL1_HumanGirl = true;
              String OUT = NAME + "\n\tCheater!";
              System.out.print(OUT);
       }

       public void DisplayStats()
       {
              String STATS = "\n\n\t-------------------------------------------------------\n";

              STATS = STATS + "\t  Name: " + NAME + "   " + "Hp: " + hitpoints +
                             "   Atk: " + atack + "   Def: " + defense +
                             "   Score: " + score + "\n";

              STATS = STATS + "\t-------------------------------------------------------\n";


              System.out.print(STATS);

       }

       public void Inventory()
       {
              String choice = "";
              char WhatToDo = '#';
              boolean successful = false;
              Functions.ClearScreen(8);

              while(WhatToDo != 'q')
              {
                   String OUT = "\n\n\t\t\t***** Inventory Menu ******\n"
                              + "\t\t\t*                         *\n"
                              + "\t\t\t*    (L)ist Inventory     *\n"
                              + "\t\t\t*    (S)elect Item        *\n"
                              + "\t\t\t*    (U)se Item           *\n"
                              + "\t\t\t*    (D)rop Item          *\n";

                              if(MutantWars.Player.GetHumanGirl())
                              { OUT = OUT +  "\t\t\t*    (T)alk to Survivors  *\n"; }

                              OUT = OUT + "\t\t\t*    (Q)uit               *\n"
                              + "\t\t\t*                         *\n"
                              + "\t\t\t***************************\n";

                  OUT = OUT + "\n\t\t\tCurrently Selected Item: " + InventoryItem +
                              "\n\n\n\n\n\n\n\n\t\t\t";
                  System.out.print(OUT);

                  WhatToDo = Functions.INPUTchar();

                  switch(WhatToDo)
                  {
                    case 'l' : ListInventory(); Functions.PAUSE(); break;
                    case 's' : SelectInventory(); break;
                    case 'u' : UseInventory(); break;
                    case 'd' : DropInventory(); break;
                    case 't' : MutantWars.L1_HumanGirl.Talk(); break;
                    case 'q' : break;
                    default : OUT = "\n\tInvalid choice!\n"; break;
               } //close switch

        } //close while loop
       }

       public void ListInventory()
       {
              int count = 0;
              String INV = "";

              INV = "\n\t-------------------- Current Inventory: --------------------\n\n";
              if(Gun) { INV = INV + "\t" + ++count + ". 9mm Gun (+8 attack)\n"; }
              if(Ammo9mm > 0) { INV = INV + "\t" + ++count + ". 9mm Ammunition Clips: " + Ammo9mm + "\n"; }
              if(Syringe) { INV = INV + "\t" + ++count + ". Medical Syringe (+20 attack)\n"; }
              if(SyringeCartridge > 0) { INV = INV + "\t" + ++count + ". Syringe Cartridges: " + SyringeCartridge + "\n"; }
              if(Machete) { INV = INV + "\t" + ++count + ". Machete (+4 attack)\n"; }
              if(Jacket) { INV = INV + "\t" + ++count + ". Straight Jacket (+2 defense)\n"; }
              if(MedKit > 0) { INV = INV + "\t" + ++count + ". Med Kits: " + MedKit + "\n"; }
              if(MRErations > 0) { INV = INV + "\t" + ++count + ". MRE Rations: " + MRErations + "\n"; }
              if(FramePack) { INV = INV + "\t" + ++count + ". FramePack\n"; }
              if(datacrystal) { INV = INV + "\t" + ++count + ". Data Crystal\n"; }
              if(Matches) { INV = INV + "\t" + ++count + ". Matches\n"; }
              if(Sterno) { INV = INV + "\t" + ++count + ". Can of Sterno\n"; }
              if(KeyCard) { INV = INV + "\t" + ++count + ". Electronic Key Card\n"; }
              if(Key) { INV = INV + "\t" + ++count + ". Key\n"; }
              if(FoundL1_HumanGirl)
              { INV = INV + "\t" + ++count + ". " + MutantWars.L1_HumanGirl.GetName() + " (rescued survivor)\n"; }

              if(!datacrystal && (Ammo9mm <= 0) && !Machete && !Syringe && !Matches &&
                 !FramePack && (MedKit <= 0) && (MRErations <= 0) && !Sterno && !Jacket &&
                 !Gun && !KeyCard && !Key && !FoundL1_HumanGirl)

              { INV = INV + "\tAbsolutely nothing!"; }

              INV = INV + "\n\t------------------------------------------------------------\n\n";

              System.out.print(INV);

       }

       public void SelectInventory()
       {
              char choice = '#';

          while(choice != 'q')
          {
              String INV = "\n\t-------- Select An Item --------\n\n";
              if(Gun) { INV = INV + "\t(G)un\n"; }
              if(Ammo9mm > 0) { INV = INV + "\t(A)mmo Clips: " + Ammo9mm + "\n"; }
              if(Syringe) { INV = INV + "\t(S)yringe\n"; }
              if(SyringeCartridge > 0) { INV = INV + "\tSyringe (C)artridge\n"; }
              if(Machete) { INV = INV + "\t(M)achete\n"; }
              if(Jacket) { INV = INV + "\t(J)acket\n"; }
              if(MedKit > 0) { INV = INV + "\tMed(K)it\n"; }
              if(MRErations > 0) { INV = INV + "\tMR(E)rations\n"; }
              if(FramePack) { INV = INV + "\t(F)rame Pack\n"; }
              if(datacrystal) { INV = INV + "\t(D)ata Crystal\n"; }
              if(Matches) { INV = INV + "\tMa(t)ches\n"; }
              if(Sterno) { INV = INV + "\tStern(o)\n"; }
              if(KeyCard) { INV = INV + "\tE(l)lectronic Key Card\n"; }
              if(Key) { INV = INV + "\tKe(y)\n"; }
              INV = INV + "\t(Q)uit\n\n\t\t";

              System.out.print(INV);
              choice = Functions.INPUTchar();

              switch(choice)
              {
                  case 'g' : if(Gun) { InventoryItem = "Gun"; } break;
                  case 'a' : if(Ammo9mm > 0) { InventoryItem = "9mm Ammo Clip"; } break;
                  case 's' : if(Syringe) { InventoryItem = "Syringe"; } break;
                  case 'c' : if(SyringeCartridge > 0) { InventoryItem = "Syringe Cartridge"; } break;
                  case 'm' : if(Machete) { InventoryItem = "Machete"; } break;
                  case 'j' : if(Jacket) { InventoryItem = "Jacket"; } break;
                  case 'k' : if(MedKit > 0) { InventoryItem = "MedKit"; } break;
                  case 'e' : if(MRErations > 0) { InventoryItem = "MRE-Rations"; } break;
                  case 'f' : if(FramePack) { InventoryItem = "Frame Pack"; } break;
                  case 'd' : if(datacrystal) { InventoryItem = "Data Crystal"; } break;
                  case 't' : if(Matches) { InventoryItem = "Book of Matches";  } break;
                  case 'o' : if(Sterno) { InventoryItem = "Sterno"; } break;
                  case 'l' : if(KeyCard) { InventoryItem = "Electronic Key Card"; } break;
                  case 'y' : if(Key){ InventoryItem = "Key"; } break;
                  case 'n' : InventoryItem = "Nothing"; break;
                  case 'q' : break;
                  default : System.out.print("\tInvalid Choice...\n"); break;
              }
          }
       }

       public void UseInventory()
       {
              String OUT = "\n\tUsing " + InventoryItem + "...\n";

              if(InventoryItem.equals("MedKit"))
              {
                  MedKit--;
                  MutantWars.Player.SetHit(MutantWars.Player.GetHit() + 20);
                  if(MedKit < 1) { InventoryItem = "None"; }
                  OUT = OUT + "\tApplied Medical Kit to wounds.\n"
                            + "\tRestores 20 points to health!\n";
              }

              if(InventoryItem.equals("MRE-Rations"))
              {
                  MRErations--;
                  MutantWars.Player.SetHit(MutantWars.Player.GetHit() + 15);
                  if(MRErations < 1) { InventoryItem = "None"; }
                  OUT = OUT + "\tYou eat an MRE. Mmmmm!\n"
                            + "\tIt adds 15 points to health!\n";
              }

              if(InventoryItem.equals("Jacket"))
              {
                  if(!WearingJacket)
                  {
                      OUT = OUT + "\tYippee! You put on the Straight Jacket.\n"
                                + "\tYou look like a lunatic, but it adds 2 to your defense.\n";
                      MutantWars.Player.SetDef(MutantWars.Player.GetDef() + 2);
                      WearingJacket = true;
                  }
                  else
                  {
                       OUT = OUT + "\tYou were already wearing the Straight Jacket, nutball.\n"
                                 + "\tI guess you want to take it off. Subtract 2 from your defense.\n";
                       MutantWars.Player.SetDef(MutantWars.Player.GetDef() - 2);
                       WearingJacket = false;
                       InventoryItem = "None";
                  }
              }

              System.out.print(OUT);
       }

       public void DropInventory()
       {
              String OUT = "\n\tDropping " + InventoryItem + "...\n";
              System.out.print(OUT);
       }

       public void ChooseWeapon()
       {
              while(WeaponChoice.equals("UNDECIDED"))
              {
                    String OUT = "\n\tWhich weapon do you choose for combat?\n\n"
                               + "\t(H)and to Hand\n";
                    if(Gun) { OUT = OUT + "\t(G)un       [+8]\n"; }
                    if(Machete)  { OUT = OUT + "\t(M)achete   [+4]\n"; }
                    if(Syringe) { OUT = OUT + "\t(S)yringe   [+20]\n"; }
                    if(MutantWars.Player.GetFLY() || MutantWars.Player.GetFREEZE() ||
                       MutantWars.Player.GetHEAL() || MutantWars.Player.GetMINDREAD() ||
                       MutantWars.Player.GetFIRE() || MutantWars.Player.GetMOVE() ||
                       MutantWars.Player.GetTIMESHIFT())
                    { OUT = OUT + "\t(A)bility\n"; }

                    System.out.print(OUT);
                    OUT = "";

                    char choice = Functions.INPUTchar();

                    switch(choice)
                    {
                          case 'h' : WeaponChoice = "HAND"; break;
                          case 'g' : if(Gun)
                                     {
                                         if(Ammo9mm > 0)
                                         { WeaponChoice = "GUN"; }
                                         else
                                         {
                                           OUT = "\n\tYou can't use the gun. No ammunition!\n";
                                         }
                                     }
                                     else { OUT = "\n\tYou don't have the gun.\n"; }
                                     break;
                          case 'm' : if(Machete) { WeaponChoice = "MACHETE"; }
                                     else { OUT = "\n\tYou do not have the Machete.\n"; }
                                     break;
                          case 's' : if(Syringe)
                                     {
                                        if(SyringeCartridge > 0) { WeaponChoice = "SYRINGE"; }
                                        else { OUT = "\n\tCan't use the syringe. No cartridges!\n"; }
                                     }
                                     else { OUT = "\n\tYou do not have the Syringe.\n"; }
                                     break;
                          case 'a' : MutantWars.Player.ChooseAbilities();
                                     if(MutantWars.Player.GetMutantPower() > MutantWars.Player.GetAbilityCost())
                                     { WeaponChoice = "ABILITY"; }


                                     break;
                          default : OUT = "\n\tThat was an invalid choice...\n"; break;
                    }
                    System.out.print(OUT);

              }

       }

       public void Attack(LifeForm opponent)
       {
              String WPN = "";
              String OUT = "";
              int damage = 0;
              damage = Functions.GRN(15);
              //WeaponChoice = "UNDECIDED"; //reset weapon choice

              if(CHAR_CLASS.equals("Impath"))
              {
                  if(WeaponChoice.equals("UNDECIDED"))
                  { ChooseWeapon(); }

                  if(WeaponChoice.equals("HAND"))
                  {
                       WPN = "\n\t" + NAME + " lets fly with fists of fury!";
                  }

                  if(WeaponChoice.equals("MACHETE"))
                  {
                       damage = damage + 4;
                       WPN = "\n\t" + NAME + " swings the machete!";
                  }
                  if(WeaponChoice.equals("GUN"))
                  {
                       if(Ammo9mm > 0)
                       {
                            damage = damage + 8;
                            Ammo9mm--;
                            WPN = "\n\t" + NAME + " fires the 9mm pistol!  "
                                + "Ammo: " + Ammo9mm;
                       }
                       else
                       {
                            System.out.print("\n\tSorry, out of 9mm ammunition!\n");
                            WeaponChoice = "UNDECIDED";
                       }
                  }
                  if(WeaponChoice.equals("SYRINGE"))
                  {
                       if(SyringeCartridge > 0)
                       {
                            damage = damage + 20; SyringeCartridge--;
                            WPN = "\n\t" + NAME + " injects with the syringe!"
                                + "  Cartridges: " + SyringeCartridge;
                       }
                       else
                       {
                            System.out.print("\n\tSorry, out of syringe cartridges!\n");
                            WeaponChoice = "UNDECIDED";
                       }
                  }

                  if(WeaponChoice.equals("ABILITY"))
                  {
                       damage = damage + MutantWars.Player.GetAbilityCost();
                       MutantWars.Player.SetMutantPower(
                       MutantWars.Player.GetMutantPower() - MutantWars.Player.GetAbilityCost());
                       WPN = "\n\t" + NAME + " uses the mutant ability "
                             + MutantWars.Player.GetAbilityChoice() + "!\n"
                             + "\tRemaining Mutant Power: " + MutantWars.Player.GetMutantPower();
                  }

              }

              OUT = "\n\t---------- Attack for " + NAME + " ----------"
                     + "\n\t" + opponent.GetName() + " hitpoints before attack: "
                     + opponent.GetHit() + "\t";

              if(CHAR_CLASS.equals("Impath")) { OUT = OUT + WPN; }

              System.out.print(OUT);

              if(damage > opponent.GetDef())
              { damage = damage - opponent.GetDef(); }
              else { damage = 0; }

              if(opponent.GetHit() - damage > 0)
              { opponent.SetHit(opponent.GetHit() - damage); }
              else { opponent.SetHit(0); }

              OUT = "\n\t" + opponent.GetName() + " hitpoints after attack: "
                     + opponent.GetHit() + "\n"
                     + "\t----------------------------------------\n\n";

              System.out.print(OUT);
       }


       //Public Accessor Methods
       public int GetHit() { return hitpoints; } 
       public void SetHit(int x) { hitpoints = x; }
       public int GetAtack() { return atack; }
       public void SetAtack(int x) { atack = x; }
       public int GetDef() { return defense; }
       public void SetDef(int x) { defense = x; }
       public int GetScore() { return score; }
       public void SetScore(int x) { score = x; }
       public void SetName(String n) { NAME = n; }
       public String GetName() { return NAME; }
       public void SetCharClass(String CHR) { CHAR_CLASS = CHR; } 
       public String GetCharClass() { return CHAR_CLASS; }                   

       //Inventory Accesors
       public void SetGun(boolean x) { Gun  = x; }
       public boolean GetGun() { return Gun ; } 
       public void Set9mmAmmo(int x) { Ammo9mm = x; }
       public int Get9mmAmmo() { return Ammo9mm; } 
       public void SetMachete(boolean x) { Machete = x; }
       public boolean GetMachete() { return Machete; } 
       public void SetSyringe(boolean x) { Syringe = x; }
       public boolean GetSyringe() { return Syringe; } 
       public void SetSyringeCart(int x) { SyringeCartridge = x; }
       public int GetSyringeCart() { return SyringeCartridge; }
       public void SetJacket(boolean x) { Jacket  = x; }
       public boolean GetJacket() { return Jacket ; }
       public void SetMedKit(int x) { MedKit = x; }
       public int GetMedKit() { return MedKit; } 
       public void SetMRErations(int x) { MRErations = x; }
       public int GetMRErations() { return MRErations; } 
       public void SetFramePack(boolean x) { FramePack  = x; }
       public boolean GetFramePack() { return FramePack ; }
       public void SetDataCrystal(boolean x) { datacrystal = x; }
       public boolean GetDataCrystal() { return datacrystal; }
       public void SetMatches(boolean x) { Matches = x; }
       public boolean GetMatches() { return Matches; }
       public void SetSterno(boolean x) { Sterno  = x; }
       public boolean GetSterno () { return Sterno ; }
       public void SetKeyCard(boolean x) { KeyCard = x; }
       public boolean GetKeyCard() { return KeyCard ; }
       public void SetKey(boolean x) { Key  = x; }
       public boolean GetKey() { return Key  ; }
       public void SetHumanGirl(boolean x) { FoundL1_HumanGirl = x; }
       public boolean GetHumanGirl() { return FoundL1_HumanGirl; }
       public String GetWeaponChoice() { return WeaponChoice; }
       public void SetWeaponChoice(String x) { WeaponChoice = x; }
       public void SetInventoryItem(String x) { InventoryItem = x; }
       public String GetInventoryItem() { return InventoryItem; }

       //Private Data
       private int hitpoints = 100;
       private int atack = 1;
       private int defense = 1;
       private int score = 0;
       private String NAME = "";
       private String CHAR_CLASS = "LIFEFORM";

       //Inventory Items
       private boolean Gun = false;
       private int Ammo9mm = 0;
       private boolean Syringe = false;
       private int SyringeCartridge = 0;
       private boolean Machete = false;
       private boolean Jacket = false;
       private boolean WearingJacket = false;
       private int MedKit = 0; 
       private int MRErations = 0;
       private boolean FramePack = false;
       private boolean datacrystal = false;
       private boolean Matches = false;
       private boolean Sterno = false;
       private boolean KeyCard = false;
       private boolean Key = false;
       private String WeaponChoice = "UNDECIDED";
       private boolean FoundL1_HumanGirl = false;
       private String InventoryItem = "Nothing";
}

