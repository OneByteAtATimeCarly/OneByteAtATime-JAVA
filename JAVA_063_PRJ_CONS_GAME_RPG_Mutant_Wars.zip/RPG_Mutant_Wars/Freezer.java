//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 45 lines of code

import javax.swing.*;
import java.io.*;

public class Freezer extends Mutant
{
       public Freezer() 
       {  
              String OUT = "\n\tCreating a Freezer Mutant.";
              System.out.println(OUT);
              SetCharClass("Freezer");
       }

       public Freezer(String x)
       { 
              String OUT = "\n\tCreating a Freezer Mutant.";
              System.out.println(OUT);
              SetName(x);
              SetCharClass("Freezer");
       }       

       public Freezer(String x, int hit)
       { 
              String OUT = "\n\tCreating a Freezer Mutant.";
              System.out.println(OUT);
              SetName(x);
              SetHit(hit);
              SetCharClass("Freezer");
       }

       //Functions
       public void Freeze() 
       { 
              String OUT = "\n\tFreezing...";
              System.out.println(OUT); 
       }

       //Public Accesors
       

       //Private Data
}
