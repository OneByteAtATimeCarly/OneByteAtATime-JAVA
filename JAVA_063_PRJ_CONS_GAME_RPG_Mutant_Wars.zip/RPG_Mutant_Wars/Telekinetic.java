//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class Telekinetic extends Mutant
{
       public Telekinetic() 
       {  
              String OUT = "\n\tCreating an Telekinetic mutant.";
              System.out.print(OUT);
       }

       public Telekinetic(String x)
       { 
              String OUT = "\n\tCreating an Telekinetic mutant.";
              System.out.print(OUT);
              SetName(x);
       } 

       //Functions
       public void MindMove() 
       { 
              String OUT = "\n\tMoving object telekinetically...";
              System.out.print(OUT); 
       }

       //Public Accesors
       

       //Private Data
}
