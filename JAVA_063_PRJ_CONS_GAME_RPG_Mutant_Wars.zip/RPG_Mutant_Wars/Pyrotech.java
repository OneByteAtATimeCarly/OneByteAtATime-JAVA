//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class Pyrotech extends Mutant
{
       public Pyrotech() 
       {  
              String OUT = "\n\tCreating an Pyrotech mutant.";
              System.out.print(OUT);
       }

       public Pyrotech(String x)
       { 
              String OUT = "\n\tCreating an Pyrotech mutant.";
              System.out.print(OUT);
              SetName(x);
       } 

       //Functions
       public void Fire() 
       { 
              String OUT = "\n\tIgniting objects with ability...";
              System.out.print(OUT);
       }

       //Public Accesors
       

       //Private Data
}
