//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Game Functions

//Modular functions class used throughout the game.

//668 lines of code

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Functions
{
       String OUT = "";

       static LineNumberReader cin = new LineNumberReader(new InputStreamReader(System.in));
       static Random RAND = new Random();   
 
//-------------------------------------------------------------------------------

       public Functions() 
       { OUT = "\n\tCreating a Function class object."; System.out.print(OUT);}

//-------------------------------------------------------------------------------

       //No method to convert String to boolean in Java as in C++, so let's make our own!     
       public static boolean TrueOrFalse(String x)
       {
              if(x.equals("true"))  { return true; }
              else { return false; }
       }
       
//------------------------------------------------------------------------------------

       //No method for "PAUSE" in Java as in C++, so let's make our own!
       public static void PAUSE()
       {
              //Since Java doesn't have a PAUSE command lie C++, let's make our own!
              String CONTINUE = "";
              String OUT = "";

              while(CONTINUE == "")
              {
                   OUT = "\n\n\tPaused. Press ENTER to continue.\t";
                   System.out.print(OUT);
                   ClearScreen(1);
                   try { CONTINUE = cin.readLine(); }
                   catch (IOException e) { OUT = "Error."; }
              }
       }
//--------------------------------------------------------------------------------

       //No concise CIN method in Java for "char" as in C++, so let's make our own!
       //Can't overload since not taking different arguments, we'll just name them different.
       //Make them static so other classes can use them. One for char, String and int.

       public static char INPUTchar()
       {
              String choice = "";
              String OUT = "";
              char WhatToDo = '#';

              try { choice = cin.readLine(); }               
              catch (IOException e) { OUT = "Error."; System.out.print(OUT); }
              choice.toLowerCase();
              if(choice.equals("")) { WhatToDo = '#'; }
              else { WhatToDo = choice.charAt(0); }
              return WhatToDo;
       }

//------------------------------------------------------------------------------

       public static String INPUTstring() 
       {
              String choice = "";
              String OUT = "";

              try { choice = cin.readLine(); }               
              catch (IOException e) { OUT = "Error."; System.out.print(OUT); }
              return choice;
       }

//------------------------------------------------------------------------------

       public static int INPUTint() 
       {
              String choice = "";
              String OUT = "";
              int z = 0;

              try { choice = cin.readLine(); }               
              catch (IOException e) { OUT = "Error."; System.out.print(OUT); }
              try { z = Integer.parseInt(choice); }
              catch(NumberFormatException e) 
              {
                System.out.print("\tThat was not a number! Defaulting to 0.\n");
                z = 0;
              }
              return z;
       }

//------------------------------------------------------------------------------

       //No method for "CLS" in Java as in C++,
       //so let's make our own to approximate it with "\n"
       public static void ClearScreen(int x)   
       { 
             String OUT = "\n";

             for(int z = 0; z < x; z++)
             {
                 System.out.print(OUT);
             }
       }       
     
//-----------------------------------------------------------------------------   
    
       //Uses new Random object declared up top in Globals
       public static int GRN(int x)  { return RAND.nextInt(x) + 1; }
                
//-----------------------------------------------------------------------------

    public static void Options()
    {
           String choice = ""; 
           char WhatToDo = '#'; 
           boolean successful = false; 
           ClearScreen(8); 

           while(WhatToDo != 's' && WhatToDo != 'l' && WhatToDo != 'h' && WhatToDo != 'r' && WhatToDo != 'q')
           {  
               String OUT = "\n\n\t\t\t********* OPTIONS *********\n"
                     + "\t\t\t*                         *\n"
                     + "\t\t\t*      (s)ave game        *\n"
                     + "\t\t\t*      (l)oad game        *\n"
                     + "\t\t\t*      (h)igh scores      *\n"
                     + "\t\t\t*      (q)uit             *\n"
                     + "\t\t\t*      (r)eturn to game   *\n"
                     + "\t\t\t*                         *\n"
                     + "\t\t\t***************************\n\n\n\n\n\n\n\n\t\t\t";
          
               System.out.print(OUT);

               WhatToDo = INPUTchar(); 

               switch(WhatToDo)
               {
  
                  case 'l' : successful = LoadCharacter(MutantWars.Player);
                             if(successful) 
                             { OUT = "\n\tCharacter successfully loaded.\n"; }
                             else { OUT = "\n\tSomething went wrong!\n"; } 
                             break;
                  case 's' : successful = SaveCharacter(MutantWars.Player);
                             if(successful) 
                             { OUT = "\n\tCharacter successfully saved.\n"; }
                             else { OUT = "\n\tSomething went wrong!\n"; } 
                             break;
                  case 'h' : OUT = "\tDisplay high scores here..."; 
                             break;
                  case 'r' : break;
                  case '~' : MutantWars.Player.Cheat(); 
                             MutantWars.Player.AbilityCheat();
                             break;
                  case '/' : MutantWars.Player.InitializeInventory(); 
                             MutantWars.Player.InitializeAbilities(); 
                             break;
                  case 'q' : MutantWars.CONTINUE = false; break;
                  default : OUT = "\n\tInvalid choice!\n"; break;
               } //close switch

               System.out.print(OUT);

        } //close while loop
  
    }//close Options function

//-----------------------------------------------------------------------------

       public static void Combat(LifeForm player, LifeForm opponent)
       { 
              String OUT = "\n\tLifeform attacks LifeForm!\n";
              System.out.print(OUT);

              //Randomize who attacks first
              int FirstAttack = GRN(2);

              if(FirstAttack == 1)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                       player.Attack(opponent);
                       opponent.Attack(player);
                  }
              }

              if(FirstAttack == 2)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                       opponent.Attack(player);
                       player.Attack(opponent);
                  }
              }
        
              if(player.GetHit() > 0)
              { OUT = OUT + "\n\tThe player wins this match!\n"; }
              else { OUT = OUT + "\n\tSorry, you were killed.\n"; }

              System.out.print(OUT);
       }

//-----------------------------------------------------------------------------


// Examples for Combat Function Overloading
//-----------------------------------------------------------------------------

         public static void Combat(Mutant player, Human opponent)
         {
              String OUT = "\n\tMutant attacks Human!\n";
              System.out.print(OUT);

              //Randomize who attacks first
              int FirstAttack = GRN(2);

              if(FirstAttack == 1)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                       player.Attack(opponent);
                       opponent.Attack(player);
                  }
              }

              if(FirstAttack == 2)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                       opponent.Attack(player);
                       player.Attack(opponent);
                  }
              }
        
              if(player.GetHit() > 0)
              { OUT = OUT + "\n\tThe player wins this match!\n"; }
              else { OUT = OUT + "\n\tSorry, you were killed.\n"; }

              System.out.print(OUT);         
         }

//-----------------------------------------------------------------------------

         public static void Combat(Mutant player, Mutant opponent)
         {
               String OUT = "\n\tMutant attacks Mutant!\n";
               System.out.print(OUT);

              //Randomize who attacks first
              int FirstAttack = GRN(2);

              if(FirstAttack == 1)
              {
                  System.out.print("\n\tPlayer lucks out and attacks mutant first!\n");

                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  {
                       if(player.GetHit() > 0) { player.Attack(opponent); }
                       if(opponent.GetHit() > 0) { opponent.Attack(player); }
                       try { Thread.sleep(4000); }
                       catch(Exception e) {  }
                  }
              }

              if(FirstAttack == 2)
              {
                  System.out.print("\n\tMutant lucks out and attacks player first!\n");

                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  {
                       if(opponent.GetHit() > 0) { opponent.Attack(player); }
                       if(player.GetHit() > 0) { player.Attack(opponent); }
                       try { Thread.sleep(4000); }
                       catch(Exception e) {  } 
                  }
              }

              //Force new weapon choice for next combat session
              player.SetWeaponChoice("UNDECIDED");

              if(player.GetHit() > 0)
              { OUT = "\n\tThe player wins this match!\n"; }
              else { OUT = "\n\tSorry, you were killed.\n\tGame Over.\n"; }

              System.out.print(OUT);   
         }

//-----------------------------------------------------------------------------

       // Function - SaveHighScores
       public static boolean SaveHighScores(LifeForm player) 
       {
            boolean successful = false;
            String OUT = "";            

            try 
            {
                File scores = new File("highscores.txt");
                FileOutputStream highscores;
                
                if (scores.exists())
		{
                    //If "true", don't destroy previous, append 2 arguments
		    OUT = 
                    "\thighscores.txt already exists - appending new score to it.";
		    highscores = new FileOutputStream(scores, true); 
		}
		else
		{
                    //Create new, no append, just 1 argument
		    OUT = 
                    "\thighscores.txt does not exist -- I'll create it!";
		    highscores = new FileOutputStream(scores); 
		}                

                PrintStream hiscores = new PrintStream(highscores);
                hiscores.println(player.GetName());
                hiscores.println(player.GetScore());  
                hiscores.close(); highscores.close();
                successful = true;  
            }
            catch (IOException e) 
            { 
                OUT = "ERROR saving scores.";
                successful = false; 
            }

            System.out.print(OUT);     

            return successful;
       }  //close SaveHighScores() function

//-------------------------------------------------------------------------
    
       // Function - DisplayHighScores
       public static boolean DisplayHighScores() 
       {
               ClearScreen(8); 
               String OUT = ""; 
               boolean successful = false; 
          
               String HoldMeStringName = ""; 
               String HoldMeStringInteger = "";
               int HoldMeInteger = 0;
               int z = 0; 
               int x = 0;

               try 
               {        
                   File scores = new File("highscores.txt");
                   FileInputStream highscores = new FileInputStream(scores);
                   InputStreamReader hiscores = new InputStreamReader(highscores);
                   BufferedReader SCORES = new BufferedReader(hiscores);

                   while(HoldMeStringName != null)
                   {
                       HoldMeStringName = SCORES.readLine();
                       HoldMeStringInteger = SCORES.readLine();
                       x++;  //add one for every 2 lines (name and score pair) 
                   }
                     
                   x = x - 1; //Subtract 1 for the offset (one too many)
                     
                   String[] NAMES = new String[x];
                   int[] TheSCORES = new int[x];
                     
                   //Reset all the stream and file objects, move pointer back to beginning 
                   scores = new File("highscores.txt");
                   highscores = new FileInputStream(scores);
                   hiscores = new InputStreamReader(highscores);
                   SCORES = new BufferedReader(hiscores);
                     
                   //Put each line into 
                   for(z = 0; z < x; z++)
                   {
                       NAMES[z] = SCORES.readLine();
                       HoldMeStringInteger = SCORES.readLine();
                       TheSCORES[z] = Integer.parseInt(HoldMeStringInteger);

                   }
                     
                     highscores.close();
                     
                     OUT = "\t\tTotal of " + x + " score records present in file.\n";
                     System.out.print(OUT);
        
                     for(int q = 0; q < x; q++)
                     {
                         for(int r = 1; r < x; r++)
                         {
                             if(TheSCORES[r] > TheSCORES[r - 1])
                             {
                                HoldMeInteger = TheSCORES[r];
                                HoldMeStringName = NAMES[r];
                                TheSCORES[r] = TheSCORES[r - 1]; 
                                NAMES[r] = NAMES[r - 1];
                                TheSCORES[r - 1] = HoldMeInteger; 
                                NAMES[r - 1] = HoldMeStringName;           
                             }
                         }
                     } 
        
                     OUT = 
                     "\t\t***************** High Scores *****************\n\n";
                     OUT = OUT + 
                     "\t\t-----------------------------------------------\n"; 

	             for(z = 0; z < x; z++)
                     {
                        OUT = OUT + "\t\t" + (z+1) + ". Name: " + NAMES[z] + 
                                         "  Score: " + TheSCORES[z] + "\n";
                        OUT = OUT +
                     "\t\t-----------------------------------------------\n";    
                     }

	             OUT = OUT +
                     "\n\t\t***********************************************\n";

                     System.out.print(OUT + "\n\n\t\t\t");                      
 
                     PAUSE();
                     successful = true;
               }
               
               catch(IOException e)
               {
                   OUT = 
                   "\tUnable to find \"highscores.txt\" or read scores.\n";
                   System.out.print(OUT);
                   successful = false;
               }
         
               //Declared 2 Parallel Arrays where # elements = # lines.
               //Above is a Bubble Sort for High Scores. Go through each Name
               //and Score set and swap to arrange in descending order
               return successful;
        
       }//close DisplayHighScores() Function



//-------------------------------------------------------------------------
       
       public static boolean SaveCharacter(Mutant player) 
       {                     

               boolean successful = false;

               String CharacterName = "";
               String passwd = "";
               String OUT = "";

               OUT = "\n\tEnter the file name to save as: ";
               System.out.print(OUT);

               try { CharacterName = cin.readLine(); }               
               catch (IOException e) { OUT = "Error."; System.out.print(OUT); }
               
               CharacterName = CharacterName + ".gam";
   
               OUT = "\n\tEnter a password:   ";
               System.out.print(OUT);

               passwd = INPUTstring();

               try
               {
                   MutantWars.PlayerFile = new File(CharacterName);
                   MutantWars.PlayerOut = new FileOutputStream(MutantWars.PlayerFile);
                   MutantWars.WritePlayer = new PrintStream(MutantWars.PlayerOut);
                   
                   //Simple Serialization of Character class in plain ASCII 

                   //Save Character Attributes
                   MutantWars.WritePlayer.println(passwd);
                   MutantWars.WritePlayer.println(player.GetName());
                   MutantWars.WritePlayer.println(player.GetHit());
                   MutantWars.WritePlayer.println(player.GetAtack());
                   MutantWars.WritePlayer.println(player.GetDef());
                   MutantWars.WritePlayer.println(player.GetScore());
                   MutantWars.WritePlayer.println(player.GetCharClass());

                   //Save Mutant Ablity Data
                   MutantWars.WritePlayer.println(player.GetFLY());
                   MutantWars.WritePlayer.println(player.GetFREEZE());
                   MutantWars.WritePlayer.println(player.GetHEAL());
                   MutantWars.WritePlayer.println(player.GetMINDREAD());
                   MutantWars.WritePlayer.println(player.GetFIRE());
                   MutantWars.WritePlayer.println(player.GetMOVE());
                   MutantWars.WritePlayer.println(player.GetTIMESHIFT());
                   MutantWars.WritePlayer.println(player.GetMutantPower());

                   //Save Character Inventory
                   MutantWars.WritePlayer.println(player.GetDataCrystal());
                   MutantWars.WritePlayer.println(player.GetMachete());
                   MutantWars.WritePlayer.println(player.GetGun());
                   MutantWars.WritePlayer.println(player.Get9mmAmmo());
                   MutantWars.WritePlayer.println(player.GetSyringe());
                   MutantWars.WritePlayer.println(player.GetSyringeCart());
                   MutantWars.WritePlayer.println(player.GetMatches());
                   MutantWars.WritePlayer.println(player.GetFramePack());
                   MutantWars.WritePlayer.println(player.GetMedKit());
                   MutantWars.WritePlayer.println(player.GetMRErations());
                   MutantWars.WritePlayer.println(player.GetJacket());
                   MutantWars.WritePlayer.println(player.GetSterno());
                   MutantWars.WritePlayer.println(player.GetKeyCard());
                   MutantWars.WritePlayer.println(player.GetKey());

                   switch(MutantWars.LEVEL)
                   {
                      case 1: MutantWars.Level1Events.SaveLevel(CharacterName); break;
                      //case 2: MutantWars.Level2Events.SaveLevel(CharacterName); break;
                      //case 3: MutantWars.Level3Events.SaveLevel(CharacterName); break;
                   }

                   MutantWars.WritePlayer.close(); MutantWars.PlayerOut.close();
                   successful = true;
            }

            catch(IOException e) 
            { 
                OUT = "ERROR saving character file.";
                successful = false; 
            }

            return successful;

       } 

//-------------------------------------------------------------------------

       public static boolean LoadCharacter(Mutant player) 
       {
               boolean successful = false;
               String OUT = ""; 
          
               //Make copies local to function
           
               System.out.print("\n\tEnter the name of the Character to load: "); 
               String CharacterName = INPUTstring();              
               
               CharacterName = CharacterName + ".gam";
   
               System.out.print("\n\tEnter the password:   ");
               String passwd = INPUTstring();
	          
               try 
               {        
                  MutantWars.PlayerFile = new File(CharacterName);
                  MutantWars.PlayerIn = new FileInputStream(MutantWars.PlayerFile);
                  MutantWars.ReadPlayer = new InputStreamReader(MutantWars.PlayerIn);
                  MutantWars.StreamPlayer = new BufferedReader(MutantWars.ReadPlayer);

                  String pass = MutantWars.StreamPlayer.readLine();

                  if(pass.equals(passwd))
                  {
                     //Careful! serialization = you must read in exactly
                     //the same order as you wrote!

                     //Character Attributes
                     String PlayerName = MutantWars.StreamPlayer.readLine();
                     String PlayerHit = MutantWars.StreamPlayer.readLine();
                     String PlayerAttack = MutantWars.StreamPlayer.readLine();
                     String PlayerDefense = MutantWars.StreamPlayer.readLine();
                     String PlayerScore = MutantWars.StreamPlayer.readLine();
                     String PlayerClass = MutantWars.StreamPlayer.readLine();

                     //Read Mutant Ablity Data
                     String fly = MutantWars.StreamPlayer.readLine();
                     String freeze = MutantWars.StreamPlayer.readLine();
                     String heal = MutantWars.StreamPlayer.readLine();
                     String mindread = MutantWars.StreamPlayer.readLine();
                     String fire = MutantWars.StreamPlayer.readLine();
                     String move = MutantWars.StreamPlayer.readLine();
                     String timeshift = MutantWars.StreamPlayer.readLine();
                     String mutantpower = MutantWars.StreamPlayer.readLine();

                     //Read Character Inventory
                     String datacrystal = MutantWars.StreamPlayer.readLine();
                     String machete = MutantWars.StreamPlayer.readLine();
                     String gun = MutantWars.StreamPlayer.readLine();
                     String ammo9mm = MutantWars.StreamPlayer.readLine();
                     String syringe = MutantWars.StreamPlayer.readLine();
                     String syringecart = MutantWars.StreamPlayer.readLine();
                     String matches = MutantWars.StreamPlayer.readLine();
                     String framepack = MutantWars.StreamPlayer.readLine();
                     String medkit = MutantWars.StreamPlayer.readLine();
                     String mrerations = MutantWars.StreamPlayer.readLine();
                     String jacket = MutantWars.StreamPlayer.readLine();
                     String sterno = MutantWars.StreamPlayer.readLine();
                     String keycard = MutantWars.StreamPlayer.readLine();
                     String key = MutantWars.StreamPlayer.readLine();
                     
                     //Set player attributes
                     player.SetName(PlayerName);
                     player.SetHit(Integer.parseInt(PlayerHit));
                     player.SetAtack(Integer.parseInt(PlayerAttack));
                     player.SetDef(Integer.parseInt(PlayerDefense));
                     player.SetScore(Integer.parseInt(PlayerScore));
                     player.SetCharClass(PlayerClass);

                     //Set player mutant abiliites
                     player.SetFLY(TrueOrFalse(fly));
                     player.SetFREEZE(TrueOrFalse(freeze));
                     player.SetHEAL(TrueOrFalse(heal));
                     player.SetMINDREAD(TrueOrFalse(mindread));
                     player.SetFIRE(TrueOrFalse(fire));
                     player.SetMOVE(TrueOrFalse(move));
                     player.SetTIMESHIFT(TrueOrFalse(timeshift));
                     player.SetMutantPower(Integer.parseInt(mutantpower)); 

                     //Set player inventory
                     player.SetDataCrystal(TrueOrFalse(datacrystal));
                     player.SetMachete(TrueOrFalse(machete));
                     player.SetGun(TrueOrFalse(gun));
                     player.Set9mmAmmo(Integer.parseInt(ammo9mm));
                     player.SetSyringe(TrueOrFalse(syringe));
                     player.SetSyringeCart(Integer.parseInt(syringecart));
                     player.SetMatches(TrueOrFalse(matches));
                     player.SetFramePack(TrueOrFalse(framepack));
                     player.SetMedKit(Integer.parseInt(medkit));
                     player.SetMRErations(Integer.parseInt(mrerations));
                     player.SetJacket(TrueOrFalse(jacket));
                     player.SetSterno(TrueOrFalse(sterno));
                     player.SetKeyCard(TrueOrFalse(keycard));
                     player.SetKey(TrueOrFalse(key));

                   switch(MutantWars.LEVEL)
                   {
                      case 1: MutantWars.Level1Events.LoadLevel(CharacterName); break;
                      //Haven't been built yet, but this is how we'd save future levels.
                      //case 2: MutantWars.Level2Events.LoadLevel(CharacterName); break;
                      //case 3: MutantWars.Level3Events.LoadLevel(CharacterName); break;
                   }

                     MutantWars.ReadPlayer.close(); MutantWars.PlayerIn.close();
                     successful = true;
               }

               else
               {
                    OUT = "\n\tThat was not the correct password!";
                    System.out.print(OUT); 
                    successful = false; 
               }
            }
            
            catch(IOException e)
            {
                OUT = "\tUnable to create character file.\n";
                System.out.print(OUT);
                successful = false;
            }

            return successful;

       }//close LoadCharacter() function 

//-------------------------------------------------------------------------

}