//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class and ADT
//Derived Class and ADT
//Class = 49 lines of code

import javax.swing.*;
import java.io.*;

public class SuperMutant extends Mutant
{    
       public SuperMutant() 
       {
              String OUT = "\n\tCreating a SuperMutant object.";
              System.out.print(OUT);
       }

       //SuperMutant Functions
       public void TakeMutantAbility() 
       { 
              String OUT = "\n\tTaking another mutant's ability...";
              System.out.print(OUT);
       }


       //Public Accesor Methods
       public void SetFIRE(boolean x) { FIRE = x; }
       public void SetICE(boolean x) { ICE = x; }
       public void SetHEAL(boolean x) { HEAL = x; }
       public void SetFLY(boolean x) { FLY = x; }
       public void SetMINDREAD(boolean x) { MINDREAD = x; }
       public void SetTIMETRAVEL(boolean x) { TIMETRAVEL = x; }
       public void SetMINDMOVE(boolean x) { MINDMOVE = x; } 

       public boolean GetFIRE() { return FIRE; }
       public boolean GetICE() { return ICE; }
       public boolean GetHEAL() { return HEAL; }
       public boolean GetFLY() { return FLY; }
       public boolean GetMINDREAD() { return MINDREAD; }
       public boolean GetTIMETRAVEL() { return TIMETRAVEL; }
       public boolean GetMINDMOVE() { return MINDMOVE; }

       //Private Data      
       private boolean FIRE;
       private boolean ICE;
       private boolean HEAL;
       private boolean FLY;
       private boolean MINDREAD;
       private boolean TIMETRAVEL;
       private boolean MINDMOVE;
}
