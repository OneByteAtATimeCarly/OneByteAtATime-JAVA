//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 32 lines of code

import javax.swing.*;
import java.io.*;

public class Seeker extends Human
{    
       public Seeker() 
       {
              String OUT = "\n\tCreating an Seeker human.";
              System.out.print(OUT);
       }


       public Seeker(String x)
       { 
              String OUT = "\n\tCreating an Seeker human.";
              System.out.print(OUT);
              SetName(x);
       } 

       //Human Functions


       //Public Accesor Methods


       //Private Data     

}
