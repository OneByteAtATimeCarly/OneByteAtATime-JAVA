//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class and ADT
//Derived Class and ADT
//Class = 296 lines of code

import javax.swing.*;
import java.io.*;

public class Mutant extends LifeForm
{    
       public Mutant() 
       {
              String OUT = "\n\tCreating a base class ADT Mutant.";
              System.out.print(OUT);
       }

       public void InitializeAbilities()
       {
              FLY = false;
              FREEZE = false;
              HEAL = false;
              MINDREAD = false;
              FIRE = false;
              MOVE = false;
              TIMESHIFT = false;
              
       }

       //Choose and Use Mutant Abilities

       public void AbilityCheat()
       {
              FLY = true;
              FREEZE = true;
              HEAL = true;
              MINDREAD = true;
              FIRE = true;
              MOVE = true;
              TIMESHIFT = true;
              MutantPower = 1000;

       }

       public void Abilities()
       {
              char choice = '#';

              while(choice != 'q')
              {
                  String OUT = "\n\t--------------------Mutant Abilities--------------------\n\n";
                         OUT = OUT + "\t\tMutant Energy = " + MutantPower + "\n";
                         OUT = OUT + "\t\tCurrently Selected Ability = " + AbilityChoice + "\n";
                         OUT = OUT + "\t\tSelected Ability Cost = " + AbilityCost + "\n\n";
                         OUT = OUT + "\t\t(L)ist abilities\n";
                         OUT = OUT + "\t\t(C)hoose Ability\n";
                         OUT = OUT + "\t\t(U)se Ability\n";
                         OUT = OUT + "\t\t(Q)uit\n";

                  System.out.print(OUT);
                  choice = Functions.INPUTchar();

                  switch(choice)
                  {
                     case 'l' : ListAbilities(); break;
                     case 'c' : ChooseAbilities(); break;
                     case 'u' : UseMutantAbility(); break;
                     case 'q' : break;
                  }
              }

       }

       public void ListAbilities()
       {
              int count = 0;
              String INV = "";

              INV = ("\n\n\t------------------- Current Mutant Abilities -------------------\n\n");
              if(FLY) { INV = INV + "\t" + ++count + " = Fly (Levitation)\n"; }
              if(FREEZE)  { INV = INV + "\t" + ++count + " = Freeze (Lowers Ambient Temperature)\n"; }
              if(HEAL) { INV = INV + "\t" + ++count + " = Heal (Regeneration)\n"; }
              if(MINDREAD) { INV = INV + "\t" + ++count + " = MindRead (Telepathy)\n"; }
              if(FIRE)  { INV = INV + "\t" + ++count + " = Fire (Pyrokenisis)\n"; }
              if(MOVE)  { INV = INV + "\t" + ++count + " = Move (Telekenisis)\n"; }
              if(TIMESHIFT) { INV = INV + "\t" + ++count + " = Time Shift (Time Manipulation)\n"; }

              if(!FLY && !FREEZE && !HEAL && !MINDREAD && !FIRE && !MOVE && !TIMESHIFT)
              {
                  INV = INV + "\tYou are a fledgeling Impath. You have no mutant abilities yet.";
              }
              INV = INV + "\n\t--------------------------------------------------------\n\n";

              System.out.print(INV);
       }


       public void ChooseAbilities()
       {      
              String OUT = "";
              int choice = 1;
              AbilityChoice = "ZIP";
              while(choice != 0 && AbilityChoice.equals("ZIP"))
              {
                  if(!FLY && !FREEZE && !HEAL && !MINDREAD && !FIRE && !MOVE && !TIMESHIFT)
                  {
                     OUT = "\tYou have no mutant abilities to choose from...\n";
                     System.out.print(OUT);
                     break;
                  }

                  ListAbilities();

                  OUT = "\n\tWhich mutant ability do you wish to employ?\n\n"
                      + "\t\t0 = Exit         5 = Fire\n"
                      + "\t\t1 = Fly          6 = Move\n"
                      + "\t\t2 = Freeze       7 = TimeShift\n"
                      + "\t\t3 = Heal         8 = None\n"
                      + "\t\t4 = MindRead\n\n\t\t";

                  System.out.print(OUT);

                  choice = Functions.INPUTint();

                  switch(choice)
                  {
                      case 0 : break;
                      case 1 : if(FLY) { AbilityChoice = "FLY"; AbilityCost = 6; }
                               else { OUT = "\n\tYou don't have the mutant ability to FLY!\n"; }
                               break;
                      case 2 : if(FREEZE) { AbilityChoice = "FREEZE"; AbilityCost = 10; }
                               else
                               { OUT = "\n\tYou don't have the mutant ability to FREEZE!\n"; }
                               break;
                      case 3 : if(HEAL) { AbilityChoice = "HEAL"; AbilityCost = 3; }
                               else { OUT = "\n\tYou don't have the mutant ability to HEAL!\n"; }
                               break;
                      case 4 : if(MINDREAD) { AbilityChoice = "MINDREAD"; AbilityCost = 2; }
                               else { OUT = "\n\tYou don't have the mutant ability to MINDREAD!\n"; }
                               break;
                      case 5 : if(FIRE) { AbilityChoice = "FIRE"; AbilityCost = 12; }
                               else
                               { OUT = "\n\tYou don't have the mutant ability to cause FIRE!\n"; }
                               break;
                      case 6 : if(MOVE) { AbilityChoice = "MOVE"; AbilityCost = 15; }
                               else { OUT = "\n\tYou don't have the mutant ability to MOVE objects telekinetically!\n"; }
                               break;
                      case 7 : if(TIMESHIFT) { AbilityChoice = "TIMESHIFT"; AbilityCost = 20; }
                               else { OUT = "\n\tYou don't have the mutant ability to SHIFT TIME!\n"; }
                               break;
                      case 8 : System.out.print("\tCanceling...\n");
                               AbilityChoice = "NONE"; break;
                      default : OUT = "\n\tThat was an invalid choice...\n"; break;
                 }

                 System.out.print(OUT);
             }

       }

       public void UseMutantAbility()
       {
              if(!FLY && !FREEZE && !HEAL && !MINDREAD && !FIRE && !MOVE && !TIMESHIFT)
                  {
                    String OUT = "\tYou have no mutant abilities to choose from...\n"
                        + "\tYou can't use what you don't have!\n";
                    System.out.print(OUT);
                    return;
                  }

              String INV = "";

              if(AbilityChoice.equals("FLY"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost;
                    INV = "\tFlying...\n"; CanUseAbility = true;
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              if(AbilityChoice.equals("FREEZE"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost; CanUseAbility = true;
                    INV = "\tFreezing...\n";
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              if(AbilityChoice.equals("HEAL"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost;
                    SetHit(GetHit() + 10);

                    INV = "\tHealing...\n\tAdding 10 hp to player's health.\n";
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              if(AbilityChoice.equals("MINDREAD"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost; CanUseAbility = true;
                    INV = "\tMind Reading...\n";
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              if(AbilityChoice.equals("FIRE"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost; CanUseAbility = true;
                    INV = "\tBurning...\n";
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              if(AbilityChoice.equals("MOVE"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost; CanUseAbility = true;
                    INV = "\tMind Moving...\n";
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              if(AbilityChoice.equals("TIMESHIFT"))
              {
                 if(MutantPower - AbilityCost >= 0)
                 {
                    MutantPower = MutantPower - AbilityCost; CanUseAbility = true;
                    INV = "\tShifting Time...\n";
                 }
                 else { INV = "\tYou do not have enough power to use this ability.\n"; }
              }

              System.out.print(INV);

       }

       //Mutant Functions
       public void fly() { String OUT = "\tFlying...\n"; System.out.print(OUT); }
       public void freeze() { String OUT = "\tFreezing...\n"; System.out.print(OUT); }
       public void heal() { String OUT = "\tHealing...\n"; System.out.print(OUT); }
       public void mindread() { String OUT = "\tTelepathing...\n"; System.out.print(OUT); }
       public void fire() { String OUT = "\tBurning...\n"; System.out.print(OUT); }
       public void move() { String OUT = "\tMind Moving...\n"; System.out.print(OUT); }
       public void timeshift() { String OUT = "\tTime Shifting...\n"; System.out.print(OUT); }

       //Mutant Data Accesors
       public String GetAbilityChoice() { return AbilityChoice; }
       public void SetAbilityChoice(String x) { AbilityChoice = x; }
       public int GetAbilityCost() { return AbilityCost; }
       public void SetAbliityCost(int x) { AbilityCost = x; }
       public int GetMutantPower() { return MutantPower; }
       public void SetMutantPower(int x) { MutantPower = x; }
       public void SetCanUseAbility(boolean x) { CanUseAbility = x; }
       public boolean GetCanUseAbility() { return CanUseAbility; }

       //Mutant Ability Accessors
       public boolean GetFLY() { return FLY; }
       public void SetFLY(boolean x) { FLY = x; }
       public boolean GetFREEZE() { return FREEZE; }
       public void SetFREEZE(boolean x) { FREEZE = x; }
       public boolean GetHEAL() { return HEAL; }
       public void SetHEAL(boolean x) { HEAL = x; }
       public boolean GetMINDREAD() { return MINDREAD; }
       public void SetMINDREAD(boolean x) { MINDREAD = x; }
       public boolean GetFIRE() { return FIRE; }
       public void SetFIRE(boolean x) { FIRE = x; }
       public boolean GetMOVE() { return MOVE; }
       public void SetMOVE(boolean x) { MOVE = x; }
       public boolean GetTIMESHIFT() { return TIMESHIFT; }
       public void SetTIMESHIFT(boolean x) { TIMESHIFT = x; }

       //Private Data
       private String AbilityChoice = "NONE";
       private int MutantPower = 0;
       private int AbilityCost = 0;

       //Mutant Abilities (7 Possible)
       private boolean FLY = false;
       private boolean FREEZE = false;
       private boolean HEAL = false;
       private boolean MINDREAD = false;
       private boolean FIRE = false;
       private boolean MOVE = false;
       private boolean TIMESHIFT = false;
       private boolean CanUseAbility = false;
}
