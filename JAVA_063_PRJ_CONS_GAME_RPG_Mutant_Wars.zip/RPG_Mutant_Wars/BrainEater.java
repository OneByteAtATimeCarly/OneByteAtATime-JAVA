//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class, Game Boss
//Derived Class - Level and Game Boss
//Class = 42 lines of code

import javax.swing.*;
import java.io.*;

public class BrainEater extends SuperMutant
{
       public BrainEater() 
       {  
              String OUT = "\n\tCreating a BrainEater SuperMutant!";
              System.out.print(OUT);
              SetCharClass("BrainEater");
       }

       public BrainEater(String x)
       { 
              String OUT = "\n\tCreating a BrainEater SuperMutant!";
              System.out.print(OUT);
              SetName(x);
              SetCharClass("BrainEater");
       }   

       //Functions
       public void EatBrains()  
       { 
              String OUT = "\n\tEating brains!";
              System.out.print(OUT); 
       }

       //Public Accesors
       public String GetEatenAbilities() { return EatenAbilities; }
       public int GetNumEatenAbilities() { return NumEatenAbilities; }
       public void SetEatenAbilities(String x) { EatenAbilities = x; }
       public void SetNumEatenAbilities(int x) { NumEatenAbilities = x; }        

       //Private Data
       private String EatenAbilities;
       private int NumEatenAbilities; 
}
