//Mutant Wars 1.5 for Java - Carly Salali Germany - 07/04/2007 - Derived class
//Derived Class
//Class = 35 lines of code

import javax.swing.*;
import java.io.*;

public class MindReader extends Mutant
{
       public MindReader() 
       {  
              String OUT = "\n\tCreating a MindReader mutant.";
              System.out.print(OUT);
       }


       public MindReader(String x)
       { 
              String OUT = "\n\tCreating a MindReader mutant.";
              System.out.print(OUT);
              SetName(x);
       } 

       //Functions
       public void MindRead() 
       { 
              String OUT = "\n\tReading a mind...";
              System.out.print(OUT);
       }

       //Public Accesors
       

       //Private Data
}
