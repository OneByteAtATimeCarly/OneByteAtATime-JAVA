//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 31 lines of code

import javax.swing.*;
import java.io.*;

public class Human extends LifeForm
{    
       public Human() 
       {
              String OUT = "\n\tCreating a base class ADT Human object.";
              MutantWars.MainOutput.setText(OUT);
       }

       //Human Functions
       public void Speak()
       { MutantWars.MainOutput.setText("Human speaking..."); }

       //Public Accesor Methods
       public boolean GetMachienGun() { return MachineGun; }
       public boolean GetFlameThrower() { return FlameThrower; }
       
       public void SetMachineGun(boolean x) { MachineGun = x; } 
       public void SetFlameThrower(boolean x) { FlameThrower = x; } 

       //Private Data
       private boolean MachineGun;
       private boolean FlameThrower;     

}
