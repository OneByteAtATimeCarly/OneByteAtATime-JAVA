//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Main Game class
//Main Class - Static
//Class = 107 lines of code
import java.io.*;
import javax.swing.*;
import java.awt.*;

public class Events
{
//-----------------------------------------------------------------------------------------------------

       //Pointers to Globals
       public static int LEVEL = 1;

       public static int LastNumber = 0;

       public static boolean L2WasInitialized = false;
       public static boolean L3WasInitialized = false;

       public static boolean CONTINUE = true;

       //Level 1 Items (global pointers)
       public static Level1 Level1Events; 
       public static Freezer L1_FreezerMutant;
       public static Civilian L1_HumanGirl;
       public static Telekinetic Movz;
       public static Freezer[] FreezerSquad = new Freezer[2];
       public static Pyrotech[] PyroSquad = new Pyrotech[2];

       //Level 2 Items (global pointers)
       public static Level2 Level2Events;

       //Level 3 Items (global pointers)
       public static Level3 Level3Events;

       //The Player Object
       public static Impath Player = new Impath();

       //Global pointers to File I/O Objects
       public static File PlayerFile;
       public static FileOutputStream PlayerOut;
       public static PrintStream WritePlayer;
       public static FileInputStream PlayerIn;
       public static InputStreamReader ReadPlayer;
       public static BufferedReader StreamPlayer;

       public static MutantWars GUI_INTERFACE;

//---------------------------------------------------------------------------------------------------

       //Note : We take a pointer to the applet in the constructor so
       //we can manipulate "refresh" from the other level classes.
       public Events(MutantWars x)
       {      
              GUI_INTERFACE = x;
              MutantWars.MainOutput.setText("\n  Starting Mutant Wars 1.0 Events class!");
              Initialize_L1();
       }

//-----------------------------------------------------------------------------------------------------

              //Remove loop since not Event-based
              //Need to make static so it persists, it's being called from applet
              public static void SwitchBoard()
              {
                  //Don't instantiate levels and use resources until needed!
                  if(LEVEL == 2 && L2WasInitialized == false) {  Initialize_L2(); }
                  if(LEVEL == 3 && L3WasInitialized == false) {  Initialize_L3(); }

                  switch(LEVEL)
                  {
                      case 1 : Level1Events.Switchboard(); break;
                      case 2 : Level2Events.Switchboard(); break;
                      case 3 : Level3Events.Switchboard(); break;
                  }

              }

//-----------------------------------------------------------------------------------------------------

       public static void Initialize_L1()
       {
              String OUT = "\n\t--------- Creating and Initializing Level 1 Objects ---------";
              MutantWars.MainOutput.setText(OUT);
              Level1Events = new Level1();
              L1_FreezerMutant = new Freezer("ICE",130);
              L1_HumanGirl = new Civilian("Trillian");
              Movz = new Telekinetic("Movz");
              MutantWars.LockButtons(false);
              Level1Events.Switchboard();
       }

//-----------------------------------------------------------------------------------------------------

       public static void Initialize_L2()
       {
              String OUT = "\n\t--------- Creating and Initializing Level 2 Objects ---------";
              MutantWars.MainOutput.setText(OUT);
              Level2Events = new Level2();
              L2WasInitialized = true;
              
       }

//-----------------------------------------------------------------------------------------------------

       public static void Initialize_L3()
       {
              String OUT = "\n\t--------- Creating and Initializing Level 3 Objects ---------";
              MutantWars.MainOutput.setText(OUT);
              Level3Events = new Level3();
              L3WasInitialized = true;

       }
//-----------------------------------------------------------------------------------------------------

       public static void GameOver()
       {
              //JOptionPane.showMessageDialog(null, "GAME OVER!");
              MutantWars.MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 24));
              MutantWars.MainOutput.setForeground(Color.red);
              MutantWars.MainOutput.setText("\n  Game Over!\n" +
                                        "  Exiting\n" +
                                        "  Mutant\n" +
                                        "  Wars...\n");

              Functions.SaveHighScores(Player);
              MutantWars.Started = false;
              End();
       }

//-----------------------------------------------------------------------------------------------------
     public static void End()
     {
                  switch(LEVEL)
                  {
                      case 1 : break;
                      case 2 : break; //Add level 2 stuff here
                      case 3 : break; //Add level 3 stuff here
                  }
     }
//-----------------------------------------------------------------------------------------------------
}//close Events class