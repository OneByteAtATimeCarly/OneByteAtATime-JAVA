//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class and ADT
//Derived Class and ADT
//Class = 49 lines of code

import javax.swing.*;
import java.io.*;

public class SuperMutant extends Mutant
{    
       public SuperMutant() 
       {
              String OUT = "\n\tCreating a SuperMutant object.";
              MutantWars.MainOutput.setText(OUT);
       }

       //SuperMutant Functions
       public void TakeMutantAbility() 
       { 
              String OUT = "\n\tTaking another mutant's ability...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesor Methods

}
