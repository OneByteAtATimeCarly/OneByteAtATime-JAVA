//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 60 lines of code

import javax.swing.*;
import java.io.*;

public class Civilian extends Human
{    
       //Overloaded Constructors

       public Civilian() 
       {
              String OUT = "\n\tCreating a Civilian Human.";
              MutantWars.MainOutput.setText(OUT);
       }

       public Civilian(String x) 
       {
              String OUT = "\n\tCreating a Civilian Human.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
       }       

       //Human Functions
       public String Talk()
       {
              int x = 1;

              while(Events.LastNumber == x)
              {    x = Functions.GRN(10); }

              Events.LastNumber = x;
 
              String SAYIT = "  Turning towards you, " + GetName() + " says:\n"
                           + "        \"";

              switch(x)
              {
                   case 1 : SAYIT = SAYIT + "It was horrible..."; break;
                   case 2 : SAYIT = SAYIT + "Where's my mommy..."; break;
                   case 3 : SAYIT = SAYIT + "It's a bad dream..."; break;
                   case 4 : SAYIT = SAYIT + "Where's mommy?"; break;
                   case 5 : SAYIT = SAYIT + "I... I... (sobbing...)"; break;
                   case 6 : SAYIT = SAYIT + "Is the mean man gone?"; break;
                   case 7 : SAYIT = SAYIT + "The code. The man said the code..."; break;
                   case 8 : SAYIT = SAYIT + "Will we die here?"; break;
                   case 9 : SAYIT = SAYIT + "The man in the white coat said the code\n"
                                          + "         was 7,3. Maybe ut wsa 3, 7...";
                            break;
                   case 10 : SAYIT = SAYIT + "Go away! You're with the bad man..."; break;
                   default : SAYIT = SAYIT + "Never happen..."; break;
              }

              return SAYIT + "\"\n";
       }

       //Public Accesor Methods


       //Private Data     

}
