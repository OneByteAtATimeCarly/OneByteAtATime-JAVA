//Settings
timegap=500
followspeed=0
followrate=0
suboffset_top=5;
suboffset_left=0;

effect = "fade(duration=0.3);Shadow(color='#000000', Direction=135, Strength=5)"

function openwin(url)
{
	nwin=window.open(url, "nwin",config="scrollbars=yes,resizable=yes,toolbar=yes,location=yes,status=yes,menubar=yes,");
	nwin.focus();
}

prop1=[						// prop1 is an array of properties you can have as many property arrays as you need
"ffffff",					// Off Font Color
"000000",					// Off Back Color
"ff0000",					// On Font Color
"000000",					// On Back Color
"48488f",					// Border Color
12,						// Font Size
"normal",					// Font Style 
"normal",					// Font Weight
"Tahoma",	                                // Font
5,						// Padding
"arrow.gif",				        // Sub Menu Image
0,						// 3D Border & Separator
"c3accf",					// 3D High Color
"6c6cd3",					// 3D Low Color
"32cd32",					// Referer item Font Color (leave this blank to disable)
"000000",					// Referer item Back Color (leave this blank to disable)
]







menu1=[				        // This is the array that contains your menu properties and details
0,					// Top
250,					// left
,					// Width
1,					// Border Width
"left",			                // Screen Position - here you can use "center;middle;right"
prop1,				        // Properties Array Name - this array is set higher up, as above
1,					// Always Visible - allows the menu item to be visible at all time
"center",			        // Alignment - sets the menu elements alignment, HTML values are valid here for example: left, right or center
,					// Filter - Text variable for setting transitional effects on menu activation
1,					// Follow Scrolling - Tells the menu item to follow the user down the screen
1, 					// Horizontal Menu - Tells the menu to be horizontal instead of top to bottom style
,					// Keep Alive - Keeps the menu visible until the user moves over another menu or clicks elsewhere on the page
,					// Position of sub image left:center:right:middle:top:bottom
1,					// Show an image on top menu bars indicating a sub menu exists below
,					// Reserved for future use


// "Description Text", "URL", "Alternate URL", "Status", "Separator Bar"



//---------Top level menu categories------------------------------------------------------------

"Main","show-menu2",,"#",0,
"C++","show-menu3",,"#",0,
"C","show-menu65",,"#",0,
"Visual Basic","show-menu16",,"#",0,
"Java","show-menu22",,"#",0,
"DHTML","show-menu29",,"#",0,
"Scripting","show-menu37",,"#",0,
"C#","show-menu45",,"#",0,
"Flash","show-menu48",,"#",0,
"Networking","show-menu51",,"#",0,
"Interactive","show-menu59",,"#",0,
"Links","show-menu60",,"#",0,
"Search","show-menu61",,"#",0
]







//---------MAIN Submenu------------------------------------------------------------------------
menu2=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"Home","index.html",,,0,
"Site Search","search.html",,,0,
"Contact","contact.html",,,0,
"About","about.html",,,0,
"Normalization","normalization.html",,,0,
"Home Videos","homevideos.html",,,0,
"Resume","resume.html",,,0,
"RainOfGod","http://www.rainofgod.com",,,0
]










//---------C++ Submenu-------------------------------------------------------------------------
menu3=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"MFC Projects","show-menu15",,,0,
"MFC Objects","show-menu13",,,0,
"MFC Section 1","show-menu12",,,0,
"Console Proj 1","show-menu14",,,0,
"Console Proj 2","show-menu67",,,0,
"Windows API","show-menu68",,,0,
"DirectX 3D","show-menu69",,,0,
"C++ Section 1","show-menu4",,,0,
"C++ Section 2 ","show-menu5",,,0,
"C++ Section 3","show-menu6",,,0,
"C++ Section 4","show-menu7",,,0,
"C++ Section 5","show-menu8",,,0,
"C++ Section 6","show-menu9",,,0,
"C++ Section 7","show-menu10",,,0,
"C++ Section 8","show-menu11",,,0,
"C++ Section 9","show-menu62",,,0,
"Contents","cppcontents.html",,,0
]

//---------C++ Submenu Submenus---------------------------------------------------------------
menu4=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"1. Theory","c1.html",,,0,
"2. Variables","c2.html",,,0,
"3. Expressions","c3.html",,,0,
"4. Decisions","c4.html",,,0,
"5. Repetitions","c5.html",,,0
]

menu5=[
,,150,1,"",prop1,,"left",effect,,,,,,,
"6. Functions","c6.html",,,0,
"7. Classes","c7.html",,,0,
"8. Pointers I","c8.html",,,0,
"9. Pointers II","c9.html",,,0,
"10. References","c10.html",,,0,
"11. Advanced Indirection","c11.html",,,0
]

menu6=[
,,155,1,"",prop1,,"left",effect,,,,,,,
"12. Overloading","c12.html",,,0,
"13. Operator Overloading","c13.html",,,0,
"14. Arrays","c14.html",,,0,
"15. Inheritance","c15.html",,,0,
"16. Overriding","c16.html",,,0
]

menu7=[
,,130,1,"",prop1,,"",effect,,,,,,,
"17. Polymorphism I","c17.html",,,0,
"18. Polymorphism II","c18.html",,,0,
"19. Linked Lists","c19.html",,,0,
"20. Static Data","c20.html",,,0,
"21. Function Pointers","c21.html",,,0
]

menu8=[
,,115,1,"",prop1,,"left",effect,,,,,,,
"22. Templates","c22.html",,,0,
"23. Preprocessor","c23.html",,,0,
"24. Exceptions","c24.html",,,0,
"25. Design","c25.html",,,0,
"26. Hexadecimal","c26.html",,,0,
"27. Precedence","c27.html",,,0
]

menu9=[
,,125,1,"",prop1,,"left",effect,,,,,,,
"28. Strings","c28.html",,,0,
"29. File Access","c29.html",,,0,
"30. Sequential Files","c30.html",,,0,
"31. Binary Files","c31.html",,,0,
"32. Namespaces","c32.html",,,0,
"33. CMath","c33.html",,,0
]

menu10=[
,,170,1,"",prop1,,"left",effect,,,,,,,
"34. Command Line","c34.html",,,0,
"35. Bitwise Operators","c35.html",,,0,
"36. Function Objects","c36.html",,,0,
"37. Non-mutating Algorithms","c37.html",,,0,
"38. Mutating Algorithms","c38.html",,,0
]

menu11=[
,,125,1,"",prop1,,"left",effect,,,,,,,
"39. STL","c39.html",,,0,
"40. Vectors","c40.html",,,0,
"41. Lists","c41.html",,,0,
"42. STL Containers","c42.html",,,0,
"43. Maps","c43.html",,,0,
"44. Iterators","c44.html",,,0,
"45. Find","c45.html",,,0,
"46. Sort","c46.html",,,0
]

menu12=[
,,130,1,"",prop1,,"left",effect,,,,,,,
"1. Introduction","mfc1.html",,,0,
"2. .Net MFC Dialogs","mfc4.html",,,0,
"3. MFC Menus","mfcproject1.html",,,0,
"4. MFC CEdit","mfcproject2.html",,,0,
"5. Multiple Windows","mfcproject3.html",,,0,
"6. Mouse Behavior","mfcproject4.html",,,0,
"7. Keyboard Input","mfcproject5.html",,,0,
"8. DLLs","mfc2.html",,,0
]

menu13=[
,,130,1,"",prop1,,"left",effect,,,,,,,
"1. Keyboard Input","mfcproject5.html",,,0,
"2. Center Text","mfcproject6.html",,,0,
"3. MultiLine Text","mfcproject7.html",,,0,
"4. Check Boxes","mfcproject8.html",,,0,
"5. Radio Buttons","mfcproject9.html",,,0,
"6. List Boxes","mfcproject10.html",,,0,
"7. Combo Boxes","mfcproject11.html",,,0,
"8. Shapes","mfcproject12.html",,,0,
"9. Lines","mfcproject13.html",,,0,
"10. Dynamic Colors","mfcproject14.html",,,0,
"11. Displaying Images","mfcproject15.html",,,0,
"12. Font Objects","mfcproject16.html",,,0,
"13. Password Login","mfcproject3.html",,,0,
"14. Mouse Detection","mfcproject4.html",,,0
]


menu14=[
,,145,1,"",prop1,,"left",effect,,,,,,,
"1. Adventure Game 2.5","cproject2c.html",,,0,
"2. Adventure Game 2.0","cproject2.html",,,0,
"3. MegaPet 1.0","cproject13.html",,,0,
"4. Calculator 1.0","cproject6.html",,,0,
"5. Calculator 2.0","cproject11.html",,,0,
"6. MorseCode 2.0","cproject12.html",,,0,
"7. Number Game","cproject7.html",,,0,
"8. Hangman","cproject5.html",,,0,
"9. GuessAWord 1.0","cproject14.html",,,0,
"10. Monster Combat","cproject15.html",,,0,
"11. Tic Tac Toe","cproject16.html",,,0,
"12. Quiz","cproject17.html",,,0,
"13. Black Jack","cproject18.html",,,0,
"14. Checkers","cproject19.html",,,0
]

menu15=[
,,135,0,"1",prop1,,"left",effect,,,,,,,
"1. .Net MFC Dialog","mfc4.html",,,0,
"2. Hills Game 3","mfcproject18.html",,,0,
"3. MegaPet 2.0","mfcproject17.html",,,0,
"4. MFC Calc 3.0","mfcproject2.html",,,0,
"5. Database 1.0","mfcproject19.html",,,0,
"6. NetProgPlanner 1.0","mfcproject20.html",,,0,
"7. ODBC/OLE DB Data","mfcproject21.html",,,0,
"8. DLLs","mfc2.html",,,0,
"9. Menu","mfcproject1.html",,,0
]











//---------VB Submenu-------------------------------------------------------------------------
menu16=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"VB6 Tutorial 1","show-menu17",,,0,
"VB6 Tutorial 2","show-menu18",,,0,
"VB6 Examples","show-menu19",,,0,
"VB6 Projects","show-menu20",,,0,
"VB6 RunTime DLL","../VB/msvbvm60.exe",,,0,
"VB.NET","show-menu21",,,0,
"Normalization","normalization.html",,,0
]

//---------VB Submenu Submenus----------------------------------------------------------------
menu17=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Lesson 1","vbkeywords.html",,,0,
"2. Lesson 2","vbkeywords2.html",,,0
]

menu18=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Lesson 1","vbkeywords3.html",,,0,
"2. Lesson 2","vbkeywords4.html",,,0
]

menu19=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Examples 1","vbsource.html",,,0,
"2. Examples 2","vbsource.html",,,0
]

menu20=[
,,185,1,"",prop1,,"left",effect,,,,,,,
"1. Calculator 1.0 (.Net)","vbNetPro1.html",,,0,
"2. Game 2 (.Net)","vbproject11.html",,,0,
"3. Database (.Net)","vbproject12.html",,,0,
"4. Game 1(Sequential/Random)","vbproject1.html",,,0,
"5. Editor (Sequential)","vbproject2.html",,,0,
"6. Organizer (Random Access)","vbproject3.html",,,0,
"7. Organizer (ADO)","vbproject4.html",,,0,
"8. Validation","vbproject5.html",,,0,
"9. Datagrid","vbproject6.html",,,0,
"10. Passing Objects","vbproject7.html",,,0,
"11. Database Intro","vbproject8.html",,,0,
"12. Database (Random)","vbproject9.html",,,0,
"13. Database (ADO)","vbproject10.html",,,0
]

menu21=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Lesson 1","vbnet1.html",,,0,
"2. Lesson 2","vbnet2.html",,,0
]








//---------Java Submenu-----------------------------------------------------------------------
menu22=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"Mutant Wars","show-menu71",,,0,
"Console Projects","show-menu70",,,0,
"Applet Projects","show-menu28",,,0,
"Midlet Projects","midlets1.html",,,0,
"Java 1","show-menu23",,,0,
"Java 2","show-menu24",,,0,
"Java 3","show-menu25",,,0,
"Java 4","show-menu26",,,0,
"AWT","show-menu27",,,0

]


//---------Java Submenu Submenus------------------------------------------------------------------
menu23=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"1. Introduction","javasource.html",,,0,
"2. Variables","javasource1.html",,,0,
"3. Decisions","javasource2.html",,,0,
"4. Repetitions","javasource3.html",,,0,
"5. Functions","javasource4.html",,,0,
"6. Classes","javasource5.html",,,0
]

menu24=[
,,112,1,"",prop1,,"left",effect,,,,,,,
"7. Arrays","javasource8.html",,,0,
"8. Strings","javasource6.html",,,0,
"9. Files Sequential","javasource7.html",,,0,
"10. Files Random","javasource9.html",,,0,
"11. Try/Catch","javasource10.html",,,0
]

menu25=[
,,120,1,"",prop1,,"left",effect,,,,,,,
"12. Applets Intro","javasource11.html",,,0,
"13. Interfaces","javasource17.html",,,0,
"14. Threads","javasource20.html",,,0,
"15. Graphics","javasource18.html",,,0,
"16. Packages/JARs","javasource19.html",,,0
]

menu26=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Tutorial 7","javasource6.html",,,0,
"2. Tutorial 8","javasource7.html",,,0
]

menu27=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. AWT 1","javasource7.html",,,0,
"2. AWT 2","javasource7.html",,,0
]

menu28=[
,,140,1,"",prop1,,"left",effect,,,,,,,
"1. Mutant Wars","show-menu71",,,0,
"2. BlackJack Game","javasource29.html",,,0,
"3. BlackJack Code","javasource28.html",,,0,
"4. Adventure Game I","javasource15.html",,,0,
"5. Adventure Game II","javasource32.html",,,0,
"6. Adventure Game III","javasource33.html",,,0,
"7. LifeForm Combat","javasource31.html",,,0,
"8. MegaPet","javasource14.html",,,0,
"9. Calculator","javasource16.html",,,0,
"10. Hello World","javasource11.html",,,0,
"11. Password","javasource12.html",,,0,
"12. Guess Number","javasource13.html",,,0,
"13. Quiz 1","javasource30.html",,,0,
"14. Quiz 2","javasource21.html",,,0
]



//---------DHTML Submenu----------------------------------------------------------------------
menu29=[
,,150,1,"",prop1,,"left",effect,,,,,,,
"Section 1","show-menu30",,,0,
"Section 2","show-menu31",,,0,
"Section 3","show-menu32",,,0,
"Section 4","show-menu33",,,0,
"Cascading Style Sheets","show-menu34",,,0,
"Active X Controls","show-menu35",,,0,
"TDC Data Binding","show-menu36",,,0
]

//---------DHTML Submenu Submenus-----------------------------------------------------------------
menu30=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Tutorial 1","html1.html",,,0,
"2. Tutorial 2","html1.html",,,0
]

menu31=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Tutorial 3","html2.html",,,0,
"2. Tutorial 4","html2.html",,,0
]

menu32=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Tutorial 5","html3.html",,,0,
"2. Tutorial 6","html3.html",,,0
]

menu33=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Tutorial 7","html4.html",,,0,
"2. Tutorial 8","html4.html",,,0
]

menu34=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. CSS Tutorial 1","cascading.html",,,0,
"2. CSS Tutorial 2","cascading.html",,,0
]

menu35=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Active X 1","activex.html",,,0,
"2. Active X 2","activex.html",,,0
]

menu36=[
,,125,1,"",prop1,,"left",effect,,,,,,,
"1. TDC Data Binding","datasource.html",,,0,
"2. TDC Data Binding","datasource.html",,,0
]











//---------Script Submenu---------------------------------------------------------------------
menu37=[
,,85,1,"",prop1,,"left",effect,,,,,,,
"JavaScript","show-menu38",,,0,
"VBScript","show-menu39",,,0,
"ASP","show-menu40",,,0,
"SQL","show-menu41",,,0,
"Perl","show-menu42",,,0,
"PHP","show-menu43",,,0,
"XML","show-menu44",,,0
]

//---------Script Submenu Submenus-----------------------------------------------------------
menu38=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. JavaScript 1","javascriptsource1.html",,,0,
"2. JavaScript 2","javascriptsource2.html",,,0,
"3. JavaScript 3","javascriptsource3.html",,,0,
"4. JavaScript 4","javascriptsource4.html",,,0,
"5. JavaScript 5","javascriptsource5.html",,,0,
"6. JavaScript 6","javascriptsource6.html",,,0,
"7. Projects","show-menu63",,,0,
"8. Fragments","javascriptsource.html",,,0
]

menu39=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. VBScript 1","vbscript1.html",,,0,
"2. VBScript 2","vbscript1.html",,,0,
"3. Projects","show-menu64",,,0
]

menu40=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. ASP Intro","aspsource.html",,,0,
"2. ASP Section 1","aspsource1.html",,,0,
"3. ASP Section 2","aspsource2.html",,,0,
"4. ASP Section 3","aspsource3.html",,,0,
"5. ASP Section 4","aspsource4.html",,,0
]

menu41=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. SQL 1","sqlsource.html",,,0,
"2. SQL 2","sqlsource.html",,,0
]

menu42=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. Perl and CGI 1","cgiperlsource.html",,,0,
"2. Perl and CGI 2","cgiperlsource.html",,,0
]

menu43=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. PHP 1","phpsource.html",,,0,
"2. PHP 2","phpsource.html",,,0
]

menu44=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. XML 1","xmlsource.html",,,0,
"2. XML 2","xmlsource.html",,,0
]









//---------C# Submenu---------------------------------------------------------------------
menu45=[
,,95,1,"",prop1,,"left",effect,,,,,,,
"C# Section 1","show-menu46",,,0,
"C# Section 2","show-menu47",,,0
]

//---------C# Submenu Submenus------------------------------------------------------------
menu46=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. C# Tutorial 1","csharp1.html",,,0,
"2. C# Tutorial 2","csharp1.html",,,0
]

menu47=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. C# Tutorial 3","csharp2.html",,,0,
"2. C# Tutorial 4","csharp2.html",,,0
]










//---------Flash Submenu---------------------------------------------------------------------
menu48=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"Flash Tutorials","show-menu49",,,0,
"Flash Projects","show-menu50",,,0
]

//---------Flash Submenu Submenus------------------------------------------------------------
menu49=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Tutorial 1","flash.html",,,0,
"2. Tutorial 2","flash.html",,,0
]

menu50=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Project 1","flash.html",,,0,
"2. Project 2","flash.html",,,0,
"1. Project 3","flash.html",,,0,
"2. Project 4","flash.html",,,0
]










//---------Networking Submenu---------------------------------------------------------------------
menu51=[
,,89,1,"",prop1,,"left",effect,,,,,,,
"Videos","NET14.html",,,0,
"General","show-menu66",,,0,
"A+ and N+","show-menu72",,,0,
"Linux+","show-menu53",,,0,
"MCSE","show-menu52",,,0,
"Cisco","show-menu57",,,0,
"Cat-5 Wiring","show-menu54",,,0

]

//---------Networking Submenu Submenus------------------------------------------------------------
menu52=[
,,110,1,"",prop1,,"left",effect,,,,,,,
"1. History","mcse3.html",,,0,
"2. Install","mcse1.html",,,0,
"3. Repairs","mcse2.html",,,0,
"4. Networking","mcse4.html",,,0,
"5. Permissions","mcse5.html",,,0,
"6. Group Policy","mcse5.html",,,0
]

menu53=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"1. History","linux7.html",,,0,
"2. Intro","linux1.html",,,0,
"3. Repairs","linux5.html",,,0,
"4. Commands","linux2.html",,,0,
"5. Configuration","linux3.html",,,0,
"6. Networking","linux4.html",,,0,
"7. Scripting","linux6.html",,,0
]

menu54=[
,,120,1,"",prop1,,"left",effect,,,,,,,
"1. Crossover Cables","cabling1.html",,,0,
"2. Standard Cables","cabling1.html",,,0
]

menu55=[
,,135,1,"",prop1,,"left",effect,,,,,,,
"1. Wireless 802.11b","underdevelopment.html",,,0,
"2. Wireless 802.11a/g","underdevelopment.html",,,0
]

menu56=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Diagnostics","underdevelopment.html",,,0,
"2. Diagnostics","underdevelopment.html",,,0
]

menu57=[
,,120,1,"",prop1,,"left",effect,,,,,,,
"1. IP Addressing","ipaddress1.html",,,0,
"2. Subnetting","ipaddress2.html",,,0,
"3. Supernetting","ipaddress3.html",,,0,
"4. CIDR - VLSM","ipaddress4.html",,,0,
"5. Routing","routingprotocols.html",,,0,
"6. Switches","switches.html",,,0,
"7. VLANs","vlans.html",,,0,
"8. Access Lists","accesslists.html",,,0,
"9. WAN Protocols","wlanprotocols.html",,,0,
"10. Configuration","routerconfiguration.html",,,0
]

menu58=[
,,90,1,"",prop1,,"left",effect,,,,,,,
"1. Security","underdevelopment.html",,,0,
"2. Security","underdevelopment.html",,,0
]










//---------Interactive Submenu---------------------------------------------------------------------
menu59=[
,,130,1,"",prop1,,"left",effect,,,,,,,
"Available Always:","",,,1,
"1. Discussion Forums","http://www.networkingprogramming.com/PORTAL/cgi-bin/index.cgi?action=forum",,,0,
"2. Write Articles","http://www.networkingprogramming.com/PORTAL/cgi-bin/index.cgi?action=topics",,,0,
"3. Downloads","http://www.networkingprogramming.com/PORTAL/cgi-bin/index.cgi?action=downloads",,,0,
"4. NP Web Portal","http://www.networkingprogramming.com/PORTAL/cgi-bin/index.cgi",,,0,
"5. NP Portal Admin","http://www.networkingprogramming.com/PORTAL/cgi-bin/admin/siteadmin.cgi",,,1,
"Available Occasionally When My Other Linux Server Is On:","",,,1,
"1. Discussion Forums","http://72.188.135.177/cgi-bin/dcforum/dcboard.cgi",,,0,
"2. Discussion Admin","http://72.188.135.177/cgi-bin/dcforum/dcadmin.cgi",,,0,
"3. Upload Files","http://72.188.135.177/cgi-bin/uploads/upload.pl",,,0,
"4. FTP Server","http://72.188.135.177",,,0,
"6. Training Videos","http://72.188.135.177/VideoProfessor",,,0,
"7. Music","http://72.188.135.177/CoverTunes",,,0,
"8. Post Cards","http://72.188.135.177/cgi-bin/webportal/index.cgi",,,0,
"9. Make Web Pages","http://72.188.135.177/cgi-bin/webportal/index.cgi",,,0,
"10. Alternate Forum","http://72.188.135.177/cgi-bin/forum/Blah.pl",,,0
]





//---------Links Submenu---------------------------------------------------------------------
menu60=[
,,150,1,"",prop1,,"left",effect,,,,,,,
"RainOfGod","http://www.rainofgod.com",,,0,
"Search","search.html",,,0,
"Sun Microsystems Java","http://www.java.com",,,0,
"The Java Botique","http://www.javabotique.com",,,0,
"The JavaScript Source","http://javascript.internet.com",,,0,
"JavaScript.com","http://www.javascript.com",,,0,
"MSDN Visual C++","http://msdn.microsoft.com/visualc",,,0,
"MSDN Visual Basic","http://msdn.microsoft.com/vbasic/default.aspx",,,0,
"MSDN Visual C#","http://msdn.microsoft.com/vcsharp",,,0,
"MSDN .NET","http://www.microsoft.com/net",,,0,
"Programmer\'s Heaven","http://www.programmersheaven.com",,,0,
"C++ Resources Network","http://www.cplusplus.com",,,0,
"C and C++ Reference","http://www.cppreference.com",,,0,
"C++ Home","http://www.cpp-home.com",,,0,
"Code Guru","http://www.codeguru.com",,,0,
"ASP 101","http://www.asp101.com",,,0,
"ASP Resources","http://www.aspin.com",,,0,
"Linux GNU","http://www.linux.com",,,0,
"Linux Red Hat","http://www.redhat.com",,,0,
"Linux Mandrake","http://www.mandrakesoft.com",,,0,
"MCSE","http://www.microsoft.com/learning/mcp/mcse",,,0
/* "Online Bible","http://bible.gospelcom.net/",,,0  */
/* "Germany Family Web","http://www.networkingprogramming.com/traveler",,,0 */
]



//---------Search Submenu---------------------------------------------------------------------
menu61=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"NetProg Search","search.html",,,0,
"Google","http://www.google.com",,,0,
"Yahoo!","http://www.yahoo.com",,,0,
"Alta Vista","http://www.altavista.com",,,0,
"MSN","http://www.msn.com",,,0,
"Lycos","http://www.lycos.com",,,0,
"Excite","http://www.excite.com",,,0,
"37.com","http://www.37.com",,,0,
"Dog Pile","http://www.dogpile.com",,,0
]



//---------Search Submenu---------------------------------------------------------------------
menu62=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"Casting","c48.html",,,0,
"Supplementary","c47.html",,,0
]


menu63=[
,,100,1,"",prop1,,"left",effect,,,,,,,
"1. Calculators","calculators.html",,,0,
"2. Password","js2.html",,,0,
"3. Classes","js1.html",,,0,
"4. Quiz 1","js3.html",,,0,
"5. Quiz 2","js4.html",,,0,
"5. Quiz 3","js5.html",,,0
]

menu64=[
,,185,1,"",prop1,,"left",effect,,,,,,,
"1. Password","vbs1.html",,,0,
"2. Classes","vbs2.html",,,0,
"3. Quiz 1 - Arrays","vbs3.html",,,0,
"4. Quiz 2 - Form + Arrays","vbs4.html",,,0,
"5. GBook 2.0 - Sequential","vbs5.html",,,0,
"6. GBook 3.0 - Class File","vbs6.html",,,0,
"7. GBook 4.0 - ADO and SQL","vbs7.html",,,0
]


menu65=[
,,185,1,"",prop1,,"left",effect,,,,,,,
"Old C Projects","cOLD.html",,,0
]


menu66=[
,,120,1,"",prop1,,"left",effect,,,,,,,
"1. IP Addressing","ipaddress1.html",,,0,
"2. Subnetting","ipaddress2.html",,,0,
"3. Supernetting","ipaddress3.html",,,0,
"4. CIDR - VLSM","ipaddress4.html",,,0,
"5. Routing","routingprotocols.html",,,0
]


menu67=[
,,145,1,"",prop1,,"left",effect,,,,,,,
"1. Database 1.0","cproject1.html",,,0,
"2. Database 2.0","cproject3.html",,,0,
"3. Addressbook 1.0","cproject9.html",,,0,
"4. AdventureGame 1","cproject2.html",,,0,
"5. AdventureGame 2","cproject2b.html",,,0,
"6. Mad Lib 1.0","cproject8.html",,,0,
"7. Command Line","cproject4.html",,,0,
"8. Binary Data","cproject10.html",,,0,
"9. Code Scraps","csource9.html",,,0
]


menu68=[
,,145,1,"",prop1,,"left",effect,,,,,,,
"1. Calculator 1","winapiproject1.html",,,0,
"2. Backgrounds","winapiproject2.html",,,0,
"3. Window Styles","winapiproject3.html",,,0,
"4. Number Game","winapiproject4.html",,,0,
"5. Calculations 1","winapiproject5.html",,,0,
"6. Calculations 2","winapiproject7.html",,,0,
"7. Quiz","winapiproject6.html",,,0,
"8. Calculator 2","winapiproject8.html",,,0,
"9. Calculator 3","winapiproject9.html",,,0,
"10. Menus","winapiproject10.html",,,0
]


menu69=[
,,145,1,"",prop1,,"left",effect,,,,,,,
"1. Background","directx1.html",,,0,
"2. Flashing","directx2.html",,,0,
"3. Bitmap","directx3.html",,,0
]


menu70=[
,,145,1,"",prop1,,"left",effect,,,,,,,
"1. Mutant Wars - 1","javaconsole8a.html",,,0,
"2. Mutant Wars - 2","javaconsole8b.html",,,0,
"3. Mutant Wars - 3","javaconsole8c.html",,,0,
"4. Adv Game - HOD","javaconsole7.html",,,0,
"5. Black Jack","javaconsoleBJ.html",,,0,
"6. GuessNumber1","javaconsole1.html",,,0,
"7. GuessNumber2","javaconsole2.html",,,0,
"8. Calculator","javaconsole3.html",,,0,
"9. MegaPet","javaconsole4.html",,,0,
"10. Quiz","javaconsole5.html",,,0,
"11. Monster Combat","javaconsole6.html",,,0
]

menu71=[
,,150,1,"",prop1,,"left",effect,,,,,,,
"1. MutantWars Applet","javasource22.html",,,0,
"2. MutantWars Interface","javasource23.html",,,0,
"3. MutantWars Classes 1","javasource24.html",,,0,
"4. MutantWars Classes 2","javasource25.html",,,0,
"5. MutantWars Classes 3","javasource26.html",,,0,
"6. MutantWars Map","javaconsole8a.html",,,0,
"7. MutantWars Console 2","javaconsole8b.html",,,0,
"8. MutantWars Console 3","javaconsole8c.html",,,0
]

menu72=[
,,142,1,"",prop1,,"left",effect,,,,,,,
"1. INTRO Videos","NET13.html",,,0,
"2. OSI Networks","NET2_Summary.html",,,0,
"3. HD Repair","NET5_HardDriveRepair.html",,,0,
"4. HD Maintenance","NET5_HardDriveRepair.html",,,0,
"5. Power Supplies","NET9_PowerSupplies.html",,,0,
"6. Backing Up","NET7_BackingUp.html",,,0,
"7. RAID and Clustering","NET8_RAIDandClustering.html",,,0,
"8. Quantum Computing","NET10_QuantumComputing.html",,,0,
"9. Computer History","NET12_ComputerHistory.html",,,0,
"10. Multiple Core CPUs","NET11_MultipleCoreProcessors.html",,,0,
"11. Building PCs","NET1_BuildingPCs.html",,,0,
"12. IP Addressing","ipaddress1.html",,,0,
"13. Subnetting","ipaddress2.html",,,0,
"14. Supernetting","ipaddress3.html",,,0,
"15. CIDR - VLSM","ipaddress4.html",,,0,
"16. Routing","routingprotocols.html",,,0,
"17. Paper CERTs","NET3_PaperCerts.html",,,0,
"18. Security Risks","NET4_SecurityRisks.html",,,0
]