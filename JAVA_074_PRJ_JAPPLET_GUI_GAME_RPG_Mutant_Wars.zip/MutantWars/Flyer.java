//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class Flyer extends Mutant
{
       public Flyer() 
       {  
              String OUT = "\n\tCreating a Flyer mutant.";
              MutantWars.MainOutput.setText(OUT);
       }

       public Flyer(String x)
       { 
              String OUT = "\n\tCreating a Flyer mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
       }  
 
       //Functions
       public void Fly() 
       { 
              String OUT = "\n\tFlying...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesors
       

       //Private Data
}
