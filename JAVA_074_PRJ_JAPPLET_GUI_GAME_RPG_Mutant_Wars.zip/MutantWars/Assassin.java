//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 28 lines of code

import javax.swing.*;
import java.io.*;

public class Assassin extends Human
{    
       public Assassin() 
       {
              String OUT = "\n\tCreating a Assassin human.";
              MutantWars.MainOutput.setText(OUT);
              SetCharClass("Assassin");
       }

       public Assassin(String x)
       {
              String OUT = "\n\tCreating an Assassin human.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
              SetCharClass("Assassin");
       }   

       //Human Functions


       //Public Accesor Methods


       //Private Data     

}
