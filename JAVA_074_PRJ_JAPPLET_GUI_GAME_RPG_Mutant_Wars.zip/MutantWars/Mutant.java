//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class and ADT
//Derived Class and ADT
//Class = 296 lines of code

import javax.swing.*;
import java.io.*;

public class Mutant extends LifeForm
{    
       public Mutant() 
       {
              String OUT = "\n\tCreating a base class ADT Mutant.";
              MutantWars.MainOutput.setText(OUT);
              InitializeAbilities();
       }

       public void InitializeAbilities()
       {
              FLY = false;
              FREEZE = false;
              HEAL = false;
              MINDREAD = false;
              FIRE = false;
              MOVE = false;
              TIMESHIFT = false;
              MutantPower = 10;
       }

       //Choose and Use Mutant Abilities

       public void AbilityCheat()
       {
              FLY = true;
              FREEZE = true;
              HEAL = true;
              MINDREAD = true;
              FIRE = true;
              MOVE = true;
              TIMESHIFT = true;
              MutantPower = 1000;
       }

       public void AbilityCost()
       {
              if(UseFLY) { AbilityCost = 7; }
              if(UseFREEZE) { AbilityCost = 10; }
              if(UseHEAL) { AbilityCost = 5; }
              if(UseMINDREAD) { AbilityCost = 2; }
              if(UseFIRE) { AbilityCost = 12; }
              if(UseMOVE) { AbilityCost = 13; }
              if(UseTIMESHIFT) { AbilityCost = 15; }
       }

       //Mutant Data Accesors
       public int GetAbilityCost() { return AbilityCost; }
       public void SetAbliityCost(int x) { AbilityCost = x; }
       public int GetMutantPower() { return MutantPower; }
       public void SetMutantPower(int x) { MutantPower = x; }

       //Mutant Ability Accessors
       public boolean GetFLY() { return FLY; }
       public void SetFLY(boolean x) { FLY = x; }
       public boolean GetFREEZE() { return FREEZE; }
       public void SetFREEZE(boolean x) { FREEZE = x; }
       public boolean GetHEAL() { return HEAL; }
       public void SetHEAL(boolean x) { HEAL = x; }
       public boolean GetMINDREAD() { return MINDREAD; }
       public void SetMINDREAD(boolean x) { MINDREAD = x; }
       public boolean GetFIRE() { return FIRE; }
       public void SetFIRE(boolean x) { FIRE = x; }
       public boolean GetMOVE() { return MOVE; }
       public void SetMOVE(boolean x) { MOVE = x; }
       public boolean GetTIMESHIFT() { return TIMESHIFT; }
       public void SetTIMESHIFT(boolean x) { TIMESHIFT = x; }

       public boolean GetUseFLY() { return UseFLY; }
       public void SetUseFLY(boolean x) { UseFLY = x; }
       public boolean GetUseFREEZE() { return UseFREEZE; }
       public void SetUseFREEZE(boolean x) { UseFREEZE = x; }
       public boolean GetUseHEAL() { return UseHEAL; }
       public void SetUseHEAL(boolean x) { UseHEAL = x; }
       public boolean GetUseMINDREAD() { return UseMINDREAD; }
       public void SetUseMINDREAD(boolean x) { UseMINDREAD = x; }
       public boolean GetUseFIRE() { return UseFIRE; }
       public void SetUseFIRE(boolean x) { UseFIRE = x; }
       public boolean GetUseMOVE() { return UseMOVE; }
       public void SetUseMOVE(boolean x) { UseMOVE = x; }
       public boolean GetUseTIMESHIFT() { return UseTIMESHIFT; }
       public void SetUseTIMESHIFT(boolean x) { UseTIMESHIFT = x; }
       public void SetAlreadyFlying(boolean x) { AlreadyFlying = x; }
       public boolean GetAlreadyFlying() { return AlreadyFlying; }

       //Private Data
       private int MutantPower = 0;
       private int AbilityCost = 0;

       //Mutant Abilities (7 Possible)
       private boolean FLY = false;
       private boolean FREEZE = false;
       private boolean HEAL = false;
       private boolean MINDREAD = false;
       private boolean FIRE = false;
       private boolean MOVE = false;
       private boolean TIMESHIFT = false;

       private boolean UseFLY = false;
       private boolean UseFREEZE = false;
       private boolean UseHEAL = false;
       private boolean UseMINDREAD = false;
       private boolean UseFIRE = false;
       private boolean UseMOVE = false;
       private boolean UseTIMESHIFT = false;
       private boolean AlreadyFlying = false;
}
