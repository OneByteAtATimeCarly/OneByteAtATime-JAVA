//Mutant Wars 1.5 for Java - Charles Germany - 2007 - ADT LifeForm class
//ADT Base Class for all game objects
//Class = 520 lines of code

import javax.swing.*;
import java.io.*;

//Base Class ADT
public class LifeForm
{
       //4 Overloaded Constructors 
       public LifeForm()
       {
              String OUT = "\n  Creating a base class ADT LifeForm object.";
              MutantWars.MainOutput.setText(OUT);
              hitpoints = 100; 
              atack = 1; 
              defense = 1; 
              NAME = "LifeForm";
              SEX = "FEMALE";
              InitializeInventory();
       }

       public LifeForm(String n)
       {
              String OUT = "\n  Creating a base class ADT LifeForm object.";
              MutantWars.MainOutput.setText(OUT);
              hitpoints = 100; atack = 1; defense = 1; NAME = n;
              InitializeInventory();
       }

       public LifeForm(String n, int h)
       {
              String OUT = "\n  Creating a base class ADT LifeForm object.";
              MutantWars.MainOutput.setText(OUT);
              hitpoints = h; atack = 1; defense = 1; NAME = n;
              InitializeInventory();
       }

       public LifeForm(String n, int h, int a, int d)
       {
              String OUT = "\n  Creating a base class ADT LifeForm object.";
              MutantWars.MainOutput.setText(OUT);
              hitpoints = h; atack = a; defense = d; NAME = n;
              InitializeInventory();
       }

       //Functions

       public String Speak(String x)
       {
              String OUT = "  " + NAME + 
              " looks at you and says, \n      \"" + x + "\".\n";
              return OUT;
       }

       public void InitializeInventory()
       {
              datacrystal = false;
              Gun = false;
              Ammo9mm = 0;
              Syringe = false;
              SyringeCartridge = 0;
              Machete = false;
              Jacket = false;
              MedKit = 0;
              MRErations = 0;
              FramePack = false;
              Matches = false;
              Sterno = false;
              KeyCard = false;
              Key = false;
              FoundL1_HumanGirl = false;
              WeaponChoice = "UNDECIDED";
              
              hitpoints = 100;
              atack = 1;
              defense = 1;
              CONQUESTS = "";
       }


       public void Cheat()
       {
              datacrystal = true;
              Gun = true;
              Ammo9mm = 100;
              Syringe = true;
              SyringeCartridge = 100;
              Machete = true;
              Jacket = true;
              MedKit = 100;
              MRErations = 100;
              FramePack = true;
              Matches = true;
              Sterno = true;
              KeyCard = true;
              Key = true;
              FoundL1_HumanGirl = true;
              
              hitpoints = 1000;
              atack = 10;
              defense = 10;
              Events.Player.SetMutantPower(100);
              
              Events.Player.AbilityCheat();
       }

       public void DisplayStats()
       {
              MutantWars.OutName.setText("  " + NAME);
              MutantWars.OutSex.setText("  " + SEX);
              MutantWars.OutLife.setText(" " + hitpoints);
              MutantWars.OutDefense.setText(" " + defense);
              MutantWars.OutAttack.setText(" " + atack);
              MutantWars.OutScore.setText(" " + score);
              MutantWars.OutMutantPower.setText(" " + Events.Player.GetMutantPower());
              MutantWars.OutCharClass.setText(" " + CHAR_CLASS);
       }

       public void ListInventory()
       {
              int count = 0;
              String INV = "\n";

              if(Gun) 
              { INV = INV + " " + ++count + ". 9mm Gun\n     (+8 attack)\n\n"; }
              if(Ammo9mm > 0) 
              { INV = INV + " " + ++count + ". 9mm Ammo:\n     " + Ammo9mm + "\n\n"; }
              if(Syringe) 
              { 
                 INV = INV + " " + ++count + 
                 ". Medical\n    Syringe\n     (+20 attack)\n\n"; 
              }
              if(SyringeCartridge > 0)
              { 
                  INV = INV + " " + ++count + ". Syringe\n     Cart: " 
                      + SyringeCartridge + "\n\n"; 
              }
              if(Machete)
              { INV = INV + " " + ++count + ". Machete\n     (+4 attack)\n\n"; }
              if(Jacket)
              { INV = INV + " " + ++count + ". SJacket\n     (+2 defense)\n\n"; }
              if(MedKit > 0)
              { INV = INV + " " + ++count + ". MedKits: " + MedKit + "\n\n"; }
              if(MRErations > 0)
              { INV = INV + " " + ++count + ". MREs: " + MRErations + "\n\n"; }
              if(FramePack)
              { INV = INV + " " + ++count + ". FramePack\n\n"; }
              if(datacrystal)
              { INV = INV + " " + ++count + ". Data\n     Crystal\n\n"; }
              if(Matches) { INV = INV + " " + ++count + ". Matches\n\n"; }
              if(Sterno) { INV = INV + " " + ++count + ". Sterno\n\n"; }
              if(KeyCard) { INV = INV + " " + ++count + ". KeyCard\n\n"; }
              if(Key) { INV = INV + " " + ++count + ". Key\n\n"; }
              if(FoundL1_HumanGirl)
              { 
                INV = INV + " " + ++count + ". " + Events.L1_HumanGirl.GetName() 
                + "\n      (rescued)\n\n"; 
              }

              if(!datacrystal && (Ammo9mm <= 0) && !Machete && !Syringe && !Matches 
                 && !FramePack && (MedKit <= 0) && (MRErations <= 0) && !Sterno && 
                 !Jacket && !Gun && !KeyCard && !Key && !FoundL1_HumanGirl)

              { INV = INV + "  Absolutely\n  nothing!"; }

              MutantWars.OutInventory.setText(INV);
              MutantWars.OutInventory.setCaretPosition(0); //Position at top
              MutantWars.Out9mm.setText(" " + Events.Player.Get9mmAmmo());
              MutantWars.OutCart.setText(" " + Events.Player.GetSyringeCart());
       }

       public void DropInventory()
       {
              String OUT = "\n  Dropping " + InventoryItem + "...\n";
              MutantWars.MainOutput.setText(OUT);
       }

       public void AddConquest(String x)
       {
            CONQUESTS = CONQUESTS + "\n" + ++CONQUESTcount + " " + x;
            MutantWars.OutConquests.setText("You survived:\n" + CONQUESTS);
            MutantWars.OutConquests.setCaretPosition(0); //Position at top
            //MutantWars.OutConquests.setText("Mutant Roaches");
       }

       public void ListConquests()
       { MutantWars.OutConquests.setText("You survived:\n" + CONQUESTS); }


       public void Attack(LifeForm opponent)
       {
              String WPN = "";
              String OUT = "";
              int damage = 0;

              damage = Functions.GRN(25);
              MutantWars.WEAPONS();
              MutantWars.ABILITIES();

              if(CHAR_CLASS.equals("Impath"))
              {
                  if(UseGun)
                  {
                       if(Ammo9mm > 0)
                       {
                            damage = damage + 8;
                            Ammo9mm--;
                            WPN = "\n  " + NAME + " fires the 9mm pistol!  "
                                + "Ammo: " + Ammo9mm;
                            if(MutantWars.SOUNDEFFECTS) { MutantWars.Gun.play(); }
                       }
                       else
                       {
                            WPN = "\n  Sorry, out of 9mm ammunition!\n"
                                + "  Choose something else.\n"
                                + "  In the mean time, use your hands...\n";
                            UseGun = false;
                            UseHand = true;
                       }
                  }

                  else if(UseMachete)
                  {
                       damage = damage + 4;
                       WPN = "\n  " + NAME + " swings the machete!";
                       if(MutantWars.SOUNDEFFECTS) { MutantWars.Machete.play(); }
                  }

                  else if(UseSyringe)
                  {
                       if(SyringeCartridge > 0)
                       {
                            damage = damage + 20;
                            SyringeCartridge--;
                            WPN = "\n  " + NAME + " injects with the syringe!"
                                + "  Cartridges: " + SyringeCartridge;
                            if(MutantWars.SOUNDEFFECTS) { MutantWars.Syringe.play(); }
                       }
                       else
                       {
                            WPN = "\n  Sorry, all out of syringe cartridges!\n"
                                + "  Choose something else.\n"
                                + "  In the mean time, use your hands...\n";

                            UseSyringe = false;
                            UseHand = true;
                       }
                  }

                  //Hand To hand Default
                  else
                  {
                     WPN = "\n\n  Hands? Up close and personal?\n"
                         + "  An excellent choice!\n"
                         + "\n  " + NAME + " lets fly with the fists of fury!\n";
                     if(MutantWars.SOUNDEFFECTS) { MutantWars.HandToHand.play(); }
                  }

                  //Check for Abilities
                  if(Events.Player.GetUseFREEZE())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() -
                       Events.Player.GetAbilityCost() > 0)
                       {
                          damage = damage + Events.Player.GetAbilityCost();
                          Events.Player.SetMutantPower(
                          Events.Player.GetMutantPower() - Events.Player.GetAbilityCost());
                          WPN = WPN + "\n  " + NAME + " blasts with cold using the\n"
                              + "  mutant ability FREEZE!\n"
                              + "  Remaining Mutant Power: " + Events.Player.GetMutantPower();
                          if(MutantWars.SOUNDEFFECTS) { MutantWars.WindIce.play(); }
                       }
                       else
                       { 
                          WPN = WPN + "\n  You do not have enough mutant power to FREEZE.\n"
                              + "  Mind as well use your hands...\n";

                          Events.Player.SetUseFREEZE(false);
                          UseHand = true;
                       }
                  }

                  else if(Events.Player.GetUseFIRE())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() - 
                       Events.Player.GetAbilityCost() > 0)
                       {
                          damage = damage + Events.Player.GetAbilityCost();
                          Events.Player.SetMutantPower(
                          Events.Player.GetMutantPower() - Events.Player.GetAbilityCost());
                          WPN = WPN + "\n  " + NAME + " torches with searing flames\n"
                              + "  using the mutant ability FIRE!\n"
                              + "  Remaining Mutant Power: " + Events.Player.GetMutantPower();
                          if(MutantWars.SOUNDEFFECTS) { MutantWars.Explosion.play(); }
                       }
                       else
                       { 
                          WPN = WPN + "\n  You do not have enough mutant power to use FIRE.\n"
                              + "  Mind as well use your hands...\n";

                          Events.Player.SetUseFIRE(false);
                          UseHand = true;
                       }
                  }
                  
                  else if(Events.Player.GetUseHEAL())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() - 
                       Events.Player.GetAbilityCost() > 0)
                       {
                          damage = damage + Events.Player.GetAbilityCost();
                          Events.Player.SetMutantPower(
                          Events.Player.GetMutantPower() - Events.Player.GetAbilityCost());
                          WPN = WPN + "\n  HEAL is good for restoring life points, but not\n"
                              + "  very useful in combat.\n"
                              + "  You restore 10 life points. Now what?\n"
                              + "  Remaining Mutant Power: " + Events.Player.GetMutantPower();

                       }
                       else
                       { 
                          WPN = WPN + "\n  You do not have enough mutant power to HEAL.\n"
                              + "  Mind as well use your hands to fight...\n";

                          Events.Player.SetUseHEAL(false);
                          UseHand = true;
                       }
                  }

                  else if(Events.Player.GetUseFLY())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() -
                       Events.Player.GetAbilityCost() > 0)
                       {
                              if(!Events.Player.GetAlreadyFlying())
                              {
                                  defense = defense + 3;
                                  DisplayStats();
                                  Events.Player.SetMutantPower(
                                  Events.Player.GetMutantPower() - 
                                  Events.Player.GetAbilityCost());
                                  WPN = WPN + "\n  " + 
                                  NAME + " soars into the sky using the\n"
                                  + "  mutant ability FLY! This makes you\n"
                                  + "  much harder to hit, increasing your\n"
                                  + "  defensive capability by 3, temporarily.\n"
                                  + "  This does not however help your attack.\n"
                                  + "  Remaining Mutant Power: " + 
                                  Events.Player.GetMutantPower();
                                  Events.Player.SetAlreadyFlying(true);
                              }
                              else
                              {
                                 WPN = WPN + 
                                 "\n  You can't \"FLY\" again, you are already flying!\n";
                              }
                       }
                       else
                       {
                           WPN = WPN + 
                           "\n  You do not have enough mutant power to use FLY.\n"
                           + "  Mind as well use your hands...\n";

                           Events.Player.SetUseFLY(false);
                           UseHand = true;
                       }
                  }

                  else if(Events.Player.GetUseMOVE())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() - 
                       Events.Player.GetAbilityCost() > 0)
                       {
                          damage = damage + Events.Player.GetAbilityCost();
                          Events.Player.SetMutantPower(
                          Events.Player.GetMutantPower() - Events.Player.GetAbilityCost());
                          WPN = WPN + "\n  " + NAME + " telekinetically moves objects in\n"
                              + "  the environment using the mutant abliity\n"
                              + "  \"MOVE\"  This has the interesting\n"
                              + "  defensive capability of making nearly\n"
                              + "  everything around you a deadly projectile!\n"
                              + "  Remaining Mutant Power: " + 
                              Events.Player.GetMutantPower();
                       }
                       else
                       { 
                          WPN = WPN + 
                          "\n  You do not have enough mutant power to use MOVE.\n"
                          + "  Without telekenisis, mind as well use your hands...\n";

                          Events.Player.SetUseMOVE(false);
                          UseHand = true;
                       }
                  }

                  else if(Events.Player.GetUseMINDREAD())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() - 
                       Events.Player.GetAbilityCost() > 0)
                       {
                          damage = damage + Events.Player.GetAbilityCost();
                          Events.Player.SetMutantPower(
                          Events.Player.GetMutantPower() - Events.Player.GetAbilityCost());
                          WPN = WPN + "\n  " + NAME + " telepathically reads the\n"
                              + "  the opponent's mind. The opponent doesn't\n"
                              + "  seem to be thinking anything, not that could\n"
                              + "  be used for combat, anyway. A weapon might\n"
                              + "  be a lot more useful.\n"
                              + "  Remaining Mutant Power: " + 
                              Events.Player.GetMutantPower();
                       }
                       else
                       { 
                          WPN = WPN + 
                          "\n  You do not have enough mutant power to use MINDREAD.\n"
                          + "  Without telekenisis, mind as well use your hands...\n";

                          Events.Player.SetUseMINDREAD(false);
                          UseHand = true;
                       }
                  }

                  else if(Events.Player.GetUseTIMESHIFT())
                  {    WPN = WPN + "\n\n  Simultaneous attack with WEAPON and ABILITY!\n";
                       if(Events.Player.GetMutantPower() -
                       Events.Player.GetAbilityCost() > 0)
                       {
                          damage = (damage + Events.Player.GetAbilityCost()) * 3;
                          Events.Player.SetMutantPower(
                          Events.Player.GetMutantPower() - Events.Player.GetAbilityCost());
                          WPN = WPN + "\n  " + NAME + " shifts time around the opponent.\n"
                              + "  This, if only for a brief moment, gives you\n"
                              + "  time to attack your opponent three times\n"
                              + "  a counter-attack or defensive maneuver can\n"
                              + "  be initiated.\n"
                              + "  Remaining Mutant Power: " + Events.Player.GetMutantPower();
                       }
                       else
                       { 
                          WPN = WPN + 
                          "\n  You do not have enough mutant power to use MINDREAD.\n"
                          + "  Without telekenisis, mind as well use your hands...\n";

                          Events.Player.SetUseTIMESHIFT(false);
                          UseHand = true;
                       }
                  }

              }

              else
              {
                  if(CHAR_CLASS.equals("Freezer"))
                  {
                      WPN = " Freezing mutant attack. Ambient temperature\n"
                          + " lowering. So cold!";
                      MutantWars.WindIce.play();
                  }
                  
                  if(CHAR_CLASS.equals("Pyro"))
                  {
                      WPN = " Burning mutant attack. Spontaneously\n"
                          + " combusting. So hot!";
                      MutantWars.Explosion.play();
                  }
              }

              OUT = OUT + 
              "\n  -------------------- Attack for " + NAME + " --------------------"
              + "\n  " + opponent.GetName() + " hitpoints before attack: "
              + opponent.GetHit() + "  ";

              if(damage > opponent.GetDef())
              { damage = damage - opponent.GetDef(); }
              else { damage = 0; }

              if(opponent.GetHit() - damage > 0)
              { opponent.SetHit(opponent.GetHit() - damage); }
              else { opponent.SetHit(0); }

              OUT = OUT + "\n  " + opponent.GetName() + " hitpoints after attack: "
              + opponent.GetHit() + "\n"
              + "  ----------------------------------------------------------------\n";

              OUT = OUT + "\n" + WPN + "\n\n";
              MutantWars.MainOutput.setText(OUT);

       }

       //Public Accessor Methods
       public int GetHit() { return hitpoints; } 
       public void SetHit(int x) { hitpoints = x; }
       public int GetAtack() { return atack; }
       public void SetAtack(int x) { atack = x; }
       public int GetDef() { return defense; }
       public void SetDef(int x) { defense = x; }
       public int GetScore() { return score; }
       public void SetScore(int x) { score = x; }
       public void SetName(String n) { NAME = n; }
       public String GetName() { return NAME; }
       public void SetSex(String x) { SEX = x; }
       public String GetSex() { return SEX; }
       public void SetCharClass(String CHR) { CHAR_CLASS = CHR; } 
       public String GetCharClass() { return CHAR_CLASS; }                   

       //Inventory Accesors
       public void SetGun(boolean x) { Gun  = x; }
       public boolean GetGun() { return Gun ; }
       public void Set9mmAmmo(int x) { Ammo9mm = x; }
       public int Get9mmAmmo() { return Ammo9mm; } 
       public void SetMachete(boolean x) { Machete = x; }
       public boolean GetMachete() { return Machete; } 
       public void SetSyringe(boolean x) { Syringe = x; }
       public boolean GetSyringe() { return Syringe; } 
       public void SetSyringeCart(int x) { SyringeCartridge = x; }
       public int GetSyringeCart() { return SyringeCartridge; }
       public void SetJacket(boolean x) { Jacket  = x; }
       public boolean GetWearingJacket() { return WearingJacket ; }
       public void SetWearingJacket(boolean x) { WearingJacket  = x; }
       public boolean GetJacket() { return Jacket ; }
       public void SetMedKit(int x) { MedKit = x; }
       public int GetMedKit() { return MedKit; }
       public void SetMRErations(int x) { MRErations = x; }
       public int GetMRErations() { return MRErations; } 
       public void SetFramePack(boolean x) { FramePack  = x; }
       public boolean GetFramePack() { return FramePack ; }
       public void SetDataCrystal(boolean x) { datacrystal = x; }
       public boolean GetDataCrystal() { return datacrystal; }
       public void SetMatches(boolean x) { Matches = x; }
       public boolean GetMatches() { return Matches; }
       public void SetSterno(boolean x) { Sterno  = x; }
       public boolean GetSterno () { return Sterno ; }
       public void SetKeyCard(boolean x) { KeyCard = x; }
       public boolean GetKeyCard() { return KeyCard ; }
       public void SetKey(boolean x) { Key  = x; }
       public boolean GetKey() { return Key  ; }
       public void SetHumanGirl(boolean x) { FoundL1_HumanGirl = x; }
       public boolean GetHumanGirl() { return FoundL1_HumanGirl; }
       public String GetWeaponChoice() { return WeaponChoice; }
       public void SetWeaponChoice(String x) { WeaponChoice = x; }
       public void SetInventoryItem(String x) { InventoryItem = x; }
       public String GetInventoryItem() { return InventoryItem; }
       
       public void SetUseHand(boolean x) { UseHand = x; }
       public void SetUseGun(boolean x) { UseGun = x; }
       public void SetUseSyringe(boolean x) { UseSyringe = x; }
       public void SetUseMachete(boolean x) { UseMachete = x; }
       public void SetUseAbility(boolean x) { UseAbility = x; }

       public boolean GetUseHand() { return UseHand; }
       public boolean GetUseGun() { return UseGun; }
       public boolean GetUseSyringe() { return UseSyringe; }
       public boolean GetUseMachete() { return UseMachete; }
       public boolean GetUSeAbility() { return UseAbility; }

       //Private Data
       private int hitpoints = 100;
       private int atack = 1;
       private int defense = 1;
       private int score = 0;
       private String NAME = "";
       private String SEX = "UNDECIDED";
       private String CHAR_CLASS = "LIFEFORM";

       //Inventory Items
       private boolean Gun = false;
       private int Ammo9mm = 0;
       private boolean Syringe = false;
       private int SyringeCartridge = 0;
       private boolean Machete = false;
       
       private boolean UseGun = false;
       private boolean UseSyringe = false;
       private boolean UseMachete = false;
       private boolean UseAbility = false;
       private boolean UseHand = true;

       private boolean Jacket = false;
       private boolean WearingJacket = false;
       private int MedKit = 0;
       private int MRErations = 0;
       private boolean FramePack = false;
       private boolean datacrystal = false;
       private boolean Matches = false;
       private boolean Sterno = false;
       private boolean KeyCard = false;
       private boolean Key = false;
       private String WeaponChoice = "UNDECIDED";
       private boolean FoundL1_HumanGirl = false;
       private String InventoryItem = "Nothing";
       private int CONQUESTcount = 0;
       private String CONQUESTS = "";
}
