//Modular functions class used throughout the game.
//648 lines of code

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Functions
{
       String OUT = "";
       static Random RAND = new Random();
 
//-------------------------------------------------------------------------------

       public Functions() 
       { OUT = "\n\tCreating a Function class object."; MutantWars.MainOutput.setText(OUT);}

//-------------------------------------------------------------------------------

       //No method to convert String to boolean in Java as in C++, so let's make our own!     
       public static boolean TrueOrFalse(String x)
       {
              if(x.equals("true"))  { return true; }
              else { return false; }
       }
       
//-----------------------------------------------------------------------------
    
       //Uses new Random object declared up top in Globals
       public static int GRN(int x)  { return RAND.nextInt(x) + 1; }

//-----------------------------------------------------------------------------

       public static void Combat(LifeForm player, LifeForm opponent)
       { 
              //Events.GUI_INTERFACE.refresh();

              MutantWars.MainOutput.setText("\n  Mortal Combat!\n"
                                      + "  Lifeform attacks LifeForm.\n");

              try { Thread.sleep(3000); }
              catch(Exception e) { }

              //Randomize who attacks first
              int FirstAttack = GRN(2);

              //Player Attacks First
              if(FirstAttack == 1)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                        //Only allow attack if alive. No post-mortem.
                        if(player.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            player.Attack(opponent);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(5200); }
                            catch(Exception e) { }
                         }

                        if(opponent.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            opponent.Attack(player);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(4000); }
                            catch(Exception e) { }
                         }
                  }
              }

              if(FirstAttack == 2)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  {
                        //Only allow attack if alive. No post-mortem.
                        if(player.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            player.Attack(opponent);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(5200); }
                            catch(Exception e) { }
                         }

                        if(opponent.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            opponent.Attack(player);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(4000); }
                            catch(Exception e) { }
                        }
                  }
              }

              if(player.GetHit() > 0)
              { 
                MutantWars.MainOutput.setText("\n  The player wins this match!\n"); 
              }
              else 
              {
                Events.Player.SetHit(0);
                Events.Player.DisplayStats();
                Events.Player.ListInventory();
                MutantWars.MainOutput.setText("\n  Sorry, you were killed.\n");
              }

              Events.GUI_INTERFACE.refresh();
              try { Thread.sleep(3000); }
              catch(Exception e) { }

              if(Events.Player.GetAlreadyFlying())
              {  
                Events.Player.SetAlreadyFlying(false);
                Events.Player.SetDef(Events.Player.GetDef() - 3);
              }
       }

//-----------------------------------------------------------------------------


// Examples for Combat Function Overloading
//-----------------------------------------------------------------------------

         public static void Combat(Mutant player, Human opponent)
         {
              //Events.GUI_INTERFACE.refresh();

              MutantWars.MainOutput.setText("\n  Mortal Combat!\n"
                                      + "  Lifeform attacks Human.\n");

              try { Thread.sleep(3000); }
              catch(Exception e) { }

              //Randomize who attacks first
              int FirstAttack = GRN(2);

              //Player Attacks First
              if(FirstAttack == 1)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                        //Only allow attack if alive. No post-mortem.
                        if(player.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            player.Attack(opponent);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(5200); }
                            catch(Exception e) { }
                         }

                        if(opponent.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            opponent.Attack(player);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();;
                            try { Thread.sleep(4000); }
                            catch(Exception e) { }
                         }
                  }
              }

              if(FirstAttack == 2)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  {
                        //Only allow attack if alive. No post-mortem.
                        if(player.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            player.Attack(opponent);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(5200); }
                            catch(Exception e) { }
                         }

                        if(opponent.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            opponent.Attack(player);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();;
                            try { Thread.sleep(4000); }
                            catch(Exception e) { }
                        }
                  }
              }

              if(player.GetHit() > 0)
              { 
                MutantWars.MainOutput.setText("\n  The player wins this match!\n"); 
              }
              else 
              {
                Events.Player.SetHit(0);
                Events.Player.DisplayStats();
                Events.Player.ListInventory();
                MutantWars.MainOutput.setText("\n  Sorry, you were killed.\n");
              }
              
              Events.GUI_INTERFACE.refresh();
              try { Thread.sleep(3000); }
              catch(Exception e) { }

              if(Events.Player.GetAlreadyFlying())
              {  
                Events.Player.SetAlreadyFlying(false);
                Events.Player.SetDef(Events.Player.GetDef() - 3);
              }

         }

//-----------------------------------------------------------------------------

         public static void Combat(Mutant player, Mutant opponent)
         {
                //Events.GUI_INTERFACE.refresh();

              MutantWars.MainOutput.setText("\n  Mortal Combat!\n"
                                      + "  Mutant attacks Mutant.\n");

              //Events.GUI_INTERFACE.refresh();
              try { Thread.sleep(3000); }
              catch(Exception e) { }

              //Randomize who attacks first
              int FirstAttack = GRN(2);

              //Player Attacks First
              if(FirstAttack == 1)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  { 
                        //Only allow attack if alive. No post-mortem.
                        if(player.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            player.Attack(opponent);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(5400); }
                            catch(Exception e) { }
                         }

                        if(opponent.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            opponent.Attack(player);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(4000); }
                            catch(Exception e) { }
                         }
                  }
              }

              if(FirstAttack == 2)
              {
                  while(player.GetHit() > 0 && opponent.GetHit() > 0)
                  {
                        //Only allow attack if alive. No post-mortem.
                        if(player.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            player.Attack(opponent);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(5400); }
                            catch(Exception e) { }
                         }

                        if(opponent.GetHit() > 0)
                        {
                            MutantWars.MainOutput.setText("");
                            opponent.Attack(player);
                            Events.Player.DisplayStats();
                            Events.Player.ListInventory();
                            try { Thread.sleep(4000); }
                            catch(Exception e) { }
                        }
                  }
              }

              if(player.GetHit() > 0)
              { 
                MutantWars.MainOutput.setText("\n  The player wins this match!\n"); 
              }
              else 
              {
                Events.Player.SetHit(0);
                Events.Player.DisplayStats();
                Events.Player.ListInventory();
                MutantWars.MainOutput.setText("\n  Sorry, you were killed.\n");
              }
              
              //Events.GUI_INTERFACE.refresh();
              try { Thread.sleep(3000); }
              catch(Exception e) { }

              if(Events.Player.GetAlreadyFlying())
              {  
                Events.Player.SetAlreadyFlying(false);
                Events.Player.SetDef(Events.Player.GetDef() - 3);
              }

         }

//-----------------------------------------------------------------------------

       // Function - SaveHighScores
       public static void SaveHighScores(LifeForm player)
       {
            String OUT = "\n\n\n";

            try
            {
                File scores = new File("highscores.txt");
                FileOutputStream highscores;
                
                if (scores.exists())
		{
                    //If "true", don't destroy previous, append 2 arguments
		    OUT = OUT +
                    " The file \"highscores.txt\" already exists.\n" 
                    + "Appending new score to it...";
		    highscores = new FileOutputStream(scores, true);
		}
		else
		{
                    //Create new, no append, just 1 argument
		    OUT =  OUT +
                    " The file \"highscores.txt\" does not exist.\n I'll create it!";
		    highscores = new FileOutputStream(scores);
		}                

                PrintStream hiscores = new PrintStream(highscores);
                hiscores.println(player.GetName());
                hiscores.println(player.GetScore());
                hiscores.close(); highscores.close();
            }

            catch (IOException e) 
            { 
                OUT = OUT + "ERROR saving scores.";
            }

            MutantWars.MainOutput.setText(OUT);

       }  //close SaveHighScores() function

//-------------------------------------------------------------------------
    
       // Function - DisplayHighScores
       public static void DisplayHighScores()
       {
               String OUT = "";

               String HoldMeStringName = ""; 
               String HoldMeStringInteger = "";
               int HoldMeInteger = 0;
               int z = 0; 
               int x = 0;

               try 
               {        
                   File scores = new File("highscores.txt");
                   FileInputStream highscores = new FileInputStream(scores);
                   InputStreamReader hiscores = new InputStreamReader(highscores);
                   BufferedReader SCORES = new BufferedReader(hiscores);

                   while(HoldMeStringName != null)
                   {
                       HoldMeStringName = SCORES.readLine();
                       HoldMeStringInteger = SCORES.readLine();
                       x++;  //add one for every 2 lines (name and score pair) 
                   }
                     
                   x = x - 1; //Subtract 1 for the offset (one too many)
                     
                   String[] NAMES = new String[x];
                   int[] TheSCORES = new int[x];
                     
                   //Reset all stream and file objects, move pointer back to beginning 
                   scores = new File("highscores.txt");
                   highscores = new FileInputStream(scores);
                   hiscores = new InputStreamReader(highscores);
                   SCORES = new BufferedReader(hiscores);
                     
                   //Put each line into
                   for(z = 0; z < x; z++)
                   {
                       NAMES[z] = SCORES.readLine();
                       HoldMeStringInteger = SCORES.readLine();
                       TheSCORES[z] = Integer.parseInt(HoldMeStringInteger);

                   }
                     
                     highscores.close();
                     
                     OUT = " Total of " + x + " score records present\n in file.\n";
                     MutantWars.MainOutput.setText(OUT);
        
                     //Bubble Sort - Multi-Array
                     for(int q = 0; q < x; q++)
                     {
                         for(int r = 1; r < x; r++)
                         {
                             if(TheSCORES[r] > TheSCORES[r - 1])
                             {
                                HoldMeInteger = TheSCORES[r];
                                HoldMeStringName = NAMES[r];
                                TheSCORES[r] = TheSCORES[r - 1]; 
                                NAMES[r] = NAMES[r - 1];
                                TheSCORES[r - 1] = HoldMeInteger; 
                                NAMES[r - 1] = HoldMeStringName;           
                             }
                         }
                     } 
        
                     OUT = 
                     "***************** High Scores *****************\n\n";
                     OUT = OUT + 
                     "-----------------------------------------------\n";

	             for(z = 0; z < x; z++)
                     {
                        OUT = OUT + " " + (z+1) + ". Name: " + NAMES[z] +
                                         "  Score: " + TheSCORES[z] + "\n";
                        OUT = OUT +
                     "-----------------------------------------------\n";
                     }

	             OUT = OUT +
                     "\n***********************************************\n";

                     MutantWars.MainOutput.setText(OUT);

               }
               
               catch(IOException e)
               {
                   OUT =
                   " Unable to find \"highscores.txt\" or read scores.\n";
                   MutantWars.MainOutput.setText(OUT);
               }
         
               //Declared 2 Parallel Arrays where # elements = # lines.
               //Above is a Bubble Sort for High Scores. Go through each Name
               //and Score set and swap to arrange in descending order

       }//close DisplayHighScores() Function



//-------------------------------------------------------------------------
       
       public static void SaveCharacter(Mutant player)
       {
               String OUT = "";
               String CharacterName = player.GetName();

               CharacterName = CharacterName + ".gam";

               try
               {
                   Events.PlayerFile = new File(CharacterName);
                   Events.PlayerOut = new FileOutputStream(Events.PlayerFile);
                   Events.WritePlayer = new PrintStream(Events.PlayerOut);

                   //Simple Serialization of Character class in plain ASCII

                   //Save Character Attributes
                   Events.WritePlayer.println(player.GetName());
                   Events.WritePlayer.println(player.GetSex());
                   Events.WritePlayer.println(player.GetHit());
                   Events.WritePlayer.println(player.GetAtack());
                   Events.WritePlayer.println(player.GetDef());
                   Events.WritePlayer.println(player.GetScore());
                   Events.WritePlayer.println(player.GetCharClass());

                   //Save Mutant Ablity Data
                   Events.WritePlayer.println(player.GetFLY());
                   Events.WritePlayer.println(player.GetFREEZE());
                   Events.WritePlayer.println(player.GetHEAL());
                   Events.WritePlayer.println(player.GetMINDREAD());
                   Events.WritePlayer.println(player.GetFIRE());
                   Events.WritePlayer.println(player.GetMOVE());
                   Events.WritePlayer.println(player.GetTIMESHIFT());
                   Events.WritePlayer.println(player.GetMutantPower());

                   //Save Character Inventory
                   Events.WritePlayer.println(player.GetDataCrystal());
                   Events.WritePlayer.println(player.GetMachete());
                   Events.WritePlayer.println(player.GetGun());
                   Events.WritePlayer.println(player.Get9mmAmmo());
                   Events.WritePlayer.println(player.GetSyringe());
                   Events.WritePlayer.println(player.GetSyringeCart());
                   Events.WritePlayer.println(player.GetMatches());
                   Events.WritePlayer.println(player.GetFramePack());
                   Events.WritePlayer.println(player.GetMedKit());
                   Events.WritePlayer.println(player.GetMRErations());
                   Events.WritePlayer.println(player.GetJacket());
                   Events.WritePlayer.println(player.GetSterno());
                   Events.WritePlayer.println(player.GetKeyCard());
                   Events.WritePlayer.println(player.GetKey());

                   switch(Events.LEVEL)
                   {
                      case 1: Events.Level1Events.SaveLevel(CharacterName); break;
                      //As New Levels are added, they will be placed here like so:
                      //case 2: Events.Level2Events.SaveLevel(CharacterName); break;
                      //case 3: Events.Level3Events.SaveLevel(CharacterName); break;
                   }

                   Events.WritePlayer.close(); Events.PlayerOut.close();
            }

            catch(IOException e) 
            { 
                OUT = "ERROR saving character file.";
            }
       }

//-------------------------------------------------------------------------

       public static void LoadCharacter(Mutant player)
       {
               String OUT = "";
               String CharacterName = player.GetName();
               CharacterName = CharacterName + ".gam";

               try
               {
                  Events.PlayerFile = new File(CharacterName);
                  Events.PlayerIn = new FileInputStream(Events.PlayerFile);
                  Events.ReadPlayer = new InputStreamReader(Events.PlayerIn);
                  Events.StreamPlayer = new BufferedReader(Events.ReadPlayer);

                     //Careful! serialization = you must read in exactly
                     //the same order as you wrote!

                     //Character Attributes
                     String PlayerName = Events.StreamPlayer.readLine();
                     String PlayerSex = Events.StreamPlayer.readLine();
                     String PlayerHit = Events.StreamPlayer.readLine();
                     String PlayerAttack = Events.StreamPlayer.readLine();
                     String PlayerDefense = Events.StreamPlayer.readLine();
                     String PlayerScore = Events.StreamPlayer.readLine();
                     String PlayerClass = Events.StreamPlayer.readLine();

                     //Read Mutant Ablity Data
                     String fly = Events.StreamPlayer.readLine();
                     String freeze = Events.StreamPlayer.readLine();
                     String heal = Events.StreamPlayer.readLine();
                     String mindread = Events.StreamPlayer.readLine();
                     String fire = Events.StreamPlayer.readLine();
                     String move = Events.StreamPlayer.readLine();
                     String timeshift = Events.StreamPlayer.readLine();
                     String mutantpower = Events.StreamPlayer.readLine();

                     //Read Character Inventory
                     String datacrystal = Events.StreamPlayer.readLine();
                     String machete = Events.StreamPlayer.readLine();
                     String gun = Events.StreamPlayer.readLine();
                     String ammo9mm = Events.StreamPlayer.readLine();
                     String syringe = Events.StreamPlayer.readLine();
                     String syringecart = Events.StreamPlayer.readLine();
                     String matches = Events.StreamPlayer.readLine();
                     String framepack = Events.StreamPlayer.readLine();
                     String medkit = Events.StreamPlayer.readLine();
                     String mrerations = Events.StreamPlayer.readLine();
                     String jacket = Events.StreamPlayer.readLine();
                     String sterno = Events.StreamPlayer.readLine();
                     String keycard = Events.StreamPlayer.readLine();
                     String key = Events.StreamPlayer.readLine();
                     
                     //Set player attributes
                     player.SetName(PlayerName);
                     player.SetSex(PlayerSex);
                     player.SetHit(Integer.parseInt(PlayerHit));
                     player.SetAtack(Integer.parseInt(PlayerAttack));
                     player.SetDef(Integer.parseInt(PlayerDefense));
                     player.SetScore(Integer.parseInt(PlayerScore));
                     player.SetCharClass(PlayerClass);

                     //Set player mutant abiliites
                     player.SetFLY(TrueOrFalse(fly));
                     player.SetFREEZE(TrueOrFalse(freeze));
                     player.SetHEAL(TrueOrFalse(heal));
                     player.SetMINDREAD(TrueOrFalse(mindread));
                     player.SetFIRE(TrueOrFalse(fire));
                     player.SetMOVE(TrueOrFalse(move));
                     player.SetTIMESHIFT(TrueOrFalse(timeshift));
                     player.SetMutantPower(Integer.parseInt(mutantpower)); 

                     //Set player inventory
                     player.SetDataCrystal(TrueOrFalse(datacrystal));
                     player.SetMachete(TrueOrFalse(machete));
                     player.SetGun(TrueOrFalse(gun));
                     player.Set9mmAmmo(Integer.parseInt(ammo9mm));
                     player.SetSyringe(TrueOrFalse(syringe));
                     player.SetSyringeCart(Integer.parseInt(syringecart));
                     player.SetMatches(TrueOrFalse(matches));
                     player.SetFramePack(TrueOrFalse(framepack));
                     player.SetMedKit(Integer.parseInt(medkit));
                     player.SetMRErations(Integer.parseInt(mrerations));
                     player.SetJacket(TrueOrFalse(jacket));
                     player.SetSterno(TrueOrFalse(sterno));
                     player.SetKeyCard(TrueOrFalse(keycard));
                     player.SetKey(TrueOrFalse(key));

                   switch(Events.LEVEL)
                   {
                      case 1: Events.Level1Events.LoadLevel(CharacterName); break;
                      //Haven't been built yet, but this is how we'd save future levels.
                      //case 2: Events.Level2Events.LoadLevel(CharacterName); break;
                      //case 3: Events.Level3Events.LoadLevel(CharacterName); break;
                   }

                     Events.ReadPlayer.close(); Events.PlayerIn.close();
                     
                     player.DisplayStats();
                     player.ListInventory();
                     MutantWars.WEAPONS();
                     MutantWars.ABILITIES();
                     Events.SwitchBoard();
            }

            catch(IOException e)
            {
                OUT = "\tUnable to create character file.\n";
                MutantWars.MainOutput.setText(OUT);
            }

       }//close LoadCharacter() function 

//-------------------------------------------------------------------------

}
