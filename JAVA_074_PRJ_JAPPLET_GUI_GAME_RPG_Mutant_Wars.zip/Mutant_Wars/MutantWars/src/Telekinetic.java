//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class Telekinetic extends Mutant
{
       public Telekinetic() 
       {  
              String OUT = "\n\tCreating an Telekinetic mutant.";
              MutantWars.MainOutput.setText(OUT);
       }

       public Telekinetic(String x)
       { 
              String OUT = "\n\tCreating an Telekinetic mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
       } 

       //Functions
       public void MindMove() 
       { 
              String OUT = "\n\tMoving object telekinetically...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesors
       

       //Private Data
}
