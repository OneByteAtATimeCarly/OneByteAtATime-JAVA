//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 35 lines of code

import javax.swing.*;
import java.io.*;

public class MindReader extends Mutant
{
       public MindReader() 
       {  
              String OUT = "\n\tCreating a MindReader mutant.";
              MutantWars.MainOutput.setText(OUT);
       }


       public MindReader(String x)
       { 
              String OUT = "\n\tCreating a MindReader mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
       } 

       //Functions
       public void MindRead() 
       { 
              String OUT = "\n\tReading a mind...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesors
       

       //Private Data
}
