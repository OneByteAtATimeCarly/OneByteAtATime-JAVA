//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 45 lines of code

import javax.swing.*;
import java.io.*;

public class Freezer extends Mutant
{
       public Freezer()
       {  
              String OUT = "\n\tCreating a Freezer Mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetCharClass("Freezer");
       }

       public Freezer(String x)
       { 
              String OUT = "\n\tCreating a Freezer Mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
              SetCharClass("Freezer");
       }       

       public Freezer(String x, int hit)
       { 
              String OUT = "\n\tCreating a Freezer Mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
              SetHit(hit);
              SetCharClass("Freezer");
       }

       //Functions
       public void Freeze() 
       { 
              String OUT = "\n\tFreezing...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesors
       

       //Private Data
}
