                                                                              //Mutant Wars 1.5 for Java - Charles Germany - 2007
//First Two Rings of Level 1 Completed.
//3513 lines of code for this class.  This class is 2 of 23.
//Events shell for Level 1.

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Level1
{
       String OUT = "";

//---------------------- Level 1 Location Tracking Globals-------------------

       //Location Tracking Constants
       public static final int QUIT = 0;
       public static final int C1 = 1;
       public static final int C1Roof = 2;
       public static final int C1Basement = 3;
       public static final int N1 = 4;
       public static final int S1 = 5;
       public static final int E1 = 6;
       public static final int E1Closet = 7;
       public static final int W1 = 8;
       public static final int N2 = 9;
       public static final int N2Garage = 10;
       public static final int N2Service = 11;
       public static final int S2 = 12;
       public static final int E2 = 13;
       public static final int W2 = 14;
       public static final int Surface = 15;
       public static final int BOSSFIGHT_L1 = 16;
       public static final int INTRO = 17;

       public static final int DATATerminal = 18;
       public static final int TheFRIDGE = 19;
       public static final int FREEZERFIGHT = 20;
       public static final int THESAFE = 21;
       
       public static final int SpiderImage = 22;
       public static final int RoachImage = 23;
       public static final int FreezerMutant1Image = 24;
       public static final int FreezerMutant2Image = 25;
       public static final int PyroMutant1Image = 26;
       public static final int PyroMutant2Image = 27;
       public static final int MutantMixImage = 28;

       public static int LOCATION = INTRO; //starts here
       public int INTROPAGE = 1;

       public static boolean MapC1 = false;
       public static boolean MapC1Roof = false;
       public static boolean MapC1Basement = false;
       public static boolean MapN1 = false;
       public static boolean MapS1 = false;
       public static boolean MapE1 = false;
       public static boolean MapE1Closet = false;
       public static boolean MapW1 = false;
       public static boolean MapN2 = false;
       public static boolean MapN2Garage = false;
       public static boolean MapN2Service = false;
       public static boolean MapS2 = false;
       public static boolean MapE2 = false;
       public static boolean MapW2 = false;
       public static boolean MapSurface = false;

//--------- Level 1 GLOBALS --------------------------

       //Declare and Initialize Event Data
       public final int KeyCode = 777;
       public boolean C1FirstTime = true;
       public boolean DataCrystalTaken = false;
       public boolean Found9mmAmmo = false;
       public boolean Found9mmAmmoBox = false;
       public boolean CardReaderActivated = false;
       public boolean Center1BasementFirstTime = true;
       public boolean DrankSoda = false;
       public boolean AteSandwhich = false;
       public boolean FoundMachete = false;
       public boolean FoundSyringe = false;
       public boolean FoundMatches = false;
       public boolean FoundFramePack = false;
       public boolean FoundMedKit = false;
       public boolean FoundMRERations = false;
       public boolean FoundSterno = false;
       public boolean N2FirstTime = true;
       public boolean FoundJacket = false;
       public boolean ExplodedTripBomb = false;
       public boolean FoundGun = false;
       public boolean FoundKeyCard = false;
       public boolean SwipedKeyCard = false;
       public boolean SurfaceDoorsLocked = true;
       public boolean East2FirstTime = true;
       public boolean West2FirstTime = true;
       public boolean FoughtFreezerMutant = false;
       public boolean RanAwayFromFreezerMutant = false;
       public boolean FoundKey = false;
       public boolean SafeFirstTime = true;
       public boolean SafeUnlocked = false;
       public boolean KEYinserted = false;
       public boolean FoundL1_HumanGirl = false;
       public boolean FromAtrium = false;
       public boolean FromBelow = false;

//-------------------------------------------------------------------------------
       //Constructor
       public Level1() 
       { 
          InitializeGlobals();
          InitializeMap();
       }
//-------------------------------------------------------------------------------

       public void Switchboard()
       {
              switch(LOCATION)
              {
                   case C1 : MapC1 = true; Center1(); break;
                   case C1Roof : MapC1Roof = true; Center1Roof(); break;
                   case C1Basement : MapC1Basement = true; Center1Basement(); break;
                   case N1 : MapN1 = true; North1(); break;
                   case S1 : MapS1 = true; South1(); break;
                   case E1 : MapE1 = true; East1(); break;
                   case E1Closet : MapE1Closet = true; East1Closet(); break;
                   case W1 : MapW1 = true; West1(); break;
                   case N2 : MapN2 = true; North2(); break;
                   case N2Garage : MapN2Garage = true; North2Garage(); break;
                   case N2Service : MapN2Service = true; N2ServiceCorridor(); break;
                   case S2 : MapS2 = true; South2(); break;
                   case E2 : MapE2 = true; East2();  break;
                   case W2 : MapW2 = true; West2();  break;
                   case Surface : MapSurface = true; SurfaceAccess(); break;
                   case BOSSFIGHT_L1 : FinalBossFight(); break;
                   case INTRO : MapC1 = true; Intro(); break;
                   case DATATerminal : DataTerminalAccess(); break;
                   case TheFRIDGE : TheFridge(); break;
                   case FREEZERFIGHT : L1_FreezerMutantFight(); break;
                   case THESAFE : TheSafe(); break;
                   case QUIT : Events.GameOver(); break;
                   case SpiderImage : break;        //Do nothing, displays image only
                   case RoachImage : break;         //Do nothing, displays image only
                   
                   //FinalBossFight, display images
                   case FreezerMutant1Image: FinalBossFight(); break; 
                   case FreezerMutant2Image: FinalBossFight(); break;
                   case PyroMutant1Image:    FinalBossFight(); break;
                   case PyroMutant2Image:    FinalBossFight(); break;
                   case MutantMixImage:      FinalBossFight(); break;
                   default : OUT = OUT + "Invalid input from switchboard...";
                             MutantWars.MainOutput.setText(OUT);
                             break;
              }

              if(Events.Player.GetHit() == 0)
              {
                   MutantWars.MainOutput.setText("\n\n\n Apparently, you died.\n" +
                                             " Click \"GO\" to continue.\n\n");
                   MutantWars.LOCK = false;
                   LOCATION = QUIT;
              }
       }

//-------------------------------------------------------------------------------

       void InitializeGlobals()
       {
            Events.Player.InitializeInventory();
            LOCATION = INTRO;
            INTROPAGE = 1;
            C1FirstTime = true;
            DataCrystalTaken = false;
            Found9mmAmmo = false;
            Found9mmAmmoBox = false;
            CardReaderActivated = false;
            Center1BasementFirstTime = true;
            DrankSoda = false;
            AteSandwhich = false;
            FoundMachete = false;
            FoundSyringe = false;
            FoundMatches = false;
            FoundFramePack = false;
            FoundMedKit = false;
            FoundMRERations = false;
            FoundSterno = false;
            N2FirstTime = true;
            FoundJacket = false;
            ExplodedTripBomb = false;
            FoundGun = false;
            FoundKeyCard = false;
            SwipedKeyCard = false;
            SurfaceDoorsLocked = true;
            East2FirstTime = true;
            West2FirstTime = true;
            FoughtFreezerMutant = false;
            RanAwayFromFreezerMutant = false;
            FoundKey = false;
            SafeFirstTime = true;
            SafeUnlocked = false;
            KEYinserted = false;
            FromAtrium = false;
            FromBelow = false;
            FoundL1_HumanGirl = false;
            MutantWars.LOCK = false;
       }
//-----------------------------------------------------------------------------
       public void InitializeMap()
       {
              MapC1 = true;
              MapC1Roof = false;
              MapC1Basement = false;
              MapN1 = false;
              MapS1 = false;
              MapE1 = false;
              MapE1Closet = false;
              MapW1 = false;
              MapN2 = false;
              MapN2Garage = false;
              MapN2Service = false;
              MapS2 = false;
              MapE2 = false;
              MapW2 = false;
              MapSurface = false;
       }
//-----------------------------------------------------------------------------
       public void MapCheat()
       {
              MapC1 = true;
              MapC1Roof = true;
              MapC1Basement = true;
              MapN1 = true;
              MapS1 = true;
              MapE1 = true;
              MapE1Closet = true;
              MapW1 = true;
              MapN2 = true;
              MapN2Garage = true;
              MapN2Service = true;
              MapS2 = true;
              MapE2 = true;
              MapW2 = true;
              MapSurface = true;
       }

//-----------------------------------------------------------------------------


       public void Intro()
       {
              switch(INTROPAGE)
              {
                 case 1 : OUT = "\n\n Please enter a name for your character\n"
                              + " in the input field above.\n\n";
                          OUT = OUT + " Click the \"GO\" button to continue.";
                          MutantWars.MainOutput.setText(OUT);
                          MutantWars.Input.setText("Enter your name HERE.");
                          MutantWars.Input.requestFocus(); //Changes Focus
                          MutantWars.Input.selectAll();
                          if(MutantWars.NARRATE) { MutantWars.PleaseEnterName.play(); }
                          INTROPAGE++;
                          break;

                 case 2 : Events.Player.SetName(MutantWars.Input.getText().toUpperCase());
                          OUT = "\n\n  " + Events.Player.GetName() + "?\n\n"
                                + "  That is an admirable and honorable name.\n"
                                + "  Welcome to MutantWars " +
                                Events.Player.GetName() + "!\n\n"
                                + "  Click \"GO\" to continue.";
                          MutantWars.Input.setText("");
                          MutantWars.MainOutput.setText(OUT);
                          if(MutantWars.NARRATE)
                          { 
                            MutantWars.PleaseEnterName.stop();
                            MutantWars.ThatIsAnAdmirableName.play();
                          }
                          INTROPAGE++;
                          break;

                 case 3 : OUT = "\n\n  Please choose your character's sex:\n"
                              + "  [M]ale or [F]emale ?\n\n\n"
                              + "  Enter your choice in the input box above.\n"
                              + "  Click \"GO\" to continue.";

                          MutantWars.MainOutput.setText(OUT);
                          MutantWars.Input.requestFocus();
                          if(MutantWars.NARRATE) 
                          {
                             MutantWars.ThatIsAnAdmirableName.stop();
                             MutantWars.ChooseSex.play();
                          }
                          INTROPAGE++;
                          break;

                 case 4 : String SEX = MutantWars.Input.getText().toLowerCase();
                                 OUT = "\n\n  " + Events.Player.GetName() + 
                                       ", you begin the game as";

                          MutantWars.ChooseSex.stop();

                          switch(SEX.charAt(0))
                          {
                               case 'm' : 
                               Events.Player.SetSex("MALE");
                               OUT = OUT + "\n  a handsome, strapping young lad!";
                               if(MutantWars.NARRATE) { MutantWars.YouBeginMale.play(); }
                               break;

                               case 'f' : 
                               Events.Player.SetSex("FEMALE");
                               OUT = OUT + "\n  a beautiful, confident young lady!";
                               if(MutantWars.NARRATE) 
                               { MutantWars.YouBeginFemale.play(); }
                               break;

                               default : 
                               Events.Player.SetSex("An \"IT\"");
                               OUT = OUT + "\n  an IT, as you were unable to"
                                         + "\n  decide your gender!";
                               Events.Player.SetName(
                               "ANDROGENOUS " + Events.Player.GetName());
                               if(MutantWars.NARRATE) 
                               { MutantWars.YouBeginIT.play(); }
                               break;
                          }
                          OUT = OUT + "\n\n  Of course, you are also an Impath. You can,"
                              + "\n  over time, absorb other mutant's abilities...";
                          OUT = OUT + "\n\n  Click \"GO\" to continue on with the game.";
                          Events.Player.DisplayStats();
                          Events.Player.ListInventory();
                          MutantWars.Input.setText("g");
                          MutantWars.MainOutput.setText(OUT);

                          if(MutantWars.NARRATE) 
                          {  //Wait for last narration to finish
                          
                       //-------------------------------------
                          SwingWorker worker = new SwingWorker()
                          {
                               public Object construct()
                               {
                                      try { Thread.sleep(4350); }
                                      catch(Exception e) { }
                                      MutantWars.YouBeginFemale.stop();
                                      MutantWars.YouBeginMale.stop();
                                      MutantWars.YouBeginIT.stop();
                                      MutantWars.YouBeginLastPart.play();
                                      return 0;
                               }
                               public void finished() {  }
                          };
                          worker.start();
                       //-------------------------------------
                          }
                          INTROPAGE++;
                          break;

                 case 5 : if(MutantWars.MUSIC) 
                          { MutantWars.ThemeMusic.loop(); }
                          if(MutantWars.NARRATE)
                          {
                             MutantWars.YouBeginLastPart.stop();
                             MutantWars.INTRO1.play();
                          }

                          OUT = "                   Mutant Wars for Java  -  1.0\n"
                              + "                     Charles Germany - 2007\n\n"
                              + "  It is the year 2050 - 20 long years since the war\n"
                              + "  between humans and mutants brought\n"
                              + "  unbelieveable devastation to all of earth's\n"
                              + "  inhabitants. Some called it survival of the\n"
                              + "  fittest, a rite of passage for those who\n"
                              + "  survived and extinction for those who didn't.\n\n"
                              + "  Now, with the exception of a few scattered \n"
                              + "  bands of survivors, mutants are the only\n"
                              + "  inhabitants left upon the earth. Many mutant\n"
                              + "  genes lie dormant until puberty, others\n"
                              + "  manifest themselves at birth.\n\n"
                              + "  In this post-apocalyptic world, some mutant\n"
                              + "  traits are obvious to an observer, manifesting\n"
                              + "  themselves as aberrations of color and physical\n"
                              + "  form. Other mutant traits are concealed, masking\n"
                              + "  abilities beyond comprehension within an\n"
                              + "  otherwise unremarkable and frail human frame.\n";

                          OUT = 
                          OUT +  "\n\n" + "  Type \"G\" in the command box and click\n"
                          + "  the \"GO\" button to continue " 
                          + Events.Player.GetName() + "!";

                          MutantWars.Input.setText("g");
                          MutantWars.MainOutput.setText(OUT);
                          INTROPAGE++;
                          break;

                 case 6 : if(MutantWars.NARRATE) 
                          { 
                             MutantWars.INTRO1.stop();
                             MutantWars.INTRO2.play();
                          }

                          OUT = "\n  At first, the war was a matter of survival.\n"
                              + "  Humans who did not share the anomalies of\n"
                              + "  their mutant neighbors felt threatened by\n"
                              + "  what they could not understand. Eventually,\n"
                              + "  rationality and reason gave way to fear and\n"
                              + "  paranoia. Concentration camps were created\n"
                              + "  to contain what was seen as an increasing\n"
                              + "  threat and menace to society. Riots and civic\n"
                              + "  unrest ensued and the mutant phenomena was\n"
                              + "  almost eradicated completely from humanity.\n\n"
                              + "  At the brink of annihalation, a lone figure arose\n"
                              + "  among the mutants, rallying them together and\n"
                              + "  gathering their will to fight for survival. He\n"
                              + "  called himself \"Odyicis\", and led them in a\n"
                              + "  genocidal campaign to eradicate those who\n"
                              + "  would destroy mutant kind.\n\n"
                              + "  After 15 years, humans made their last stand\n"
                              + "  at a secret compound in White Sands, New\n"
                              + "  Mexico. A treaty was signed guaranteeing\n"
                              + "  their survival in exchange for unconditonal\n"
                              + "  surrender. They now number only a few\n"
                              + "  thousand and are too small to be any threat.";

                          OUT = OUT +  
                          "\n\n" + "  Type \"G\" and click \"GO\" to continue...";

                          MutantWars.Input.setText("g");
                          MutantWars.MainOutput.setText(OUT);
                          INTROPAGE++;
                          break;

                 case 7 : if(MutantWars.NARRATE)
                          {  
                             MutantWars.INTRO2.stop();
                             MutantWars.INTRO3.play();
                          }

                          OUT = "\n  For a time there was peace and relative\n"
                              + "  tranquility enveloped the inhabitants of\n"
                              + "  earth, both human and mutant. But while\n"
                              + "  the genetic structure of humanity had\n"
                              + "  changed, its nature had not. Two powerful\n"
                              + "  clans of mutants arose, both having the\n"
                              + "  capability to acquire the mutant abilities\n"
                              + "  of others. These were the Disectors and\n"
                              + "  Impaths.\n\n"
                              + "  The Disectors (commonly referred to as\n"
                              + "  Brain Eaters) had an unquenchable thirst\n"
                              + "  for power, and could acquire the abilities\n"
                              + "  of mutants they killed and disected. Once\n"
                              + "  a particular mutant class's ability was\n"
                              + "  acquired, all other mutants in that class\n"
                              + "  were either enslaved or destroyed as a\n"
                              + "  threat to the Disector clan's power and\n"
                              + "  domination. Disectors had to defeat their\n"
                              + "  opponents in battle and kill them before\n"
                              + "  they could acquire a new ability.\n"
                              + "  However, once acquired, they mastered\n"
                              + "  the ability instantly.\n";

                          OUT = OUT +  "\n\n" + 
                          "  Type \"G\" and click \"GO\" to continue...";
                          MutantWars.Input.setText("g");
                          MutantWars.MainOutput.setText(OUT);
                          INTROPAGE++;
                          break;

                 case 8 : if(MutantWars.NARRATE) 
                          { 
                             MutantWars.INTRO3.stop();
                             MutantWars.INTRO4.play();
                          }
                          OUT = "\n  The Impaths had the ability to acquire other\n"
                              + "  mutant's abilities, just as the Disectors. The\n"
                              + "  key difference was that they could acquire\n"
                              + "  another mutant's abilities just by standing\n"
                              + "  next to them. They did not have to defeat and\n"
                              + "  kill their opponent in battle, or even let\n"
                              + "  them know that they were absorbing their\n"
                              + "  abilities. They could acquire them in \"stealth\"\n"
                              + "  if necessary.\n\n"
                              + "  In some cases, an advanced Impath could\n"
                              + "  engage another mutant in combat, even a\n"
                              + "  Disector, and almost instantly use their\n"
                              + "  own abilities against them, as well as\n"
                              + "  any other abilities they had previously\n"
                              + "  acquired. This was extremely rare, however,\n"
                              + "  and only the most advanced Impaths were\n"
                              + "  capable of it. Unlike a Disector's instant\n"
                              + "  mastery of an acquired ability, it took an\n"
                              + "  average Impath  months, sometimes years to\n"
                              + "  master a newly acquired ability.\n";

                          OUT = OUT +  "\n\n" + 
                          "  Type \"G\" and click \"GO\" to continue...";
                          MutantWars.Input.setText("g");
                          MutantWars.MainOutput.setText(OUT);
                          INTROPAGE++;
                          break;

                 case 9 : if(MutantWars.NARRATE) 
                          { 
                             MutantWars.INTRO4.stop();
                             MutantWars.INTRO5.play();
                          }
                          OUT = "\n  You are a young Impath, aimlessly wandering\n"
                              + "  post-apocalyptic earth alone, looking for\n"
                              + "  others like yourself. Your have endured\n"
                              + "  years of solitude since the Disectors\n"
                              + "  slaughtered your village and destroyed your\n"
                              + "  clan's way of life. At one time, Impaths\n"
                              + "  were considered benign, and lived in relative\n"
                              + "  peace with both other mutants and humans.\n\n"
                              + "  Now there exists great distrust among\n"
                              + "  mutants and humans, and you can never be sure\n"
                              + "  when you meet a stranger whether they will be\n"
                              + "  your friend or foe. Pensively reflecting on\n"
                              + "  these fading memories, your thoughts drift\n"
                              + "  back to your present circumstances.\n";

                          OUT = OUT +  "\n\n" + 
                          "  Type \"G\" and click \"GO\" to continue...";
                          MutantWars.Input.setText("g");
                          MutantWars.MainOutput.setText(OUT);
                          INTROPAGE++;
                          MutantWars.LockButtons(false);
                          LOCATION = C1;  //Place player in start position
                          break;

                 default : MutantWars.MainOutput.setText
                           ("\nError. Invalid value in INTRO function!\n");
                           break;
              }
       }

//-----------------------------------------------------------------------------

       public void Center1()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              MutantWars.ButtonAction.setEnabled(true);

              if( MutantWars.WhatToDo == 'n' ||
                  MutantWars.WhatToDo == 's' ||
                  MutantWars.WhatToDo == 'e' ||
                  MutantWars.WhatToDo == 'w' ||
                  MutantWars.WhatToDo == 'u' ||
                  MutantWars.WhatToDo == 'd' ||
                  MutantWars.WhatToDo == 'l' ||
                  MutantWars.WhatToDo == 't'
                  )
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = C1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : LOCATION = N1; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 's' : LOCATION = S1; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick(); 
                                  break;

                       case 'e' : LOCATION = E1; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick(); 
                                  break;

                       case 'w' : LOCATION = W1; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick(); 
                                  break;

                       case 'u' : LOCATION = C1Roof;
                                  FromBelow = true;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick(); 
                                  break;

                       case 'd' : LOCATION = C1Basement; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 't' : if(!Events.Player.GetDataCrystal())
                                  {
                                    OUT = 
                                    "\n  You lift the crystal and put it in your pocket!"
                                    + "\n  It's shiny and way cool and you are pretty sure"
                                    + "\n  that it will be useful for something...\n\n";
                                    Events.Player.SetDataCrystal(true);
                                    Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                    OUT = "\n  Nothing else worth taking here.\n\n";
                                  }
                                  break;

                       default : OUT = OUT + "\n\n  Invalid input in CENTER 1...";
                                 MutantWars.MainOutput.setText(OUT);
                                 break;
                     }//close switch
                     MutantWars.INTRO6.stop();
                     //Second "if" is necessary to prvent string from
                     if( MutantWars.WhatToDo == 'n' ||
                         MutantWars.WhatToDo == 's' ||
                         MutantWars.WhatToDo == 'e' ||
                         MutantWars.WhatToDo == 'w' ||
                         MutantWars.WhatToDo == 'u' ||
                         MutantWars.WhatToDo == 'd' ||
                         MutantWars.WhatToDo == 'l' ||
                         MutantWars.WhatToDo == 't'
                    )
                    {
                        OUT = OUT +
                        "\n  Directions: (N)orth (S)outh (E)ast (W)est?\n\n"
                        + "  Possibilities: (L)ook  (U)pstairs  (D)ownstairs\n";
                    }
             MutantWars.MainOutput.setText(OUT);
             MutantWars.LOCK = true;

             }//close if

             //
             else
             {
                MutantWars.LOCK = true;

                if(C1FirstTime)
                {
                   OUT = "\n  You awake. Your head is pounding and you feel\n"
                       + "  groggy - drugged. In your mouth you taste the\n"
                       + "  acrid bitterness of some metalic salt. Staring\n"
                       + "  at the mildew stains on the ceiling, you slowly\n"
                       + "  gather your strength and raise yourself up\n"
                       + "  off of a cold and unforgiving surface.\n"
                       + "  Sitting up, blinking in the partial darkness,\n"
                       + "  you slowly become aware of your surroundings.\n";

                   C1FirstTime = false;
                   
                   if(MutantWars.NARRATE)
                   { 
                      MutantWars.INTRO5.stop();
                      MutantWars.INTRO6.play();
                      MutantWars.NARRATE = false;
                   }
               }
               else
               {
                  OUT = "\n  You return to where you originally\n"
                      + "  started, the TREATMENT ROOM.\n";
               }
               if(MutantWars.NARRATE)
               {
                  MutantWars.NARRATE = false;
               }

               OUT = OUT + "\n  You see a dimly lit cubicle, larger\n"
                   + "  than a typical living room. It is difficult\n"
                   + "  to make out any colors, and the only \n"
                   + "  illumination that you can see by appears to\n"
                   + "  be radiating from behind the red translucent\n"
                   + "  letters of two emergency exit signs.\n\n"
                   + "  You manage to ferret out six possible exits \n"
                   + "  amidst the shadows. To the north-west, you see\n"
                   + "  several steel tables with worn leather\n"
                   + "  restraints. Behind the tables you see a\n"
                   + "  door with stairs ascending towards the west. To\n"
                   + "  the south-east you see another door with stairs\n"
                   + "  descending into an erie glowing blue abyss.\n\n";

               OUT = OUT + "  You look and see four pale-white metal\n"
                   + "  doors leading to the north, south, east and\n"
                   + "  west on each wall of the room. Marked with \n"
                   + "  scratches, each has a dull gray box mounted on\n"
                   + "  the wall beside it for key card access.\n\n";

               OUT = OUT + "  To the east, you see several gurnies\n"
                   + "  was most probably used for shock treatment.\n"
                   + "  You can almost hear the screams of unwilling\n"
                   + "  participants receiving their \"treatment\" as\n"
                   + "  haunting echoes from the past.\n";

               if(!Events.Player.GetDataCrystal())
               {
                   OUT = OUT + "\n  On a shelf over one of the restraint\n"
                       + "  tables a sparkling crystal catches your eye. It\n"
                       + "  is next to a spool of twine and some tape.\n\n\n";
               }

                   OUT = OUT +
                   "\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n\n"
                   + "  Possibilities: (L)ook   (U)pstairs   (D)ownstairs\n";

                   if(!Events.Player.GetDataCrystal())
                   { OUT = OUT + "                           (T)ake crystal"; }

                   OUT = OUT + "\n\n\n";

               MutantWars.MainOutput.setText(OUT);

             } //close else 

       }//close function

//-----------------------------------------------------------------------------

       public void Center1Roof()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'd' ||
                 MutantWars.WhatToDo == 'l' ||
                 MutantWars.WhatToDo == 'p' ||
                 MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'c')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = C1Roof;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : if(!Found9mmAmmo)
                                  {
                                    OUT = "\n\n  You see a wall, too high and straight\n"
                                    + "  to scale. But at its solitary base you\n"
                                    + "  find 10 clips of ammo! Must have been the\n"
                                    + "  ammo in that box you saw...\n";
                                     Found9mmAmmo = true;
                                     Events.Player.Set9mmAmmo(
                                     Events.Player.Get9mmAmmo() + 10);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n\n  Once again you spy the wall,\n"
                                         + "  too high and straight to scale,\n"
                                         + "  but at its base you step upon\n"
                                         + "  a sharp and rusty nail!\n"
                                         + "  Insatiable, your putrid GREED\n"
                                         + "  has caused you here to fail,\n"
                                         + "  limping you continue on,\n"
                                         + "  no faster than a snail...\n\n"
                                         + "  You loose 4 life points!\n";
                                     Events.Player.SetHit(Events.Player.GetHit() - 4);
                                     Events.Player.DisplayStats();
                                     Events.Player.AddConquest("Rusty Nail");
                                  }
                                  break;

                       case 'e' : OUT = "\n\n  You brush against cold, hard concrete.\n";
                                  break;

                       case 's' : OUT = "\n\n  Exploring the south wall, you are\n"
                                            + "  apprehensive about touching it as\n"
                                            + "  it is covered with a thick, green,\n"
                                            + "  slimy moss.\n";
                                  break;

                       case 'w' : OUT = "\n\n  Looking closer at the west wall, you\n"
                                  + "  notice fresh blood stains along the\n"
                                  + "  south-west corner. A shiver goes up\n"
                                  + "  your spine. Someone or something recently\n"
                                  + "  met its demise here.\n";
                                  break;

                       case 'c' : LOCATION = N2Service;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'd' : LOCATION = C1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'p' : if(!Found9mmAmmoBox)
                                  {
                                     OUT = "\n  You pick up the box of ammo. Nifty.\n"
                                     + "  But there's no ammo inside it. Disgusted,\n"
                                     + "  you toss it up into the air and over the\n"
                                     + "  wall, never to be seen again.\n";
                                     Found9mmAmmoBox = true;
                                  }
                                  else
                                  { OUT = "\n  Eeew! You get a hand full of bird poo.\n"; }
                                  break;

                       default : OUT = "\n  Invalid input in C1Roof...";
                                 break;
                     }

                     if(MutantWars.WhatToDo == 'd' ||
                        MutantWars.WhatToDo == 'l' ||
                        MutantWars.WhatToDo == 'p' ||
                        MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'c')
                     {
                         OUT = OUT + "\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n"
                         + "  Possibilities: (L)ook  (D)ownstairs  (C)orridor\n";

                         if(!Found9mmAmmoBox && MutantWars.WhatToDo != 'p')
                         { OUT = OUT + "  (P)ick Up Ammo"; }

                     }

                     OUT = OUT + "\n\n\n";
                     MutantWars.MainOutput.setText(OUT);

                  MutantWars.LOCK = true;

             }//close if

             else
             {
                 MutantWars.LOCK = true;
                 if(MutantWars.SOUNDEFFECTS) { MutantWars.Wind.play();  }

                 if(FromBelow)
                 {
                   OUT = "\n\n  You climb up the stairs to the ROOF.\n"
                       + "  You press against the door and it swings\n"
                       + "  open. Fresh air, at last!\n\n";
                   FromBelow = false;
                 }

                 else
                 { OUT = "\n\n  You are standing on the ROOF.\n"; }

                 OUT = OUT + "  You are surrounded by walls 25 feet tall\n"
                     + "  and too smoothe to climb on all four sides.\n"
                     + "  Glancing upwards, you see gray-blue \n"
                     + "  skies and a few rays of pale moonlight\n"
                     + "  filtering through the whispy clouds\n"
                     + "  refracting the dusky overtones of the\n"
                     + "  rapidly setting sun. \n\n"
                     + "  To the north-east you see a reinforced steel\n"
                     + "  door with the words \"service corridor\"\n"
                     + "  stenciled above it.\n\n";

                if(!Found9mmAmmoBox)
                {
                   OUT = OUT + "  In the corner to your right you see\n"
                             + "  a large box of 9mm ammunition.\n";
                }
                else
                { OUT = OUT + "\n  Against the wall to your left you see\n"
                            + "  a large pile of bird dung.\n"; }

                  OUT = OUT + "\n  Where will you go?\n"
                            + "  (N)orth  (S)outh  (E)ast  (W)est?\n\n"
                            + "  Possibilities:\n  (L)ook  (D)ownstairs  (C)orridor\n";
                  if(!Found9mmAmmoBox) { OUT = OUT + "  (P)ick Up Ammo"; }

                OUT = OUT + "\n\n\n";

                MutantWars.MainOutput.setText(OUT);

             }//close else

       }//close function

//-----------------------------------------------------------------------------
       public void Center1Basement()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'u' ||
                 MutantWars.WhatToDo == 'd' ||
                 MutantWars.WhatToDo == 'l' ||
                 MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == '~' ||
                 MutantWars.WhatToDo == '|')
              {

                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = C1Basement;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : OUT = "  \n\n  Against the north wall, you see\n"
                                        + "  a shelf with disks and storage crystals.";
                                  break;

                       case 'e' : LOCATION = SpiderImage;
                                  Events.GUI_INTERFACE.refresh();  //For Graphics
                                  LOCATION = C1Basement;
                                  OUT = "  \n\n  Walking to the east end of the room, "
                                  + "you\n  disturb a nest of spider mites. Scampering\n"
                                  + "  in an angry frenzy, they painfully envenomate\n"
                                  + "  your left leg. You loose 5 life points!\n";
                                  if(Events.Player.GetHit() - 5 > 0)
                                  {
                                      Events.Player.SetHit(Events.Player.GetHit() - 5);
                                  }
                                  else { Events.Player.SetHit(0); }
                                  Events.Player.SetScore(Events.Player.GetScore() + 25);
                                  Events.Player.DisplayStats();
                                  Events.Player.AddConquest("Spider Mites");
                                  break;

                       case 's' : OUT = 
                                  "  \n\n  At the south end, a bank of servers humms,"
                                  + "\n  each one mounted vertically within a rack.\n";
                                  break;

                       case 'w' : OUT = 
                                  "  \n\n  Adjacent to the west wall, a gaggle of\n"
                                  + "  fiber optics cables winds its way down into\n"
                                  + "  the racks of servers lined up row after row.\n";
                                  break;

                       case 'u' : LOCATION = C1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'd' : LOCATION = DATATerminal;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case '~' : Events.Player.Cheat();
                                  MapCheat();
                                  OUT = "\n  Cheat activated!\n";
                                  Events.Player.DisplayStats();
                                  Events.Player.ListInventory();
                                  MutantWars.WEAPONS();
                                  MutantWars.ABILITIES();
                                  break;

                       case '|' : Events.Player.InitializeInventory();
                                  Events.Player.InitializeAbilities();
                                  OUT = "\n Cheat deactivated!\n";
                                  Events.Player.DisplayStats();
                                  Events.Player.ListInventory();
                                  break;

                       default : OUT = "  Invalid input from Center1Basement...";
                                 break;
                     }

                     if(MutantWars.WhatToDo == 'u' ||
                        MutantWars.WhatToDo == 'd' ||
                        MutantWars.WhatToDo == 'l' ||
                        MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == '~' ||
                        MutantWars.WhatToDo == '|')
                     {
                         OUT = OUT +
                         "\n\n  Directions:  (N)orth  (S)outh  (E)ast  (W)est\n"
                         + "  Possibilities: (L)ook  (D)ata Terminal  (U)pstairs\n\n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;

             }//close if

             else
             {
                MutantWars.LOCK = true;
                if(MutantWars.SOUNDEFFECTS) { MutantWars.ComputerSound1.play(); }

                if(Center1BasementFirstTime)
                {
                     OUT = "\n\n  You descend into the glowing blue abyss\n"
                         + "  to find yourself standing in a CONTROL\n"
                         + "  ROOM of sorts.\n\n";
                     Center1BasementFirstTime = false;
                }

                else
                {
                    OUT = "\n\n  You are in the CONTROL ROOM beneath the\n"
                        + "  treatment facility.\n\n";
                }

                    OUT = OUT +
                        "  To the south is a giant LCD display and\n"
                      + "  keyboard. The large display is projecting\n"
                      + "  a rotating bio-hazzard logo on a blue\n"
                      + "  background. Centered at the bottom of\n"
                      + "  the screen in bold black letters are\n"
                      + "  the words \"Data Terminal Access\".\n\n"
                      + "  You can now see that it is this large\n"
                      + "  display that is producing the eerie\n"
                      + "  iridescence in the room.\n";

                   OUT = OUT + "\n  Where will you go?\n"
                         + "  (N)orth  (S)outh  (E)ast  (W)est?\n\n"
                         + "  Possibilities:\n  (L)ook  (D)ata Terminal  (U)pstairs\n";

                    MutantWars.MainOutput.setText(OUT);

           }//close else

       }//close function

//-----------------------------------------------------------------------------
       public void DataTerminalAccess()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(Events.Player.GetDataCrystal() &&
                 MutantWars.WhatToDo == 'x' ||
                 MutantWars.WhatToDo == 'p' ||
                 MutantWars.WhatToDo == 'l' ||
                 MutantWars.WhatToDo == 'm' ||
                 MutantWars.WhatToDo == 'c'
                 )
              {
                       switch(MutantWars.WhatToDo)
                       {
                         case 'p' : OUT = "\n\n  The display returns the result:\n" +
                                    "  \"Insufficient Access Privileges!\"\n\n";
                                    break;

                         case 'l' : DataTerminalLog();
                                    break;

                         case 'm' : OUT = "\n\n  The display returns the result:\n" +
                                    "  \"Level Two Access Key Required.\"\n\n";
                                    break;

                         case 'c' : if(!CardReaderActivated)
                                    {
                                       OUT = "\n\n  The display returns the result:\n" +
                                       "  \"Success! Card Reader is now Active!\"\n\n";
                                       CardReaderActivated = true;
                                    }
                                    else
                                    {
                                       OUT = "\n\n  The display returns the result:\n  \"" +
                                       "Can not comply. Card Reader Already Active!\"\n\n";
                                    }
                                    break;

                         case 'x' : OUT = "\n  Exiting terminal...\n\n";
                                    LOCATION = C1Basement;
                                    MutantWars.LOCK = false;
                                    MutantWars.ButtonGo.doClick();
                                    break;

                         default :  OUT = "\n\n  The display returns the result "
                                    + "  \"Security perimeter violated.\n"
                                    + "  Only limited commands available.\"\n\n";
                                   break;

                       }//close switch
                 
                 //To keep from repeating on exit, need to filter based on input.
                 if(Events.Player.GetDataCrystal() &&
                 MutantWars.WhatToDo == 'x' ||
                 MutantWars.WhatToDo == 'p' ||
                 MutantWars.WhatToDo == 'l' ||
                 MutantWars.WhatToDo == 'm' ||
                 MutantWars.WhatToDo == 'c'
                 )
                    {     OUT = OUT +
                          "\n  Your choices are: \n"
                          + "\n  (P)atient Bios\n"
                          + "  (L)og files\n"
                          + "  (M)edical Inventory\n"
                          + "  (C)ard Reader Activation\n"
                          + "  E(x)it Terminal\n\n";
                    }
                 MutantWars.MainOutput.setText(OUT);
                 MutantWars.LOCK = true;

                 }//close if

                 else
                 {
                     MutantWars.LOCK = true;

                     if(!Events.Player.GetDataCrystal())
                     {
                         OUT = "\n  You attempt to access the data terminal. You\n"
                         + "  type a few characters trying to brute force a\n"
                         + "  password or two, but to no avail. All you see\n"
                         + "  at the terminal is:\n\n  \"Access Denied!\"\n";
                         
                         OUT = OUT + "\n  Where will you go?\n"
                         + "  (N)orth  (S)outh  (E)ast  (W)est?\n\n"
                         + "  Possibilities:\n  (L)ook  (D)ata Terminal  (U)pstairs\n";
                         
                         LOCATION = C1Basement;
                    }

                   else
                   {
                      if(MutantWars.SOUNDEFFECTS) { MutantWars.ComputerSound2.play(); }

                      OUT = "\n  You take the data crystal and insert it\n"
                          + "  into the data terminal. The large LCD display\n"
                          + "  in front of you flashes for a brief moment.\n"
                          + "  Sporadically, a menu displays with several\n"
                          + "  choices blinking in the background.\n";

                      OUT = OUT +
                         "\n  Your choices are: \n\n"
                       + "  (P)atient Bios\n"
                       + "  (L)og files\n"
                       + "  (M)edical Inventory\n"
                       + "  (C)ard Reader Activation\n"
                       + "  E(x)it Terminal\n\n";

                   }//close else

           }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void DataTerminalLog()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              int SayWhat = Functions.GRN(10);

              OUT = "\n  The display reads:\n\n"
                  + "  \"Data timestamps damaged.\n"
                  + "  Attempting to recover.\n"
                  + "  Accessing internal log files...\" \n\n"
                  + "  It pauses a few seconds for processing,\n"
                  + "  then spits out:\n\n";

              switch(SayWhat)
              {
                   case 1 : OUT = OUT + "  \"10/18/2080 - BrainEaters everywhere.\n"
                            + "  The horror is unbearable. I can't endure\n"
                            + "  this hell on earth much longer...";
                            break;

                   case 2 : OUT = OUT + "  \"10/17/2080 - Went out with Jenny tonight.\n"
                            + "  Man is she hot! Hotter than the sun, baby!.\n"
                            + "  Hot mamma. I like big butts. I can not lie...";
                            break;

	           case 3 : OUT = OUT + "  \"10/16/2080 - Working with mutant who has \n" 
                            + "  apparent freezing abilities. He extracts\n"
                            + "  moisture from the air and absorbs its ambient\n"
                            + "  temperature.";
                            break;

	           case 4 : OUT = OUT + "  \"10/21/2080 - Safe damaged. Perhaps a heat\n"
                            + "  source will expand the lock mechanism.";
                            break;

	           case 5 : OUT = OUT + "  \"10/15/2080 - Met a girl at a party the \n"
	                    + "  other night. I can't stop thinking about her.\n"
                            + "  Trying to put her out of my mind."; 
                            break;

	           case 6 : OUT = OUT + "  \"10/14/2080 - Second week in this underground\n"
                            + "  facility. Can't remember what the sun looks like."
                            + "\n  I guess it's safer down here."; 
                            break;

	           case 7 : OUT = OUT + "  \"10/19/2080 - The freezer mutant is becoming\n"
	                    + "  more powerful. It appears it would not be\n"
	                    + "  prudent to oppose him without a weapon or\n"
                            + "  some other sort of tactical advantage...";
                            break;

                   case 8 : OUT = OUT + 
                            "  \"10/22/2080 - There are only 3 of us left.\n"
                            + "  We are going to try to make it to the surface.\n"
                            + "  If only the card reader was functioning!";
                            break;

                   case 9 : OUT = OUT + 
                            "  \"10/03/2080 - Moving facilities underground to\n"
                            + "  an emergency bunker. We should be able to carry\n"
                            + "  out our research free of the war above.";
                            break;

                   case 10 : OUT = OUT + 
                            "  \"10/20/2080 - Need to find the key and try to\n"
                            + "  unlock the safe. There is danger everywhere.";
                            break;

	           default : OUT = OUT + "  Uh oh, this should never happen.."; 
                             break;
              } //closes switch

            OUT = OUT + "\"\n\n";
            MutantWars.MainOutput.setText(OUT);

       }

//-----------------------------------------------------------------------------

       public void North1()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics
              MutantWars.Water.stop();
              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'c' ||
                 MutantWars.WhatToDo == 'l')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = N1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : LOCATION = N2;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 's' : LOCATION = C1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'e' : OUT = "\n\n  You walk over to the east side of the\n"
                                      + "  room. A row of desks runs in a straight\n"
                                      + "  row adjacent to the wall. You see\n"
                                      + "  miscellaneous office supplies.\n\n"
                                      + "  Nothing interesting.";;
                                  break;

                       case 'c' : if(!FoundMachete)
                                  {
                                     OUT = "\n  Too high above your head to see, you\n"
                                     + "  run your fingers along the shelf and find a\n"
                                     + "  trapezoidal object made of canvas. You pull it\n"
                                     + "  down and see that it is a machete inside a\n"
                                     + "  canvas sheath.\n\n  This may come in handy!\n";
                                     FoundMachete = true;
                                     Events.Player.SetMachete(true);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n  You feel along the edge of the shelf\n"
                                         + "  where you had previously found the\n"
                                         + "  machete, hoping to acquire any other\n"
                                         + "  useful objects that may be stored there.\n"
                                         + "  Instead, you cut your hand on an\n"
                                         + "  abandoned razor blade and loose four\n"
                                         + "  points of your precious life.\n\n"
                                         + "  Maybe this was not a good idea...\n";
                                     Events.Player.SetHit(Events.Player.GetHit() - 4);
                                     Events.Player.DisplayStats();
                                     Events.Player.AddConquest("Razor Cut");
                                  }
                                  break;

                       case 'w' : LOCATION = TheFRIDGE;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       default : OUT = "  Invalid input from North1...";
                                 break;
                     }//close switch
                     
                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'c' ||
                        MutantWars.WhatToDo == 'l')
                     {
                            OUT = OUT +
                            "\n\n  Where will you go:\n"
                            + "  (N)orth (S)outh (E)ast (W)est?\n\n"
                            + "  Possibilities: (L)ook  (C)heck Shelves\n\n";

                     }//close inner if

             MutantWars.MainOutput.setText(OUT);
             MutantWars.LOCK = true;
             }//close outer if

             else
             {    
                  MutantWars.LOCK = true;

                  OUT = "\n  You find yourself in the MAIN OFFICE.\n"
                  + "  It is fairly spacious and consists of \n"
                  + "  approximately 10 cubicles partitioned off\n"
                  + "  with folding dividers. To the east, flush\n"
                  + "  against the wall, is a row of desks with\n"
                  + "  folder racks, coffee cups, cannisters of\n"
                  + "  pens and laptops. To the west you see a\n"
                  + "  small refrigerator about four feet high,\n"
                  + "  covered with mildew.\n\n"
                  + "  To the north you see a door and what\n"
                  + "  appears to be daylight coming through a\n"
                  + "  small window criss-crossed with some\n"
                  + "  metallic filament embedded within the\n"
                  + "  door. You can see that the door is\n"
                  + "  constructed of heavy steel and that the\n"
                  + "  window it contains are designed to be\n"
                  + "  shatter-proof.\n\n"
                  + "  Flourescent lights are flickering on and\n"
                  + "  off from fixtures adjacent to insulating\n"
                  + "  tiles that cover the roof. A small shelf\n"
                  + "  runs above the door.\n";

                  OUT = OUT +
                  "\n  Where will you go:\n"
                  + "  (N)orth (S)outh (E)ast (W)est?\n\n"
                  + "  Possibilities: (L)ook  (C)heck Shelves\n\n";

                  MutantWars.MainOutput.setText(OUT);

             }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void TheFridge()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'd' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'c')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'd' : if(!DrankSoda)
                                  {
                                     OUT = "\n  You drink the soda...\n"
                                         + "  Cold and refreshing!\n\n"
                                         + "  It adds 10 points to your life.\n";
                                     Events.Player.SetHit(Events.Player.GetHit() + 10);
                                     Events.Player.DisplayStats();
                                     DrankSoda = true;
                                  }
                                  else
                                  { OUT = "\n  Nothing to drink here.\n"
                                        + "  You already drank the soda!\n"; }
                                  break;

                       case 'e' : if(!AteSandwhich)
                                  {
                                     OUT = "\n  You eat the tuna sandwhich...\n"
                                         + "  Oh no, rancid mayonaise!!!\n\n"
                                         + "  You vomit profusely.\n\n"
                                         + "  You begin to call \"RALPH\"\n"
                                         + "  on the big white porcelain phone...\n\n"
                                         + "  You begin chunking Mulligan stew,\n"
                                         + "  everywhere, extra chunky...\n\n"
                                         + "  It's that bad. You loose 10 points\n"
                                         + "  of your fragile and queasy life.\n";
                                     Events.Player.SetHit(Events.Player.GetHit() - 10);
                                     Events.Player.DisplayStats();
                                     Events.Player.AddConquest("Tuna Sandwhich");
                                     AteSandwhich = true;
                                  }
                                  else
                                  { OUT = "\n  There's no food in this fridge, Sherlock.\n"
                                        + "  You already ate the tuna sandwhich!\n"; }
                                  MutantWars.MainOutput.setText(OUT);
                                  break;

                       case 'c' : OUT = "\n  You close the refrigerator door\n"
                                      + "  and step back to where you were.\n";
                                  LOCATION = N1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       default : OUT = "\n  Invalid input from the Fridge...";
                                 MutantWars.MainOutput.setText(OUT);
                                 break;
                     }//close switch
                     
                     if(MutantWars.WhatToDo == 'd' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'c')
                     {
                         OUT = OUT + "\n  You may:\n\n";
                         if(!DrankSoda) { OUT = OUT + "  (D)rink the soda\n"; }
                         if(!AteSandwhich) { OUT = OUT + "  (E)at the tuna sandwhich\n"; }
                         OUT = OUT + "  (C)lose the refrigerator door\n\n\n  ";

                         MutantWars.MainOutput.setText(OUT);
                     }

             }//close if
             
             else
             {
                  OUT = "\n  You go to the west side of the room.\n"
                  + "  You see a refrigerator and can hear its\n"
                  + "  compressor humming. Curious, you open the\n"
                  + "  door and peer inside. There are some empty\n"
                  + "  vaccine cannisters in the bottom.\n\n";

                   if(!DrankSoda)
                   { OUT = OUT + "  On a shelf up top there is\n"
                          + "  a can of soda.\n\n";
                   }

                   if(!AteSandwhich)
                   { OUT = OUT + "  On the middle shelf sits a\n"
                          + "  tuna fish sandwhich.\n\n";
                   }

                   OUT = OUT + "\n  You may:\n\n";
                   if(!DrankSoda) { OUT = OUT + "  (D)rink the soda\n"; }
                   if(!AteSandwhich) { OUT = OUT + "  (E)at the tuna sandwhich\n"; }
                   OUT = OUT + "  (C)lose the refreigerator door\n\n\n  ";

                   MutantWars.MainOutput.setText(OUT);

             }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void South1()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' || 
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'l' ||
                 MutantWars.WhatToDo == 'c')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = S1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : LOCATION = C1; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 's' : LOCATION = S2; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'e' : OUT = "\n\n  You see a row of LCD monitors displaying\n"
                                      + "  patient records, histograms and various\n"
                                      + "  vital statistics.\n";
                                  break;

                       case 'w' : if(!FoundSyringe)
                                  {
                                     OUT = "\n\n  Digging around in a pile of glass on\n"
                                     + "  one of the medical shelves, you find an\n"
                                     + "  unused syringe with a cartridge!\n";
                                     FoundSyringe = true;
                                     Events.Player.SetSyringe(true);
                                     Events.Player.SetSyringeCart(1);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n\n  Where formerly you found the syringe,\n"
                                         + "  you see nothing but a pile of broken\n"
                                         + "  glass.\n";
                                  }
                                  break;

                       case 'c' : if(!FoundMedKit)
                                  {
                                     OUT = "\n\n  Digging through piles of broken glass,\n"
                                         + "  you find an unused med kit!\n";
                                     FoundMedKit = true;
                                     Events.Player.SetMedKit(Events.Player.GetMedKit() + 1);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n\n  Ouch! In almost the same place where\n"
                                         + "  you found the med kit, you slice your\n"
                                         + "  finger on broken glass!\n\n"
                                         + "  You loose 1 measly lifepoint!\n"
                                         + "  Merely a flsh wound...\n";
                                     Events.Player.SetHit(Events.Player.GetHit() - 1);
                                     Events.Player.DisplayStats();
                                     Events.Player.AddConquest("Broken Glass");
                                  }
                                  break;

                       default : OUT = "\n\n  Invalid input from South1...";
                                 break;
                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'l' ||
                        MutantWars.WhatToDo == 'c')
                     {
                            OUT = OUT +
                            "\n\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n"
                            + "  Possibilities:  (L)ook   (C)heck Cabinets\n";
                     }
                     
                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;

             }//close if
             
             else
             {
                  MutantWars.LOCK = true;

                  OUT = "\n  You enter the NURSING STATION. There\n"
                      + "  are white medicine cabinets mounted against\n"
                      + "  the walls. They have glass doors that allow\n"
                      + "  you to see the contents inside them. Piles\n"
                      + "  of glass from smashed glass bottles and\n"
                      + "  equipment cover the shelves inside of the\n"
                      + "  cabinets.\n\n"
                      + "  Shattered glass crunches beneath your feet\n"
                      + "  as you walk across the blue and gray terazzo\n"
                      + "  floor. To the north is a door leading to the\n"
                      + "  treatment room. To the south, a a hallway\n"
                      + "  lined with gurneys appears to lead to an ICU.\n";

                      OUT = OUT +
                      "\n\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n"
                      + "  Possibilities:  (L)ook   (C)heck Cabinets\n";

                  MutantWars.MainOutput.setText(OUT);
             }

       }//close function

//-----------------------------------------------------------------------------

       public void East1()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'l' ||
                 MutantWars.WhatToDo == 'g')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = E1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : if(!FoundMatches)
                                  {
                                     OUT = 
                                     "\n\n  Raffling through the boxes on the storeage"
                                         + "\n  shelves, you find a book of matches!\n";
                                     FoundMatches = true;
                                     Events.Player.SetMatches(true);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n\n  Where formerly you found the book of\n"
                                         + "  matches, you see nothing but boxes\n"
                                         + "  and crates.\n";
                                  }
                                  break;

                       case 's' : OUT = "\n\n  You see lots of lovely boxes.\n"
                                      + "  How Quaint!\n";
                                  break;

                       case 'e' : LOCATION = E2; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'w' : LOCATION = C1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'g' : LOCATION = E1Closet;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       default : OUT = "\n\n  Invalid input from East 1...";
                                 break;
                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'l' ||
                        MutantWars.WhatToDo == 'g')
                     {
                            OUT = OUT +
                            "\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n"
                            + "  Possibilities:  (L)ook   (G)o Into the Closet\n";
                     }

                     MutantWars.MainOutput.setText(OUT);

             MutantWars.MainOutput.setText(OUT);
             MutantWars.LOCK = true;

             }//close if

             else
             {
                  MutantWars.LOCK = true;
                  if(MutantWars.SOUNDEFFECTS) { MutantWars.FootSteps.play(); }

                  OUT = "\n\n  You enter into a large STORAGE ROOM\n"
                      + "  facility. It is dimly lighted by a few\n"
                      + "  flourescent panels that are embedded in\n"
                      + "  the baseboard that borders the room.\n\n"
                      + "  Amidst the shadows you see miscellaneous\n"
                      + "  boxes and crates of supplies. Shelves\n"
                      + "  line the walls and various boxes of\n"
                      + "  different sizes and colors are stacked\n"
                      + "  on them.\n\n"
                      + "  To the north-east is a small black closet\n"
                      + "  door with a vent at the bottom. To the east\n"
                      + "  a short hallway leads to another, even larger\n"
                      + "  storage room with a 20 foot ceiling. The room\n"
                      + "  to the east appears to be a warehouse of sorts.\n";

                      OUT = OUT +
                      "\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n"
                      + "  Possibilities:  (L)ook   (G)o Into the Closet\n";

                  MutantWars.MainOutput.setText(OUT);
             }

       }

//-----------------------------------------------------------------------------

       public void East1Closet()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'c' ||
                 MutantWars.WhatToDo == 'l')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = E1Closet;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : if(!FoundFramePack)
                                  {
                                     OUT = 
                                     "\n\n  Feeling your way through the darkness,\n"
                                     + "  you discover a large steel frame back\n"
                                     + "  pack!\n";
                                     FoundFramePack = true;
                                     Events.Player.SetFramePack(true);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = 
                                     "\n\n  You feel sround in the darkness where\n"
                                     + "  you formerly found the frame pack but\n"
                                     + "  find nothing.\n";
                                  }
                                  break;

                       case 's' : OUT = "\n\n  You see various firearms mounted in\n"
                                      + "  locked rack. If only you had the key\n"
                                      + "  to this sumptuous arsenal...\n";
                                  break;

                       case 'e' : OUT = "\n\n  You see boots, parkas and camping\n"
                                      + "  gear locked inside a translucent\n"
                                      + "  storage container.\n";
                                  break;

                       case 'w' : OUT = "\n\n  You find a large, locked cabinet.\n"
                                  + "  Through the shatter-proof glass you can\n"
                                  + "  see a copious amount of camera and GPS\n"
                                  + "  equipment. If only there was a key...";
                                  break;

                       case 'c' : LOCATION = E1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       default : OUT = "\n\n  Invalid input from East1 Closet...";
                                 break;
                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                     MutantWars.WhatToDo == 's' ||
                     MutantWars.WhatToDo == 'e' ||
                     MutantWars.WhatToDo == 'w' ||
                     MutantWars.WhatToDo == 'c' ||
                     MutantWars.WhatToDo == 'l')
                     {
                          OUT = OUT +
                          "\n\n  Where will you go:\n  (N)orth (S)outh (E)ast (W)est?\n\n"
                          + "  Possibilities: (L)ook\n"
                          + "                          (C)ome Out of the Closet\n\n"
                          + "                          ;-) haha\n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;

             }//close if

             else
             {
                 MutantWars.LOCK = true;
                 if(MutantWars.SOUNDEFFECTS) { MutantWars.DoorOpen.play(); }

                 OUT = "\n\n  You walk into a large CLOSET illuminated\n"
                     + "  by a large singular disk mounted in the\n"
                     + "  center of the ceiling. It appears to be\n"
                     + "  outfitted with expeditionary supplies.\n\n"
                     + "  Guns, GPS units, boots and parkas are all\n"
                     + "  locked inside various cabinets and protected\n"
                     + "  with shatterproof glass. Boxes of different\n"
                     + "  sizes and colors are stacked on them.\n\n"
                     + "  You can see numerous items transfigured in\n"
                     + "  the shadows as you glance around the\n"
                     + "  environment.\n";

                     OUT = OUT +
                     "\n\n  Where will you go:\n  (N)orth (S)outh (E)ast (W)est?\n\n"
                     + "  Possibilities: (L)ook\n"
                     + "                          (C)ome Out of the Closet\n\n"
                     + "                          ;-) haha\n";

                     MutantWars.MainOutput.setText(OUT);
             }
       }

//-----------------------------------------------------------------------------

       public void West1()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'l')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = W1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : if(!FoundSterno)
                                  {
                                     OUT = "\n\n  Looking underneath one of the catering\n"
                                     + "  tables, you find a full can of high heat\n"
                                     + "  STERNO fuel. It must have been used to\n"
                                     + "  keep the food warm during meal times.\n";
                                     FoundSterno = true;
                                     Events.Player.SetSterno(true);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n\n  Where formerly you found the can of\n"
                                     + "  STERNO, you see nothing but empty shelves\n"
                                     + "  smattered with food stains and rat droppings\n"
                                     + "  underneath the catering tables.\n";
                                  };
                                  break;

                       case 's' : if(!FoundMRERations)
                                  {
                                     OUT = "\n\n  You walk towards the crate that\n"
                                     + "  is sitting against the southern wall.\n\n"
                                     + "  Ferreting through the box, you \n"
                                     + "  unrap one of the parcels to read\n"
                                     + "  the label printed on it:\n\n"
                                     + "  \"U.S. Armed Forces.\"\n"
                                     + "  \"MRE = Meal Ready to Eat\"\n\n"
                                     + "  You are filled with relief. You were\n"
                                     + "  getting hungry. There are too many\n"
                                     + "  units to take by hand - 10 is as many\n"
                                     + "  as you can carry. If only you had a\n"
                                     + "  way to carry them all...\n";
                                     FoundMRERations = true;
                                     Events.Player.SetMRErations(
                                     Events.Player.GetMRErations() + 10);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     LOCATION = RoachImage;
                                     Events.GUI_INTERFACE.refresh();  //For Graphics
                                     LOCATION = W1;
                                     OUT = "\n\n  Again you see the box or MRE rations.\n"
                                     + "  The box is still full, minus the ones\n"
                                     + "  you have already taken. You reach in to\n"
                                     + "  take another, but are horrified at what\n"
                                     + "  you see...\n\n"
                                     + "  Mutant carnivorous cockroaches come\n"
                                     + "  streaming out of the bottom of the box\n"
                                     + "  and tear the flesh from your arm!\n\n"
                                     + "  Screaming in severe pain and agony,\n"
                                     + "  (or is it disgust), you back away.\n\n"
                                     + "  You lose 10 life points by way of\n"
                                     + "  this ordeal.\n";
                                     if(Events.Player.GetHit() - 10 > 0)
                                     {
                                       Events.Player.SetHit(
                                       Events.Player.GetHit() - 10);
                                     }
                                     else { Events.Player.SetHit(0); }
                                     Events.Player.SetScore(
                                     Events.Player.GetScore() + 25);
                                     Events.Player.DisplayStats();
                                     Events.Player.AddConquest("Mutant Roaches");
                                  }
                                  break;

                       case 'e' : LOCATION = C1; 
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'w' : LOCATION = W2;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       default : OUT = "  Invalid input from West1...";
                                 break;
                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'l')
                     {
                         OUT = OUT +
                         "\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n\n"
                         + "  Possibilities: (L)ook\n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;

             }//close if

             else
             {
                     MutantWars.LOCK = true;
                     
                     OUT = "\n\n  You walk into the primary MESS HALL,\n"
                         + "  or Dining Facility. This is a large room\n"
                         + "  with a ceiling approximately 15 feet high.\n\n"
                         + "  The room contains ten rows of tables\n"
                         + "  equipped with napkin holders, salt and\n"
                         + "  pepper shakers and ketchup and musard\n"
                         + "  bottles. Eight white plastic chairs are\n"
                         + "  pushed neatly under each black formica\n"
                         + "  table, arranged asymmetrically within\n"
                         + "  their rows.\n\n"
                         + "  This must have been where the original\n"
                         + "  inhabitants of this long abandoned facility\n"
                         + "  took their meals. To the south a long, open\n"
                         + "  crate contains several smaller parcels within\n"
                         + "  it. An empty serving table, like those used\n"
                         + "  for catering, lines up against the north wall.\n";

                     MutantWars.MainOutput.setText(OUT);

                     OUT = OUT +
                     "\n  Where will you go: (N)orth (S)outh (E)ast (W)est?\n\n"
                     + "  Possibilities: (L)ook\n";

                     MutantWars.MainOutput.setText(OUT);
             }

       }//close function

//-----------------------------------------------------------------------------

       public void North2()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 't' ||
                 MutantWars.WhatToDo == 'c' ||
                 MutantWars.WhatToDo == 'l')
              {
                     switch(MutantWars.WhatToDo)
                     {
                        case 'l' : LOCATION = N2;
                                   MutantWars.LOCK = false;
                                   MutantWars.ButtonGo.doClick();
                                   break;

                        case 'n' : OUT = 
                                   "\n\n  You walk to the north end of the Atrium.\n\n"
                                 + "  Examining the three bodies, you are filled\n"
                                 + "  with a macabre sense of wonder as the light\n"
                                 + "  from the glass panes above the Atrium sparkles\n"
                                 + "  when it is scattered into a thousand prismic\n"
                                 + "  rays by the ice that has crystallized on the\n"
                                 + "  outer surface of the deceased.\n\n"
                                 + "  You wonder who, or better yet what, did this?\n";
                                 break;

                        case 's' : LOCATION = N1;
                                   MutantWars.LOCK = false;
                                   MutantWars.ButtonGo.doClick();
                                   break;

                        case 'e' : OUT = 
                                   "\n\n  You see vines and the branches of several\n"
                                   + "  small trees growing against the east wall. ";

                                   if(!FoundJacket)
                                   {
                                     OUT = 
                                     "\n\n  In the corner you find a canvas straight\n"
                                     + "  jacket. The material is tough and resistant\n"
                                     + "  to tearing. It may also offer some protection\n"
                                     + "  from the frigid fate that befell the\n"
                                     + "  unfortunate frozen few in this room.\n\n"
                                     + "  You remove the restraining straps so\n"
                                     + "  you can wear it as you would a normal\n"
                                     + "  article of clothing. Though not fashionable,\n"
                                     + "  it looks as though it might add +2 to your\n"
                                     + "  ability to defend yourself - that is, IF\n"
                                     + "  you were to put it on...";
                                   FoundJacket = true;
                                   Events.Player.SetJacket(true);
                                   Events.Player.ListInventory();
                                 }
                                else 
                                { OUT = "\n\n  Previously you found the straight jacket\n"
                                      + "  here. Now it's empty space.\n"; }
                                break;

                        case 'w' : OUT = "\n\n  Nothing too interesting. Thick vines\n"
                                       + "  cover the wall and a gurney with broken\n"
                                       + "  straps sits off in the corner.\n";
                                   break;

                        case 't' : LOCATION = N2Garage; 
                                   FromAtrium = true;
                                   MutantWars.LOCK = false;
                                   MutantWars.ButtonGo.doClick();
                                   break;

                        case 'c' : LOCATION = N2Service;
                                   FromAtrium = true;
                                   MutantWars.LOCK = false;
                                   MutantWars.ButtonGo.doClick();
                                   break;

                        default : OUT = "  Invalid input...";
                                  break;
                     }
                     
                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 't' ||
                        MutantWars.WhatToDo == 'c' ||
                        MutantWars.WhatToDo == 'l')
                     {
                        OUT = OUT +
                        "\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n\n"
                        + "  Possibilities: (L)ook  (T)ake Elevator Down \n"
                        + "                          (C)orridor\n\n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;

             }//close if

             else
             {
                 MutantWars.LOCK = true;
                 if(MutantWars.SOUNDEFFECTS) { MutantWars.Water.play(); }

              if(N2FirstTime)
              {
                 OUT = "\n  Stepping through the door, you jump\n"
                     + "  back, shielding your eyes from the\n"
                     + "  burning sunlight pouring in the shatter-\n"
                     + "  proof glass panels 25 feet above your\n"
                     + "  head. Seeing the surface illuminated so\n"
                     + "  far above you, you now realize that you\n"
                     + "  must be at least 30 feet underground.\n\n"
                     + "  Surrounded by an increasingly false\n"
                     + "  sense of serenity, you find yourself\n"
                     + "  standing in the middle of a beautiful\n"
                     + "  ATRIUM. As your eyes begin to adjust to\n"
                     + "  the brightness, you begin to understand\n"
                     + "  the reason you are feeling so jumpy and\n"
                     + "  skittish.\n\n";

                 N2FirstTime = false;

              }

              else { OUT = "\n  You return to the ATRIUM.\n\n"; }

              OUT = OUT + "  You are surrounded by tranquility and beauty.\n"
                        + "  There are lush green plants and a Japanese\n"
                        + "  water fountain in the center. You can\n"
                        + "  see multi-colored goldfish frozen in the\n"
                        + "  pool of water which the fountain runs into.\n"
                        + "  Frozen? How is that possible when the ambient\n"
                        + "  temperature of the room must be at least 90\n"
                        + "  degrees Farenheit?\n\n"
                        + "  You look to the north and see, to your horror,\n"
                        + "  three corpses frozen solid. Their bodies are\n"
                        + "  disfigured in agonizing positions and a fog\n"
                        + "  surrounds them as if they were composed of\n"
                        + "  dry ice reacting to the atmosphere. You are\n"
                        + "  unnerved and perplexed about how these\n"
                        + "  unfortunate souls met their demise. Oddly,\n"
                        + "  to the east, you see an elevator. Above the\n"
                        + "  entry way, the words \"Parking - SubLevel 1\"\n"
                        + "  are inscribed upon the wall in a stencil-like\n."
                        + "  fashion. Beneath it, an arrow points downward.\n\n"
                        + "  To the north-west you see a service corridor \n"
                        + "  containing a stairwell ascending towards\n"
                        + "  the waning dusk outside\n";

                        OUT = OUT +
                        "\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n\n"
                        + "  Possibilities: (L)ook  (T)ake Elevator Down \n"
                        + "                          (C)orridor\n\n";

              MutantWars.MainOutput.setText(OUT);
             }

       }//close function

//-----------------------------------------------------------------------------

       public void North2Garage()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics
              MutantWars.Water.stop();
              OUT = "";

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 't' ||
                 MutantWars.WhatToDo == 'l')
              {
                   switch(MutantWars.WhatToDo)
                   {
                      case 'l' : LOCATION = N2Garage;
                                 MutantWars.LOCK = false;
                                 MutantWars.ButtonGo.doClick();
                                 break;

                      case 'n' : OUT = "\n  Hydraulic pipes and hoses. Yippie!\n";
                                 break;

                      case 's' : if(!ExplodedTripBomb)
                                 {
                                    OUT = "\n  It's a trap! Boom!\n\n"
                                        + "  A trip bomb explodes, dealing out deadly\n"
                                        + "  shrapnel and debris and doing 30 points\n"
                                        + "  of dammage.\n";
                                    if(MutantWars.SOUNDEFFECTS) 
                                    { MutantWars.Explosion.play(); }
                                    if(Events.Player.GetHit() - 50 > 0)
                                    {
                                        Events.Player.SetHit(Events.Player.GetHit() - 50);
                                    }
                                    else { Events.Player.SetHit(0); }
                                    Events.Player.DisplayStats();
                                    Events.Player.AddConquest("Trip Bomb");
                                    ExplodedTripBomb = true;
                                 }
                                 else
                                 {
                                    OUT = "\n  You return to the area where the trip\n"
                                    + "  bomb that almost took your life exploded.\n\n"
                                    + "  You can't believe that you survived such\n"
                                    + "  an ordeal. Your hearts sinks...\n\n"
                                    + "  The transport vehicle has been reduced to\n"
                                    + "  a pile of rubble. Bits and pieces of it,\n"
                                    + "  thrown by the explosion, are strewn across\n"
                                    + "  the underground parking garage.\n"
                                    + "  There is absolutely no hope of using it now.\n";
                                 }
                                 break;

                      case 'e' : OUT = "\n  You see rows of vehicles, shattered and\n"
                                     + "  pulverized almost beyond recognition.\n\n"
                                     + "  There is definite evidence of sabotage,\n"
                                     + "  perhaps some sort of explosive device.\n\n"
                                     + "  Nothing here but smoldering refuse...\n";
                                 break;

                      case 'w' : OUT = "\n  You walk to the west of the garage\n"
                                 + "  and check out the security booth. It looks\n"
                                 + "  as though it has been abandoned for years.\n\n"
                                 + "  You examine the access door. It has been\n"
                                 + "  welded and bolted shut. \n\n"
                                 + "  You wonder, were they trying to keep someone\n"
                                 + "  from getting IN, or someone or someTHING\n"
                                 + "  from getting OUT?\n";
                                 break;

                      case 't' : LOCATION = N2;
                                 MutantWars.LOCK = false;
                                 MutantWars.ButtonGo.doClick();
                                 break;

                      default : OUT = "\n  Invalid input from North2 basement...";;
                                break;
                   }//close switch
                   
                   if(MutantWars.WhatToDo == 'n' ||
                      MutantWars.WhatToDo == 's' ||
                      MutantWars.WhatToDo == 'e' ||
                      MutantWars.WhatToDo == 'w' ||
                      MutantWars.WhatToDo == 't' ||
                      MutantWars.WhatToDo == 'l')
                   {
                       OUT = OUT +
                       "\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n\n"
                       + "  Possibliities: (L)ook \n"
                       + "                           (T)ake Elevator up to Atrium\n\n";;
                   }

                   MutantWars.MainOutput.setText(OUT);
                   MutantWars.LOCK = true;
                   
                   }//close if
                   
                   else
                   {
                       if(FromAtrium)
                       {
                           OUT = "\n  You press the button beside the elevator\n"
                               + "  door and it slides open. You step in and\n"
                               + "  press \"P - SL1\". The button lights up with a\n"
                               + "  pale, blue iridescence, and the doors close.\n\n"
                               + "  You grab the rail on the side of the car as\n"
                               + "  it jolts and begins to descend.  After a few \n"
                               + "  moments, the elevator car stops and \"dings\"\n"
                               + "  to notify you that you have arrived at your\n"
                               + "  destination. The doors slide open and a wave\n"
                               + "  of cool, damp air rushes into the elevator car.\n\n"
                               + "  You step outside the elevator and take a look at\n"
                               + "  your surroundings...\n\n";

                           FromAtrium = false;
                       }

                       if(MutantWars.SOUNDEFFECTS) { MutantWars.FootSteps.play(); }

                       OUT = OUT + "\n  You are in the complex's parking GARAGE\n"
                           + "  underneath the Atrium.\n\n"
                           + "  Looking through the vast expanse to the\n"
                           + "  north, you see a gray concrete wall with several\n"
                           + "  hydraulic pipes and hoses running the length\n"
                           + "  of it. To the east are several vehicles,\n"
                           + "  dammaged almost beyond recognition.\n\n"
                           + "  To the south you see a transport vehicle\n"
                           + "  that appears to be in good condition.\n"
                           + "  Behind it, against the wall, an eerie\n"
                           + "  red glow emmanates from the shadows.\n\n"
                           + "  To the west of the garage lies a security\n"
                           + "  booth and an access door that has been\n"
                           + "  welded shut, apparently for quite some time.\n";

                       OUT = OUT +
                       "\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n\n"
                       + "  Possibliities: (L)ook \n"
                       + "                           (T)ake Elevator up to Atrium\n\n";

                       MutantWars.MainOutput.setText(OUT);

             }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void N2ServiceCorridor()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics
              MutantWars.Water.stop();
              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'd' ||
                 MutantWars.WhatToDo == 'c' ||
                 MutantWars.WhatToDo == 'l')
              {
                   switch(MutantWars.WhatToDo)
                   {
                      case 'l' : LOCATION = N2Service;
                                 MutantWars.LOCK = false;
                                 MutantWars.ButtonGo.doClick(); 
                                 break;

                      case 'n' : if(!Events.Player.GetHumanGirl())
                                 {
                                    L1_HumanGirlEncounter();
                                    Events.Player.SetHumanGirl(true);
                                    Events.Player.ListInventory();
                                 }
                                 else
                                 {
                                    OUT = "\n  You return to the spot where you\n"
                                    + "  first met " + Events.L1_HumanGirl.GetName()
                                    + ".\n\n"
                                    + "  She is standing beside you with a blank\n"
                                    + "  expression on her face. Perhaps she is\n"
                                    + "  trying to block many painful memories...\n\n";

                                    OUT = OUT + Events.L1_HumanGirl.Talk();
                                 }
                                 break;

                      case 's' : OUT = "\n  You see a white concrete block wall.\n"
                                     + "  That's it.\n";
                                 break;

                      case 'e' : OUT = "\n  You see motion sensors and a camera.\n";
                                 break;

                      case 'w' : OUT = "\n  You see electrical conduit and duct work.\n";
                                 break;

                      case 'c' : LOCATION = C1Roof;
                                 MutantWars.LOCK = false;
                                 MutantWars.ButtonGo.doClick();
                                 break;

                      case 'd' : LOCATION = N2;
                                 MutantWars.LOCK = false;
                                 MutantWars.ButtonGo.doClick();
                                 break;

                      default : OUT = "  Invalid input...";
                                break;
                   }//switch

                   if(MutantWars.WhatToDo == 'n' ||
                     MutantWars.WhatToDo == 's' ||
                     MutantWars.WhatToDo == 'e' ||
                     MutantWars.WhatToDo == 'w' ||
                     MutantWars.WhatToDo == 'd' ||
                     MutantWars.WhatToDo == 'c' ||
                     MutantWars.WhatToDo == 'l'
                   )
                   {
                       OUT = OUT + "\n  Directions: (N)orth (S)outh (E)ast (W)est\n"
                       + "  Possibilities: (L)ook  (D)ownstairs\n"
                       + "                           (C)orridor to Roof\n\n\n";;
                   }

             MutantWars.MainOutput.setText(OUT);
             MutantWars.LOCK = true;
             }//close if

             else
             {
                 if(FromAtrium)
                 {
                     OUT = "\n  You ascend the stairs located inside the\n"
                         + "  SERVICE CORRIDOR from the Atrium below.\n\n";
                     FromAtrium = false;
                 }

                 else { OUT = "\n  You are standing in the center of\n"
                            + "  the SERVICE CORRIDOR.\n\n";
                      }

                 OUT = OUT + "  You are in a multi-story concrete-block \n"
                     + "  stairwell connecting two floors of the complex.\n"
                     + "  Looking down the stairs you can see plants and\n"
                     + "  sunlight and hear what appears to be running\n"
                     + "  water. \n\n"
                     + "  To the south is a door labled:\n\n"
                     + "       \"Service Corridor - Roof Access\".\n\n"
                     + "  To the north, you see a storage area where\n"
                     + "  some lab coats are hanging on a rack. To the\n"
                     + "  east, you see a reinforced concrete wall\n"
                     + "  where several motion sensors and a camera\n"
                     + "  are mounted.\n\n"
                     + "  To the west, electrical conduit and duct work\n"
                     + "  for the air filtration system run adjacent to\n"
                     + "  the inner wall...\n";

              if(!Events.Player.GetHumanGirl())
              {
                  OUT = OUT + "\n  Somehow, somewhere close by, you hear\n"
                            + "  someone breathing, mournfully sobbing\n"
                            + "  in a gentle whisper.\n";

                  if(MutantWars.SOUNDEFFECTS) { MutantWars.GirlCrying.play(); }
              }

              OUT = OUT + "\n  Directions: (N)orth (S)outh (E)ast (W)est\n"
                  + "  Possibilities: (L)ook  (D)ownstairs\n"
                  + "                           (C)orridor to Roof\n\n\n";
                  
              if(Events.Player.GetHumanGirl()) { MutantWars.DoorOpen.play(); }

              MutantWars.MainOutput.setText(OUT);

             }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void L1_HumanGirlEncounter()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              OUT = "\n  You shuffle the lab coats around and find\n"
                  + "  in the corner the source of the mournful sobs\n"
                  + "  that haunt you in this room. There in the\n"
                  + "  shadows, almost indistinguishable from the\n"
                  + "  lab coats, a little girl is hiding, peering\n"
                  + "  up at you with moist, blue-green eyes.\n\n"
                  + "  Her clothes are torn and tattered, and her\n"
                  + "  brown-blond hair obscures some of the dirt\n"
                  + "  streaks smudged around the creases of her\n"
                  + "  mouth and tear-stained cheeks. She must\n"
                  + "  have been pretty innovative to escape "
                  + Events.L1_FreezerMutant.GetName() + "'s\n"
                  + "  psychotic rampage\n\n"
                  + "  She could only be, at the oldest, five or six.\n"
                  + "  You bend down to ask her her name, not\n"
                  + "  knowing if she is too deeply disturbed\n"
                  + "  to communicate. She is trembling,\n"
                  + "  perhaps from the cold, perhaps from\n"
                  + "  a state of shock. To your amazement, she\n"
                  + "  answers you, her eyes still unfocused and\n"
                  + "  vacant. She tells you her name is "
                  + Events.L1_HumanGirl.GetName() + ".\n\n"
                  + "  You wrap a lab coat around her and decide to\n"
                  + "  bring her with you.\n\n";

                  OUT = OUT + Events.L1_HumanGirl.Speak("The man in the white coat,\n" +
                                            "        he said seven, but three times...");

                  OUT = OUT + "\n  You try and comfort her, but words are\n"
                      + "  inadequate in this situation. You sit on the\n"
                      + "  floor beside her, wiping the tears from her\n"
                      + "  eyes, muffling her sobs.\n\n";

                  OUT = OUT + Events.L1_HumanGirl.Talk();

                  //Now go back to Service Corrdor NORTH wall
       }


//-----------------------------------------------------------------------------

       public void South2()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'l')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = S2;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : LOCATION = S1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 's' : LOCATION = Surface;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'e' : OUT = "\n  You examine the rows of beds and medical\n"
                                  + "  equipment further. Exhausted, you would love\n"
                                  + "  to lay down and take a nap in one of those\n"
                                  + "  beds.\n\n"
                                  + "  The cool, crisp white sheets seem to call to\n"
                                  + "  you. But your adrenaline is pumping and you\n"
                                  + "  are far too creeped out to snooze now!\n";
                                  break;

                       case 'w' : if(!FoundGun)
                                  {
                                     OUT = "\n  You walk westward over to the basket\n"
                                     + "  of laundry. Although disgusted by the obvious\n"
                                     + "  blood and vomit stains on the contents of the\n"
                                     + "  basket, as well as the sickening odor of\n"
                                     + "  death emanating from the garments, you\n"
                                     + "  decide to root through the basket.\n\n"
                                     + "  Your curiosity pays off!\n\n"
                                     + "  After ferreting through numerous pieces of\n"
                                     + "  of laundry, you find a 9mm pistol!\n";

                                     FoundGun = true;
                                     Events.Player.SetGun(true);
                                     Events.Player.ListInventory();
                                  }
                                  else
                                  {
                                     OUT = "\n  Where you previously found the gun,\n"
                                         + "  you see a pile of dirty laundry.\n\n"
                                         + "  Whoopie! Not doing that again...\n";
                                  }
                                  if(Events.Player.Get9mmAmmo() <= 0)
                                  { 
                                    OUT = OUT + 
                                    "\n  If only you could find some 9mm ammo...\n"; 
                                  }
                                  else
                                  { 
                                    OUT = OUT + 
                                    "\n  Good thing you found that 9mm ammo!\n"; 
                                  }
                                  break;

                       default : OUT = "\n  Invalid input from South2...";
                                 break;
                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'l')
                     {
                        OUT = OUT
                        + "\n  Directions:  (N)orth  (S)outh  (E)ast  (W)est\n"
                        + "  Possibilities: (L)ook  \n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;

             }//close if

             else
             {        
                      MutantWars.LOCK = true;

                      OUT = "\n  Walking down the long hallway strewn\n"
                          + "  with gurneys, you enter the INTENSIVE\n"
                          + "  CARE UNIT. Above your head flourescent\n"
                          + "  tube lights flicker, casting their \n"
                          + "  illumination on the white linoleum floor.\n\n"
                          + "  To the east of the room you see several\n"
                          + "  rows of beds, IV equipment, defibrillators\n"
                          + "  and oxygen tanks. To the west you see an\n"
                          + "  industrial size laudry basket piled high\n"
                          + "  with dirty surgical gowns and sheets.\n\n"
                          + "  To the south, you see elevator doors \n"
                          + "  and a control mechanism mounted on the\n"
                          + "  wall. Painted above the doors in\n"
                          + "  stenciled letters are the words: \n\n"
                          + "      \"Surface Access\"\n";

                          OUT = OUT
                          + "\n  Directions:  (N)orth  (S)outh  (E)ast  (W)est\n"
                          + "  Possibilities: (L)ook  \n";

                          MutantWars.MainOutput.setText(OUT);

             }//close switch

       }//close function

//-----------------------------------------------------------------------------

       public void SurfaceAccess()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 't' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'h' ||
                 MutantWars.WhatToDo == 'r')
              {
                 switch(MutantWars.WhatToDo)
                 {
                    case 't' : if(!CardReaderActivated)
                               {
                                  OUT = "\n  You enter a few digits on the keypad\n"
                                      + "  and nothing happens. On the display\n"
                                      + "  the words \"Terminal Inactive\" appear\n"
                                      + "  and an unpleasant piezzo buzzer sounds\n"
                                      + "  an alarm.\n";
                               }
                               else
                               {
                                   if(!SwipedKeyCard)
                                   {
                                      OUT = 
                                      "\n  When you touch the orange backlit keypad,\n"
                                      + "  it displays the words:\n\n"
                                      + "       \"Terminal Active - Swipe Key Card\"\n\n"
                                      + "  This is accompanied by a pleasant \"ding\".\n"
                                      + "  You try to enter a sequence of digits, but\n"
                                      + "  to no avail. The only thing the reader does\n"
                                      + "  is display the blinking phrase:\n\n"
                                      + "       \"Key Card Required\"\n\n"
                                      + "  on the LCD display panel.\n";
                                   }
                                   else
                                   {
                                      
                                      if(SurfaceDoorsLocked)
                                      {
                                          MutantWars.Input.setText("");

                                          String CODE = JOptionPane.showInputDialog(null,
                                          "\n  When you touch the orange backlit keypad,\n"
                                          + "  the words:\n\n"
                                          + "       \"Terminal Active - Enter Key Code\"\n\n"
                                          + "  appear on the LCD display. The cursor\n"
                                          + "  on the display is blinking. It reads:\n\n"
                                          + "       \"Enter the access code:\"\n\n"
                                          + "  Type the code in and click \"OK\""
                                          + "  to proceed.\n");

                                          int x = Integer.parseInt(CODE);

                                          if(x == KeyCode)
                                          {
                                             OUT = "\n  The display changes to:\n\n"
                                             + "       \"Surface Access Doors Unlocked\""
                                             + " \n\n The elevator button on the reader\n"
                                             + "  console glows green and is blinking.\n";
                                             SurfaceDoorsLocked = false;
                                          }

                                          else
                                          {  
                                            OUT = "\n  The phrase:\n\n"
                                            + "     \"Sorry, that Was an Incorrect Code!\"\n\n"
                                            + "  is displayed on the LCD panel. The display\n"
                                            + "  goes blank.\n";
                                          }
                                      }

                                      else
                                      {
                                         OUT = "\n  Silly, you already entered a valid code\n"
                                             + "  and unlocked the doors.\n";
                                      }
                                   }
                               }
                               MutantWars.MainOutput.setText("GOT HERE " + OUT);
                               break;

                    case 's' : if(!Events.Player.GetKeyCard())
                               {
                                   OUT = "\n  You grab the badge off of the top\n"
                                   + "  of the reader and swipe it through the\n"
                                   + "  slot to your left. Nothing happens.\n\n"
                                   + "  In disgust you place the badge back on\n"
                                   + "  top of the reader.\n";
                               }
                               else
                               {
                                      String CHOICE = JOptionPane.showInputDialog(null,
                                         "  Which card will you swipe, the badge\n"
                                       + "  on top of the reader or the card \n"
                                       + "  you are now holding?\n\n"
                                       + "  Your choices are:\n\n"
                                       + "  swipe the (b)adge\n  swipe your (c)ard\n");

                                      switch(CHOICE.charAt(0))
                                      {
                                         case 'b' : 
                                         OUT = 
                                         "\n  The display reads \"Invalid Card\".\n";
                                         MutantWars.MainOutput.setText(OUT);
                                         break;

                                         case 'c' : 
                                         OUT = 
                                         "\n  The display reads \"Card Accepted\".\n";
                                         MutantWars.MainOutput.setText(OUT);
                                         SwipedKeyCard = true;
                                         break;

                                         default : 
                                         OUT = 
                                         "\n  Invalid response. Choose \"b\" or \"c\".\n";
                                         MutantWars.MainOutput.setText(OUT);
                                         break;
                                      }
                               }
                               break;

                    case 'h' : if(SurfaceDoorsLocked)
                               {
                                  OUT = "\n  You press the elevator button but\n"
                                      + "  nothing happens.\n";
                               }
                               else
                               {
                                   LOCATION = BOSSFIGHT_L1;
                                   MutantWars.LOCK = false;
                                   MutantWars.ButtonGo.doClick();
                                   break;
                               }
                               break;

                    case 'r' : LOCATION = S2;
                               MutantWars.LOCK = false;
                               MutantWars.ButtonGo.doClick();
                               break;

                    default : OUT = "\n  Invalid input from Surface Access...\n";
                              break;

                 }//close switch

                 if(MutantWars.WhatToDo == 't' ||
                    MutantWars.WhatToDo == 's' ||
                    MutantWars.WhatToDo == 'h' ||
                    MutantWars.WhatToDo == 'r')
                 {
                      OUT = OUT + "\n  Your choices are:\n"
                      + "  (t)ry a sequence of numbers on the keypad\n"
                      + "  (s)wipe something through the slot\n"
                      + "  (h)it the elevator button\n"
                      + "  (r)eturn to the center of the ICU\n\n  ";
                 }

                 MutantWars.MainOutput.setText(OUT);
                 MutantWars.LOCK = true;
              }//close if
              
              else
              {
                  MutantWars.LOCK = true;
                  if(MutantWars.SOUNDEFFECTS) { MutantWars.ComputerSound1.play(); }

                  OUT = "\n  You walk towards the control mechanism. It\n"
                      + "  appears to be some sort of key card reader.\n"
                      + "  There is a slot to the side and an alpha-\n"
                      + "  numeric keypad in the center. Underneath\n"
                      + "  the keypad is a large button labeled \"Enter\".\n\n"
                      + "  A name badge lies on top of the reader. In\n"
                      + "  the center above the keypad is a small,\n"
                      + "  orange backlit LCD display. What do you do?\n\n";

                 OUT = OUT + "\n  Your choices are:\n"
                 + "  (t)ry a sequence of numbers on the keypad\n"
                 + "  (s)wipe something through the slot\n"
                 + "  (h)it the elevator button\n"
                 + "  (r)eturn to the center of the ICU\n\n  ";

                 MutantWars.MainOutput.setText(OUT);
              }
       }

//-----------------------------------------------------------------------------

     public void East2()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'l')
              {
                    switch(MutantWars.WhatToDo)
                    {
                       case 'l' : LOCATION = E2;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       case 'n' : if(!FoughtFreezerMutant)
                                  {
                                      String x = JOptionPane.showInputDialog(null,
                                            "  You walk to the north wall of the\n"
                                          + "  warehouse and spy a pair of bolt\n"
                                          + "  cutters!\n\n"
                                          + "  Do you want to pick them up?\n"
                                          + "  (y)es or (n)o").toLowerCase();

                                         switch(x.charAt(0))
                                         {
                                             case 'y' : LOCATION = FREEZERFIGHT;
                                                        MutantWars.LOCK = false;
                                                        MutantWars.ButtonGo.doClick();
                                                        break;

                                             case 'n' : 
                                             OUT = "\n  You decide to leave them there.\n";
                                             break;

                                             default : OUT = "\n  Invalid response."
                                                           + "  (Y)es or (N)o please.\n";
                                                       break;
                                         }//close switch
                                  }//close if
                                  else
                                  {
                                     OUT = "\n  You stumble over the corpse of the\n"
                                         + "  freezer mutant you killed.\n";
                                  }
                                  break;
                       case 's' : if(!Events.Player.GetKey())
                                  {
                                     OUT = "\n  You walk to the north end of the warehouse.\n"
                                     + "  There on a shelf at the very back, you find a\n"
                                     + "  small black, steel box. It looks like it might\n"
                                     + "  hold a key or valuables.\n\n"
                                     + "  If only you could open it!\n\n"
                                     + "  If only there were a pair of bolt cutters\n"
                                     + "  around here somewhere...\n";
                                  }
                                  else
                                  {
                                     OUT = "\n  You return to the far-north end of the\n"
                                         + "  the complex's warehouse. You try the key\n"
                                         + "  out that you took from around "
                                         + Events.L1_FreezerMutant.GetName() + "'s neck.\n\n"
                                         + "  No matter how you insert it into the lock\n"
                                         + "  on the black steel box, it doesn't seem to\n"
                                         + "  open it. Perhaps it is possible that this\n"
                                         + "  key goes to something else...\n";
                                  }
                                  break;

                       case 'e' : OUT = "\n  You walk towards the east about half\n"
                                      + "  the length of the warehouse. There appears\n"
                                      + "  to be nothing interesting there. Just boxes\n"
                                      + "  and crates of perishables that have long\n"
                                      + "  since past their due dates.\n\n"
                                      + "  You return to your original location.\n";
                                  break;

                       case 'w' : LOCATION = E1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;

                       default : OUT = "\n  Invalid input from East2...";
                                 break;

                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'l')
                     {
                         OUT = OUT +
                         "\n  Directions:  (N)orth  (S)outh  (E)ast  (W)est\n"
                         + "  Possibilities: (L)ook \n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;
        }//close if

        else
        {
              MutantWars.LOCK = true;
              //RanAwayFromFreezerMutant = true;

              if(RanAwayFromFreezerMutant)
              {
                  LOCATION = FREEZERFIGHT;
                  MutantWars.LOCK = false;
                  MutantWars.ButtonGo.doClick();
              }

              else
              {
                  if(MutantWars.SOUNDEFFECTS) { MutantWars.WindIce.play(); }

                  if(East2FirstTime)
                  {
                     OUT = "\n  You walk down the dim hallway from\n"
                         + "  the previous storage room into a much\n"
                         + "  larger room, a WAREHOUSE. It must be\n"
                         + "  at least 20 degrees colder in this room\n"
                         + "  than in the previous one. Brrr!\n\n";

                     East2FirstTime = false;
                  }
                  else
                  {
                      OUT = "\n  You return to the WAREHOUSE and shiver\n"
                      + "  as a blast of cold air hits you in the face.\n"
                      + "  It's so cold you can see your breath in the\n"
                      + "  the dim lighting.\n";
                  }


                  OUT = OUT + "\n  You are standing in the middle of an\n"
                            + "  enormous room. The ceiling must at\n"
                            + "  least 25 feet high and reinforced\n"
                            + "  with thick steel girders that run the\n"
                            + "  length of the room.\n";

                  OUT = OUT + "\n  To the west behind you is the previous\n"
                            + "  storage room. Ahead, to your east, as\n"
                            + "  well as to the north and south,\n"
                            + "  you see nothing but crates, shipping\n"
                            + "  containers and boxes. Too far away to\n"
                            + "  make out any detail, you conclude that\n"
                            + "  this room warrants further investigation...\n";

                  if(FoughtFreezerMutant)
                  { OUT = OUT + "\n  To the north lies a dead freezer mutant.\n"; }

                  OUT = OUT +
                  "\n  Directions:  (N)orth  (S)outh  (E)ast  (W)est\n"
                  + "  Possibilities: (L)ook \n";

                  MutantWars.MainOutput.setText(OUT);

         }//close inner else

        }//close outer else

       }//close function

//-----------------------------------------------------------------------------
       public void L1_FreezerMutantFight()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'r' ||
                 MutantWars.WhatToDo == 'f' ||
                 MutantWars.WhatToDo == 'g')
              {
                   switch(MutantWars.WhatToDo)
                   {
                      case 'f' : if(!FoughtFreezerMutant)
                                 {
                                     //Need to Use a ThreadWorker object to make
                                     //GUI accessible while combat is looping
                                     SwingWorker worker = new SwingWorker()
                                     {
                                          public Object construct()
                                          {
                                              Functions.Combat(
                                              Events.Player, Events.L1_FreezerMutant);
                                              return 0;
                                          }

                                          public void finished()
                                          {

                                            if(Events.Player.GetHit() > 0)
                                            {
                                               OUT = "  Congratulations. " + 
                                               "You survived your ordeal\n"
                                               + "  with " + 
                                               Events.L1_FreezerMutant.GetName() 
                                               + ".\n\n"
                                               + "  You notice a metal KEY hanging around "
                                               + "your defeated opponent's neck.\n"
                                               + "  You decide to take it. It must go\n"
                                               + "  to something important...\n";

                                               FoundKey = true;
                                               FoughtFreezerMutant = true;
                                               Events.Player.SetKey(true);
                                               Events.Player.SetFREEZE(true);
                                               Events.Player.SetMutantPower(
                                               Events.Player.GetMutantPower() + 30);
                                               Events.Player.AddConquest(
                                               Events.L1_FreezerMutant.GetName());
                                               Events.Player.SetScore(
                                               Events.Player.GetScore() + 100);
                                               Events.Player.DisplayStats();

                                               OUT = OUT + "\n  You absorb " 
                                               + Events.L1_FreezerMutant.GetName()
                                               + "'s ability to FREEZE\n  "
                                               + "(lower ambient temperature)!\n\n"
                                               + "  You also absorb 30 points of "
                                               + "mutant energy.\n\n";

                                               OUT = OUT + "  Due to exceptional combat "
                                               + "prowess,\n  100 is added to your score!\n";

                                               OUT = OUT + "\n  Enter \"G\" and "
                                               + "click \"GO\" to move on.";

                                               MutantWars.Input.setText("G");
                                               MutantWars.MainOutput.setText(OUT);
                                               RanAwayFromFreezerMutant = false;
                                            }
                                          }
                                     };
                                     Events.GUI_INTERFACE.refresh();
                                     worker.start();
                                     if(Events.Player.GetHit() == 0) { Events.GameOver(); }
                                 }
                                 else
                                 {
                                      MutantWars.MainOutput.setText(
                                      "\n  You already fought the freezer mutant!\n");
                                 }
                                 break;
                      case 'r' : OUT = "\n  You decide to run away to save your life.\n"
                                 + "  Unfortunately, " + Events.L1_FreezerMutant.GetName()
                                 + "  is able to land a few\n"
                                 + "  chilling blows in your retreat.\n\n"
                                 + "  30 points worth!\n\n"
                                 + "  In a panic, you run, not caring where\n"
                                 + "  you will end up - just anywhere but here,\n"
                                 + "  you think to yourself...\n\n"
                                 + "  Enter \"G\" and click \"GO\" to continue.\n";

                                 MutantWars.Input.setText("G");

                                 if(Events.Player.GetHit() - 30 > 0)
                                 {
                                    Events.Player.SetHit(Events.Player.GetHit() - 30);
                                 }
                                 else
                                 {
                                    Events.Player.SetHit(0);
                                    LOCATION = QUIT;
                                    OUT = OUT + "\n  You did not survive this ordeal.";
                                 }
                                 RanAwayFromFreezerMutant = true;
                                 Events.Player.DisplayStats();
                                 MutantWars.Input.setText("g");
                                 break;
                      case 'g' : if(RanAwayFromFreezerMutant || FoughtFreezerMutant)
                                 {
                                    if(RanAwayFromFreezerMutant) { LOCATION = E1; }
                                    else { LOCATION = E2; }
                                    MutantWars.LOCK = false;
                                    MutantWars.ButtonGo.doClick();
                                 }
                                 break;
                      default : OUT = "  Invalid response...\n";
                                break;

                   }//close switch

              MutantWars.MainOutput.setText(OUT);
              MutantWars.LOCK = true;

              }//close if

              else
              {
                  MutantWars.LOCK = true;

                  if(!FoughtFreezerMutant)
                  {
                      if(!RanAwayFromFreezerMutant)
                      {
                         OUT = "\n  As you reach for the bolt cutters, the\n"
                             + "  hair on the back of your neck stands up.\n\n"
                             + "  Out of the corner of your eye you see a\n"
                             + "  man walk towards you from the shadows.\n\n"
                             + "  \"You can call me "
                             + Events.L1_FreezerMutant.GetName() + "\", he\n"
                             + "  says, \"and I hope you like it cold!\"\n\n"
                             + "  You gasp for breath as the air around you\n"
                             + "  becomes so cold it stings your lungs.\n\n";

                         if(MutantWars.SOUNDEFFECTS) { MutantWars.ICETalk.play(); }
                      }

                      else
                      {
                         OUT = "\n  The freezer mutant you ran away\n"
                             + "  from sees you and charges you!\n\n";
                      }

                      OUT = OUT + "  Will you (F)ight or (R)un away?\n"
                          + "\n  If you choose to fight, first select a weapon for\n"
                          + "  combat, if you are lucky enough to possess one.\n\n"
                          + "  You may also select an ability if you wish to use\n"
                          + "  it for this combat session.\n";
                  }

                  else
                  {
                      OUT = "\n  You have successfully vanquished "
                            + Events.L1_FreezerMutant.GetName() + ".\n\n"
                          + "  With the key you now possess, you\n"
                          + "  realize you didn't really need those\n"
                          + "  bolt cutters anyway...\n\n"
                          + "  Click \"GO\" to move on.";

                          MutantWars.LOCK = false;
                  }

                  MutantWars.MainOutput.setText(OUT);
              }

       }

//-----------------------------------------------------------------------------

       public void West2()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'n' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 'e' ||
                 MutantWars.WhatToDo == 'w' ||
                 MutantWars.WhatToDo == 'l')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'l' : LOCATION = W2;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;
                       case 'n' : OUT = "\n  You walk over to the north side of the\n"
                                      + "  room. A long conference table that\n"
                                      + "  could seat approximately 12 people\n"
                                      + "  sits adjacent to the wall.\n\n"
                                      + "  It is made of what appears to be a\n"
                                      + "  woodgrain formica and there is a\n"
                                      + "  conference phone situated in the very\n"
                                      + "  middle.\n\n"
                                      + "  Not finding anything you can use,\n"
                                      + "  you walk back to the center of the\n"
                                      + "  room.\n";
                                  break;
                       case 's' : MutantWars.Input.requestFocus();
                                  LOCATION = THESAFE;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;
                       case 'e' : LOCATION = W1;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;
                       case 'w' : OUT = "\n  You walk over the the west side of the\n"
                                      + "  room, blinded by the flashing lights.\n\n"
                                      + "  You can hear the capacitors discharge and\n"
                                      + "  the clicks of the relays in the strobe's\n"
                                      + "  circuitry. Nothing else seems interesting\n"
                                      + "  and you are getting a splitting headache,\n"
                                      + "  so you decide to return to the center of\n"
                                      + "  the room.\n";
                                  break;
                       default : OUT = "\n  Invalid input from West2...";
                                 break;

                     }//close switch

                     if(MutantWars.WhatToDo == 'n' ||
                        MutantWars.WhatToDo == 's' ||
                        MutantWars.WhatToDo == 'e' ||
                        MutantWars.WhatToDo == 'w' ||
                        MutantWars.WhatToDo == 'l')
                     {
                        OUT = OUT +
                        "\n\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n"
                        + "  Possibilities:  (L)ook\n";
                     }

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;
             }//close if

             else
             {
                 if(West2FirstTime)
                 {
                    OUT = "\n  You proceed down the hallway from the\n"
                        + "  dining room and through two steel and\n"
                        + "  glass doors into what appears to be a\n"
                        + "  CONFERENCE ROOM.\n";
                    West2FirstTime = false;
                 }

                 else
                 {
                   OUT = "\n  You return to the CONFERENCE ROOM to\n"
                       + "  find it much as it was before.\n";
                 }

                 if(MutantWars.SOUNDEFFECTS) { MutantWars.Warning.play(); }

                 OUT = OUT + "\n  A piercing alarm painfully fills your\n"
                        + "  ears. The room is intermittently\n"
                        + "  illuminated by a flashing strobe light\n"
                        + "  part of the alarm system. In blinks of\n"
                        + "  light amidst the darkness, you look to\n"
                        + "  the north and are able to make out a\n"
                        + "  conference table.\n\n"
                        + "  To the south, you can see the outline\n"
                        + "  of a large, heavy steel box - perhaps a\n"
                        + "  safe. Towards the west wall a bank of\n"
                        + "  flashing strobe lights disorients you.\n";

                        OUT = OUT +
                        "\n\n  Directions: (N)orth  (S)outh  (E)ast  (W)est\n"
                        + "  Possibilities:  (L)ook\n";

                 MutantWars.MainOutput.setText(OUT);

             }//close else

       }//close function

//-----------------------------------------------------------------------------

       public void TheSafe()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'p' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 't' ||
                 MutantWars.WhatToDo == 'r')
              {
                     switch(MutantWars.WhatToDo)
                     {
                       case 'p' : if(!SafeUnlocked)
                                  {
                                     OUT = "\n  You can not open the safe.\n"
                                         + "  It is locked and latched.\n";
                                  }
                                  else
                                  {
                                     if(!FoundKeyCard)
                                     {
                                        OUT = "\n  After several tries, you open the \n"
                                            + "  safe door. Inside you find an electronic\n"
                                            + "  key card! This might come in handy\n";
                                        FoundKeyCard = true;
                                        Events.Player.SetKeyCard(true);
                                        Events.Player.ListInventory();
                                     }
                                     else
                                     { OUT = "\n  The safe is empty. You already found\n"
                                           + "  the key card.\n";
                                     }
                                  }
                                  MutantWars.MainOutput.setText(OUT);
                                  break;
                       case 's' : if(!FoundKey)
                                  {
                                     OUT = "\n  You have no keys to insert into the safe!\n";
                                  }
                                  else
                                  {
                                     if(!KEYinserted)
                                     {
                                        OUT = "\n  You insert the KEY you found on the\n"
                                            + "  mutant into the safe. It bonds to the\n"
                                            + "  surface of the locking mechanism and\n"
                                            + "  you can not get it out.\n";
                                        KEYinserted = true;
                                        Events.Player.SetKey(false);
                                     }
                                     else
                                     {
                                        OUT = "\n  The key is still there from the\n"
                                            + "  last time you inserted it into\n"
                                            + "  the locking mechanism. It is stuck.\n";
                                     }
                                  }
                                  MutantWars.MainOutput.setText(OUT);
                                  break;
                       case 't' : if(!KEYinserted)
                                  {
                                      OUT = "\n  You can't turn the handle. \n"
                                          + "  No key is inserted.\n";
                                  }
                                  else  //Key IS Inserted
                                  {
                                      if(!FoundMatches)
                                      {
                                         OUT = "\n  With the key inserted, you turn the\n"
                                         + "  handle. Nothing Happens. The inner\n"
                                         + "  mechanism has been bent and can't be\n"
                                         + "  released. It must have been "
                                         + Events.L1_FreezerMutant.GetName()
                                         + "  's\n  handywork.\n\n"
                                         + "  Somehow he damaged the mechanism,\n"
                                         + "  freezing the internal catch pins\n"
                                         + "  together in a jammed state. The\n"
                                         + "  metal handle is so cold it burns you\n"
                                         + "  to touch it. You try to bend the metal\n"
                                         + "  back but it can't be bent. You can see ice\n"
                                         + "  crystals along the edge of the handle.\n\n"
                                         + "  It might be possible to release it\n"
                                         + "  if you could make the metal more maleable,\n"
                                         + "  that is, to somehow thaw it out.\n\n"
                                         + "  If only there were a heat source...\n";
                                      }
                                      else   //Got Matches
                                      {
                                        if(!FoundSterno)
                                        {
                                          OUT = "\n  You have the right idea with the matches,"
                                          + "\n  but none of them will burn long enough to\n"
                                          + "  heat the metal to a sufficient temperature.\n"
                                          + "  You need a fuel source to ignite with those\n"
                                          + "  matches...";
                                        }
                                        else  //Got Sterno
                                        {
                                          if(!SafeUnlocked)
                                          {
                                            OUT = "\n  With the key inserted, you are still\n"
                                            + "  unable to turn the handle. Now that you\n"
                                            + "  have a fuel source, you take one of your\n"
                                            + "  matches and ignite the can of sterno. You\n"
                                            + "  place it underneath the handle and it\n"
                                            + "  slowly heats the metal, causing it to\n"
                                            + "  become more maleable. After a few minutes,\n"
                                            + "  you try to turn the handle again.\n\n"
                                            + "  \"Click!\", it turns. It's unjammed!\n"
                                            + "  You did it! The safe is now unlocked.\n";

                                            SafeUnlocked = true;
                                          }

                                          else
                                          {
                                             OUT = "\n  You have already inserted the key,\n"
                                             + "  heated the lock mechanism, and turned\n"
                                             + "  the handle. It is unlatched and open,\n"
                                             + "  there's no point in turning it again.\n";
                                          }
                                         }

                                      }
                                  }
                                  MutantWars.MainOutput.setText(OUT);
                                  break;
                       case 'r' : LOCATION = W2;
                                  MutantWars.LOCK = false;
                                  MutantWars.ButtonGo.doClick();
                                  break;
                       default : OUT = "\n  Invalid input from the Safe...";
                                 MutantWars.MainOutput.setText(OUT);
                                 break;

                     }//close switch

              if(MutantWars.WhatToDo == 'p' ||
                 MutantWars.WhatToDo == 's' ||
                 MutantWars.WhatToDo == 't' ||
                 MutantWars.WhatToDo == 'r')
              {
                     OUT = OUT +
                     "\n\n  What will you try to do? \n\n"
                     + "  (P)ull the safe door open\n"
                     + "  (S)tick something into the key hole\n"
                     + "  (T)urn the handle\n"
                     + "  (R)eturn to the center of the room\n";

                     MutantWars.MainOutput.setText(OUT);
                     MutantWars.LOCK = true;
              }

             }//close if

             else
             {
                  MutantWars.LOCK = true;
                  if(MutantWars.SOUNDEFFECTS) { MutantWars.ComputerSound1.play(); }

                  if(SafeFirstTime)
                  {
                       OUT = "\n  You walk over to the south side of the\n"
                       + "  Conference Room. You can definitely tell\n"
                       + "  now, despite all the strobing madness, that\n"
                       + "  the cubical object you saw was indeed a safe.\n"
                       + "  You can see that it has a handle for clasping\n"
                       + "  and a slot to insert a metal key.\n";
                       SafeFirstTime = false;
                   }

                   else { OUT = "\n  You return once again to the safe.\n"; }

                   OUT = OUT
                       + "\n\n  What will you try to do? \n\n"
                       + "  (P)ull the safe door open\n"
                       + "  (S)tick something into the key hole\n"
                       + "  (T)urn the handle\n"
                       + "  (R)eturn to the center of the room\n";

                   MutantWars.MainOutput.setText(OUT);
             }

       }//close function

//-----------------------------------------------------------------------------

       public void FinalBossFight()
       {
              Events.GUI_INTERFACE.refresh();  //For Graphics

              if(MutantWars.WhatToDo == 'f')
              {
                   //Events.FreezerSquad[0].Speak("Look what we have here!");
                   //Events.PyroSquad[0].Speak("It's a wussy little Impath.");

                   OUT = "\n  A telekinetic, Movz walks away, mumbling...\n";
                   OUT = "\n  Fire and Ice!\n"
                       + "  The Freezers and Pyros attack you all at once!\n";

                   MutantWars.MainOutput.setText(OUT);

                   //Need to Use ThreadWorker object to make GUI accessible while combat
                   //is looping. Example uses arrays with static instances in Events.

                   SwingWorker worker = new SwingWorker()
                   {
                          public Object construct()
                          {
                                for(int x = 0; x < 2; x++)
                                {
                                    Events.FreezerSquad[x] = new Freezer();
                                    if(x == 0) { LOCATION = FreezerMutant1Image; }
                                    if(x == 1) { LOCATION = FreezerMutant2Image; }
                                    Events.GUI_INTERFACE.DrawImages();
                                    Functions.Combat(Events.Player,Events.FreezerSquad[x]);


                                    Events.PyroSquad[x] = new Pyrotech();
                                    if(x == 0) { LOCATION = PyroMutant1Image; }
                                    if(x == 1) { LOCATION = PyroMutant2Image; }
                                    Events.GUI_INTERFACE.DrawImages();
                                    Functions.Combat(Events.Player,Events.PyroSquad[x]);

                                }

                                return 0;
                          }//close worker thread construct

                          public void finished()
                          {
                                 if(Events.Player.GetHit() > 0)
                                 {
                                     OUT = "\n\n  Congratulations!"
                                     + "\n\n  No one will ever truly understand\n"
                                     + "  how you survived such a massive onslaught.\n\n"
                                     + "  Badly bruised and beaten, you feel lucky to\n"
                                     + "  even be alive. Gathering your strength and\n"
                                     + "  wits, you try to prepare yourself for the\n"
                                     + "  enevitable backlash that will ensue...";
                                 }
                                 else
                                 {
                                    OUT = "\n\n  You did not survive this encounter.\n"
                                    + "  Who could blame you? How could anyone have\n"
                                    + "  withstood that many powerful mutant opponents\n"
                                    + "  at one time?";
                                 }

                                 OUT = OUT + "\n\n  Click \"GO\" to continue.";
                                 //MutantWars.Input.setText("G");
                                 MutantWars.LOCK = false;
                                 Events.Player.SetMutantPower(
                                 Events.Player.GetMutantPower() + 1000);
                                 Events.Player.AddConquest(
                                 Events.L1_FreezerMutant.GetName());
                                 Events.Player.SetScore(
                                 Events.Player.GetScore() + 2000);
                                 Events.Player.DisplayStats();
                                 Events.Player.ListInventory();
                                 MutantWars.MainOutput.setText(OUT);
                                 LOCATION = QUIT;
                          }
                   }; //close worker thread definition
                   Events.GUI_INTERFACE.refresh();
                   worker.start();

              }//close TOP if for Final_Boss_Fight

              else
              {
                   MutantWars.LOCK = true;
                   LOCATION = MutantMixImage;
                   Events.GUI_INTERFACE.refresh();  //For Graphics

                   OUT = "\n  You press the elevator button and the\n"
                   + "  doors swing open. You feel a gigantic\n"
                   + "  sense of relief at the thought of escaping\n"
                   + "  this underground nightmare, but you also\n"
                   + "  feel a knot swell in your throat as\n"
                   + "  apprehension builds concerning what you\n"
                   + "  may find on the surface...\n";

                   OUT = OUT + "\n\n  You enter the elevator and ascend to the\n"
                       + "  surface. Walking outside, you blink in the\n"
                       + "  blinding glow of the burning sun. Your head\n"
                       + "  is pounding as you try to ascertain your\n"
                       + "  surroundings with a narrow squint.\n"
                       + "  Unbearable fear grips you, twisting the knot\n"
                       + "  in your throat into cruel contortions. There,\n"
                       + "  in standing in the clearing you have just\n"
                       + "  walked into, stands 7 mutants. They leer at\n"
                       + "  you with a menacing gaze. Your blood runs\n"
                       + "  cold...\n\n"
                       + "  Choose a weapon or ability for combat and\n"
                       + "  \"f\" to fight, then click \"GO\" to continue...";

                   MutantWars.MainOutput.setText(OUT);

              }

       }//close function

//-----------------------------------------------------------------------------

    public void SaveLevel(String FileName)
    {
           try
           {
               //Open for Append
               Events.PlayerOut = new FileOutputStream(Events.PlayerFile, true);
               Events.WritePlayer = new PrintStream(Events.PlayerOut);

               //Save Event Data
               Events.WritePlayer.println("---- Begin Level 1 Data ----");
               Events.WritePlayer.println(LOCATION);
               Events.WritePlayer.println(C1FirstTime);
               Events.WritePlayer.println(DataCrystalTaken);
               Events.WritePlayer.println(Found9mmAmmo );
               Events.WritePlayer.println(Found9mmAmmoBox);
               Events.WritePlayer.println(CardReaderActivated);
               Events.WritePlayer.println(Center1BasementFirstTime);
               Events.WritePlayer.println(DrankSoda);
               Events.WritePlayer.println(AteSandwhich);
               Events.WritePlayer.println(FoundMachete);
               Events.WritePlayer.println(FoundSyringe);
               Events.WritePlayer.println(FoundMatches);
               Events.WritePlayer.println(FoundFramePack);
               Events.WritePlayer.println(FoundMedKit);
               Events.WritePlayer.println(FoundMRERations);
               Events.WritePlayer.println(FoundSterno);
               Events.WritePlayer.println(N2FirstTime);
               Events.WritePlayer.println(FoundJacket);
               Events.WritePlayer.println(ExplodedTripBomb);
               Events.WritePlayer.println(FoundGun);
               Events.WritePlayer.println(FoundKeyCard);
               Events.WritePlayer.println(SwipedKeyCard);
               Events.WritePlayer.println(SurfaceDoorsLocked);
               Events.WritePlayer.println(East2FirstTime);
               Events.WritePlayer.println(West2FirstTime);
               Events.WritePlayer.println(FoughtFreezerMutant);
               Events.WritePlayer.println(RanAwayFromFreezerMutant);
               Events.WritePlayer.println(FoundKey);
               Events.WritePlayer.println(SafeFirstTime);
               Events.WritePlayer.println(SafeUnlocked);
               Events.WritePlayer.println(KEYinserted);
               Events.WritePlayer.println(FoundL1_HumanGirl);
               Events.WritePlayer.println(Events.Player.GetHumanGirl());
               Events.WritePlayer.println(FromAtrium);
               Events.WritePlayer.println(FromBelow);
               Events.WritePlayer.println(MapC1);
               Events.WritePlayer.println(MapC1Roof);
               Events.WritePlayer.println(MapC1Basement);
               Events.WritePlayer.println(MapN1);
               Events.WritePlayer.println(MapS1);
               Events.WritePlayer.println(MapE1);
               Events.WritePlayer.println(MapE1Closet);
               Events.WritePlayer.println(MapW1);
               Events.WritePlayer.println(MapN2);
               Events.WritePlayer.println(MapN2Garage);
               Events.WritePlayer.println(MapN2Service);
               Events.WritePlayer.println(MapS2);
               Events.WritePlayer.println(MapE2);
               Events.WritePlayer.println(MapW2);
               Events.WritePlayer.println(MapSurface);
               Events.WritePlayer.println("---- End Level 1 Data ----");
         }

         catch(IOException e)
         {
                OUT = "Unable to save level 1 event values";
         }
    }


    public void LoadLevel(String FileName)
    {
           try
           {
               //Save Level 1 Event Data
               Events.StreamPlayer.readLine(); //Read empty line for label
               String PlayerLocation = Events.StreamPlayer.readLine();
               String c1firsttime = Events.StreamPlayer.readLine();
               String datacrystaltaken = Events.StreamPlayer.readLine();
               String found9mmammo = Events.StreamPlayer.readLine();
               String found9mmammobox = Events.StreamPlayer.readLine();
               String cardreaderactivated = Events.StreamPlayer.readLine();
               String center1basementfirsttime = Events.StreamPlayer.readLine();
               String dranksoda = Events.StreamPlayer.readLine();
               String atesandwhich = Events.StreamPlayer.readLine();
               String foundmachete = Events.StreamPlayer.readLine();
               String foundsyringe = Events.StreamPlayer.readLine();
               String foundmatches = Events.StreamPlayer.readLine();
               String foundframepack = Events.StreamPlayer.readLine();
               String foundmedkit = Events.StreamPlayer.readLine();
               String foundmrerations = Events.StreamPlayer.readLine();
               String foundsterno = Events.StreamPlayer.readLine();
               String n2firsttime = Events.StreamPlayer.readLine();
               String foundjacket = Events.StreamPlayer.readLine();
               String explodedtripbomb = Events.StreamPlayer.readLine();
               String foundgun = Events.StreamPlayer.readLine();
               String foundkeycard = Events.StreamPlayer.readLine();
               String swipedkeycard = Events.StreamPlayer.readLine();
               String surfacedoorslocked = Events.StreamPlayer.readLine();
               String east2firsttime = Events.StreamPlayer.readLine();
               String west2firsttime = Events.StreamPlayer.readLine();
               String foughtfreezermutant = Events.StreamPlayer.readLine();
               String ranawayfromfreezermutant = Events.StreamPlayer.readLine();
               String foundkey = Events.StreamPlayer.readLine();
               String safefirsttime = Events.StreamPlayer.readLine();
               String safeunlocked = Events.StreamPlayer.readLine();
               String keyinserted = Events.StreamPlayer.readLine();
               String foundL1_humangirl = Events.StreamPlayer.readLine();
               String GotGirl = Events.StreamPlayer.readLine();
               String fromatrium = Events.StreamPlayer.readLine();
               String frombelow = Events.StreamPlayer.readLine();
               String mapc1 = Events.StreamPlayer.readLine();
               String mapc1roof = Events.StreamPlayer.readLine();
               String mapc1basement = Events.StreamPlayer.readLine();
               String mapn1 = Events.StreamPlayer.readLine();
               String maps1 = Events.StreamPlayer.readLine();
               String mape1 = Events.StreamPlayer.readLine();
               String mape1closet = Events.StreamPlayer.readLine();
               String mapw1 = Events.StreamPlayer.readLine();
               String mapn2 = Events.StreamPlayer.readLine();
               String mapn2garage = Events.StreamPlayer.readLine();
               String mapn2service = Events.StreamPlayer.readLine();
               String maps2 = Events.StreamPlayer.readLine();
               String mape2 = Events.StreamPlayer.readLine();
               String mapw2 = Events.StreamPlayer.readLine();
               String mapsurface = Events.StreamPlayer.readLine();
               Events.StreamPlayer.readLine(); //Read empty line for label

               //Set player and event data with local function data
               LOCATION = Integer.parseInt(PlayerLocation);
               C1FirstTime = Functions.TrueOrFalse(c1firsttime);
               DataCrystalTaken = Functions.TrueOrFalse(datacrystaltaken);
               Found9mmAmmo = Functions.TrueOrFalse(found9mmammo);
               Found9mmAmmoBox = Functions.TrueOrFalse(found9mmammobox);
               CardReaderActivated = Functions.TrueOrFalse(cardreaderactivated);
               Center1BasementFirstTime = Functions.TrueOrFalse(center1basementfirsttime);
               DrankSoda = Functions.TrueOrFalse(dranksoda);
               AteSandwhich = Functions.TrueOrFalse(atesandwhich);
               FoundMachete = Functions.TrueOrFalse(foundmachete);
               FoundSyringe = Functions.TrueOrFalse(foundsyringe);
               FoundMatches = Functions.TrueOrFalse(foundmatches);
               FoundFramePack = Functions.TrueOrFalse(foundframepack);
               FoundMedKit = Functions.TrueOrFalse(foundmedkit);
               FoundMRERations = Functions.TrueOrFalse(foundmrerations);
               FoundSterno = Functions.TrueOrFalse(foundsterno);
               N2FirstTime = Functions.TrueOrFalse(n2firsttime);
               FoundJacket = Functions.TrueOrFalse(foundjacket);
               ExplodedTripBomb = Functions.TrueOrFalse(explodedtripbomb);
               FoundGun = Functions.TrueOrFalse(foundgun);
               FoundKeyCard = Functions.TrueOrFalse(foundkeycard);
               SwipedKeyCard = Functions.TrueOrFalse(swipedkeycard);
               SurfaceDoorsLocked = Functions.TrueOrFalse(surfacedoorslocked);
               East2FirstTime = Functions.TrueOrFalse(east2firsttime);
               West2FirstTime = Functions.TrueOrFalse(west2firsttime);
               FoughtFreezerMutant = Functions.TrueOrFalse(foughtfreezermutant);
               RanAwayFromFreezerMutant = Functions.TrueOrFalse(ranawayfromfreezermutant);
               FoundKey = Functions.TrueOrFalse(foundkey);
               SafeFirstTime = Functions.TrueOrFalse(safefirsttime);
               SafeUnlocked = Functions.TrueOrFalse(safeunlocked);
               KEYinserted = Functions.TrueOrFalse(keyinserted);
               FoundL1_HumanGirl = Functions.TrueOrFalse(foundL1_humangirl);
               Events.Player.SetHumanGirl(Functions.TrueOrFalse(foundL1_humangirl));
               FromAtrium = Functions.TrueOrFalse(fromatrium);
               FromBelow = Functions.TrueOrFalse(frombelow);
               MapC1 = Functions.TrueOrFalse(mapc1);
               MapC1Roof = Functions.TrueOrFalse(mapc1roof);
               MapC1Basement = Functions.TrueOrFalse(mapc1basement);
               MapN1 = Functions.TrueOrFalse(mapn1);
               MapS1 = Functions.TrueOrFalse(maps1);
               MapE1 = Functions.TrueOrFalse(mape1);
               MapE1Closet = Functions.TrueOrFalse(mape1closet);
               MapW1 = Functions.TrueOrFalse(mapw1);
               MapN2 = Functions.TrueOrFalse(mapn2);
               MapN2Garage = Functions.TrueOrFalse(mapn2garage);
               MapN2Service = Functions.TrueOrFalse(mapn2service);
               MapS2 = Functions.TrueOrFalse(maps2);
               MapE2 = Functions.TrueOrFalse(mape2);
               MapW2 = Functions.TrueOrFalse(mapw2);
               MapSurface = Functions.TrueOrFalse(mapsurface);

         }

         catch(IOException e)
         {
                OUT = "  Unable to load level 1 event values.\n";
         }

    }

}//end Level1 Events class
