//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 41 lines of code

import javax.swing.*;
import java.io.*;

public class Impath extends SuperMutant
{
       public Impath()
       {  
              String OUT = "\n\tCreating an Impath SuperMutant.";
              MutantWars.MainOutput.setText(OUT);
              SetCharClass("Impath");
       }

       public Impath(String x)
       { 
              String OUT = "\n\tCreating an Impath SuperMutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
              SetCharClass("Impath");
       }

       //Functions
       public void FeelThePower() 
       { 
              String OUT = "\n\tAbsorbing ability...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesor Methods
       public String GetLearnedAbilities() { return LearnedAbilities; }
       public int GetNumLearnedAbilities() { return NumLearnedAbilities; }
       public void SetLearnedAbilities(String x) { LearnedAbilities = x; }
       public void SetNumLearnedAbilities(int x) { NumLearnedAbilities = x; }        

       //Private Data
       private String LearnedAbilities;
       private int NumLearnedAbilities; 
}
