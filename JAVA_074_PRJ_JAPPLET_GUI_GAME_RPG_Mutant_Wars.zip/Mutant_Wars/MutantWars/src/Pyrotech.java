//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class Pyrotech extends Mutant
{
       public Pyrotech() 
       {  
              String OUT = "\n\tCreating an Pyrotech mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetCharClass("Pyro");
       }

       public Pyrotech(String x)
       { 
              String OUT = "\n\tCreating an Pyrotech mutant.";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
              SetCharClass("Pyro");
       } 

       //Functions
       public void Fire() 
       { 
              String OUT = "\n\tIgniting objects with ability...";
              MutantWars.MainOutput.setText(OUT);
       }

       //Public Accesors
       

       //Private Data
}
