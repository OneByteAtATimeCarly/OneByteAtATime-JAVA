//Mutant Wars 1.5 for Java - Charles Germany - 2007 - Derived class
//Derived Class
//Class = 34 lines of code

import javax.swing.*;
import java.io.*;

public class TimeTraveler extends Mutant
{
       public TimeTraveler() 
       {  
              String OUT = "\n\tCreating a TimeTraveler mutant!";
              MutantWars.MainOutput.setText(OUT);
       }

       public TimeTraveler(String x)
       { 
              String OUT = "\n\tCreating a TimeTraveler mutant!";
              MutantWars.MainOutput.setText(OUT);
              SetName(x);
       } 

       //Functions
       public void TimeTravel() 
{ 
              String OUT = "\n\tTraveing through time...";
              MutantWars.MainOutput.setText(OUT);;
}

       //Public Accesors
       

       //Private Data
}
