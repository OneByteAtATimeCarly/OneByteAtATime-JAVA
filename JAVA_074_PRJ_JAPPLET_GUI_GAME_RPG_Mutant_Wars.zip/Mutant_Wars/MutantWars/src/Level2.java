//Class for Future Level 2 Events. This will modularize level design.
//16 lines of code

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Level2
{
       public Level2() {  }   
    
       public void Switchboard() 
       {

       }   
}