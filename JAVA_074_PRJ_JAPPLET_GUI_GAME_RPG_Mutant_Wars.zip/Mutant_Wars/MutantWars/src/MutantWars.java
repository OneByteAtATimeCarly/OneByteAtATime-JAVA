//Applet Interface Class - 2,415 lines of code

import java.awt.Dimension.*;
import javax.swing.JApplet.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.Font;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;
import javax.swing.JTextPane;
import javax.swing.*;
import java.awt.Insets;
import java.awt.Dimension;
import java.io.*;
import java.util.*;

// Only really need ActionListener and KeyListener for buttons here. The other interfaces
// are implemented as examples in case you want to use them. Examples:
// Runnable = Threads
// ActionListener = Buttons
// MouseListener = Mouse clicking and exiting
// MouseMotionListener = mouse moving and dragging
// TextListener = text changing events
// Remember that every time you add an interface using "implements" you must add 
// its corresponding event handler functions as well.



public class MutantWars extends JApplet implements
             Runnable, ActionListener, MouseMotionListener, 
             MouseListener, TextListener, KeyListener
{
       //Declare Global Interface Items
       public static boolean Continue = true;
       public static boolean successful = false;
       public static boolean Started = false;
       public static boolean LOCK = false;
       public static boolean NeedName = true;
       public static String choice = "";
       public static char WhatToDo = '#';
       MediaTracker TRACKER;

       public static boolean NARRATE = true;
       public static boolean MUSIC = true;
       public static boolean SOUNDEFFECTS = true;
       public static boolean SCORETOGGLE = true;
       public String PREVIOUS = "";

       //ACTs as a global pointer to Events class object
       Events Game;

      //Image Objects for Level 1
      Image INTROimage;
      Image N1image;
      Image N2image;
      Image N2GARAGEimage;
      Image N2SERVICEimage;
      Image S1image;
      Image S2image;
      Image S2CardReaderimage;
      Image E1image;
      Image E1CLOSETimage;
      Image E2image;
      Image W1image;
      Image W2image;
      Image C1image;
      Image C1ROOFimage;
      Image C1BASEMENTimage;
      Image DATATERMINALimage;
      Image FREEZERFIGHTimage;
      Image THESAFEimage;
      Image TheFRIDGEimage;
      Image Surfaceimage;
      Image BOSSFIGHT_L1image;
      Image Spiderimage;
      Image Roachimage;
      Image FreezerMutant1image;
      Image FreezerMutant2image;
      Image PyroMutant1image;
      Image PyroMutant2image;
      Image MutantMiximage;

       //Audio Clips
       public static AudioClip C1;
       public static AudioClip ChooseSex;
       public static AudioClip HELP;
       public static AudioClip INTRO1;
       public static AudioClip INTRO2;
       public static AudioClip INTRO3;
       public static AudioClip INTRO4;
       public static AudioClip INTRO5;
       public static AudioClip INTRO6;
       public static AudioClip PleaseEnterName;
       public static AudioClip ThatIsAnAdmirableName;
       public static AudioClip YouBeginFemale;
       public static AudioClip YouBeginIT;
       public static AudioClip YouBeginMale;
       public static AudioClip YouBeginLastPart;
       public static AudioClip ThemeMusic;
       public static AudioClip DoorOpen;
       public static AudioClip FootSteps;
       public static AudioClip GirlCrying;
       public static AudioClip Gun;
       public static AudioClip HandToHand;
       public static AudioClip Machete;
       public static AudioClip Wind;
       public static AudioClip WindIce;
       public static AudioClip ComputerSound1;
       public static AudioClip ComputerSound2;
       public static AudioClip Water;
       public static AudioClip Explosion;
       public static AudioClip ICETalk;
       public static AudioClip Warning;
       public static AudioClip Syringe;

       //Borders
       Border border2 = BorderFactory.createLineBorder(Color.white, 2);

       //Menu Stuff
       JMenuBar MutantWarsMenuBar;
       JMenu MutantMenu;
       JMenuItem MutantMenuItem;
       
       //Global Pointers For PopUp Inventory Frame
       JFrame MutantInventoryPopUp;
       ButtonGroup InventoryButtonGroup = new ButtonGroup();
       JRadioButton RadioKey = new JRadioButton();
       JRadioButton RadioDataCrystal = new JRadioButton();
       JRadioButton RadioFramePack = new JRadioButton();
       JRadioButton RadioMREs = new JRadioButton();
       JRadioButton RadioMedKit = new JRadioButton();
       JRadioButton RadioSterno = new JRadioButton();
       JRadioButton RadioMatches = new JRadioButton();
       JRadioButton RadioKeyCard = new JRadioButton();
       JRadioButton RadioStraightJacket = new JRadioButton();
       JLabel InventoryTitle = new JLabel();
       TitledBorder titledBorder1 = new TitledBorder("");
       int RadioCount = 1;

       //Add JTextArea to constructor of JScrollPane, but add JScrollPane to
       //applet, NOT JTextArea. Also, do not refresh whole applet, only images. 
       //All need to be global and static so they can be passed to other classes.
       public static JTextArea MainOutput = new JTextArea();
       public static JScrollPane MainOutputScroll = new JScrollPane
       (MainOutput,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
       public static JTextArea OutInventory = new JTextArea();
       public static JScrollPane OutInventoryScroll = new JScrollPane
       (OutInventory,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
       public static JTextArea OutConquests = new JTextArea();
       public static JScrollPane OutConquestsScroll = new JScrollPane
       (OutConquests,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

       //Labels and JLabels. (JLabels necessary so won't obscure JMenu)
       JLabel LabelName = new JLabel();
       JLabel LabelOutput = new JLabel();
       JLabel LabelTitle = new JLabel();
       JLabel LabelInput = new JLabel();
       JLabel LabelSex = new JLabel();

       Label LablelLife = new Label();
       Label LabelDefense = new Label();
       Label LabelAttack = new Label();
       Label LabelScore = new Label();
       Label LabelMutantPower = new Label();
       Label LabelWeapons = new Label();
       Label LabelAbilities = new Label();
       Label LabelView = new Label();
       Label LabelInventory = new Label();
       Label LabelAmmo9mm = new Label();
       Label LabelCart = new Label();
       Label LabelConquests = new Label();
       Label LabelAmmo = new Label();
       Label LabelDirection = new Label();
       Label LabelMap = new Label();
       Label LabelClass = new Label();
       Label LabelCommands = new Label();

       //JTextFields
       public static JTextField Input = new JTextField();
       public static JTextField OutLife = new JTextField();
       public static JTextField OutDefense = new JTextField();
       public static JTextField OutAttack = new JTextField();
       public static JTextField OutMutantPower = new JTextField();
       public static JTextField OutScore = new JTextField();
       public static JTextField Out9mm = new JTextField();
       public static JTextField OutCart = new JTextField();
       public static JTextField OutCharClass = new JTextField();
       public static JTextField OutName = new JTextField();
       public static JTextField OutSex = new JTextField();

       //Borders Created by TextFields
       JTextField BorderAmmo = new JTextField();
       JTextField BorderWeapons = new JTextField();
       JTextField BorderAbilities = new JTextField();
       JTextField BorderDirection = new JTextField();
       JTextField ImageBox = new JTextField();
       JTextField MapBox = new JTextField();

       //ButtonGroups for Toggling Radio Buttons
       ButtonGroup GroupWeapons = new ButtonGroup();
       ButtonGroup GroupAbilities = new ButtonGroup();

       //Radio Buttons
       public static JRadioButton RadioMachete = new JRadioButton();
       public static JRadioButton RadioSyringe = new JRadioButton();
       public static JRadioButton RadioGun = new JRadioButton();
       public static JRadioButton RadioHand = new JRadioButton();
       public static JRadioButton RadioHeal = new JRadioButton();
       public static JRadioButton RadioFreeze = new JRadioButton();
       public static JRadioButton RadioFire = new JRadioButton();
       public static JRadioButton RadioFly = new JRadioButton();
       public static JRadioButton RadioMove = new JRadioButton();
       public static JRadioButton RadioTimeTravel = new JRadioButton();
       public static JRadioButton RadioMindRead = new JRadioButton();
       public static JRadioButton RadioNone = new JRadioButton();

       //Buttons
       public static JButton ButtonNorth = new JButton();
       public static JButton ButtonSouth = new JButton();
       public static JButton ButtonWest = new JButton();
       public static JButton ButtonEast = new JButton();
       public static JButton ButtonAction = new JButton();
       public static JButton ButtonUseInventory = new JButton();
       public static JButton ButtonUseAbility = new JButton();
       public static JButton ButtonGo = new JButton();
       public static JButton ButtonStart = new JButton();
       public static JButton ButtonQuit = new JButton();
       public static JButton ButtonHelp = new JButton();
       public static JButton ButtonScores = new JButton();
       public static JButton ButtonLoad = new JButton();
       public static JButton ButtonSave = new JButton();
       public static JButton ButtonFIGHT = new JButton();
       public static JButton ButtonALT1 = new JButton();
       public static JButton ButtonALT2 = new JButton();
       public static JButton ButtonLook = new JButton();
       
       JButton ButtonUse = new JButton();        //for Inventory PopUp
       JButton ButtonAbilityUse = new JButton(); //for Mutant ABilities PopUp 

    //Constructor
    public MutantWars()  {   }

    //Initialize the applet - Component initialization
    public void init()
    {
           //Applet and Background
           this.setLayout(null);
           //this..setBackground(Color.BLACK); //for Applet, not JApplet
           this.getContentPane().setBackground(Color.BLACK);
           this.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           this.setForeground(Color.white);

           //Menu Items
           //---------------------------------------------------
           MutantWarsMenuBar = new JMenuBar();
           MutantMenu = new JMenu("File");
           MutantMenu.setMnemonic(KeyEvent.VK_F);
           MutantMenu.getAccessibleContext().setAccessibleDescription(
           "MutantWars File Menu");
           MutantWarsMenuBar.add(MutantMenu);

           MutantMenuItem = new JMenuItem("Load", KeyEvent.VK_L);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_L, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Load a character for MutantWars");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonLoad.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("Save", KeyEvent.VK_S);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_S, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Save a character from MutantWars");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonSave.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("Quit", KeyEvent.VK_Q);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_Q, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Quit MutantWars");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonQuit.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

           //-------------------------------------------------
           MutantMenu = new JMenu("Help");
           MutantMenu.setMnemonic(KeyEvent.VK_H);
           MutantMenu.getAccessibleContext().setAccessibleDescription(
           "MutantWars Help");
           MutantWarsMenuBar.add(MutantMenu);

           MutantMenuItem = new JMenuItem("Assistance", KeyEvent.VK_T);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_T, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "MutantWars Assistance");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonHelp.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("About", KeyEvent.VK_A);
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "About MutantWars");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { JOptionPane.showMessageDialog(null, "MutantWars 2007 C. Germany"); }
           } );
           MutantMenu.add(MutantMenuItem);

           //------------------------------------------------------

           MutantMenu = new JMenu("Functions");
           MutantMenu.setMnemonic(KeyEvent.VK_U);
           MutantMenu.getAccessibleContext().setAccessibleDescription(
           "MutantWars Functions");
           MutantWarsMenuBar.add(MutantMenu);

           MutantMenuItem = new JMenuItem("Action", KeyEvent.VK_A);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_A, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Action");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonAction.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("Use Ability", KeyEvent.VK_U);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_U, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Use Ability");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonUseAbility.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("Inventory", KeyEvent.VK_I);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_I, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Inventory");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { ButtonUseInventory.doClick(); }
           } );
           MutantMenu.add(MutantMenuItem);

//---------------------------------------------------------------

           MutantMenu = new JMenu("Sound");
           MutantMenu.setMnemonic(KeyEvent.VK_S);
           MutantMenu.getAccessibleContext().setAccessibleDescription(
           "MutantWars Sound");
           MutantWarsMenuBar.add(MutantMenu);

           MutantMenuItem = new JMenuItem("Narration |On|Off|", KeyEvent.VK_N);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_N, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Turn Narration On or Off");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {  if(NARRATE == true)
              {
                 NARRATE = false;
                 C1.stop();
                 ChooseSex.stop();
                 HELP.stop();
                 INTRO1.stop();
                 INTRO2.stop();
                 INTRO3.stop();
                 INTRO4.stop();
                 INTRO5.stop();
                 INTRO6.stop();
                 YouBeginLastPart.stop();
                 PleaseEnterName.stop();
                 ThatIsAnAdmirableName.stop();
                 YouBeginFemale.stop();
                 YouBeginIT.stop();
                 YouBeginMale.stop();
                 YouBeginLastPart.stop();
                 JOptionPane.showMessageDialog(null,"Narration has been turned off!");
              }
              else
              {  NARRATE = true; JOptionPane.showMessageDialog(null,
                 "Narration has been turned on!");}
              }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("Music |On|Off|", KeyEvent.VK_M);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_M, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Turn Music On or Off");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {  if(MUSIC == true)
              {
                 MUSIC = false;
                 ThemeMusic.stop();
                 JOptionPane.showMessageDialog(null,"Music has been turned off!");
              }
              else
              {
                 MUSIC = true;
                 ThemeMusic.play();
                 JOptionPane.showMessageDialog(null,"Music has been turned on!");
              }
           }
           } );
           MutantMenu.add(MutantMenuItem);

           MutantMenuItem = new JMenuItem("Sound Effects |On|Off|", KeyEvent.VK_F);
           MutantMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_F, ActionEvent.ALT_MASK));
           MutantMenuItem.getAccessibleContext().setAccessibleDescription(
           "Turn Sound Effects On or Off");
           MutantMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {  if(SOUNDEFFECTS == true)
              {
                 SOUNDEFFECTS = false;
                 JOptionPane.showMessageDialog(null,"Sound Effects have been turned off!");
              }
              else
              {
                 SOUNDEFFECTS = true;
                 JOptionPane.showMessageDialog(null,"Sound Effects have been turned on!");
              }
           }
           } );
           MutantMenu.add(MutantMenuItem);
//---------------------------------------------------------------
           this.setJMenuBar(MutantWarsMenuBar);

           //Borders
           BorderAmmo.setBackground(Color.black);
           BorderAmmo.setForeground(Color.red);
           BorderAmmo.setBorder(border2);
           BorderAmmo.setEditable(false);
           BorderAmmo.setHorizontalAlignment(SwingConstants.CENTER);
           BorderAmmo.setBounds(new Rectangle(528, 24, 54, 80));
           BorderAbilities.setBackground(Color.black);
           BorderAbilities.setForeground(Color.white);
           BorderAbilities.setBorder(border2);
           BorderAbilities.setEditable(false);
           BorderAbilities.setBounds(new Rectangle(584, 122, 92, 150));
           BorderWeapons.setBackground(Color.black);
           BorderWeapons.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           BorderWeapons.setForeground(Color.white);
           BorderWeapons.setBorder(border2);
           BorderWeapons.setEditable(false);
           BorderWeapons.setBounds(new Rectangle(585, 24, 92, 80));
           BorderDirection.setBackground(Color.black);
           BorderDirection.setForeground(Color.white);
           BorderDirection.setBorder(border2);
           BorderDirection.setEditable(false);
           BorderDirection.setHorizontalAlignment(SwingConstants.CENTER);
           BorderDirection.setBounds(new Rectangle(310, 68, 70, 75));

           //Output and Input
           MainOutput.setBackground(new Color(210, 236, 255));
           MainOutput.setForeground(Color.black);
           MainOutput.setEditable(false);
           MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
           MainOutput.setBounds(new Rectangle(6, 71, 300, 423));
           MainOutputScroll.setBounds(new Rectangle(6, 71, 300, 423));

           OutInventory.setBackground(new Color(210, 236, 255));
           OutInventory.setForeground(Color.black);
           OutInventory.setEditable(false);
           OutInventory.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 9));
           OutInventory.setBounds(new Rectangle(588, 291, 91, 204));
           OutInventoryScroll.setBounds(new Rectangle(588, 291, 91, 204));

           OutConquests.setBackground(new Color(210, 236, 255));
           OutConquests.setForeground(Color.black);
           OutConquests.setEditable(false);
           OutConquests.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 9));
           OutConquests.setBounds(new Rectangle(467, 417, 117, 78));
           OutConquestsScroll.setBounds(new Rectangle(467, 417, 117, 78));

           OutName.setBackground(new Color(210, 236, 255));
           OutName.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutName.setForeground(Color.black);
           OutName.setEditable(false);
           OutName.setText("");
           OutName.setBounds(new Rectangle(38, 19, 180, 12));
           OutLife.setBackground(Color.black);
           OutLife.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutLife.setForeground(Color.white);
           OutLife.setEditable(false);
           OutLife.setText("0");
           OutLife.setBounds(new Rectangle(316, 25, 36, 20));
           OutDefense.setBackground(Color.black);
           OutDefense.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutDefense.setForeground(Color.white);
           OutDefense.setEditable(false);
           OutDefense.setText("0");
           OutDefense.setBounds(new Rectangle(358, 25, 36, 20));
           OutAttack.setBackground(Color.black);
           OutAttack.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutAttack.setForeground(Color.white);
           OutAttack.setEditable(false);
           OutAttack.setText("0");
           OutAttack.setBounds(new Rectangle(400, 25, 36, 20));
           OutMutantPower.setBackground(Color.black);
           OutMutantPower.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutMutantPower.setForeground(Color.white);
           OutMutantPower.setEditable(false);
           OutMutantPower.setText("0");
           OutMutantPower.setBounds(new Rectangle(483, 25, 36, 20));
           OutScore.setBackground(Color.black);
           OutScore.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutScore.setForeground(Color.white);
           OutScore.setEditable(false);
           OutScore.setText("0");
           OutScore.setBounds(new Rectangle(441, 25, 36, 20));

           Out9mm.setBackground(Color.black);
           Out9mm.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           Out9mm.setForeground(Color.white);
           Out9mm.setEditable(false);
           Out9mm.setText("0");
           Out9mm.setBounds(new Rectangle(538, 44, 36, 14));
           OutCart.setBackground(Color.black);
           OutCart.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutCart.setForeground(Color.white);
           OutCart.setEditable(false);
           OutCart.setText("0");
           OutCart.setBounds(new Rectangle(537, 77, 36, 14));

           OutCharClass.setBackground(new Color(240, 245, 255));
           OutCharClass.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutCharClass.setForeground(Color.black);
           OutCharClass.setEditable(false);
           OutCharClass.setBounds(new Rectangle(526, 123, 53, 14));

           OutSex.setBackground(new Color(210, 236, 255));
           OutSex.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           OutSex.setForeground(Color.black);
           OutSex.setEditable(false);
           OutSex.setText("");
           OutSex.setBounds(new Rectangle(245, 19, 61, 12));

           Input.setBackground(new Color(210, 236, 255));
           Input.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           Input.setBounds(new Rectangle(37, 34, 269, 19));
           MapBox.setBackground(Color.black);
           MapBox.setForeground(Color.white);
           MapBox.setBorder(border2);
           MapBox.setEditable(false);
           MapBox.setHorizontalAlignment(SwingConstants.CENTER);
           MapBox.setBounds(new Rectangle(310, 378, 153, 118));
           ImageBox.setBackground(Color.black);
           ImageBox.setForeground(Color.white);
           ImageBox.setBorder(border2);
           ImageBox.setEditable(false);
           ImageBox.setHorizontalAlignment(SwingConstants.CENTER);
           ImageBox.setBounds(new Rectangle(310, 149, 268, 208));

           //Labels
           LabelName.setBackground(Color.black);
           LabelName.setForeground(Color.white);
           LabelName.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
           LabelName.setText("Name:");
           LabelName.setBounds(new Rectangle(5, 17, 84, 16));
           //LabelOutput.setAlignment(Label.CENTER);
           LabelOutput.setBackground(Color.black);
           LabelOutput.setForeground(Color.white);
           LabelOutput.setText("Events Output");
           LabelOutput.setBounds(new Rectangle(80, 56, 147, 14));
           LablelLife.setAlignment(Label.CENTER);
           LablelLife.setBackground(Color.black);
           LablelLife.setForeground(Color.white);
           LablelLife.setText("Life");
           LablelLife.setBounds(new Rectangle(316, 9, 35, 15));
           LabelDefense.setAlignment(Label.CENTER);
           LabelDefense.setBackground(Color.black);
           LabelDefense.setForeground(Color.white);
           LabelDefense.setText("Def");
           LabelDefense.setBounds(new Rectangle(359, 9, 35, 15));
           LabelAttack.setAlignment(Label.CENTER);
           LabelAttack.setBackground(Color.black);
           LabelAttack.setForeground(Color.white);
           LabelAttack.setText("Atk");
           LabelAttack.setBounds(new Rectangle(401, 9, 35, 15));
           LabelScore.setAlignment(Label.CENTER);
           LabelScore.setBackground(Color.black);
           LabelScore.setForeground(Color.white);
           LabelScore.setText("Score");
           LabelScore.setBounds(new Rectangle(442, 9, 35, 15));
           //LabelTitle.setAlignment(Label.CENTER);
           LabelTitle.setBackground(Color.black);
           LabelTitle.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           LabelTitle.setForeground(Color.white);
           LabelTitle.setText("Mutant Wars 2007 C. Germany");
           LabelTitle.setBounds(new Rectangle(2, 2, 166, 16));
           LabelMutantPower.setAlignment(Label.CENTER);
           LabelMutantPower.setBackground(Color.black);
           LabelMutantPower.setForeground(Color.white);
           LabelMutantPower.setText("M Power");
           LabelMutantPower.setBounds(new Rectangle(476, 9, 53, 15));
           LabelWeapons.setAlignment(Label.CENTER);
           LabelWeapons.setBackground(Color.black);
           LabelWeapons.setForeground(Color.white);
           LabelWeapons.setText("Weapons");
           LabelWeapons.setBounds(new Rectangle(604, 8, 54, 15));
           LabelAbilities.setAlignment(Label.CENTER);
           LabelAbilities.setBackground(Color.black);
           LabelAbilities.setForeground(Color.white);
           LabelAbilities.setText("Abilities");
           LabelAbilities.setBounds(new Rectangle(605, 109, 53, 13));
           LabelInventory.setAlignment(Label.CENTER);
           LabelInventory.setBackground(Color.black);
           LabelInventory.setForeground(Color.white);
           LabelInventory.setText("Inventory");
           LabelInventory.setBounds(new Rectangle(600, 277, 62, 14));
           LabelView.setAlignment(Label.CENTER);
           LabelView.setBackground(Color.black);
           LabelView.setForeground(Color.white);
           LabelView.setText("View");
           LabelView.setBounds(new Rectangle(424, 130, 45, 17));
           LabelAmmo9mm.setAlignment(Label.CENTER);
           LabelAmmo9mm.setBackground(Color.black);
           LabelAmmo9mm.setForeground(Color.white);
           LabelAmmo9mm.setText("9mm");
           LabelAmmo9mm.setBounds(new Rectangle(535, 30, 41, 10));
           LabelCart.setAlignment(Label.CENTER);
           LabelCart.setBackground(Color.black);
           LabelCart.setForeground(Color.white);
           LabelCart.setText("Cart");
           LabelCart.setBounds(new Rectangle(535, 62, 41, 15));
           LabelConquests.setAlignment(Label.CENTER);
           LabelConquests.setBackground(Color.black);
           LabelConquests.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           LabelConquests.setForeground(Color.white);
           LabelConquests.setText("Conquests");
           LabelConquests.setBounds(new Rectangle(493, 400, 62, 17));
           LabelAmmo.setAlignment(Label.CENTER);
           LabelAmmo.setBackground(Color.black);
           LabelAmmo.setForeground(Color.white);
           LabelAmmo.setText("Ammo");
           LabelAmmo.setBounds(new Rectangle(527, 9, 56, 15));
           LabelDirection.setAlignment(Label.CENTER);
           LabelDirection.setBackground(Color.black);
           LabelDirection.setForeground(Color.white);
           LabelDirection.setText("Direction");
           LabelDirection.setBounds(new Rectangle(315, 50, 62, 17));
           LabelInput.setBackground(Color.black);
           LabelInput.setForeground(Color.white);
           LabelInput.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
           LabelInput.setText("Input:");
           LabelInput.setBounds(new Rectangle(5, 33, 33, 20));
           LabelMap.setAlignment(Label.CENTER);
           LabelMap.setBackground(Color.black);
           LabelMap.setForeground(Color.white);
           LabelMap.setText("Map");
           LabelMap.setBounds(new Rectangle(369, 361, 37, 17));
           LabelClass.setAlignment(Label.CENTER);
           LabelClass.setBackground(Color.black);
           LabelClass.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           LabelClass.setForeground(Color.white);
           LabelClass.setText("Char Class");
           LabelClass.setBounds(new Rectangle(525, 107, 54, 16));
           LabelCommands.setAlignment(Label.CENTER);
           LabelCommands.setBackground(Color.black);
           LabelCommands.setForeground(Color.white);
           LabelCommands.setText("Commands");
           LabelCommands.setBounds(new Rectangle(400, 51, 64, 17));
           LabelSex.setBackground(Color.black);
           LabelSex.setForeground(Color.white);
           LabelSex.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 11));
           LabelSex.setText("Sex:");
           LabelSex.setBounds(new Rectangle(221, 17, 26, 16));

           //Radio Buttons
           RadioMachete.setBackground(Color.black);
           RadioMachete.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioMachete.setForeground(Color.red);
           RadioMachete.setText("Machete");
           RadioMachete.setBounds(new Rectangle(588, 43, 80, 18));
           RadioSyringe.setBackground(Color.black);
           RadioSyringe.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioSyringe.setForeground(Color.red);
           RadioSyringe.setText("Syringe");
           RadioSyringe.setBounds(new Rectangle(588, 76, 80, 18));
           RadioGun.setBackground(Color.black);
           RadioGun.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioGun.setForeground(Color.red);
           RadioGun.setText("Gun 9mm");
           RadioGun.setBounds(new Rectangle(588, 59, 86, 18));
           RadioHand.setBackground(Color.black);
           RadioHand.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioHand.setForeground(Color.red);
           RadioHand.setText("Hand");
           RadioHand.setBounds(new Rectangle(588, 27, 73, 18));
           RadioHeal.setBackground(Color.black);
           RadioHeal.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioHeal.setForeground(Color.red);
           RadioHeal.setText("Heal");
           RadioHeal.setBounds(new Rectangle(590, 175, 80, 18));
           RadioFreeze.setBackground(Color.black);
           RadioFreeze.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioFreeze.setForeground(Color.red);
           RadioFreeze.setText("Freeze");
           RadioFreeze.setBounds(new Rectangle(590, 141, 80, 18));
           RadioFire.setBackground(Color.black);
           RadioFire.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioFire.setForeground(Color.red);
           RadioFire.setText("Fire");
           RadioFire.setBounds(new Rectangle(590, 157, 80, 18));
           RadioFly.setBackground(Color.black);
           RadioFly.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioFly.setForeground(Color.red);
           RadioFly.setText("Fly");
           RadioFly.setBounds(new Rectangle(590, 192, 80, 18));
           RadioMove.setBackground(Color.black);
           RadioMove.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioMove.setForeground(Color.red);
           RadioMove.setText("Move");
           RadioMove.setBounds(new Rectangle(590, 209, 80, 18));
           RadioTimeTravel.setBackground(Color.black);
           RadioTimeTravel.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioTimeTravel.setForeground(Color.red);
           RadioTimeTravel.setText("Shift Time");
           RadioTimeTravel.setBounds(new Rectangle(590, 243, 82, 18));
           RadioMindRead.setBackground(Color.black);
           RadioMindRead.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioMindRead.setForeground(Color.red);
           RadioMindRead.setText("MindRead");
           RadioMindRead.setBounds(new Rectangle(590, 226, 80, 18));
           RadioNone.setBackground(Color.black);
           RadioNone.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioNone.setForeground(Color.red);
           RadioNone.setText("None");
           RadioNone.setBounds(new Rectangle(590, 124, 80, 18));

           //Buttons
           ButtonNorth.setBackground(SystemColor.desktop);
           ButtonNorth.setBounds(new Rectangle(335, 71, 20, 22));
           ButtonNorth.setFont(new java.awt.Font("Tahoma", Font.BOLD, 11));
           ButtonNorth.setForeground(Color.red);
           ButtonNorth.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonNorth.setMaximumSize(new Dimension(21, 21));
           ButtonNorth.setMinimumSize(new Dimension(21, 21));
           ButtonNorth.setPreferredSize(new Dimension(21, 21));
           ButtonNorth.setMargin(new Insets(1, 1, 1, 1));
           ButtonNorth.setText("N");
           ButtonSouth.setBackground(SystemColor.desktop);
           ButtonSouth.setBounds(new Rectangle(335, 114, 20, 22));
           ButtonSouth.setFont(new java.awt.Font("Tahoma", Font.BOLD, 11));
           ButtonSouth.setForeground(Color.red);
           ButtonSouth.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonSouth.setMargin(new Insets(1, 1, 1, 1));
           ButtonSouth.setText("S");
           ButtonWest.setBackground(SystemColor.desktop);
           ButtonWest.setBounds(new Rectangle(314, 92, 20, 22));
           ButtonWest.setFont(new java.awt.Font("Tahoma", Font.BOLD, 11));
           ButtonWest.setForeground(Color.red);
           ButtonWest.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonWest.setMargin(new Insets(1, 1, 1, 1));
           ButtonWest.setText("W");
           ButtonEast.setBackground(SystemColor.desktop);
           ButtonEast.setBounds(new Rectangle(356, 92, 20, 22));
           ButtonEast.setFont(new java.awt.Font("Tahoma", Font.BOLD, 11));
           ButtonEast.setForeground(Color.red);
           ButtonEast.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonEast.setMargin(new Insets(1, 1, 1, 1));
           ButtonEast.setText("E");
           ButtonAction.setBackground(SystemColor.desktop);
           ButtonAction.setBounds(new Rectangle(388, 70, 84, 17));
           ButtonAction.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonAction.setForeground(Color.green);
           ButtonAction.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonAction.setMargin(new Insets(1, 1, 1, 1));
           ButtonAction.setText("ACTION");
           ButtonUseInventory.setBackground(SystemColor.desktop);
           ButtonUseInventory.setBounds(new Rectangle(388, 107, 84, 17));
           ButtonUseInventory.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonUseInventory.setForeground(Color.white);
           ButtonUseInventory.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonUseInventory.setMargin(new Insets(1, 1, 1, 1));
           ButtonUseInventory.setText("USE INVENTORY");
           ButtonUseAbility.setBackground(SystemColor.desktop);
           ButtonUseAbility.setBounds(new Rectangle(388, 89, 84, 17));
           ButtonUseAbility.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonUseAbility.setForeground(Color.white);
           ButtonUseAbility.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonUseAbility.setMargin(new Insets(1, 1, 1, 1));
           ButtonUseAbility.setText("USE ABILITY");
           ButtonGo.setBackground(SystemColor.desktop);
           ButtonGo.setBounds(new Rectangle(335, 92, 21, 21));
           ButtonGo.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonGo.setForeground(Color.green);
           ButtonGo.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonGo.setMargin(new Insets(1, 1, 1, 1));
           ButtonGo.setText("GO");
           ButtonStart.setBackground(SystemColor.activeCaptionText);
           ButtonStart.setBounds(new Rectangle(467, 364, 39, 17));
           ButtonStart.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonStart.setForeground(Color.red);
           ButtonStart.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonStart.setMargin(new Insets(1, 1, 1, 1));
           ButtonStart.setText("START");
           ButtonQuit.setBackground(SystemColor.activeCaptionText);
           ButtonQuit.setBounds(new Rectangle(467, 382, 39, 17));
           ButtonQuit.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonQuit.setForeground(Color.red);
           ButtonQuit.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonQuit.setMargin(new Insets(1, 1, 1, 1));
           ButtonQuit.setText("QUIT");
           ButtonHelp.setBackground(SystemColor.activeCaptionText);
           ButtonHelp.setBounds(new Rectangle(507, 382, 39, 17));
           ButtonHelp.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonHelp.setForeground(Color.red);
           ButtonHelp.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonHelp.setMargin(new Insets(1, 1, 1, 1));
           ButtonHelp.setText("HELP");
           ButtonScores.setBackground(SystemColor.activeCaptionText);
           ButtonScores.setBounds(new Rectangle(507, 364, 39, 17));
           ButtonScores.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonScores.setForeground(Color.red);
           ButtonScores.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonScores.setMargin(new Insets(1, 1, 1, 1));
           ButtonScores.setText("SCORE");
           ButtonLoad.setBackground(SystemColor.activeCaptionText);
           ButtonLoad.setBounds(new Rectangle(547, 364, 39, 17));
           ButtonLoad.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonLoad.setForeground(Color.red);
           ButtonLoad.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonLoad.setMargin(new Insets(1, 1, 1, 1));
           ButtonLoad.setText("LOAD");
           ButtonSave.setBackground(SystemColor.activeCaptionText);
           ButtonSave.setBounds(new Rectangle(547, 382, 39, 17));
           ButtonSave.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonSave.setForeground(Color.red);
           ButtonSave.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonSave.setMargin(new Insets(1, 1, 1, 1));
           ButtonSave.setText("SAVE");
           ButtonALT1.setBackground(SystemColor.desktop);
           ButtonALT1.setForeground(Color.orange);
           ButtonALT1.setBounds(new Rectangle(478, 89, 44, 17));
           ButtonALT1.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonALT1.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonALT1.setMargin(new Insets(1, 1, 1, 1));
           ButtonALT1.setMnemonic('0');
           ButtonALT1.setText("ALT 1");
           ButtonALT2.setBackground(SystemColor.desktop);
           ButtonALT2.setForeground(Color.orange);
           ButtonALT2.setBounds(new Rectangle(478, 107, 44, 17));
           ButtonALT2.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonALT2.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonALT2.setMargin(new Insets(1, 1, 1, 1));
           ButtonALT2.setText("ALT 2");
           ButtonFIGHT.setBackground(SystemColor.desktop);
           ButtonFIGHT.setForeground(Color.red);
           ButtonFIGHT.setBounds(new Rectangle(478, 71, 44, 17));
           ButtonFIGHT.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonFIGHT.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonFIGHT.setMargin(new Insets(1, 1, 1, 1));
           ButtonFIGHT.setText("FIGHT!");
           ButtonLook.setBackground(SystemColor.desktop);
           ButtonLook.setForeground(Color.green);
           ButtonLook.setBounds(new Rectangle(478, 53, 44, 17));
           ButtonLook.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 10));
           ButtonLook.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonLook.setMargin(new Insets(1, 1, 1, 1));
           ButtonLook.setText("LOOK");

           //for use on inventory JFrame, must be A separate instance
           ButtonUse.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {
                //Note to self: Later we ned to move this code to a separate class
                //and switch on it to allow different items for each new level
                String OUT = "";

                if(RadioKey.isSelected())
                {
                    if(Level1.LOCATION == Level1.W2)
                    { OUT = "\n  Looks like the key definitely goes to the safe.\n"; }
                    else { OUT = "\n  No place to use the key.\n"; }
                }

                if(RadioKeyCard.isSelected())
                {
                    if(Level1.LOCATION == Level1.S2)
                    { OUT = "\n  Wanna swipe the key card through the reader?\n"; }
                    else { OUT = "\n  Nothing to do with the key card here.\n"; }
                }
                
                if(RadioDataCrystal.isSelected())
                {
                    if(Level1.LOCATION == Level1.C1Basement)
                    { OUT = "\n  You place the data crystal into the termial.\n"; }
                    else { OUT = "\n  No place here to use the Data Crystal.\n"; }
                }
                
                if(RadioFramePack.isSelected())
                {
                    OUT = "\n  You put on the frame pack. Feels good...\n";
                }

                if(RadioMREs.isSelected())
                {
                    if(Game.Player.GetMRErations() > 0)
                    {  OUT = "\n  You eat one of your MRE rations. Yummy!\n"
                           + "  It renews your strength and adds 10 points\n"
                           + "  to your ravenous life.";
                       Game.Player.SetMRErations(Game.Player.GetMRErations() - 1);
                       Game.Player.SetHit(Game.Player.GetHit() + 10);
                       Game.Player.DisplayStats();
                    }
                    else { OUT = "\n  You have no more MRE rations!\n"; }
                }
                
                if(RadioMedKit.isSelected())
                {
                    if(Game.Player.GetMedKit() > 0)
                    {  OUT = "\n  You open a MedKit and apply its medication.\n"
                           + "  It renews your strength and adds 25 points\n"
                           + "  to your wounded life.";
                       Game.Player.SetMedKit(Game.Player.GetMedKit() - 1);
                       Game.Player.SetHit(Game.Player.GetHit() + 25);
                       Game.Player.DisplayStats();
                    }
                    else { OUT = "\n  You have no more MedKits!\n"; }
                }
                
                if(RadioSterno.isSelected())
                {
                    if(Level1.LOCATION == Level1.W2)
                    { OUT = "\n  You place the STERNO next to the safe.\n"; }
                    else { OUT = "\n  Not a place for STERNO!\n"; }
                }

                if(RadioMatches.isSelected())
                {
                   OUT = "\n  You light up a match. Didn't your mommy\n"
                       + "  tell you not to play with matches?";
                }

                if(RadioStraightJacket.isSelected())
                {
                   if(!Game.Player.GetWearingJacket())
                   {
                       OUT = "\n  You put on the straight jacket. Nice fit.\n"
                           + "  You always knew you should be in one of these!\n"
                           + "  It is composed of genetically-altered mutant\n"
                           + "  spider silk, making it both ultra flexible\n"
                           + "  and stronger than stainless steel!\n\n"
                           + "  It adds two points to your defense capability.\n";
                       Game.Player.SetDef(Game.Player.GetDef() + 2);
                       Game.Player.DisplayStats();
                       Game.Player.SetWearingJacket(true);
                   }
                   else
                   {
                       OUT = "\n  O.k., for whatever reason, you decide\n"
                           + "  to take the way cool, stronger-than-steel\n"
                           + "  spider silk jacket off. Maybe you are just\n"
                           + "  too good at combat? Need more of a challenge?\n"
                           + "  Maybe it just violates your very fashionable\n"
                           + "  sensibilities? Whatever...";
                       Game.Player.SetDef(Game.Player.GetDef() - 2);
                       Game.Player.DisplayStats();
                       Game.Player.SetWearingJacket(false);
                   }
                }

                OUT = OUT + "\n\n  Click \"LOOK\" to examine your surroundings.";
                MainOutput.setText(OUT);
                Game.Player.ListInventory();
                MutantInventoryPopUp.setVisible(false);
                MutantInventoryPopUp.dispose(); }
           } );

           //Output TextBoxes and Areas
           this.add(MainOutputScroll);
           this.add(OutInventoryScroll);
           this.add(OutConquestsScroll);

           this.add(Input);
           this.add(OutName);
           this.add(OutCart);
           this.add(Out9mm);
           this.add(OutLife);
           this.add(OutDefense);
           this.add(OutAttack);
           this.add(OutScore);
           this.add(OutMutantPower);
           this.add(OutCharClass);
           this.add(ImageBox);
           this.add(MapBox);

           //Labels
           this.add(LabelConquests);
           this.add(LabelMap);
           this.add(LabelAmmo);
           this.add(LabelDirection);
           this.add(LabelView);
           this.add(LabelCommands);
           this.add(LabelCart);
           this.add(LabelAmmo9mm);
           this.add(LabelMutantPower);
           this.add(LabelScore);
           this.add(LabelAttack);
           this.add(LabelDefense);
           this.add(LablelLife);
           this.add(LabelClass);
           this.add(LabelInput);
           this.add(LabelTitle);
           this.add(LabelOutput);
           this.add(LabelName);
           this.add(LabelWeapons);
           this.add(LabelAbilities);
           this.add(LabelInventory);
           this.add(LabelSex);
           this.add(OutSex);

           //Radio Buttons
           this.add(RadioHand);
           this.add(RadioMachete);
           this.add(RadioGun);
           this.add(RadioSyringe);
           this.add(RadioNone);
           this.add(RadioFreeze);
           this.add(RadioFire);
           this.add(RadioHeal);
           this.add(RadioFly);
           this.add(RadioMindRead);
           this.add(RadioMove);
           this.add(RadioTimeTravel);

           //Buttons
           this.add(ButtonNorth);
           this.add(ButtonSouth);
           this.add(ButtonEast);
           this.add(ButtonWest);
           this.add(ButtonGo);
           this.add(ButtonAction);
           this.add(ButtonUseAbility);
           this.add(ButtonUseInventory);
           this.add(ButtonStart);
           this.add(ButtonQuit);
           this.add(ButtonHelp);
           this.add(ButtonScores);
           this.add(ButtonLoad);
           this.add(ButtonSave);
           this.add(ButtonFIGHT);
           this.add(ButtonALT1);
           this.add(ButtonALT2);
           this.add(ButtonLook);

           //Borders
           this.add(BorderAmmo);
           this.add(BorderAbilities);
           this.add(BorderWeapons);
           this.add(BorderDirection);

           //Add RadioButtons to ButtonGroups
           GroupWeapons.add(RadioHand);
           GroupWeapons.add(RadioMachete);
           GroupWeapons.add(RadioGun);
           GroupWeapons.add(RadioSyringe);
           GroupAbilities.add(RadioNone);
           GroupAbilities.add(RadioFreeze);
           GroupAbilities.add(RadioFire);
           GroupAbilities.add(RadioHeal);
           GroupAbilities.add(RadioFly);
           GroupAbilities.add(RadioMindRead);
           GroupAbilities.add(RadioMove);
           GroupAbilities.add(RadioTimeTravel);
        
           //Add Listeners

           //If wanted to invoke function with mouse you'd add:
           addMouseListener(this);
           addMouseMotionListener(this);
        
           //Must add "ActionListener" for button clicks. Handled in "actionPerformed()".
           ButtonNorth.addActionListener(this);
           ButtonSouth.addActionListener(this);
           ButtonEast.addActionListener(this);
           ButtonWest.addActionListener(this);
           ButtonGo.addActionListener(this);
           ButtonAction.addActionListener(this);
           ButtonUseAbility.addActionListener(this);
           ButtonUseInventory.addActionListener(this);
           ButtonStart.addActionListener(this);
           ButtonQuit.addActionListener(this);
           ButtonHelp.addActionListener(this);
           ButtonScores.addActionListener(this);
           ButtonLoad.addActionListener(this);
           ButtonSave.addActionListener(this);
           ButtonFIGHT.addActionListener(this);
           ButtonALT1.addActionListener(this);
           ButtonALT2.addActionListener(this);
           ButtonLook.addActionListener(this);

           RadioHand.addActionListener(this);
           RadioMachete.addActionListener(this);
           RadioGun.addActionListener(this);
           RadioSyringe.addActionListener(this);
           RadioNone.addActionListener(this);
           RadioFreeze.addActionListener(this);
           RadioFire.addActionListener(this);
           RadioHeal.addActionListener(this);
           RadioMindRead.addActionListener(this);
           RadioMove.addActionListener(this);
           RadioTimeTravel.addActionListener(this);
           
           //Can't add KeyListener to Applet. Must be on object with focus.
           //In this case it's the input box rather than the Applet itself.   
           //this.addKeyListener(this);
           //addKeyListener(this);
           Input.addKeyListener(this);

           RadioMachete.setEnabled(false);
           RadioMachete.setVisible(true);
           RadioGun.setEnabled(false);
           RadioSyringe.setEnabled(false);
           RadioFreeze.setEnabled(false);
           RadioFire.setEnabled(false);
           RadioHeal.setEnabled(false);
           RadioFly.setEnabled(false);
           RadioMindRead.setEnabled(false);
           RadioMove.setEnabled(false);
           RadioTimeTravel.setEnabled(false);
           
           LockButtons(true);

           TRACKER = new MediaTracker(this);
           INTROimage = getImage(getCodeBase(), "images/Title.jpg");
           C1image = getImage(getCodeBase(), "images/Hospital_INTRO.jpg");
           C1ROOFimage = getImage(getCodeBase(), "images/Roof.jpg");
           C1BASEMENTimage = getImage(getCodeBase(), "images/ControlRoom.jpg");
           N1image = getImage(getCodeBase(), "images/Office.jpg");
           N2image = getImage(getCodeBase(), "images/Atrium.jpg");
           N2GARAGEimage = getImage(getCodeBase(), "images/Parking.jpg");
           N2SERVICEimage = getImage(getCodeBase(), "images/Stairs.jpg");
           S1image = getImage(getCodeBase(), "images/Hospital_NS.jpg");
           S2image = getImage(getCodeBase(), "images/Hospital_ICU.jpg");
           E1CLOSETimage = getImage(getCodeBase(), "images/E1Closet.jpg");
           E1image = getImage(getCodeBase(), "images/E1.jpg");
           E2image = getImage(getCodeBase(), "images/E2.jpg");
           W1image = getImage(getCodeBase(), "images/MessHall.jpg");
           W2image = getImage(getCodeBase(), "images/SafeRoom.jpg");
           Surfaceimage = getImage(getCodeBase(), "images/Surface.jpg");
           S2CardReaderimage = getImage(getCodeBase(), "images/CardReader.jpg");
           DATATERMINALimage = getImage(getCodeBase(), "images/DataTerminal.jpg");
           THESAFEimage = getImage(getCodeBase(), "images/SafeFront.jpg");
           TheFRIDGEimage = getImage(getCodeBase(), "images/Fridge.jpg");
           FREEZERFIGHTimage = getImage(getCodeBase(), "images/Mutant.jpg");
           Spiderimage = getImage(getCodeBase(), "images/Spider.jpg");
           Roachimage = getImage(getCodeBase(), "images/Roach.jpg");
           FreezerMutant1image = getImage(getCodeBase(), "images/FreezerMutant1.jpg");
           FreezerMutant2image = getImage(getCodeBase(), "images/FreezerMutant2.jpg");
           PyroMutant1image = getImage(getCodeBase(), "images/FireMutant1.jpg");
           PyroMutant2image = getImage(getCodeBase(), "images/FireMutant2.jpg");
           MutantMiximage = getImage(getCodeBase(), "images/MutantMix.jpg");

           TRACKER.addImage(INTROimage,1);
           TRACKER.addImage(C1image,2);
           TRACKER.addImage(C1ROOFimage,3);
           TRACKER.addImage(C1BASEMENTimage,4);
           TRACKER.addImage(N1image,5);
           TRACKER.addImage(S1image,6);
           TRACKER.addImage(E1image,7);
           TRACKER.addImage(E1CLOSETimage,8);
           TRACKER.addImage(W1image,9);
           TRACKER.addImage(N2image,10);
           TRACKER.addImage(N2GARAGEimage,11);
           TRACKER.addImage(N2SERVICEimage,12);
           TRACKER.addImage(S2image,13);
           TRACKER.addImage(E2image,14);
           TRACKER.addImage(W2image,15);
           TRACKER.addImage(Surfaceimage,16);
           TRACKER.addImage(DATATERMINALimage,17);
           TRACKER.addImage(TheFRIDGEimage,18);
           TRACKER.addImage(THESAFEimage,19);
           TRACKER.addImage(FREEZERFIGHTimage,20);
           TRACKER.addImage(Spiderimage,21);
           TRACKER.addImage(Roachimage,22);
           TRACKER.addImage(FreezerMutant1image,23);
           TRACKER.addImage(FreezerMutant2image,24);
           TRACKER.addImage(PyroMutant1image,25);
           TRACKER.addImage(PyroMutant2image,26);
           TRACKER.addImage(MutantMiximage,27);

           try { TRACKER.waitForAll(); }
           catch(Exception e) {  }

           C1 = getAudioClip(getCodeBase(),"audio/C1.au");
           ChooseSex = getAudioClip(getCodeBase(),"audio/ChooseSex.au");
           HELP = getAudioClip(getCodeBase(),"audio/HELP.au");
           INTRO1 = getAudioClip(getCodeBase(),"audio/INTRO1.au");
           INTRO2 = getAudioClip(getCodeBase(),"audio/INTRO2.au");
           INTRO3 = getAudioClip(getCodeBase(),"audio/INTRO3.au");
           INTRO4 = getAudioClip(getCodeBase(),"audio/INTRO4.au");
           INTRO5 = getAudioClip(getCodeBase(),"audio/INTRO5.au");
           INTRO6 = getAudioClip(getCodeBase(),"audio/INTRO6.au");
           PleaseEnterName = getAudioClip(getCodeBase(),"audio/PleaseEnterName.au");
           ThatIsAnAdmirableName = 
                      getAudioClip(getCodeBase(),"audio/ThatIsAnAdmirableName.au");
           YouBeginFemale = getAudioClip(getCodeBase(),"audio/YouBeginFemale.au");
           YouBeginIT = getAudioClip(getCodeBase(),"audio/YouBeginIT.au");
           YouBeginMale = getAudioClip(getCodeBase(),"audio/YouBeginMale.au");
           YouBeginLastPart = getAudioClip(getCodeBase(),"audio/YouBeginLastPart.au");
           ThemeMusic = getAudioClip(getCodeBase(),"audio/ThemeMusic.au");
           DoorOpen = getAudioClip(getCodeBase(),"audio/DoorOpen.au");
           FootSteps = getAudioClip(getCodeBase(),"audio/FootSteps.au");
           GirlCrying = getAudioClip(getCodeBase(),"audio/GirlCrying.au");
           Gun = getAudioClip(getCodeBase(),"audio/Gun.au");
           HandToHand = getAudioClip(getCodeBase(),"audio/HandToHand.au");
           Machete = getAudioClip(getCodeBase(),"audio/Machete.au");
           Wind = getAudioClip(getCodeBase(),"audio/Wind.au");
           WindIce = getAudioClip(getCodeBase(),"audio/WindIce.au");
           ComputerSound1 = getAudioClip(getCodeBase(),"audio/ComputerSound1.au");
           ComputerSound2 = getAudioClip(getCodeBase(),"audio/ComputerSound2.au");
           Water = getAudioClip(getCodeBase(),"audio/Water.au");
           Explosion = getAudioClip(getCodeBase(),"audio/Explosion.au");
           ICETalk = getAudioClip(getCodeBase(),"audio/ICETalk.au");
           Warning = getAudioClip(getCodeBase(),"audio/Warning.au");
           Syringe = getAudioClip(getCodeBase(),"audio/Syringe.au");

           refresh();
           MainOutput.setForeground(Color.blue);
           MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 20));
           MainOutput.setText("\n\n              Welcome to \n" +
                          "              MutantWars\n" +
                          "                   2007!\n\n" +
                          "     Click the \"START\" button\n" +
                          "     to begin a new game.\n\n\n\n\n" +
                          "     You \"AWT\" to \"SWING\"\n" +
                          "       into action with these\n" +
                          "      new Java components!\n");

    }//close init() function

//----------------------------------------------------------------------------------

    public void paint(Graphics g)
    {
           super.paint(g); //Necessary for all other components
           DrawImages();

                         g.setColor(Color.WHITE);

                         if(Level1.MapC1)
                         {
                           g.drawRect(380,455,10,10);    //C1 room
                         }

                         if(Level1.MapC1Roof)
                         {
                            g.drawLine(380,455,375,450);  //line C1 roof
                            g.drawRect(365,440,10,10);    //C1 roof room
                         }

                         if(Level1.MapC1Basement)
                         {
                            g.drawLine(390,465,395,470);  //line C1 basement
                            g.drawRect(395,470,10,10);    //C1 basement room
                         }

                         if(Level1.MapN1)
                         {
                            g.drawLine(385,455,385,435);  //line north1
                            g.drawRect(380,425,10,10);    //N1 room
                         }

                         if(Level1.MapS1)
                         {
                            g.drawLine(385,465,385,485);  //line south1
                            g.drawRect(380,485,10,10);    //S1 room
                         }

                         if(Level1.MapE1)
                         {
                            g.drawLine(390,460,410,460);  //line east1
                            g.drawRect(410,455,10,10);    //E1 room
                         }

                         if(Level1.MapE1Closet)
                         {
                            g.drawLine(420,455,425,445);  //E1 closet line
                            g.drawRect(425,435,10,10);    //E1 closet room
                         }

                         if(Level1.MapW1)
                         {
                            g.drawLine(380,460,360,460);  //line west1
                            g.drawRect(350,455,10,10);    //W1 room
                         }

                         if(Level1.MapN2)
                         {
                            g.drawLine(385,425,385,415);  //line north2
                            g.drawRect(380,405,10,10);    //N2 room
                         }

                         if(Level1.MapN2Garage)
                         {
                            g.drawLine(390,415,400,420);  //N2 Garage line
                            g.drawRect(400,415,10,10);    //N2 Garage room
                         }

                         if(Level1.MapN2Service)
                         {
                            g.drawLine(365,415,380,410);  //N2 Service line1
                            g.drawLine(370,440,360,425);  //N2 Service line2
                            g.drawRect(355,415,10,10);    //N2 Service room
                         }

                         if(Level1.MapS2)
                         {
                            g.drawLine(385,495,385,505);  //line south2
                            g.drawRect(380,505,10,10);    //S2 room
                         }

                         if(Level1.MapE2)
                         {
                            g.drawLine(420,460,440,460);  //line east2
                            g.drawRect(440,455,10,10);    //E2 room
                         }

                         if(Level1.MapW2)
                         {
                            g.drawLine(350,460,330,460);  //line west2
                            g.drawRect(320,455,10,10);    //W2 room
                         }

                         if(Level1.MapSurface)
                         {
                            g.drawLine(390,510,430,510); //Surface line
                            g.drawRect(430,505,20,10);   //Surface Exit
                         }

    }

//----------------------------------------------------------------------------------

    public void DrawImages()
    {
           Graphics g = getGraphics();
           g.setColor(Color.RED);

           switch(Game.LEVEL)
           {
              case 1 : switch(Level1.LOCATION)
                       {
                           case Level1.INTRO : 
                           g.drawImage(INTROimage, 314, 177, 260, 200, this);
                           break;

                           case Level1.QUIT : 
                           g.drawImage(INTROimage, 314, 177, 260, 200, this);
                           break;

                           case Level1.C1 : 
                           g.drawImage(C1image, 314, 177, 260, 200, this);
                           g.fillOval(383,458,6,6);
                           break;

                           case Level1.C1Roof : 
                           g.drawImage(C1ROOFimage, 314, 177, 260, 200, this);
                           g.fillOval(368,443,6,6);
                           break;

                           case Level1.C1Basement : 
                           g.drawImage(C1BASEMENTimage, 314, 177, 260, 200, this);
                           g.fillOval(398,473,6,6);
                           break;

                           case Level1.N1 : 
                           g.drawImage(N1image, 314, 177, 260, 200, this);
                           g.fillOval(383,428,6,6);
                           break;

                           case Level1.S1 : 
                           g.drawImage(S1image, 314, 177, 260, 200, this);
                           g.fillOval(383,488,6,6);
                           break;

                           case Level1.E1 : 
                           g.drawImage(E1image, 314, 177, 260, 200, this);
                           g.fillOval(413,458,6,6);
                           break;

                           case Level1.E1Closet : 
                           g.drawImage(E1CLOSETimage, 314, 177, 260, 200, this);
                           g.fillOval(428,438,6,6);
                           break;

                           case Level1.W1 : 
                           g.drawImage(W1image, 314, 177, 260, 200, this);
                           g.fillOval(353,458,6,6);
                           break;

                           case Level1.N2 : 
                           g.drawImage(N2image, 314, 177, 260, 200, this);
                           g.fillOval(383,408,6,6);
                           break;

                           case Level1.N2Garage : 
                           g.drawImage(N2GARAGEimage, 314, 177, 260, 200, this);
                           g.fillOval(403,418,6,6);
                           break;

                           case Level1.N2Service : 
                           g.drawImage(N2SERVICEimage, 314, 177, 260, 200, this);
                           g.fillOval(358,418,6,6);
                           break;

                           case Level1.S2 : 
                           g.drawImage(S2image, 314, 177, 260, 200, this);
                           g.fillOval(383,508,6,6);
                           break;

                           case Level1.E2 : 
                           g.drawImage(E2image, 314, 177, 260, 200, this);
                           g.fillOval(443,458,6,6);
                           break;

                           case Level1.W2 : 
                           g.drawImage(W2image, 314, 177, 260, 200, this);
                           g.fillOval(323,458,6,6);
                           break;

                           case Level1.Surface : 
                           g.drawImage(Surfaceimage, 314, 177, 260, 200, this);
                           g.fillOval(438,508,6,6);
                           break;

                           case Level1.DATATerminal : 
                           g.drawImage(DATATERMINALimage, 314, 177, 260, 200, this);
                           break;

                           case Level1.TheFRIDGE : 
                           g.drawImage(TheFRIDGEimage, 314, 177, 260, 200, this);
                           break;

                           case Level1.THESAFE : 
                           g.drawImage(THESAFEimage, 314, 177, 260, 200, this);
                           break;

                           case Level1.FREEZERFIGHT : 
                           g.drawImage(FREEZERFIGHTimage, 314, 177, 260, 200, this);
                           break;

                           case Level1.BOSSFIGHT_L1 : 
                           g.drawImage(BOSSFIGHT_L1image, 314, 177, 260, 200, this);
                           break;
                                                        
                           case Level1.SpiderImage : 
                           g.drawImage(Spiderimage, 314, 177, 260, 200, this);
                           break;
                                                      
                           case Level1.RoachImage : 
                           g.drawImage(Roachimage, 314, 177, 260, 200, this);
                           break;
                                                      
                           case Level1.FreezerMutant1Image : 
                           g.drawImage(FreezerMutant1image, 314, 177, 260, 200, this);
                           break;

                           case Level1.FreezerMutant2Image : 
                           g.drawImage(FreezerMutant2image, 314, 177, 260, 200, this);
                           break;
                                                      
                           case Level1.PyroMutant1Image : 
                           g.drawImage(PyroMutant1image, 314, 177, 260, 200, this);
                           break;

                           case Level1.PyroMutant2Image : 
                           g.drawImage(PyroMutant2image, 314, 177, 260, 200, this);
                           break;

                           case Level1.MutantMixImage : 
                           g.drawImage(MutantMiximage, 314, 177, 260, 200, this);
                           break;

                           default : break;
                         }
                         
                                                  break;
                case 2 : //Level 2 Events for Button would go here
                         break;

                case 3 : //Level 3 Events for Button would go here
                         break;
            }

            /*
            switch(Game.FightImage)
            {
                   case 'd' : g.drawImage(DRAGONimage, 338, 210, 127, 90, this);
                              break;
                   case 'g' : g.drawImage(GIANTimage, 338, 210, 127, 90, this);
                              break;
                   default :  break;
            }
            */
    }

//----------------------------------------------------------------------------------
    public void run()   {  }

//----------------------------------------------------------------------------------
    public void actionPerformed(ActionEvent e)
    {
           Object source = e.getSource( ) ;

        //*******************************************************************
        if(e.getSource().equals(ButtonStart))
        {
            if(Started == false)
            {
                  //Necessary for FireFox browser, not IE
                  Graphics x = getGraphics();
                  x.drawImage(INTROimage, 314, 177, 260, 200, this);

                MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
                MainOutput.setForeground(Color.black);
                OutConquests.setText("Loading...");
                ButtonGo.setEnabled(true);
                Continue = true;
                Started = true;
                //Pass it a pointer so it can manipulate the GUI
                Game = new Events(this);
            }//close if for "StartedGame==false"
            else
            {
                String NagMe = JOptionPane.showInputDialog(null,
                        "You are in the middle of a game. Are you sure?",
                        "no way").toLowerCase();

                  if(NagMe.equals("yes") || NagMe.equals("y"))
                  {
                     ButtonQuit.doClick();
                  }
            }//close else
            
        Input.requestFocus();
        }//close if for StartButton

     //*******************************************************************
        if(e.getSource().equals(ButtonGo))
        {
            if(Started == true)
            {
                if(Continue == true)
                {
                     WEAPONS();
                     ABILITIES();

                     if(LOCK == false)
                     {
                         WhatToDo = '#'; //Invalidate Input
                         Game.SwitchBoard();
                         Input.setText("");
                         Input.requestFocus();

                     }//close if for LOCK = false
                     else
                     {
                         //Begin else for "LOCK = true" (Locked)
                         //Accept Input
                         WhatToDo = 
                         Character.toLowerCase(MutantWars.Input.getText().charAt(0));
                         Input.setText("");
                         Game.SwitchBoard();
                         Input.requestFocus();
                     }//close else for LOCK
                     MainOutput.setCaretPosition(0);
                }//close if for Continue
                else { ButtonQuit.doClick(); }
            }//close if started
            else
            {
                String WRITEME = MainOutput.getText() +
                "\n\n  Sorry, you can not press the \"GO\" button"
                + "\n  yet. You need  to click on the \"START\""
                + "\n  button to begin the game!";
                MainOutput.setText(WRITEME);
            }
        }//close if for GoButton

     //*******************************************************************
            if(e.getSource().equals(ButtonNorth))
            {
                WhatToDo = 'n';
                Game.SwitchBoard();
                Input.requestFocus();
            }
        //*******************************************************************
             if(e.getSource().equals(ButtonSouth))
             {
                WhatToDo = 's';
                Game.SwitchBoard();
                Input.requestFocus();
             }
        //*******************************************************************
             if(e.getSource().equals(ButtonEast))
             {
                WhatToDo = 'e';
                Game.SwitchBoard();
                Input.requestFocus();
             }
        //*******************************************************************
             if(e.getSource().equals(ButtonWest))
             {
                WhatToDo = 'w';
                Game.SwitchBoard();
                Input.requestFocus();
             }
        //*******************************************************************
             if(e.getSource().equals(ButtonLook))
             {
                WhatToDo = 'l';
                Game.SwitchBoard();
                Input.requestFocus();
             }
        //*******************************************************************
        if(e.getSource().equals(ButtonAction))
         {
              switch(Game.LEVEL)
              {
                   case 1 : switch(Level1.LOCATION)
                            {
                                 case Level1.C1 : WhatToDo = 't'; break;
                                 case Level1.C1Roof : WhatToDo = 'p'; break;
                                 case Level1.C1Basement : WhatToDo = 'd'; break;
                                 case Level1.N1 : WhatToDo = 'c'; break;
                                 case Level1.S1 : WhatToDo = 'c'; break;
                                 case Level1.E1 : WhatToDo = 'g'; break;
                                 case Level1.E1Closet : WhatToDo = 'c'; break;
                                 case Level1.W1 : WhatToDo = 'l'; break;
                                 case Level1.N2 : WhatToDo = 't'; break;
                                 case Level1.N2Garage : WhatToDo = 't'; break;
                                 case Level1.N2Service : WhatToDo = 'd'; break;
                                 case Level1.S2 : WhatToDo = 'l'; break;
                                 case Level1.E2 : WhatToDo = 'l'; break;
                                 case Level1.W2 : WhatToDo = 'l'; break;
                                 case Level1.Surface : break;
                                 case Level1.BOSSFIGHT_L1 : break;
                                 case Level1.INTRO : WhatToDo = 'g'; break;

                            }
                            break;

                   case 2 : //Level 2 Events for Button would go here
                            break;

                   case 3 : //Level 3 Events for Button would go here
                            break;
              }

              Game.SwitchBoard();
              Input.requestFocus();
         }
        //*******************************************************************
        if(e.getSource().equals(ButtonQuit))
        {
             String NagMe = JOptionPane.showInputDialog(null,
             "Are you absolutely, positively sure you want to guit?",
             "No").toLowerCase();

             if(NagMe.equals("yes") || NagMe.equals("y"))
             {
                 Input.setText("");
                 MainOutput.setText("");
                 OutConquests.setText("");
                 OutInventory.setText("");
                 OutCharClass.setText("");
                 OutName.setText("");
                 OutSex.setText("");
                 Started = false;
                 Continue = false;
                 Level1.LOCATION = Level1.QUIT;
                 Input.requestFocus();
                 Functions.SaveHighScores(Game.Player);
                 MainOutput.setForeground(Color.red);
                 MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 16));
                 MainOutput.setText(MainOutput.getText() + "\n\n\n  Good\n  Bye!");
                 this.destroy();
                 System.gc(); //collect garbage, free resources

             }
        }
        //*******************************************************************
         if(e.getSource().equals(ButtonHelp))
         {
            if(NARRATE) 
            { 
               //In case other sections are being narrated, stop them.
               C1.stop();
               ChooseSex.stop();
               HELP.stop();
               INTRO1.stop();
               INTRO2.stop();
               INTRO3.stop();
               INTRO4.stop();
               INTRO5.stop();
               INTRO6.stop();
               PleaseEnterName.stop();
               ThatIsAnAdmirableName.stop();
               YouBeginFemale.stop();
               YouBeginIT.stop();
               YouBeginMale.stop();
               YouBeginLastPart.stop();
               HELP.play();
            }

            JOptionPane.showMessageDialog(null,
            "           2007 - C. Germany - www.networkingprogramming.com\n\n" +
            "                                      MutantWars Instructions\n\n" +
            "You are an Impath caught up in a power struggle between two warring\n" +
            "factions of mutants. You must defeat the Disectors, your enemies, in\n" +
            "order to survive.\n\n" +
            "The object of this game is to collect the items necessary to solve the\n" +
            "puzzles and reach subsequent levels, thus defeating your opponents.\n\n" +
            "Interspersed throughout the game you will find clues, both from the\n" +
            "characters you talk to, and occasional objects you interact with.\n\n\n" +
            "As you find new items, they will be added to your inventory and you\n" +
            "may use them when appropriate.\n\n" +
            "When engaging enemy combatants, you may choose from whatever weapons\n" +
            "you have found. Each weapon has different characteristics and will\n" +
            "offer tactical advantages in specfic situations. Some weapons are\n" +
            "better at close range, others are better from a distance.\n\n" +
            "You will also find items that can restore life points or increase\n" +
            "your defense.\n\n" +
            "As an Impath, when you defeat an opponent, you will gain their mutant\n" +
            "abilities and master them over time.\n\n" +
            "Shortct Keys:      ARROW keys = North | South | East | West\n" +
            "                               PageUP and PageDOWN = Up | Down\n" +
            "                               END = Look\n" +
            "                               DELETE = Fight\n"+
            "                               ENTER = Go");
            Input.requestFocus();
            HELP.stop(); //Stop narrating if user closes MessageDialog
         }
         //*******************************************************************
         if(e.getSource().equals(ButtonFIGHT))
         {
              WhatToDo = 'f';
              Game.SwitchBoard();
              Input.requestFocus();
         }

        //*******************************************************************

        if(e.getSource().equals(ButtonUseInventory))
        {
           MutantInventoryPopUp = new JFrame("MutantWars Inventory Items");
           MutantInventoryPopUp.setMinimumSize(new Dimension(125, 330));
           MutantInventoryPopUp.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
           MutantInventoryPopUp.getContentPane().setBackground(Color.BLACK);
           MutantInventoryPopUp.getContentPane().setForeground(Color.WHITE);
           MutantInventoryPopUp.setLocation(342,275);
           MutantInventoryPopUp.setLayout(null);

           InventoryButtonGroup.add(RadioKey);
           InventoryButtonGroup.add(RadioDataCrystal);
           InventoryButtonGroup.add(RadioFramePack);
           InventoryButtonGroup.add(RadioMREs);
           InventoryButtonGroup.add(RadioMedKit);
           InventoryButtonGroup.add(RadioSterno);
           InventoryButtonGroup.add(RadioMatches);
           InventoryButtonGroup.add(RadioKeyCard);
           InventoryButtonGroup.add(RadioStraightJacket);

           RadioKey.setBackground(Color.black);
           RadioKey.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioKey.setForeground(Color.white);
           RadioKey.setText("Key");
           RadioKeyCard.setBackground(Color.black);
           RadioKeyCard.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioKeyCard.setForeground(Color.white);
           RadioKeyCard.setText("Key Card");
           RadioDataCrystal.setBackground(Color.black);
           RadioDataCrystal.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioDataCrystal.setForeground(Color.white);
           RadioDataCrystal.setText("Data Crystal");
           RadioFramePack.setBackground(Color.black);
           RadioFramePack.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioFramePack.setForeground(Color.white);
           RadioFramePack.setText("Frame Pack");
           RadioMREs.setBackground(Color.black);
           RadioMREs.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioMREs.setForeground(Color.white);
           RadioMREs.setText("MREs  :");
           RadioMedKit.setBackground(Color.black);
           RadioMedKit.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioMedKit.setForeground(Color.white);
           RadioMedKit.setText("Medkits  :");
           RadioSterno.setBackground(Color.black);
           RadioSterno.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioSterno.setForeground(Color.white);
           RadioSterno.setText("Sterno");
           RadioMatches.setBackground(Color.black);
           RadioMatches.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioMatches.setForeground(Color.white);
           RadioMatches.setText("Matches");
           RadioStraightJacket.setBackground(Color.black);
           RadioStraightJacket.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           RadioStraightJacket.setForeground(Color.white);
           RadioStraightJacket.setText("St. Jacket");

           ButtonUse.setBackground(Color.white);
           ButtonUse.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 12));
           ButtonUse.setForeground(Color.red);
           ButtonUse.setBorder(BorderFactory.createRaisedBevelBorder());
           ButtonUse.setText("Use Item");

           InventoryTitle.setBackground(Color.black);
           InventoryTitle.setFont(new java.awt.Font("Tahoma", Font.PLAIN, 14));
           InventoryTitle.setForeground(Color.white);
           InventoryTitle.setHorizontalAlignment(SwingConstants.CENTER);
           InventoryTitle.setHorizontalTextPosition(SwingConstants.CENTER);
           InventoryTitle.setText("Inventory Items");
           InventoryTitle.setBounds(new Rectangle(6, 3, 106, 18));

           MutantInventoryPopUp.add(InventoryTitle);

           if(Game.Player.GetKey())
           {
               RadioCount = RadioCount + 25;
               RadioKey.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioKey);
           }

           if(Game.Player.GetKeyCard())
           {
               RadioCount = RadioCount + 25;
               RadioKeyCard.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioKeyCard);
           }
           
           if(Game.Player.GetDataCrystal())
           {
               RadioCount = RadioCount + 25;
               RadioDataCrystal.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioDataCrystal);
           }

           if(Game.Player.GetFramePack())
           {
               RadioCount = RadioCount + 25;
               RadioFramePack.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioFramePack);
           }
           
           if(Game.Player.GetMRErations() > 0)
           {
               RadioCount = RadioCount + 25;
               RadioMREs.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioMREs);
           }
           
           if(Game.Player.GetMedKit() > 0)
           {
               RadioCount = RadioCount + 25;
               RadioMedKit.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioMedKit);
           }
           
           if(Game.Player.GetSterno())
           {
               RadioCount = RadioCount + 25;
               RadioSterno.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioSterno);
           }
           
           if(Game.Player.GetMatches())
           {
               RadioCount = RadioCount + 25;
               RadioMatches.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioMatches);
           }

           if(Game.Player.GetJacket())
           {
               RadioCount = RadioCount + 25;
               RadioStraightJacket.setBounds(new Rectangle(10, RadioCount, 101, 23));
               MutantInventoryPopUp.add(RadioStraightJacket);
           }

           RadioCount = RadioCount + 30;
           ButtonUse.setBounds(new Rectangle(22, RadioCount, 75, 23));
           MutantInventoryPopUp.add(ButtonUse);

           MutantInventoryPopUp.setVisible(true);

           //Reset RadioCount for next time window is opened
           RadioCount = 1;
        }
        //*******************************************************************

        if(e.getSource().equals(ButtonUseAbility))
        {
                String OUT = "";

                if(RadioFreeze.isSelected())
                {
                    OUT = "\n  Nothing to FREEZE here...";
                }

                else if(RadioFire.isSelected())
                {
                     OUT = "\n  Nothing to BURN here...";
                }

                else if(RadioHeal.isSelected())
                {
                    if(Game.Player.GetMutantPower() - 10 > 0)
                    {
                       OUT = "\n  You user your mutant healing ability, thus\n"
                           + "  restoring 20 life points to yourself.\n";
                       Game.Player.SetHit(Game.Player.GetHit() + 20);
                       Game.Player.SetMutantPower(Game.Player.GetMutantPower() - 10);
                       Game.Player.DisplayStats();
                    }
                    else
                    {
                        OUT = "\n  You do not have enough Mutant Power to\n"
                            + "  initiate a healing session.";
                    }
                }

                else if(RadioFly.isSelected())
                {
                    if(Game.Player.GetMutantPower() - 20 > 0)
                    {
                       OUT = "\n  You decide to FLY and be free. As you soar\n"
                           + "  through the atmosphere, you become a more\n"
                           + "  difficult target. This temporarily increases\n"
                           + "  your defense by 2 points.";

                       Game.Player.SetDef(Game.Player.GetDef() + 2);
                       Game.Player.SetMutantPower(Game.Player.GetMutantPower() - 20);
                       Game.Player.DisplayStats();
                    }
                    else
                    {
                              OUT = "\n  Sorry, you don't have enough mutant "
                                  + "\n  power to FLY.";
                    }
                }

                else if(RadioMove.isSelected())
                {
                      OUT = "\n  You create a mental wave of force,\n"
                           + "  but here there is nothing on which to\n"
                           + "  release your telekinetic energy.";

                }

                else if(RadioMindRead.isSelected())
                {
                     OUT = "\n  You attempt a telepathic link, but become"
                         + "\n  disconnected and are unable to read any minds.";
                }

                else if(RadioTimeTravel.isSelected())
                {
                   OUT = "\n  You subtly shift the space-time around you.";
                }

                else
                {
                    OUT = "\n  How can you use an ability when no\n"
                        + "  abilities are selected?";
                }

                OUT = OUT + "\n\n  Click \"LOOK\" to examine your surroundings.";
                MainOutput.setText(OUT);
                Input.requestFocus();
        }

        //*******************************************************************


        if(e.getSource().equals(ButtonScores))
        {
             //Call this statically so they can display scores even
             //if an Events object has not been instantiated.
             MainOutput.setForeground(Color.blue);
             MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 13));
             if(SCORETOGGLE)
             {
                 PREVIOUS = MainOutput.getText();
                 MainOutput.setText("");
                 Functions.DisplayHighScores();
                 SCORETOGGLE = false;
             }
             else
             {
                 MainOutput.setForeground(Color.black);
                 MainOutput.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
                 MainOutput.setText(PREVIOUS);
                 SCORETOGGLE = true;
             }

        }
        //*******************************************************************

        if(e.getSource().equals(ButtonLoad))
        {
            if(Started)
            {
                String CharacterName =
                JOptionPane.showInputDialog(null,"Input Character's Name or enter "
                                     + "\"BROWSE\" to browse files.").toLowerCase();
                
                if(CharacterName.equals("browse"))
                {
                     //This will create a file dialg for browsing:
                     Frame parent = new Frame();
                     FileDialog TheFile = new FileDialog(parent,
                     "Please choose a file with a \".gam\" extension: ",
                     FileDialog.LOAD);
	             TheFile.setVisible(true);
	             CharacterName = TheFile.getFile();
                }

                Game.Player.SetName(CharacterName);
                Functions.LoadCharacter(Game.Player);
                Game.SwitchBoard();
            }
        }

        //*******************************************************************
        if(e.getSource().equals(ButtonSave))
        {
            if(Started)
            {
                Functions.SaveCharacter(Game.Player);
                JOptionPane.showMessageDialog(null,
                "Your Character was saved as \"" +
                Game.Player.GetName() + ".gam\"!");
            }
        }
        //*******************************************************************

} //close actionPerformed function
//----------------------------------------------------------------------------------
    public static void WEAPONS()
    {
       if(Continue && Started)
       {
           //Disable Radio Buttons if Player Doesn't Have the Weapon
           if(Events.Player.GetMachete())
           { RadioMachete.setEnabled(true); }
           else
           { RadioMachete.setEnabled(false); }

           if(Events.Player.GetGun())
           { RadioGun.setEnabled(true); }
           else
           { RadioGun.setEnabled(false); }

           if(Events.Player.GetSyringe())
           { RadioSyringe.setEnabled(true);  }
           else
           { RadioSyringe.setEnabled(false); }


           //If one is selected, deselect all others. 
           //In ButtonGroup, but still must set booleans in LifeForm
           if(RadioHand.isSelected())
           {
              Events.Player.SetUseHand(true);
              Events.Player.SetUseMachete(false);
              Events.Player.SetUseGun(false);
              Events.Player.SetUseSyringe(false);
           }

           if(RadioMachete.isSelected())
           {
              Events.Player.SetUseMachete(true);
              Events.Player.SetUseHand(false);
              Events.Player.SetUseGun(false);
              Events.Player.SetUseSyringe(false);
           }

           if(RadioGun.isSelected())
           {
              Events.Player.SetUseGun(true);
              Events.Player.SetUseMachete(false);
              Events.Player.SetUseHand(false);
              Events.Player.SetUseSyringe(false);

            }
            if(RadioSyringe.isSelected())
            {
              Events.Player.SetUseSyringe(true);
              Events.Player.SetUseGun(false);
              Events.Player.SetUseMachete(false);
              Events.Player.SetUseHand(false);
           }

       }//close weapons if

    }//close weapons function

//----------------------------------------------------------------------------------

     public static void ABILITIES()
    {
       if(Continue && Started)
       {
           //Disable Radio Buttons if Player Doesn't Have the Ability

           if(Events.Player.GetFREEZE())
           { RadioFreeze.setEnabled(true); }
           else
           { RadioFreeze.setEnabled(false); }

           if(Events.Player.GetFIRE())
           { RadioFire.setEnabled(true); }
           else
           { RadioFire.setEnabled(false); }

           if(Events.Player.GetHEAL())
           { RadioHeal.setEnabled(true);  }
           else
           { RadioHeal.setEnabled(false); }

          if(Events.Player.GetFLY())
           { RadioFly.setEnabled(true);  }
           else
           { RadioFly.setEnabled(false); }

           if(Events.Player.GetMOVE())
           { RadioMove.setEnabled(true);  }
           else
           { RadioMove.setEnabled(false); }

           if(Events.Player.GetMINDREAD())
           { RadioMindRead.setEnabled(true);  }
           else
           { RadioMindRead.setEnabled(false); }
           
           if(Events.Player.GetTIMESHIFT())
           { RadioTimeTravel.setEnabled(true);  }
           else
           { RadioTimeTravel.setEnabled(false); }


           //If one is selected, deselect all others.
           //In ButtonGroup, but still must set booleans in Mutant
           if(RadioNone.isSelected())
           {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(false);
           }

           if(RadioFreeze.isSelected())
           {
              Events.Player.SetUseFREEZE(true);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(false);
           }

           if(RadioFire.isSelected())
           {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(true);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(false);

            }
            if(RadioHeal.isSelected())
            {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(true);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(false);
           }

            if(RadioFly.isSelected())
            {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(true);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(false);
           }

            if(RadioMove.isSelected())
            {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(true);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(false);
           }
           
            if(RadioMindRead.isSelected())
            {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(true);
              Events.Player.SetUseTIMESHIFT(false);
           }

            if(RadioTimeTravel.isSelected())
            {
              Events.Player.SetUseFREEZE(false);
              Events.Player.SetUseFIRE(false);
              Events.Player.SetUseHEAL(false);
              Events.Player.SetUseFLY(false);
              Events.Player.SetUseMOVE(false);
              Events.Player.SetUseMINDREAD(false);
              Events.Player.SetUseTIMESHIFT(true);
           }

           Events.Player.AbilityCost();

       }//close ABILITIES if

    }//close ABILITIES function
//----------------------------------------------------------------------------------

           public static void LockButtons(boolean x)
           {
            //Safety lock all command buttons during combat except
            //for the radio buttons being used during combat
            if(x == true)
            {
                ButtonNorth.setEnabled(false);
                ButtonSouth.setEnabled(false);
                ButtonEast.setEnabled(false);
                ButtonWest.setEnabled(false);
                ButtonGo.setEnabled(false);
                ButtonAction.setEnabled(false);                
                ButtonScores.setEnabled(false);
                ButtonSave.setEnabled(false);
                ButtonLoad.setEnabled(false);
                ButtonUseAbility.setEnabled(false);
                ButtonUseInventory.setEnabled(false);
                ButtonFIGHT.setEnabled(false);
                ButtonLook.setEnabled(false);
                ButtonALT1.setEnabled(false);
                ButtonALT2.setEnabled(false);
            }
            else
            {
                ButtonNorth.setEnabled(true);
                ButtonSouth.setEnabled(true);
                ButtonEast.setEnabled(true);
                ButtonWest.setEnabled(true);
                ButtonGo.setEnabled(true);
                ButtonAction.setEnabled(true);                
                ButtonScores.setEnabled(true);
                ButtonSave.setEnabled(true);
                ButtonLoad.setEnabled(true);
                ButtonUseAbility.setEnabled(true);
                ButtonUseInventory.setEnabled(true);
                ButtonFIGHT.setEnabled(true);
                ButtonLook.setEnabled(true);
                ButtonALT1.setEnabled(true);
                ButtonALT2.setEnabled(true);
            }
       }

//----------------------------------------------------------------------------------

public void keyPressed(KeyEvent e)
{
       //Add short cut keys for all game butons
       int TheKey = e.getKeyCode();
       //char TheChar = e.getKeyChar(); //Gets character

       if(TheKey == KeyEvent.VK_ENTER)
       { ButtonGo.doClick(); }

       if(TheKey == KeyEvent.VK_LEFT)
       {
           WhatToDo = 'w';
           Game.SwitchBoard();
       }

       if(TheKey == KeyEvent.VK_RIGHT)
       {
           WhatToDo = 'e';
           Game.SwitchBoard();
       }

       if(TheKey == KeyEvent.VK_UP)
       {
           WhatToDo = 'n';
           Game.SwitchBoard();
       }

       if(TheKey == KeyEvent.VK_DOWN)
       {
           WhatToDo = 's';
           Game.SwitchBoard();
       }
       
       if(TheKey == KeyEvent.VK_END)
       {
           WhatToDo = 'l';
           Game.SwitchBoard();
       }

       if(TheKey == KeyEvent.VK_PAGE_UP)
       {
           WhatToDo = 'u';
           Game.SwitchBoard();
       }
       
       if(TheKey == KeyEvent.VK_PAGE_DOWN)
       {
           WhatToDo = 'd';
           Game.SwitchBoard();
       }

       if(TheKey == KeyEvent.VK_DELETE)
       {
           WhatToDo = 'f';
           Game.SwitchBoard();
       }
}

public void keyReleased(KeyEvent e)  {     }
public void keyTyped(KeyEvent e)  {     }
//----------------------------------------------------------------------------------

    //The necessary methods for implementing MouseListener
    public void mouseClicked(MouseEvent evt) {  }
    public void mouseReleased(MouseEvent evt) {  }
    public void mouseExited(MouseEvent evt) {   }
    public void mousePressed(MouseEvent evt)  {  }
    public void mouseEntered(MouseEvent evt)  {  }

//----------------------------------------------------------------------------------
    //The necessary methods for implementing MouseMotionListener
    public void mouseDragged(MouseEvent e)  {  }
    public void mouseMoved(MouseEvent e)  {  }

//----------------------------------------------------------------------------------
    //The necessary method for implementing TextListener
    public void textValueChanged(TextEvent t)  {   }

//----------------------------------------------------------------------------------

    //Necessary to repaint() screen after sleep()ing Thread objects
    public void refresh()
    {
           Graphics g = getGraphics();
           paint(g);
    }

//----------------------------------------------------------------------------------

}//close applet class
