//Class for Future Level 3 Events. This will modularize level design.
//16 lines of code

import javax.swing.*;
import java.io.*;
import java.util.Random;

public class Level3
{
       public Level3() {  }   
    
       public void Switchboard() 
       {

       }   
}