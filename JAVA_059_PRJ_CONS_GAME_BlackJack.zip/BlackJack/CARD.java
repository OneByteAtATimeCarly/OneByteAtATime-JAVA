//Project - BlackJack Game - The CARD Class - 2006 - Carly Salali Germany

//--------------------------------------------------------------------------------------

public class CARD
{
       //Globals
       //The Card Values
       public static final int DEUCE = 2;
       public static final int THREE = 3;
       public static final int FOUR = 4;
       public static final int FIVE = 5;
       public static final int SIX = 6;
       public static final int SEVEN = 7;
       public static final int EIGHT = 8;
       public static final int NINE = 9;
       public static final int TEN = 10;
       public static final int JACK = 11;
       public static final int QUEEN = 12;
       public static final int KING = 13;
       public static final int ACE = 14;

       //The Faces
       public static final int SPADES = 0;
       public static final int HEARTS = 1;
       public static final int DIAMONDS = 2;
       public static final int CLUBS = 3;

       //Constructor
       public CARD()
       {
              TheCard = DEUCE;
              TheFace = HEARTS;
              Drawn = false;
       }

       //Overloaded Constructor
       public CARD(int card, int face)
       {
              TheCard = card;
              TheFace = face;
              Drawn = false;

              switch(TheCard)
              {
                  case DEUCE : PointValue = 2; break;
                  case THREE : PointValue = 3; break;
                  case FOUR : PointValue = 4; break;
                  case FIVE : PointValue = 5; break;
                  case SIX : PointValue = 6; break;
                  case SEVEN : PointValue = 7; break;
                  case EIGHT : PointValue = 8; break;
                  case NINE : PointValue = 9; break;
                  case TEN : PointValue = 10; break;
                  case JACK : PointValue = 10; break;
                  case QUEEN : PointValue = 10; break;
                  case KING : PointValue = 10; break;
                  case ACE : PointValue = 11; break;
                  default : break;
              }
       }

       public void DisplayCard()
       {
              String OUT = "\n     A ";

              switch(TheCard)
              {
                  case DEUCE : OUT = OUT + "DEUCE"; break;
                  case THREE : OUT = OUT + "THREE"; break;
                  case FOUR : OUT = OUT + "FOUR"; break;
                  case FIVE : OUT = OUT + "FIVE"; break;
                  case SIX : OUT = OUT + "SIX"; break;
                  case SEVEN : OUT = OUT + "SEVEN"; break;
                  case EIGHT : OUT = OUT + "EIGHT"; break;
                  case NINE : OUT = OUT + "NINE"; break;
                  case TEN : OUT = OUT + "TEN"; break;
                  case JACK : OUT = OUT + "JACK"; break;
                  case QUEEN : OUT = OUT + "QUEEN"; break;
                  case KING : OUT = OUT + "KING"; break;
                  case ACE : OUT = OUT + "ACE"; break;
                  default : break;
              }

              OUT = OUT + " of ";

              switch(TheFace)
              {
                 case SPADES : OUT = OUT + "SPADES"; break;
                 case HEARTS : OUT = OUT + "HEARTS"; break;
                 case DIAMONDS : OUT = OUT + "DIAMONDS"; break;
                 case CLUBS : OUT = OUT + "CLUBS"; break;
                 default : break;
              }

              OUT = OUT + ". Points = " + PointValue + ".";

              System.out.print(OUT);
       }

       //Public Accessors
       public int GetFace() { return TheFace; }
       public int GetCard() { return TheCard; }
       public int GetPointValue() { return PointValue; }
       public boolean GetDrawn() { return Drawn; }

       public void SetFace(int x) { TheFace = x; }
       public void SetCard(int x) { TheCard = x; }
       public void SetPointValue(int x) { PointValue = x; }
       public void SetDrawn(boolean x) { Drawn = x; }

       //Private Data Members
       private int TheFace;
       private int TheCard;
       private int PointValue = 0;
       private boolean Drawn = false;

}//close CARD class
