//AdventureGame 1.0, Java Version, Character base class, C. Germany, July 01, 2006
//File 4 of 7. Save as "Character.java".

import java.util.Random;

public class Character
{
   public Character()
   {
     String WRITEME = HillsOfDarkness.OutputArea.getText() +
                      "\n Creating a Character.";
     HillsOfDarkness.OutputArea.setText(WRITEME);

     hitpoints = 40; atak = 1; defense = 1;
     level = 0; score = 0;
     InitializeInventory();
   }

   public static void DisplayStats()
   {

          HillsOfDarkness.HitpointOutputLabel.setText(
            "    " + Integer.toString(hitpoints));
          HillsOfDarkness.AttackOutputLabel.setText(
            "    " + Integer.toString(atak));
          HillsOfDarkness.DefenseOutputLabel.setText(
            "    " + Integer.toString(defense));
          HillsOfDarkness.ScoreOutputLabel.setText(
            "    " + Integer.toString(score));
          HillsOfDarkness.NameOutputLabel.setText("  " + CharName);
   }

   public static void InitializeInventory()
   {
        dagger = false;
        sword = false;
        longbow = false;
        chainmail= false;
        fullbodyarmor= false;
        healingpotion = 0;
        FishKey = false;
   }

   public static void Inventory()
   {
       int n = 0;
       String INVENTORY = "\n";
       if(dagger){ ++n; INVENTORY = INVENTORY +  " " + n +  ". Dagger\n    (+ 2 Atk)\n\n"; }
       if(sword){ ++n; INVENTORY = INVENTORY +  " " + n +  ". Sword\n    (+ 4 Atk)\n\n"; }
       if(longbow){ ++n; INVENTORY = INVENTORY +  " " + n +  ". Long Bow\n    (+2 Dist)\n\n"; }
       if(chainmail){ ++n; INVENTORY = INVENTORY +  " " + n +  ". Chain Mail\n    (+ 2 Def)\n\n"; }
       if(fullbodyarmor){ ++n; INVENTORY = INVENTORY +  " " + n +  ". Armor\n    (+4 Def)\n\n"; }
       if(healingpotion > 0)
       {  ++n;
          INVENTORY = INVENTORY +  " " + n +  ". Healing\n     Potion\n    (+20HP)\n    Quantity: "
                         +  healingpotion +  "\n\n";
       }
       if(FishKey)
       { n++; INVENTORY = INVENTORY + " " + n +  ". Fish Key\n    (Access)\n"; }
       if(dagger == false && sword == false && longbow == false
         && chainmail == false && fullbodyarmor == false &&
         healingpotion == 0 && FishKey == false)
       { INVENTORY = INVENTORY +  "\n\n  How sad!\n\n  Absolute\n  Nothing!!!"; }

       HillsOfDarkness.InventoryArea.setText(INVENTORY);
       HillsOfDarkness.InventoryArea.setCaretPosition(0);

   }

   public static void Attack(Monster Opponent)
   {
      int damage = 0;

      Random BanannaSplit = new Random();
      damage = (BanannaSplit.nextInt(10) + 1) + atak;

      String WRITEME = HillsOfDarkness.OutputArea.getText();

      if(dagger == true && UseDagger == true)
      { WRITEME = WRITEME +
        "\n  " + CharName + " stabs\n  with the dagger!\n";
        damage = damage + 2;
        HillsOfDarkness.knifeSOUND.play();
      }
      else if(sword == true && UseSword == true)
      { WRITEME = WRITEME +
        "\n  " + CharName + " swings the\n  sword!\n";
        damage = damage + 4;
        HillsOfDarkness.swordSOUND.play();
      }
      else if(longbow == true && UseLongBow == true)
      { WRITEME = WRITEME +
        "\n  " + CharName + " releases\n  the String of the longbow!";
        damage = damage + 2;
        HillsOfDarkness.bowSOUND.play();
      }
      else
      { WRITEME = WRITEME +
             "\n  " + CharName +
             " engages the\n  opponent in brutal hand\n  to hand combat!\n";
        HillsOfDarkness.handSOUND.play();
      }

           WRITEME = WRITEME
           + "\n\n  ***** " + CharName
           + " Attacks! *****\n\n"
           + "  Before Attack:\n  " + CharName
           + " Hit = " + hitpoints  + "\n"
           + "  Opponent's Hit = " + Opponent.getHit()
           + "\n\n";

      if(damage - (Opponent.getDefense()) > 0)
      { damage = damage - (Opponent.getDefense()); }
      else { damage = 0; }

      //Prevent negative values. Check that oponent is still alive.
      if((Opponent.getHit() - damage) > 0)
        { Opponent.setHit((Opponent.getHit() - damage)); }
      else
        { Opponent.setHit(0); }

      WRITEME = WRITEME
              + "  After Attack:\n  " + CharName
              + " Hit = " + hitpoints  + "\n"
              + "  Opponent's Hit = " + Opponent.getHit()
              + "\n";

      HillsOfDarkness.OutputArea.setText(WRITEME);
   }

   public static void AskName()
   {
          CharName = HillsOfDarkness.InputField.getText();
          HillsOfDarkness.NameOutputLabel.setText("  " + CharName);

          String WRITEME = "\n\n  From henceforth, you shall be called:\n"
                           + "  " + CharName + " !!!\n\n";

          HillsOfDarkness.OutputArea.setText(WRITEME);
          HillsOfDarkness.InputField.setText("");
   }

   public static void Cheat()
   {
        setDagger(true); setSword(true);
        setLongBow(true); setChainMail(true);
        setFullBodyArmor(true); setHealingPotion(7);
        setFishKey(true);
   }

   public static void UseHealingPotion()
   {
         if(healingpotion > 0)
         {
             hitpoints = hitpoints + 20;
             healingpotion = healingpotion - 1;
             DisplayStats();
             HillsOfDarkness.OutputArea.setText(
             HillsOfDarkness.OutputArea.getText() +
             "\n\n  You drink the healing elixir and feel revived!");
             Inventory();
         }
         else
         {
            HillsOfDarkness.OutputArea.setText(
            HillsOfDarkness.OutputArea.getText() +
            "\n  Wishful thinking. You don't have any\n  healing potions.\n");
         }
   }

   //Inventory Accessor Methods
   public static boolean getDagger() { return dagger; }
   public static boolean getSword() { return sword; }
   public static boolean getLongBow() { return longbow; }
   public static boolean getChainMail() { return chainmail; }
   public static boolean getFullBodyArmor() { return fullbodyarmor; }
   public static int getHealingPotion() { return healingpotion; }
   public static boolean getFishKey() { return FishKey; }
   public static void setDagger(boolean x) { dagger = x; }
   public static void setSword(boolean x) { sword = x; }
   public static void setLongBow(boolean x) { longbow = x; }
   public static void setChainMail(boolean x) { chainmail = x; }
   public static void setFullBodyArmor(boolean x) { fullbodyarmor = x; }
   public static void setHealingPotion(int x) {
                      healingpotion = healingpotion + x; }
   public static void setFishKey(boolean x) { FishKey = x; }
   public static void setUseDagger(boolean x) { UseDagger = x; }
   public static void setUseSword(boolean x) { UseSword = x; }
   public static void setUseLongBow(boolean x) { UseLongBow = x; }


   //Character Attribute Accessor Methods
   public static void setHit(int hp) { hitpoints = hp; }
   public static void setAttack(int atk)  { atak = atk; }
   public static void setDefense(int def) { defense = def; }
   public static void setLevel(int lvl) { level = lvl; }
   public static void setLocation(int loki) { location = loki; }
   public static void setName(String nm) { CharName = nm; }
   public static void setScore(int sc)  { score = sc; }
   public static int getHit() { return hitpoints; }
   public static int getAttack()  { return atak; }
   public static int getDefense() { return defense; }
   public static int getLevel() { return level; }
   public static int getLocation() { return location; }
   public static int getScore() { return score; }
   public static String getName() { return CharName; }

   //Character Attribute Items
   private static int hitpoints;
   private static int atak;
   private static int defense;
   private static int level;
   private static int location;
   private static String CharName;
   private static int score;

   //Character Inventory Items
   private static  boolean dagger;
   private static  boolean sword;
   private static  boolean longbow;
   private static  boolean UseDagger;
   private static  boolean UseSword;
   private static  boolean UseLongBow;
   private static  boolean chainmail;
   private static  boolean fullbodyarmor;
   private static  int healingpotion;
   private static  boolean FishKey;

}
