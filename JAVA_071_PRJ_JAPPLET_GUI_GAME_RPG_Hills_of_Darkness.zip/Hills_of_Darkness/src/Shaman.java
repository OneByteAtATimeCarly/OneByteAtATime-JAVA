//AdventureGame 1.0, Java Version, derived Shaman class, C. Germany, July 01, 2006
//File 5 of 7. Save as "Shaman.java".

import java.util.Random;

public class Shaman extends Character
{
       public Shaman()
       {
           String WRITEME = HillsOfDarkness.OutputArea.getText() +
                        "\n Creating a Shaman.";
           HillsOfDarkness.OutputArea.setText(WRITEME);
       }

       Random BanannaSplit = new Random();

      public void Talk()
      {
             int SayWhat = (BanannaSplit.nextInt(10) + 1);

             String WRITEME =
            "\n  The Shaman looks at you from beneath her\n"
            + "  priestly garments and says,\n\n  \"";

             switch(SayWhat)
             {
                 case 1 : WRITEME = WRITEME
                          + "I like wild flowers. They are very beautiful,\n"
                          + "   and their restorative powers are merely a\n"
                          + "   fringe benefit.";
                          break;
                 case 2 : WRITEME = WRITEME +
                          "Do not look at the outward appearance of\n"
                          + "   things, character should be judged by\n"
                          + "   what is on the inside.";
                          break;
                 case 3 : WRITEME = WRITEME +
                           "Good karma, bad karma,\n"
                           + "   it's all the same..";
                          break;
                 case 4 : WRITEME = WRITEME +
                          "I have a secret to tell...";
                          break;
                 case 5 : WRITEME = WRITEME
                          + "To unlock the gate between worlds one\n"
                          + "   needs a key";
                          break;
                 case 6 : WRITEME = WRITEME +
                          "You are not from this world, I see that\n   now.";
                          break;
                 case 7 : WRITEME = WRITEME +
                          "You did not yet know it traveler, but you\n"
                          + "   must seek the key of the fish god!"; break;
                 case 8 : WRITEME = WRITEME
                          + "Sometimes I wish I'd never taken that vow\n"
                          + "   of chastity";
                          break;
                 case 9 : WRITEME = WRITEME +
                          "Do you think I'm pretty? Don't judge a book\n"
                         + "   by its cover!";
                          break;
                 case 10 : WRITEME = WRITEME
                           + "Beware the edge of the forest. Giants\n"
                           + "   are afoot!";
                           break;
                 default : WRITEME = WRITEME +
                           "\n  Uh oh, this should never happen..";
                           break;
            } //closes switch

            HillsOfDarkness.OutputArea.setText(WRITEME + "\"\n\n");

    } //close talk function

       //Public Accesor Methods
         public void setStaff(boolean x) { staff = x; }
         public boolean getStaff() { return staff; }
         public void setMedicine(boolean x) { medicinebag = x; }
         public boolean getMedicine() { return medicinebag; }

      //Private Data Members
        private boolean staff;
        private boolean medicinebag;
};

//-----------------------------------------------------------------
