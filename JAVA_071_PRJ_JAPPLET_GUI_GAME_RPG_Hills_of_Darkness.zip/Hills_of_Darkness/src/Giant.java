//AdventureGame 1.0, Java Version, derived Giant class, C. Germany, July 01, 2006
//File 3 of 7. Save as "Giant.java".

import java.util.Random;

public class Giant extends Monster
{
       public Giant()
       {
             String WRITEME = HillsOfDarkness.OutputArea.getText() +
             "\n Creating a DERIVED class Giant.\n";
             HillsOfDarkness.OutputArea.setText(WRITEME);
       }

      public void Attack(Character Opponent)
      {
          Random BanannaSplit = new Random();
          int damage = (BanannaSplit.nextInt(10) + 1) + getAttack();
          HillsOfDarkness.giantSOUND.play();
          String WRITEME = HillsOfDarkness.OutputArea.getText();

          WRITEME = WRITEME
                  + "\n\n  ***** Giant Attacks! ****\n\n"
                  + "  Before Attack: Giant Hit = " + getHit() + "\n  "
                  + Opponent.getName() +  " Hit = "  + Opponent.getHit()
                  + "\n";

      if(damage > Opponent.getDefense())
         { damage = damage - Opponent.getDefense(); }
      else { damage = 0; }
      if(Opponent.getFullBodyArmor())
      { if(damage > 4) { damage = damage - 4; } }
      if(Opponent.getChainMail())
      { if(damage > 2) { damage = damage - 2; }  }

      //Prevent negative values. Check that oponent is still alive.
      if((Opponent.getHit() - damage) > 0)
        { Opponent.setHit((Opponent.getHit() - damage)); }
      else
        { Opponent.setHit(0); }

       WRITEME = WRITEME
                 + "\n"
                 + "  After Attack: Giant Hit = " + getHit() + "\n  "
                 + Opponent.getName() +  " Hit = "  + Opponent.getHit()
                 + "\n";

       HillsOfDarkness.OutputArea.setText(WRITEME);
   }

   public void StompOnSomethingSmallerThanMe()
   {
       String WRITEME = HillsOfDarkness.OutputArea.getText() + "Stomp on enemies.";
       HillsOfDarkness.OutputArea.setText(WRITEME);
   }

    //Public Accesor Methods
      public void setClub(boolean club) { HasClub = club; }
      public boolean getClub() { return HasClub; }

    //Private Data Members
      private boolean HasClub;

}
