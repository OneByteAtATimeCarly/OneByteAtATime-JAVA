//AdventureGame 1.0, Java Version, derived Dragon class, C. Germany, July 01, 2006
//File 2 of 7. Save as "Dragon.java".

import java.util.Random;

public class Dragon extends Monster
{
      public Dragon()
      {
          String WRITEME = HillsOfDarkness.OutputArea.getText() +
          "\n Creating a DERIVED class Dragon.\n";
          HillsOfDarkness.OutputArea.setText(WRITEME);
      }

      public void Attack(Character Opponent)
      {
          Random BanannaSplit = new Random();
          int damage = (BanannaSplit.nextInt(10) + 1) + getAttack();
          HillsOfDarkness.dragonSOUND.play();

          String WRITEME = HillsOfDarkness.OutputArea.getText();
          WRITEME = WRITEME
                  + "\n\n  ***** Dragon Attacks! ****\n\n"
                  + "  Before Attack: Giant Hit = " + getHit() + "\n  "
                  + Opponent.getName() +  " Hit = "  + Opponent.getHit()
                  + "\n";

      if(damage > Opponent.getDefense())
         { damage = damage - Opponent.getDefense(); }
      else { damage = 0; }
      if(Opponent.getFullBodyArmor())
      { if(damage > 4) { damage = damage - 4; } }
      if(Opponent.getChainMail())
      { if(damage > 2) { damage = damage - 2; }  }

      //Prevent negative values. Check that oponent is still alive.
      if((Opponent.getHit() - damage) > 0)
        { Opponent.setHit((Opponent.getHit() - damage)); }
      else
        { Opponent.setHit(0); }

       WRITEME = WRITEME
               + "\n"
               + "  After Attack: Dragon Hit = " + getHit() + "\n  "
               + Opponent.getName() +  " Hit = "  + Opponent.getHit()
               + "\n";

       HillsOfDarkness.OutputArea.setText(WRITEME);
  }

   public void BreatheFire()
   {
       String WRITEME = HillsOfDarkness.OutputArea.getText() + "Breathing fire.";
       HillsOfDarkness.OutputArea.setText(WRITEME);
   }

   //Accesor Methods
   public void setCanFly(boolean fly) { CanFly = fly; }
   public boolean getCanFly() { return CanFly; }

   //Private Data Members
   private boolean CanFly;

}
