//AdventureGame 1.0, Java Version, base Events class, C. Germany, July 01, 2006
//File 6 of 7. Save as "Events.java".

import javax.swing.*;
import java.io.*;
import java.util.Random;
import java.awt.*;
import java.applet.*;

public class Events
{
//-----------------------------------------------------------------------------------------
    //Globals to track various game events
    //This replicates the C++ enumerated constant
    public static final int QUIT = 0;
    public static final int SHAMAN = 1;
    public static final int GATE = 2;
    public static final int UNDERGRND = 3;
    public static final int CENTER1 = 4;
    public static final int N1 = 5;
    public static final int S1 = 6;
    public static final int E1 = 7;
    public static final int W1 = 8;
    public static final int N2 = 9;
    public static final int S2 = 10;
    public static final int E2 = 11;
    public static final int W2 = 12;
    public static final int GAMEOVER = 13;
    public static final int INTRO = 14;
    public static final int YOUWIN = 15;
    public static final int GIANTCAMP = 16;
    public static final int GIANTFIGHT = 17;
    public static final int DRAGONFIGHT = 18;
    public static final int PREINTRO = 19;

    public static char FightImage = '#';

    public static int location = 1000;

    static Random RAND = new Random();

    public static boolean W1GiantAlive;
    public static boolean E1DragonAlive;
    public static boolean S2MotleyCrewAlive;
    public static boolean FirstTimeInShamanHut;
    public static boolean CENTERFirstTime;
    public static boolean UNDERDragonPairAlive;
    public static boolean FoundHP_West2;
    public static boolean FoundHP_Shaman;

    public static int ConqueredDragons;
    public static int ConqueredGiants;
    public static boolean NeedName = true;
    public static boolean HiScoresToggle = false;

    public static String WRITEME = "";
    public static Character CurrentPlayer;
    public static Shaman WiseWoman;

    HillsOfDarkness y; //pointer to HOD class

       public Events(HillsOfDarkness x)
       {
           CurrentPlayer = new Character();
           WiseWoman = new Shaman();
           y = x;
       }

//-----------------------------------------------------------------------------------------

public void SwitchBoard()
{
    switch(location)
    {
        case PREINTRO : location = PREINTRO(); break;
        case INTRO : location = Introduction(); break;
        case N1 : location = NORTH1(); break;
        case S1 : location = SOUTH1(); break;
        case E1 : location = EAST1(); break;
        case W1 : location = WEST1(); break;
        case CENTER1 : location = CENTER(); break;
        case N2 : location = NORTH2(); break;
        case S2 : location = SOUTH2(); break;
        case E2 : location = EAST2(); break;
        case W2 : location = WEST2(); break;
        case UNDERGRND : location = UnderGroundPassage(); break;
        case GATE : location = GateWay(); break;
        case SHAMAN : location = SHAMANHUT(); break;
        case DRAGONFIGHT : location = DragonFight(); break;
        case GIANTFIGHT : location = GiantFight(); break;
        case GIANTCAMP : location = GiantCamp(); break;
        case GAMEOVER : location = GameOver(); break;
        case YOUWIN : location = YouWin(); break;
        case QUIT : HillsOfDarkness.Continue = false; break;
        default : HillsOfDarkness.OutputArea.setText(
                  HillsOfDarkness.OutputArea.getText() +
                  "\nNot an option.\n");
                  break;
    }//close switch

    CurrentPlayer.DisplayStats();
    CurrentPlayer.Inventory();
    Conquests();

} //close SwitchBoard()function

//-----------------------------------------------------------------------------------------

       //No method to convert String to boolean in Java as in C++, so let's make our own!
       public boolean TrueOrFalse(String x)
       {
              if(x.equals("true"))  { return true; }
              else { return false; }
       }

//-----------------------------------------------------------------------------------------

       //Uses new Random object declared up top in Globals
       public static int Randy(int x)  { return RAND.nextInt(x) + 1; }

//-----------------------------------------------------------------------------------------
       void InitializeGlobals()
       {
                    WRITEME = "\n Welcome to Hills of Darkness 3.0. You need\n" +
                              " to create a character and select a name. The\n" +
                              " object of this game is to collect enough items\n" +
                              " and gain enough experience to operate the\n" +
                              " dimensional gateway and return home. You\n" +
                              " will also need to find a key to activate this\n" +
                              " mechanism. \n\n" +
                              " You may ask the village shaman for help and\n" +
                              " useful advice on your journey. Type your\n" +
                              " name in the box to the right. Then begin\n" +
                              " the game by pressing the \"GO\" button.\n\n" +
                              " Good Luck!";

            HillsOfDarkness.OutputArea.setText(WRITEME);

            W1GiantAlive = true;
            E1DragonAlive = true;
            S2MotleyCrewAlive = true;
            FirstTimeInShamanHut = true;
            CENTERFirstTime = true;
            UNDERDragonPairAlive = true;
            FoundHP_West2 = false;
            FoundHP_Shaman = false;
            HillsOfDarkness.Started = false;
            ConqueredDragons = 0;
            ConqueredGiants = 0;

            HillsOfDarkness.LOCK = false;
            HillsOfDarkness.Continue = true;
            location = PREINTRO;

            NeedName = true;
            HiScoresToggle = true;
       }

//-----------------------------------------------------------------------------------------------

       public int PREINTRO()
       {
              if(HillsOfDarkness.WhatToDo == 'g')
              {
                   location = INTRO;
                   HillsOfDarkness.LOCK = false;
                   return location;
              }
              else
              {
                   HillsOfDarkness.LOCK = true;
                   String WRITEME = HillsOfDarkness.OutputArea.getText() +
                   "\n\n  Enter \"g\" and click \"GO\" to to make your\n  move...\n\n";
                   HillsOfDarkness.InputField.setText("g");
                   HillsOfDarkness.OutputArea.setText(WRITEME);
                   return location;
               }//close else

       }//close PREINTRO() function

       public int Introduction()
       {
           if(HillsOfDarkness.WhatToDo == 'g')
           {
              location = CENTER1;
              HillsOfDarkness.LOCK = false;
              return location;
           }
           else
           {
               HillsOfDarkness.LOCK = true;
               WRITEME = "\n     Hills of Darkness 3.0\n\n";

               HillsOfDarkness.themeSOUND.play();

               WRITEME = "\n  You awake from what appears to be a\n"
                       + "  disturbing dream, knowing neither where\n"
                       + "  you've been nor how you got where you\n"
                       + "  are now. You slowly rise to your feet,\n"
                       + "  bewildered and almost oblivious to the\n"
                       + "  throbbing ache pulsating between your\n"
                       + "  ringing ears.\n\n"
                       + "  You find yourself standing on a flowing\n"
                       + "  grassy knoll amidst the dark green hills\n"
                       + "  of medieval Scotland. In the skies above,\n"
                       + "  dark gray clouds are passing in billowing\n"
                       + "  random patterns. It appears a storm is\n"
                       + "  approaching from the east. A few black\n"
                       + "  ravens fly over your head towards some\n"
                       + "  unknown destination, a familiar caw,\n"
                       + "  their cries echoing softly against the\n"
                       + "  creeping shadows.";

               WRITEME = WRITEME +  "\n\n"
                       + "  Type \"G\" in the command box and click\n"
                       + "  the \"GO\" button to continue...";

              HillsOfDarkness.InputField.setText("g");
              HillsOfDarkness.OutputArea.setText(WRITEME);

              return location;
           }
       }

//-----------------------------------------------------------------------------------------------

       int CENTER()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 's' ||
              HillsOfDarkness.WhatToDo == 'e' || HillsOfDarkness.WhatToDo == 'w' ||
              HillsOfDarkness.WhatToDo == 't' || HillsOfDarkness.WhatToDo == '~' ||
              HillsOfDarkness.WhatToDo == '!')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 'n' : location = N1; break;
                 case 's' : location = S1; break;
                 case 'e' : location = E1; break;
                 case 'w' : location = W1; break;
                 case 't' : if(CENTERFirstTime == false)
                            { location = GATE; break; }
                            else
                            {
                               WRITEME = WRITEME +
                               "That was an invalid choice.";
                               break;
                            }
                 case '~' : CurrentPlayer.Cheat(); break;
                 case '!' : CurrentPlayer.InitializeInventory(); break;
                 default : WRITEME = WRITEME +
                           "That was an invalid choice."; break;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              return location;
            }//close if

            else
            {
               HillsOfDarkness.LOCK = true;
               HillsOfDarkness.OutputArea.setText("");

               if(CENTERFirstTime)
               {
                  WRITEME = "\n  " + CurrentPlayer.getName()
                  + ", confused, you try\n"
                  + "  to get your bearings. You see nothing but\n"
                  + "  large stone tablets and columns with \n"
                  + "  what appear to be odd and archaic symbols\n"
                  + "  engraved upon them.\n";

                  CENTERFirstTime = false;
               }
               else
               {
                  WRITEME =
                  "\n  You return to the location where you first\n"
                  + "  mysteriously appeared in this strange\n"
                  + "  medieval world. You notice that the\n"
                  + "  large stone tablets and columns have\n"
                  + "  arranged themselves into a gate.\n"
                  + "  The symbols are constantly changing,\n"
                  + "  disappearing and re-appearing at random\n"
                  + "  intervals across the surface of the\n"
                  + "  tablets.\n ";
               }

               WRITEME = WRITEME
               + "\n  You see that you can move to the north,\n"
               + "  south, east or west. To the north, you\n"
               + "  see the ruins of an ancient castle spread\n"
               + "  out across the horizon. To the east, you\n"
               + "  see the lapping waves of the ocean against\n"
               + "  a sandy shore. To the south, you see a \n"
               + "  small village with gray cobblestone houses\n"
               + "  and smoldering chimneys. To the west, you\n"
               + "  see an abandoned farm house.\n";

               WRITEME = WRITEME +
               "\n  Where will you go (n, s, e, w)?"
               + "\n  Or will you (t)ry the gates?";

               //CenterClip.play();
               //HillsOfDarkness.paint(); //Put code for image here.

               HillsOfDarkness.OutputArea.setText(WRITEME);
               location = CENTER1;
               return location;

           }//close else

       }//close CENTER() function

//-----------------------------------------------------------------

       int NORTH1()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' ||
              HillsOfDarkness.WhatToDo == 'e' || HillsOfDarkness.WhatToDo == 'w')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 's' : HillsOfDarkness.LOCK = false; return CENTER1;
                 case 'n' : HillsOfDarkness.LOCK = false; return N2;
                 case 'e' : WRITEME = WRITEME
                            + "\n  You fail to scale the east"
                            + "\n  wall and turn back...\n";
                            break;
                 case 'w' : WRITEME = WRITEME +
                            "\nYou press against hard, cold stone.\n";
                            if(!CurrentPlayer.getChainMail())
                            {
                               WRITEME = WRITEME +
                               "You find a suit of chain mail!\n";
                               CurrentPlayer.setChainMail(true);
                               CurrentPlayer.Inventory();
                            }
                            else
                            { WRITEME = WRITEME +
                            "You already have the chain mail!\n"; }
                            break;
                 default :  break;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;



              WRITEME =
              "\n  You find yourself amidst the ruins of an" +
              "\n  ancient castle. Stones lie strewn every-";

               WRITEME = WRITEME
              + "\n  where. Further to the north, you see the"
              + "\n  delapidated entrance to the abandoned"
              + "\n  castle. It is adjoined by crumbling"
              + "\n  towers, one at each corner of the"
              + "\n  foundation.\n\n  The entrance to the castle"
              + "\n  is a frail wooden door, looking as"
              + "\n  though it had been abandoned for over"
              + "\n  a hundred years. It probably would not"
              + "\n  be too difficult to force the door"
              + "\n  open...\n"
              + "\n  At this point, you may explore the castle"
              + "\n  ruins, or go back to the SOUTH. You are"
              + "\n  surrounded by impassible castle walls to "
              + "\n  the east and the west.\n\n";

              WRITEME = WRITEME + "  Where will you go (n,s,e,w)?\n";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

             HillsOfDarkness.OutputArea.setText(WRITEME);
             location = N1;
             return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int SOUTH1()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w' || HillsOfDarkness.WhatToDo == 'g')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 'n' : HillsOfDarkness.LOCK = false; return CENTER1;
                 case 's' : HillsOfDarkness.LOCK = false; return S2;
                 case 'e' : WRITEME = WRITEME +
                            "\n  You have no right to enter\n"
                            + "  someone else's dwelling!\n\n";
                            break;
                 case 'w' : if(!CurrentPlayer.getSword())
                            {
                               WRITEME = WRITEME
                               + "\n  Bonus!!! Although you can not manage"
                               + "\n  to ascend the gate in front of you,"
                               + "\n  you do find a broad sword at the"
                               + "\n  base of the wall!\n";

                               CurrentPlayer.setSword(true);
                               CurrentPlayer.Inventory();
                            }
                            else
                            {
                                WRITEME = "\n  You already took the sword!\n";
                            }
                            break;
                 case 'g' : HillsOfDarkness.LOCK = false; return SHAMAN;
                 default : WRITEME = WRITEME +
                               "That was an invalid choice.\n"; break;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You stumble into the gates of a rustic"
              + "\n  village. You see what appears to be a"
              + "\n  tavern to the north. Further south, you"
              + "\n  see a winding dirt road that meanders"
              + "\n  towards the horizon. All around you are"
              + "\n  peasants buying and selling wares in an"
              + "\n  open market place. Near the center of"
              + "\n  the village several children are playing,"
              + "\n  and in the midst of them sits an elderly"
              + "\n  woman, looking very wise and thoughtful.\n ";

              WRITEME = WRITEME +
              "\n  At this point, you may only go back to the"
              + "\n  NORTH or further SOUTH, if you so desire."
              + "\n  You are surrounded by what seems"
              + "\n  impassible terrain to the east and the"
              + "\n  west and several cottages.\n"
              + "\n  Towards thecenter of the villiage, you"
              + "\n  notice a small though nicely maintained"
              + "\n  Shaman's lodge with smoke billowing from"
              + "\n  its roof."
              +  "\n\n  Choices: (n,e,s,w)"
              + "\n  (g)o into the Shaman's Hut  \n";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = S1;
              return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int EAST1()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 'w' : HillsOfDarkness.LOCK = false; return CENTER1;
                 case 'n' : if(E1DragonAlive)
                            {
                               WRITEME = WRITEME
                               + "\n  You creep towards the Dragon. Startled, "
                               + "\n  it climbs into the sky to defend itself!\n";
                               Dragon Prometheus = new Dragon();
                               location = Combat(Prometheus, E1);
                               E1DragonAlive = false;
                               //CenterClip.play();
                               //break out of while true, re-invoke EAST1 to display text
                               break;
                             }
                             else
                             {
                                WRITEME = WRITEME
                                + "\n  You see a noble red dragon, tragically"
                                + "\n  and yet recently slain...\n";
                                break;
                             }
                  case 'e' : WRITEME = WRITEME
                             + "\n  You jump into the water. It's "
                             + "\n  freezing. You start swimming.\n";
                             HillsOfDarkness.LOCK = false; return E2;
                  case 's' : WRITEME = WRITEME
                             + "\n  You step on a jellyfish and it "
                             + "\n  stings you with its tentacles!\n";
                             if(CurrentPlayer.getHit() > 1)
                             {
                                CurrentPlayer.setHit((CurrentPlayer.getHit() - 1));
                                CurrentPlayer.DisplayStats();
                             }
                             else
                             {
                                CurrentPlayer.setHit(0);
                                WRITEME = WRITEME
                                + "\n  How pathetic! Slain by a jellyfish!\n";
                                HillsOfDarkness.Continue = false;
                                location = QUIT;
                             }
                             break;
                  default : WRITEME = WRITEME
                            + "\n  That was an invalid choice.\n"; break;
               }
                         HillsOfDarkness.OutputArea.setText(WRITEME);
                         HillsOfDarkness.LOCK = true;
                         return location;
           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You arrive at a sandy shore where green-"
              + "\n  blue translucent waves are crashing"
              + "\n  against rocky outcroppings. Overhead,"
              + "\n  seagulls are gathering, their cries echo"
              + "\n  against an amphitheatre of sand and sea,"
              + "\n  intermingling with the sound of the waves"
              + "\n  as they crash upon the beach.\n\n"
              + "  To the north, ";

              if(E1DragonAlive)
              {
                 WRITEME = WRITEME
                 + "a magnificent red dragon "
                 + "\n  folds its wings, smoke billowing from"
                 + "\n  its nostrils.\n";
              }

              else
              {
                  WRITEME = WRITEME +
                  "a slain dragon is being\n  devoured by ravens...\n\n";
              }

               WRITEME = WRITEME
               + "\n  At this point, you may only go back"
               + "\n  to the WEST. You are surrounded by "
               + "\n  turbulent water and razor sharp rocks "
               + "\n  to the east and the south.\n"
               + "\n  Where will you go (n,s,e,w)?";

               //CenterClip.play();
               //HillsOfDarkness.paint(); //Put code for image here.

               HillsOfDarkness.OutputArea.setText(WRITEME);
               location = E1;
               return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int WEST1()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 'e' : HillsOfDarkness.LOCK = false; return CENTER1;
                 case 'n' : WRITEME = WRITEME
                            + "\n  You are attacked by a vicious chicken!"
                            + "\n  You can not pass.\n";
                            if(!CurrentPlayer.getDagger())
                            {
                               WRITEME = WRITEME +
                               "  But lieing on the ground, "
                               + "you find a\n  bronze dagger!\n";
                               CurrentPlayer.setDagger(true);
                               CurrentPlayer.Inventory();
                            }
                            else
                            {
                                WRITEME = WRITEME +
                                "  You already found the dagger!\n";
                            }
                            break;
                 case 's' : if(W1GiantAlive)
                            {
                               WRITEME = WRITEME +
                               "\n  You walk towards the Giant and\n  he charges you!";
                               HillsOfDarkness.OutputArea.setText(WRITEME);
                               y.refresh();
                               try { Thread.sleep(2500); }
                               catch(Exception e) { }
                               Giant OneGiant = new Giant();
                               location = Combat(OneGiant, W1);
                               //If player survives, make sure they don't fight giant
                               //again by setting the global boolean to false
                               W1GiantAlive = false;
                            }
                            else
                            {
                               WRITEME = WRITEME +
                               "\n  You stumble over the corpse of\n  a dead giant!\n";
                            }
                            break;
                 case 'w' :  HillsOfDarkness.LOCK = false; return W2;
                 default : WRITEME = WRITEME + "\n Invalid choice.\n"; break;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;
           }

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You arrive at an abandoned farm house."
              + "\n  You see a picket fence, a rustic dilapidated"
              + "\n  barn, and a decaying hovel that used to be"
              + "\n  someone's residence. There are chickens"
              + "\n  walking around the premises."
              + "\n\n  To the south, you see ";

               if(W1GiantAlive)
               {
                  WRITEME = WRITEME +
                  "a Giant wearing old,"
                  + "\n  brown sackcloth. He is taunting you with"
                  + "\n  offensive gestures and lewd comments."
                  + "\n\n  You really don't want to tangle with"
                  + "\n  a giant, do you?";
               }

               else
               {
                   WRITEME = WRITEME +
                   "barbed wire, blood,\n  sackcloth and carnage...";
               }

               WRITEME = WRITEME +  "\n\n"
               + "  At this point, you may go NORTH or back"
               + "\n  EAST. You see only thick undergrowth"
               + "\n  and brush to the west.\n"
               + "\n  Where will you go (n,s,e,w)?\n";

               //CenterClip.play();
               //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = W1;
              return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int NORTH2()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w' || HillsOfDarkness.WhatToDo == 'g')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                case 's' : HillsOfDarkness.LOCK = false; return N1;
                case 'n' : WRITEME = WRITEME +
                           "\n  The tapestries look very dry and dusty.\n";
                           break;
                case 'e' : WRITEME = WRITEME +
                           "\n  You approach the box and cautiously open it...\n";
                           if(!CurrentPlayer.getFullBodyArmor())
                           {
                              WRITEME = WRITEME
                              + "\n  You find a well preserved suit of full"
                              + "\n  body armor!\n";
                              CurrentPlayer.setFullBodyArmor(true);
                              CurrentPlayer.Inventory();
                           }
                           else
                           {
                               WRITEME = WRITEME
                               + "\n  The box is empty - you already took"
                               + "\n  the armor.\n";
                           }
                           break;
                case 'w' : WRITEME = WRITEME
                           + "\n  You press against the wall but "
                           + "\n  find nothing.\n";
                           break;
                case 'g' : HillsOfDarkness.LOCK = false; return UNDERGRND;
                default : WRITEME = WRITEME + "\n  That was an invalid choice.\n";
                          break;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You walk inside the castle. It is dark"
              + "\n  and musty, but enough daylight is "
              + "\n  leaking through the cracks in between "
              + "\n  stones and mortar that you can ascertain"
              + "\n  your surroundings in a dim, colorless"
              + "\n  twilight. Against the wall to the east "
              + "\n  you see a long wooden box, about the size"
              + "\n  of a coffin. You can see a table, chairs"
              + "\n  and several candle stands to the west "
              + "\n  of the room.\n\n"
              + "  To the north and the south the walls are "
              + "\n  adorned with dusty, thread-bare tapestries.\n\n"
              + "  You notice stairs descending deep"
              + "\n  underground to some unknown passage to"
              + "\n  your right."
              + "\n\n  Choices: (n,s,e,w) or (g)o underground:";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = N2;
              return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int SOUTH2()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 's' : HillsOfDarkness.LOCK = false; return GIANTCAMP;
                 case 'n' : HillsOfDarkness.LOCK = false; return S1;
                 case 'e' : WRITEME = WRITEME
                            + "\n  You see a lake, covered with lily pads"
                            + "\n  and algae.\n";
                            break;
                 case 'w' : WRITEME = WRITEME
                            + "\n  You see cat tails and dragon flies"
                            + "\n  skimming across the water.\n"; break;
                 default : WRITEME = WRITEME
                           + "\n That was an invalid choice.\n"; break;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You wander through the village further to"
              + "\n  the south. You notice several of the villagers"
              + "\n  are staring at you strangely as you walk by."
              + "\n\n  You come to the southern gate that guards"
              + "\n  the entrance to the village and pass through"
              + "\n  its open doors. You follow a  meandering dirt"
              + "\n  path towards the edge of a dense hardwood"
              + "\n  forest. \n\n  As you walk along the road, you pass"
              + "\n  several merchants hauling their wares by"
              + "\n  horse and cart. ";

              if(S2MotleyCrewAlive)
              {
                  WRITEME = WRITEME
                  + "\n\n  Continuing south, you see a group of"
                  + "\n  three giants resting with their backs"
                  + "\n  against the trees.\n";
              }

              else
              {
                  WRITEME = WRITEME
                  + "\n  Looking south, you see the destruction"
                  + "\n  and carnage of your bloody victory over the"
                  + "\n  giants. Quickened by the smell of carrion,"
                  + "\n  vultures circle overhead...\n";
              }

              WRITEME = WRITEME +  "\n  Where will you go (n,s,e,w)?";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = S2;
              return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int EAST2()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 's' : WRITEME = WRITEME +
                            "\n  You see dolphins and sharks.\n";
                            if(!CurrentPlayer.getFishKey())
                            {
                              WRITEME = WRITEME
                              + "\n  You notice something metalic shining in"
                              + "\n  the sand beneath your feet. You dig into"
                              + "\n  the sand and find a bronze key with a"
                              + "\n  Fish symbol engraved upon it.\n\n";
                              CurrentPlayer.setFishKey(true);
                            }
                            else
                            {
                               WRITEME = WRITEME +
                               "\n  Hey, this is the same place"
                               + "\n  you found that Fish key!\n";
                            }
                            break;
                 case 'n' : WRITEME = WRITEME +
                            "\n  You see dolphins and sharks.\n"; break;
                 case 'e' : WRITEME = WRITEME +
                            "\n  You see dolphins and sharks.\n"; break;
                 case 'w' : HillsOfDarkness.LOCK = false; return E1;
                 default : WRITEME = WRITEME +
                           "\n  That was an invalid choice.\n"; break;
              }//close switch

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//end if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You swim out to the sand bars hundreds "
              + "\n  of feet beyond the shore. Treading water"
              + "\n  until you are almost exhausted, you"
              + "\n  notice that the water is growing more"
              + "\n  and more shallow until at last, gasping"
              + "\n  for breath, you find that your feet can"
              + "\n  touch the bottom.\n"
              + "\n  You continue advancing  up a steep"
              + "\n  slope, this time walking instead of"
              + "\n  swimming, until the water is only"
              + "\n  ankle deep. You gather your thoughts"
              + "\n  together and take in your surroundings."
              + "\n  In every direction, you see dolphins"
              + "\n  and sharks swimming around you.\n"
              + "\n  Where will you go (n,s,e,w)?";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = E2;
              return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int WEST2()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 's' || HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'e' ||
              HillsOfDarkness.WhatToDo == 'w')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();

              switch(HillsOfDarkness.WhatToDo)
              {
                 case 's' : WRITEME = WRITEME +  "\n  You see... WHEAT!\n";
                            if(!FoundHP_West2)
                            {
                               WRITEME = WRITEME +
                               "\n\n  Buried under a mound among the wheat,"
                               + "\n  you find a healing potion!\n";
                               CurrentPlayer.setHealingPotion(1);
                               FoundHP_West2 = true;
                               CurrentPlayer.Inventory();
                            }
                            else
                            {
                                WRITEME = WRITEME +
                                "\n  You already found the healing potion!\n";
                            }
                            break;
                 case 'n' : if(!CurrentPlayer.getLongBow())
                             {
                                WRITEME = WRITEME +
                                "\n  You find a well-strung long bow and arrows!\n";
                                CurrentPlayer.setLongBow(true);
                                CurrentPlayer.Inventory();
                             }
                             else
                             {
                                 WRITEME = WRITEME +
                                 "\n  You already found the long bow.\n";
                             }
                             break;
                 case 'e' : HillsOfDarkness.LOCK = false; return W1;
                 case 'w' : WRITEME = WRITEME +
                            "\n  You see various feed crops planted in rows.\n";
                            break;
                 default : WRITEME = WRITEME +
                           "\n  That was an invalid choice.\n";
                           break;
              }//close switch

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n  You find yourself walking in golden fields"
              + "\n  of billowing wheat. The wind is blowing"
              + "\n  briskly through the long, tall stalks as"
              + "\n  they rustle in the autumn air. Particles"
              + "\n  of chaff float through the air all around"
              + "\n  you and collect upon your clothing.\n\n"
              + "  Where will you go (n,s,e,w)?";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = W2;
              return location;

           }//close else

       }//close function
//-----------------------------------------------------------------

       int SHAMANHUT()
       {
           y.refresh();
           if(HillsOfDarkness.WhatToDo == 'n' || HillsOfDarkness.WhatToDo == 'l' || HillsOfDarkness.WhatToDo == 's' ||
              HillsOfDarkness.WhatToDo == 't')
           {
              WRITEME = HillsOfDarkness.OutputArea.getText();
              switch(HillsOfDarkness.WhatToDo)
              {
                 case 'n' : WRITEME = WRITEME +
                            "\n  You run into a straw-mud wall.\n"; break;
                 case 'l' : HillsOfDarkness.LOCK = false; return S1;
                 case 's' :
                            LockButtons(true);
                            HillsOfDarkness.HealButton.setEnabled(false);
                            HillsOfDarkness.themeSOUND.stop();
                            WRITEME =
                            "\n  You get the uneasy feeling that you"
                            + "\n  are going to reap serious bad karma for"
                            + "\n  this unwise action.\n";
                            HillsOfDarkness.OutputArea.setText(WRITEME);
                            //What would be a simple call in the MFC is more complex in Java.
                            //The screen must be repainted or text will not display  thread
                            //sleeps. However, the paint and getGraphics() methods can not be
                            //made static, so the applet class must be passed into this class's
                            //constructor as an argument at which point you can call refresh().
                            y.refresh();
                            try { Thread.sleep(5000); }
                            catch(Exception e) { }
                            WRITEME = WRITEME +
                            "\n  Bellowing thunder cracks and the clouds"
                            + "\n  darken the skies outside as the deity"
                            + "\n  of the temple preistess fills with"
                            + "\n  indignation and anger!\n";
                            HillsOfDarkness.OutputArea.setText(WRITEME);
                            HillsOfDarkness.thunderSOUND.play();
                            y.refresh();
                            try { Thread.sleep(6000); }
                            catch(Exception e) { }
                            WRITEME = WRITEME
                            + "\n  In an instant, lightning from the heavens"
                            + "\n  strikes you down! All that remains of you"
                            + "\n  are burning embers...\n";
                            //ThunderClip.play();
                            HillsOfDarkness.OutputArea.setText(WRITEME);
                            CurrentPlayer.setHit(0);
                            CurrentPlayer.DisplayStats();
                            y.refresh();
                            try { Thread.sleep(6000); }
                            catch(Exception e) { }
                            WRITEME = WRITEME +
                            "\n  You go into the afterlife a loser, ashamed"
                            + "\n  for the despicable deeds you have done."
                            + "\n  The warriors who have gone on before you,"
                            + "\n  the great warriors of reknown and the kings"
                            + "\n  of the past will ridicule you for all of"
                            + "\n  eternity for dieing without honor.\n"
                            + "\n  Enter \"G\" and click \"GO\" to continue.\n";
                            HillsOfDarkness.OutputArea.setText(WRITEME);
                            HillsOfDarkness.InputField.setText("g");
                            y.refresh();
                            try { Thread.sleep(10000); }
                            catch(Exception e) { }
                            LockButtons(false);
                            location = GAMEOVER;
                            break;
                 case 't' : WRITEME = WRITEME +
                            "\n  You seek audience with the preistess.\n";
                            WiseWoman.Talk();
                            WRITEME = HillsOfDarkness.OutputArea.getText() +
                            "\n\n  You may: (l)eave (t)alk or (s)teal things";
                            break;
                 default : WRITEME = WRITEME +
                           "\n  That was an invalid choice.\n"; break;
              }//close switch

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = true;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              if(FirstTimeInShamanHut)
              {
                 WRITEME =
                   "\n  You duck down and enter into the Shaman's"
                 + "\n  hut. Towards the center of the mud dwelling,"
                 + "\n  beneath an overhanging shelf descending "
                 + "\n  from the thatched roof, sits an elderly "
                 + "\n  priestess. Unphased by your presence, she"
                 + "\n  continues to stare into the flames of a"
                 + "\n  small fire burning within  a set of "
                 + "\n  blackened stone rings in the center of"
                 + "\n  the hut.\n\n  Directly over her head, an opening"
                 + "\n  in the ceiling allows the smoke to escape."
                 + "\n  She gazes at you and cackles. \"Not expecting"
                 + "\n  an old temple preistess, were you, a woman,"
                 + "\n  eh? Well, in this village, I'm the \"Shaman\".\n";

                 FirstTimeInShamanHut = false;
              }

              else
              {
                 WRITEME =
                 "\n  You re-enter the Shaman's hut. She turns her"
                 + "\n  head in a peculiar fashion and remarks, \"Back"
                 + "\n  so soon, traveler?\" She offers you a cup "
                 + "\n  of freshly brewed tea, which you gladly"
                 + "\n  accept to quench your thirst. ";

                 if(!FoundHP_Shaman)
                 {
                    WRITEME = WRITEME +
                    "\n\n  She opens her medicine bag and begins"
                    + "\n  creating an acrid mixture of herbs. She"
                    + "\n  pours it into a vial and places it in "
                    + "\n  your hand, saying \"Drink this if you "
                    + "\n  become wounded, my friend. It may restore "
                    + "\n  you to a measure of your former health"
                    + "\n  and constitution.\"\n";
                    CurrentPlayer.setHealingPotion(1);
                    FoundHP_Shaman = true;
                    CurrentPlayer.Inventory();
                 }

                 else
                 {
                    WRITEME = WRITEME +
                    "\n  You feel a sense of debt and gratitude"
                    + "\n  towards this kind old woman,"
                    + "\n  remembering the healing elixir she"
                    + "\n  gave you on your last visit.\n";
                 }
              }//close else

              WRITEME = WRITEME +
              "\n  At this point, you may (l)eave the "
              + "\n  Shaman's hut, (t)alk with her if you so"
              + "\n  desire, or try to (s)teal her medicine"
              + "\n  bag and staff for what wonders they may"
              + "\n  contain.\n"
              + "\n  You may: (l)eave (t)alk or (s)teal things";

              //CenterClip.play();
              //HillsOfDarkness.paint(); //Put code for image here.

              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = SHAMAN;
              return location;

           }//close else

       }//close function

//-----------------------------------------------------------------

       int GateWay()
       {
           String WRITEME = "";
           if(HillsOfDarkness.WhatToDo == 'g')
           {
              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              return CENTER1;
           }//end if

           else
           {
              HillsOfDarkness.LOCK = true;

              if(CurrentPlayer.getFishKey() == true)
              {
                 WRITEME =
                 "\n\n  Fumbling around the gate, you find a"
                 + "\n  slot to insert the Fish key. The tablets "
                 + "\n  and columns begin to rumble and shake."
                 + "\n  Large stones rise, levitating off the"
                 + "\n  ground, rearranging themselves.\n";
              }

              else
              {
                WRITEME =
                  "\n  You look around, trying every nook and"
                + "\n  crevice, but can not seem to find the"
                + "\n  means to open the gate, nor alter"
                + "\n  anything else around it. You see what"
                + "\n  appears to be a key hole to one side. \n";

              }

              if(CurrentPlayer.getFishKey() && CurrentPlayer.getScore() < 50)
              {
                 WRITEME = WRITEME +
                 "\n  It appears that, although you have the"
                 + "\n  key, you lack enough experience with the"
                 + "\n  ways of this world to cause the gate to "
                 + "\n  function in any useful manner.\n";
              }

              if(CurrentPlayer.getFishKey() && CurrentPlayer.getScore() >= 50)
              {
                WRITEME = WRITEME
                + "\n  With the experience you have gained since"
                + "\n  entering this strange world, you manage to"
                + "\n  figure out the correct sequence of actions"
                + "\n  to perform while turning the Fish key within"
                + "\n  the gate. You hear a loud hiss followed by a"
                + "\n  dull hum as cascading beams of light blind you"
                + "\n  from the opening dimensional portal.\n\n"
                + "\n  You feel as though you have won a series of"
                + "\n  battles in a long campaign, but that the war"
                + "\n  is far from being over. Having made several new"
                + "\n  friends and vanquished many foes as a soujourner"
                + "\n  in a strange land, you step through the gates, "
                + "\n  uncertain yet hopeful that this may bring you"
                + "\n  one step closer to home...";

                WRITEME = WRITEME +
                "\n  You win this campaign and end the game with:\n\n";
                CurrentPlayer.DisplayStats();
                CurrentPlayer.Inventory();
                WRITEME = WRITEME +
                "\n  Combat Experience Score: " + CurrentPlayer.getScore()
                + ".\n\n";

                HillsOfDarkness.LOCK = false; return YOUWIN;
             }

             WRITEME = WRITEME +
             "\n\n  Type \"G\" and click \"GO\" to continue...\n\n";

             HillsOfDarkness.InputField.setText("g");
             HillsOfDarkness.OutputArea.setText(WRITEME);
             return location;

         }//end else

       }//end function

//-----------------------------------------------------------------

       int UnderGroundPassage()
       {
           if(HillsOfDarkness.WhatToDo == 'r' || HillsOfDarkness.WhatToDo == 'l')
           {
               if(HillsOfDarkness.WhatToDo == 'l') { location = DRAGONFIGHT; }
               if(HillsOfDarkness.WhatToDo == 'r') { location = N2; }
               HillsOfDarkness.OutputArea.setText(WRITEME);
               HillsOfDarkness.LOCK = false;
               return location;
           }//end if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
              "\n\n  You descend into the darkness underground.\n\n";

              if(UNDERDragonPairAlive)
              {
                WRITEME = WRITEME +
                "\n  Peeking around a corner, you see a large\n  subterranean cavern.";
                WRITEME = WRITEME +
                "\n  Scattered around its rocky walls are piles\n  of bones from "
                + "both animals and men.\n";

                WRITEME = WRITEME +
                "\n\n  Do you want to (r)eturn to the castle above"
                + "\n  or (l)ook for what created this macabre chamber\n  of remains?\n\n";
              }

              else
              {
                 WRITEME = WRITEME +
                   "\n  You see a family of dead red dragons and the"
                 + "\n  carnal aftermath of your last great battle"
                 + "\n  with these fierce and worthy opponents."
                 + "\n\n  Enter \"r\" and click \"GO\" to"
                 + "\n  return up the stairs to the castle.";
                 HillsOfDarkness.InputField.setText("r");
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              return location;

           }//close else

       }//close function

//-------------------------------------------------------------------------

       int DragonFight()
       {
           if(HillsOfDarkness.WhatToDo == 'y' || HillsOfDarkness.WhatToDo == 'n')
           {
             if(HillsOfDarkness.WhatToDo == 'y')
             {
                 Dragon[] DragonFamily = new Dragon[5];

                 for(int x = 0; x < 5; x++)
                 {
                     WRITEME = WRITEME +
                     "\n  Dragon " + x+1 + " of 5 attacks you!";
                     DragonFamily[x] = new Dragon();
                     HillsOfDarkness.OutputArea.setText(WRITEME);
                     location = Combat(DragonFamily[x], UNDERGRND);
                     try { Thread.sleep(3000);}
                     catch(Exception e) { }
                 }

                 WRITEME = WRITEME +
                 "\n\n  Type \"G\" and click \"GO\" to continue.\n\n";
                 HillsOfDarkness.InputField.setText("g");
                 HillsOfDarkness.OutputArea.setText(WRITEME);
                 //ThemeClip.play();
                 UNDERDragonPairAlive = false;

             }//close if y

             else
             {
                 WRITEME = WRITEME +
                 "\n  Intelligently, you decide to run back up the\n  stairs...\n";
                 location = N2;
             }

             HillsOfDarkness.OutputArea.setText(WRITEME);
             HillsOfDarkness.LOCK = false;
             return location;

        }//close if y or n

        else
        {
             HillsOfDarkness.LOCK = true;
             WRITEME = WRITEME +
               "\n  You see a family of 5 dragons. Stop and think"
             + "\n  about this a minute. Are you sure you want to"
             + "\n  take on 5 dragons simultaneously? (y,n)";
             HillsOfDarkness.OutputArea.setText(WRITEME);
             return location;

         }//close else

    }//close function

//-------------------------------------------------------------------------

       int GiantFight()
       {
           if(HillsOfDarkness.WhatToDo == 'y' || HillsOfDarkness.WhatToDo == 'n')
           {
              if(HillsOfDarkness.WhatToDo == 'y')
              {
                 WRITEME = "\n  All three giants charge you at once!\n\n";
                 Giant[] MotleyCrew = new Giant[3];

                 for(int x = 0; x < 3; x++)
                 {
                     WRITEME = WRITEME +
                     "\n  Giant " + x+1 + " of 3 attacks you!";
                     MotleyCrew[x] = new Giant();
                     HillsOfDarkness.OutputArea.setText(WRITEME);
                     location = Combat(MotleyCrew[x], UNDERGRND);
                     try { Thread.sleep(3000);}
                     catch(Exception e) { }
                 }

                 S2MotleyCrewAlive = false;

                 WRITEME = WRITEME +
                 "\n\n  Type \"G\" and click \"GO\" to continue.\n\n";
                 HillsOfDarkness.InputField.setText("g");
                 HillsOfDarkness.OutputArea.setText(WRITEME);
                 //ThemeClip.play();
              }

              else
              {
                 WRITEME = WRITEME +
                 "\n  Intelligently, you decide to walk away.\n";
                 location = S2;
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              return location;

           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;
              WRITEME = WRITEME
              + "\n  Stop and think a moment. Are you really"
              + "\n  prepared to fight 3 giants at the same"
              + "\n  time? (y,n)";
              HillsOfDarkness.OutputArea.setText(WRITEME);
              return location;
           }

       }//close function

//-------------------------------------------------------------------------

       int GiantCamp()
       {
           if(HillsOfDarkness.WhatToDo == 'r' || HillsOfDarkness.WhatToDo == 'l')
           {
              if(HillsOfDarkness.WhatToDo == 'l' && S2MotleyCrewAlive)
              { location = GIANTFIGHT; }
              if(HillsOfDarkness.WhatToDo == 'r') { location = S2; }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              return location;
           }//end if

           else
           {
              HillsOfDarkness.LOCK = true;
              location = GIANTCAMP;

              WRITEME = "\n  You approach the giant's camp at"
                      + "\n  the edge of the forest.\n\n";

              if(S2MotleyCrewAlive)
              {
                WRITEME = WRITEME
                + "\n  Through a clearing among the trees,"
                + "\n  you see 3 giants dining upon what"
                + "\n  can only be human remains.\n";
              }
              else
              {
                 WRITEME = WRITEME +
                 "\n  You stumble over the corpses of three\n  dead giants.\n";
              }

              if(S2MotleyCrewAlive)
              {
                 WRITEME = WRITEME +
                 "\n\n  Do you want to (r)eturn to the forest edge"
                 + "\n   or (l)ook for giants?\n\n";
              }
              else
              {
                  WRITEME = WRITEME +
                  "\n\n  Type \"r\" and click \"GO\" or click"
                  + "\n  on any direction button (N, S, E, W) to RETURN."
                  + "\n\n  There is nothing here but death!\n\n";

                  HillsOfDarkness.InputField.setText("r");
              }

              HillsOfDarkness.OutputArea.setText(WRITEME);
              return location;

           }//close else

       }//close function

//----------------------------------------------------------------------

     int GameOver()
       {
           if(HillsOfDarkness.WhatToDo == 'g')
           {
              HillsOfDarkness.Started = false;
              HillsOfDarkness.StartButton.setVisible(true);
              HillsOfDarkness.OutputArea.setText("\n  Game Over");
              HillsOfDarkness.mighty3SOUND.play();
              HillsOfDarkness.LOCK = false;
              HillsOfDarkness.Continue = false;
              return location;
           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;
              HillsOfDarkness.GoButton.setVisible(true);

              String WRITEME =
              "\n  Game Over...\n\nEnter \"g\" and then click \"GO\"."
              + "\n\nYou may then press \"QUIT\" to exit the"
              + "\n  game or \"START\" to begin a new game.";

              //ThemeClip.play();

              HillsOfDarkness.InputField.setText("g");
              HillsOfDarkness.bowSOUND.play();
              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = GAMEOVER;
              return location;

           }//close else

       }//close function

//----------------------------------------------------------------------
//Overloaded Combat Functions, one for Dragon and one for Giant.
//Takes the global enumerated constant "EVENTS" as one of its arguments.
//----------------------------------------------------------------------
       int Combat(Dragon m, int location)
       {
           FightImage = 'd';
           y.refresh();
           HillsOfDarkness.LOCK = true;
           LockButtons(true);
           HillsOfDarkness.themeSOUND.stop();
           WRITEME = "\n\n  Mortal Combat!!!\n";
           HillsOfDarkness.OutputArea.setText(WRITEME);
           y.refresh();
           try { Thread.sleep(3000); }
           catch(Exception e) { }

           //Note: Thread.sleep is similar to C++ in that is pauses
           //program. However, in Java, unlike C++ version, player
           //will have to choose weapon BEFORE combat and can not
           //change weapons until after combat.
           while(CurrentPlayer.getHit() > 0 && m.getHit() > 0)
           {

               if(CurrentPlayer.getHit() > 0)
               {
                  HillsOfDarkness.OutputArea.setText("");
                  CurrentPlayer.Attack(m);
                  y.refresh();
                  try { Thread.sleep(4000); }
                  catch(Exception e) { }

               }

               if(m.getHit() > 0)
               {
                  HillsOfDarkness.OutputArea.setText("");
                  m.Attack(CurrentPlayer);
                  y.refresh();
                  try { Thread.sleep(4500); }
                  catch(Exception e) { }
               }

           }

           //In C++ version, you would update label after every attack.
           //Java Applet is too slow in repainting, so update here only once.
           CurrentPlayer.DisplayStats();

           if(CurrentPlayer.getHit() <= 0)
           {
                 WRITEME = WRITEME +
                   "\n\n  You die, most tragically!"
                 + "\n  The Dragon wins the battle, having\n"
                 + m.getHit() + " hitpoints left.\n";
                 HillsOfDarkness.OutputArea.setText(WRITEME);
                 HillsOfDarkness.LOCK = false;
                 LockButtons(false);
                 y.refresh();
                 try { Thread.sleep(3000); }
                 catch(Exception e) { }
                 return GAMEOVER;
           }

           else
           {
              WRITEME = WRITEME +
              "\n  You vanquish your foe most valiantly!"
              + "\n  The Dragon died, now having " + m.getHit()
              + "\n  hitpoints.\n\n  " + CurrentPlayer.getName() + " has "
              + CurrentPlayer.getHit() + " hitpoints left.\n";

              //Every three opponents, increase player's attack and defense for experience
              if( (ConqueredGiants + ConqueredDragons) == 3 ||
              (ConqueredGiants + ConqueredDragons) == 6 ||
              (ConqueredGiants + ConqueredDragons) == 9 ||
              (ConqueredGiants + ConqueredDragons) == 11)
              {
                 WRITEME = WRITEME +
                   "\n  Add 1 to your attack and 1 to your defense"
                 + "\n  as a result of combat experience acquired"
                 + "\n  defeating your last three opponents.\n";

                 CurrentPlayer.setAttack((CurrentPlayer.getAttack() + 1));
                 CurrentPlayer.setDefense((CurrentPlayer.getDefense() + 1));
              }

              CurrentPlayer.setScore((CurrentPlayer.getScore() + 10));

              WRITEME = WRITEME +
              "  " + CurrentPlayer.getName() + "'s Current Score: "
              + CurrentPlayer.getScore() + ".\n";

              WRITEME = WRITEME
                      + "\n\n  Enter \"G\" and click \"GO\" to continue.";

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              CurrentPlayer.DisplayStats();
              ConqueredDragons++;
              Conquests();
              LockButtons(false);
              FightImage = '#';
              HillsOfDarkness.themeSOUND.play();
              return location;
           }//close else

       }//close function

//-----------------------------------------------------------------

       int Combat(Giant m, int location)
       {
           FightImage = 'g';
           y.refresh();

           HillsOfDarkness.LOCK = true;
           LockButtons(true);
           HillsOfDarkness.themeSOUND.stop();
           WRITEME = "\n\n  Mortal Combat!!!\n";
           HillsOfDarkness.OutputArea.setText(WRITEME);
           y.refresh();
           try { Thread.sleep(3000); }
           catch(Exception e) { }

           //HillsOfDarkness.paint(); //Put code for image here.

           while(CurrentPlayer.getHit() > 0 && m.getHit() > 0)
           {

               if(CurrentPlayer.getHit() > 0)
               {
                  HillsOfDarkness.OutputArea.setText("");
                  CurrentPlayer.Attack(m);
                  y.refresh();
                  try { Thread.sleep(4000); }
                  catch(Exception e) { }
               }

               if(m.getHit() > 0)
               {
                  //CenterClip.play();
                  HillsOfDarkness.OutputArea.setText("");
                  m.Attack(CurrentPlayer);
                  y.refresh();
                  try { Thread.sleep(4500); }
                  catch(Exception e) { }
               }
           }

           //In C++ version, you would update label after every attack.
           //Java Applet is too slow in repainting, so update here only once.
           CurrentPlayer.DisplayStats();

           if(CurrentPlayer.getHit() <= 0)
           {
                 WRITEME = WRITEME +
                   "\n\n  You die, most tragically!"
                 + "\n  The Giant wins the battle, having\n"
                 + m.getHit() + " hitpoints left.\n";
                 HillsOfDarkness.OutputArea.setText(WRITEME);
                 HillsOfDarkness.LOCK = false;
                 LockButtons(false);
                 y.refresh();
                 try { Thread.sleep(3000); }
                 catch(Exception e) { }
                 return GAMEOVER;
           }

           else
           {
              WRITEME = WRITEME +
              "\n  You vanquish your foe most valiantly!"
              + "\n  The Giant died, now having " + m.getHit()
              + "\n  hitpoints.\n\n  " + CurrentPlayer.getName() + " has "
              + CurrentPlayer.getHit() + " hitpoints left.\n";

              //Every three opponents, increase player's attack and defense for experience
              if( (ConqueredGiants + ConqueredDragons) == 3 ||
              (ConqueredGiants + ConqueredDragons) == 6 ||
              (ConqueredGiants + ConqueredDragons) == 9 ||
              (ConqueredGiants + ConqueredDragons) == 11)
              {
                 WRITEME = WRITEME +
                   "\n  Add 1 to your attack and 1 to your defense"
                 + "\n  as a result of combat experience acquired"
                 + "\n  defeating your last three opponents.\n";

                 CurrentPlayer.setAttack((CurrentPlayer.getAttack() + 1));
                 CurrentPlayer.setDefense((CurrentPlayer.getDefense() + 1));
              }

              CurrentPlayer.setScore((CurrentPlayer.getScore() + 10));

              WRITEME = WRITEME +
              "  " + CurrentPlayer.getName() + "'s Current Score: "
              + CurrentPlayer.getScore() + ".\n";

              WRITEME = WRITEME
                      + "\n\n  Enter \"G\" and click \"GO\" to continue.";

              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              CurrentPlayer.DisplayStats();
              ConqueredGiants++;
              Conquests();
              LockButtons(false);
              FightImage = '#';
              HillsOfDarkness.themeSOUND.play();
              return location;
           }//close else
       }//close function
//-----------------------------------------------------------------------------
       public static void Conquests()
       {
            String WRITEME = ""; //must be different form global WRITEME!
            if(ConqueredGiants == 0 && ConqueredDragons == 0)
            {
               WRITEME =
               " You're special! You\n" +
               " have not yet fought\n" +
               " anything at all.\n" +
               " Beware!!!\n\n" +
               " Treacherous paths\n" +
               " unwind before you.\n\n";
            }

            if(ConqueredGiants > 0)
            {
                if(ConqueredGiants == 1)
                {
                    WRITEME = WRITEME +
                    " You have defeated a\n" +
                    " single, lone Giant.\n";
                }
                else
                {
                    WRITEME = WRITEME + " You have defeated " +
                    ConqueredGiants + "\n Giants in battle!\n";
                }
            }


            if(ConqueredDragons > 0)
            {
                if(ConqueredDragons == 1)
                {
                   WRITEME = WRITEME +
                   " You have defeated a\n single, lone Dragon.\n";
                }
                else
                {
                   WRITEME = WRITEME +
                   " You have defeated " + ConqueredDragons
                   + "\n Dragons in battle!\n";
                }
            }

           if(ConqueredDragons == 0)
           {
              WRITEME = WRITEME +
              "\n You have not battled\n any Dragons yet.\n";
           }


           if(ConqueredGiants == 0)
           {
              WRITEME = WRITEME +
              "\n You have not battled\n any Giants yet.\n";
           }

           HillsOfDarkness.ConquestsArea.setText(WRITEME);
           //Scroll TextArea to top
           HillsOfDarkness.ConquestsArea.setCaretPosition(0);

       }//close function
//-------------------------------------------------------------------------

       int YouWin()
       {
           if(HillsOfDarkness.WhatToDo == 'g')
           {
              location = QUIT;
              HillsOfDarkness.OutputArea.setText(WRITEME);
              HillsOfDarkness.LOCK = false;
              return location;
           }//close if

           else
           {
              HillsOfDarkness.LOCK = true;

              WRITEME =
                "\n\n  Good fortune is yours this day, and"
              + "\n  over fallen foes, victorious, you stand "
              + "\n  triumphant!\n"
              + "\n  You have fought well and finished the\n"
              + " game!\n"
              + "\n  Enter \"g\" and click \"GO\"\n"
              + "\n  or click \"QUIT\" to exit the program.";

              //ThemeClip.play();
              HillsOfDarkness.OutputArea.setText(WRITEME);
              location = YOUWIN;

              return location;

         }//close else

       }//close function

//----------------------------------------------------------------------

       void LockButtons(boolean x)
       {
            //Safety lock all command buttons during combat except
            //for the radio buttons being used in combat
            if(x == true)
            {
                HillsOfDarkness.NorthButton.setEnabled(false);
                HillsOfDarkness.SouthButton.setEnabled(false);
                HillsOfDarkness.EastButton.setEnabled(false);
                HillsOfDarkness.WestButton.setEnabled(false);
                HillsOfDarkness.ScoresButton.setEnabled(false);
                HillsOfDarkness.SaveButton.setEnabled(false);
                HillsOfDarkness.LoadButton.setEnabled(false);
                HillsOfDarkness.StartButton.setEnabled(false);
                HillsOfDarkness.GoButton.setEnabled(false);
                HillsOfDarkness.ActionButton.setEnabled(false);
            }

            else
            {
                HillsOfDarkness.NorthButton.setEnabled(true);
                HillsOfDarkness.SouthButton.setEnabled(true);
                HillsOfDarkness.EastButton.setEnabled(true);
                HillsOfDarkness.WestButton.setEnabled(true);
                HillsOfDarkness.ScoresButton.setEnabled(true);
                HillsOfDarkness.SaveButton.setEnabled(true);
                HillsOfDarkness.LoadButton.setEnabled(true);
                HillsOfDarkness.StartButton.setEnabled(true);
                HillsOfDarkness.GoButton.setEnabled(true);
                HillsOfDarkness.ActionButton.setEnabled(true);
                HillsOfDarkness.HealButton.setEnabled(true);
            }
       }
//----------------------------------------------------------------------
       //Note: Concerning the Following 4 Functions:
       //DisplayHighScores(), SaveHighScores(), SaveCharacter(), LoadCharacter()
       //Although the following 4 will compile, Java will not allow an
       //applet to save or write files to the client for obvious security
       //reasons.A hacker could destroy your file system with an applet is this
       //were possible. This would not work unless you compile the project as
       //a standalone JFrame program, NOT an applet. Capiche?

              //Function - SaveHighScores
              public static boolean SaveHighScores()
              {
                   boolean successful = false;

                   try
                   {
                       File scores = new File("highscores.txt");
                       FileOutputStream highscores;

                       if (scores.exists())
                       {
                           HillsOfDarkness.OutputArea.setText(
                           "\thighscores.txt already exists -- appending new score to it.");
                           //"true" = append, 2 arguments
                           highscores = new FileOutputStream(scores, true);
                       }

                       else
                       {
                           HillsOfDarkness.OutputArea.setText(
                           "\thighscores.txt does not exist -- I'll create it!");
                           highscores = new FileOutputStream(scores); //no append, 1 argument
                       }

                       PrintStream hiscores = new PrintStream(highscores);
                       hiscores.println(CurrentPlayer.getName());
                       hiscores.println(CurrentPlayer.getScore());
                       hiscores.close(); highscores.close();
                       successful = true;
                   }
                   catch (IOException e)
                   {
                       HillsOfDarkness.OutputArea.setText("ERROR saving scores.");
                       successful = false;
                   }

                   return successful;
              }  //close SaveHighScores() function

//-------------------------------------------------------------------------

              // Function - DisplayHighScores
              public static void DisplayHighScores()
              {
                      WRITEME = "\n\n";
                      boolean successful = false;

                      String HoldMeStringName = "";
                      String HoldMeStringInteger = "";
                      int HoldMeInteger = 0;
                      int z = 0;
                      int x = 0;

                      try
                      {
                          File scores = new File("highscores.txt");
                          FileInputStream highscores = new FileInputStream(scores);
                          InputStreamReader hiscores = new InputStreamReader(highscores);
                          BufferedReader SCORES = new BufferedReader(hiscores);

                          while(HoldMeStringName != null)
                          {
                              HoldMeStringName = SCORES.readLine();
                              HoldMeStringInteger = SCORES.readLine();
                              x++;  //add one for every 2 lines (name and score pair)
                          }

                          x = x - 1; //Subtract 1 for the offset (one too many)

                          String[] NAMES = new String[x];
                          int[] TheSCORES = new int[x];

                          //Reset all the stream and file objects, move pointer back to beginning
                          scores = new File("highscores.txt");
                          highscores = new FileInputStream(scores);
                          hiscores = new InputStreamReader(highscores);
                          SCORES = new BufferedReader(hiscores);

                          //Put each line into
                          for(z = 0; z < x; z++)
                          {
                              NAMES[z] = SCORES.readLine();
                              HoldMeStringInteger = SCORES.readLine();
                              TheSCORES[z] = Integer.parseInt(HoldMeStringInteger);

                          }

                            highscores.close();

                            WRITEME = WRITEME + "   Total of " + x +
                            " score records present in file.\n\n";

                            for(int q = 0; q < x; q++)
                            {
                                for(int r = 1; r < x; r++)
                                {
                                    if(TheSCORES[r] > TheSCORES[r - 1])
                                    {
                                       HoldMeInteger = TheSCORES[r];
                                       HoldMeStringName = NAMES[r];
                                       TheSCORES[r] = TheSCORES[r - 1];
                                       NAMES[r] = NAMES[r - 1];
                                       TheSCORES[r - 1] = HoldMeInteger;
                                       NAMES[r - 1] = HoldMeStringName;
                                    }
                                }
                            }

                            WRITEME = WRITEME +
                            "       ********** High Scores **********\n"
                            + "----------------------------------------------\n";

                            for(z = 0; z < x; z++)
                            {
                               WRITEME = WRITEME + "" + (z+1) + ". Name: " + NAMES[z] +
                                                "  Score: " + TheSCORES[z] + "\n";
                               WRITEME = WRITEME +
                            "----------------------------------------------\n";
                            }

                            successful = true;
                      }

                      catch(IOException e)
                      {
                          WRITEME = WRITEME +
                          "Unable to find \"highscores.txt\" or read scores.\n";
                          successful = false;
                      }

                      //Declared 2 Parallel Arrays where # elements = # lines.
                      //Above is a Bubble Sort for High Scores. Go through each Name
                      //and Score set and swap to arrange in descending order
                      HillsOfDarkness.OutputArea.setText(WRITEME);

              }//close DisplayHighScores() Function

//-------------------------------------------------------------------------

              public boolean SaveCharacter()
              {
                      boolean successful;
                      String CharacterName = "";
                      String passwd = "";

                      CharacterName =
                      JOptionPane.showInputDialog(
                      null, "Enter Character Name to Save:");

                      CharacterName = CharacterName + ".gam";

                      passwd =
                      JOptionPane.showInputDialog(
                      null, "Enter a password:");

                      try
                      {
                          File PlayerFile = new File(CharacterName);
                          FileOutputStream PlayerObject;
                          PlayerObject = new FileOutputStream(PlayerFile);
                          PrintStream WritePlayer = new PrintStream(PlayerObject);

                          //Simple serialization of Character class in plain ASCII
                          WritePlayer.println(passwd);
                          WritePlayer.println(CurrentPlayer.getName());
                          WritePlayer.println(CurrentPlayer.getHit());
                          WritePlayer.println(CurrentPlayer.getAttack());
                          WritePlayer.println(CurrentPlayer.getDefense());
                          WritePlayer.println(CurrentPlayer.getLevel());
                          WritePlayer.println(CurrentPlayer.getScore());
                          WritePlayer.println(CurrentPlayer.getLocation());

                          WritePlayer.println(CurrentPlayer.getDagger());
                          WritePlayer.println(CurrentPlayer.getSword());
                          WritePlayer.println(CurrentPlayer.getLongBow());
                          WritePlayer.println(CurrentPlayer.getChainMail());
                          WritePlayer.println(CurrentPlayer.getFullBodyArmor());
                          WritePlayer.println(CurrentPlayer.getHealingPotion());
                          WritePlayer.println(CurrentPlayer.getFishKey());

                          WritePlayer.println(W1GiantAlive);
                          WritePlayer.println(E1DragonAlive);
                          WritePlayer.println(S2MotleyCrewAlive);
                          WritePlayer.println(FirstTimeInShamanHut);
                          WritePlayer.println(CENTERFirstTime);
                          WritePlayer.println(UNDERDragonPairAlive);
                          WritePlayer.println(FoundHP_West2);
                          WritePlayer.println(FoundHP_Shaman);

                          WritePlayer.close(); PlayerObject.close();
                          successful = true;
                   }

                   catch (IOException e)
                   {
                       System.out.print("ERROR saving character file.");
                       successful = false;
                   }

                   return successful;
              }

//-------------------------------------------------------------------------

              public boolean LoadCharacter()
              {
                   boolean successful;

                   String CharacterName = "";
                   String nm = "";
                   String passwd = "";
                   String pass = "";

                   String hp = "";
                   String atk = "";
                   String def = "";
                   String lvl = "";
                   String scr = "";
                   String loc = "";

                   String dagger = "";
                   String sword = "";
                   String bow = "";
                   String mail = "";
                   String armor = "";
                   String healing = "";
                   String fkey = "";

                   String giant = "";
                   String dragon = "";
                   String motley = "";
                   String shaman = "";
                   String center = "";
                   String under = "";
                   String HPwest2 = "";
                   String HPshaman = "";

                   CharacterName =
                   JOptionPane.showInputDialog(
                      null, "Enter Character Name to Load:");

                   CharacterName = CharacterName + ".gam";

                   passwd =
                   JOptionPane.showInputDialog(
                      null, "Enter password:");

                   try
                   {
                       File PlayerFile = new File(CharacterName);
                       FileInputStream PlayerObject = new FileInputStream(PlayerFile);
                       InputStreamReader ReadPlayer = new InputStreamReader(PlayerObject);
                       BufferedReader StreamPlayer = new BufferedReader(ReadPlayer);

                       pass = StreamPlayer.readLine();

                       if(pass.equals(passwd))
                       {
                          //Careful! serialization = you must read in exactly
                          //the same order as you wrote!
                          nm = StreamPlayer.readLine();
                          hp = StreamPlayer.readLine();
                          atk = StreamPlayer.readLine();
                          def = StreamPlayer.readLine();
                          lvl = StreamPlayer.readLine();
                          scr = StreamPlayer.readLine();
                          loc = StreamPlayer.readLine();

                          dagger = StreamPlayer.readLine();
                          sword = StreamPlayer.readLine();
                          bow = StreamPlayer.readLine();
                          mail = StreamPlayer.readLine();
                          armor = StreamPlayer.readLine();
                          healing = StreamPlayer.readLine();
                          fkey = StreamPlayer.readLine();

                          giant = StreamPlayer.readLine();
                          dragon = StreamPlayer.readLine();
                          motley = StreamPlayer.readLine();
                          shaman = StreamPlayer.readLine();
                          center = StreamPlayer.readLine();
                          under = StreamPlayer.readLine();
                          HPwest2 = StreamPlayer.readLine();
                          HPshaman = StreamPlayer.readLine();

                          CurrentPlayer.setName(nm);
                          CurrentPlayer.setHit(Integer.parseInt(hp));
                          CurrentPlayer.setAttack(Integer.parseInt(atk));
                          CurrentPlayer.setDefense(Integer.parseInt(def));
                          CurrentPlayer.setLevel(Integer.parseInt(lvl));
                          CurrentPlayer.setScore(Integer.parseInt(scr));
                          CurrentPlayer.setLocation(Integer.parseInt(loc));

                          CurrentPlayer.setDagger(TrueOrFalse(dagger));
                          CurrentPlayer.setSword(TrueOrFalse(sword));
                          CurrentPlayer.setLongBow(TrueOrFalse(bow));
                          CurrentPlayer.setChainMail(TrueOrFalse(mail));
                          CurrentPlayer.setFullBodyArmor(TrueOrFalse(armor));
                          CurrentPlayer.setHealingPotion(Integer.parseInt(healing));
                          CurrentPlayer.setFishKey(TrueOrFalse(fkey));

                          W1GiantAlive = TrueOrFalse(giant);
                          E1DragonAlive = TrueOrFalse(dragon);
                          S2MotleyCrewAlive = TrueOrFalse(motley);
                          FirstTimeInShamanHut = TrueOrFalse(shaman);
                          CENTERFirstTime = TrueOrFalse(center);
                          UNDERDragonPairAlive = TrueOrFalse(under);
                          FoundHP_West2 = TrueOrFalse(HPwest2);
                          FoundHP_Shaman = TrueOrFalse(HPshaman);

                          ReadPlayer.close(); PlayerObject.close();
                          successful = true;
                      }

                      else
                      {
                           System.out.print("\n\tThat was not the correct password!!!");
                           successful = false;
                      }
                   }

                   catch(IOException e)
                   {
                       System.out.print("\tUnable to create charactrer file.\n");
                       successful = false;
                   }

                   return successful;

              }//close LoadCharacter() function

//-------------------------------------------------------------------------


}//close Events class
