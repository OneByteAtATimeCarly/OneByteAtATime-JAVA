//Main Applet class, graphical interface

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.JTextArea;
import java.awt.Rectangle;
import javax.swing.BorderFactory;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Dimension;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import java.util.*;
import javax.swing.*;
import java.io.*;


// Only really need ActionListener for buttons here. The other interfaces
// are implemented as examples in case you want to use them. Examples:
// Runnable = Threads
// ActionListener = Buttons
// MouseListener = Mouse clicking and exiting
// MouseMotionListener = mouse moving and dragging
// Runnable = Threads
// TextListener = text changing events

// Remember that every time you add an interface using "implements" you must add 
// its corresponding event handler functions as well.


public class HillsOfDarkness extends java.applet.Applet implements 
             Runnable, ActionListener, MouseMotionListener, MouseListener, TextListener
{

     public static BorderLayout borderLayout1 = new BorderLayout();

     public static TextArea OutputArea = new TextArea("",0,0,TextArea.SCROLLBARS_VERTICAL_ONLY);
     public static TextArea InventoryArea = new TextArea("",0,0,TextArea.SCROLLBARS_VERTICAL_ONLY);
     public static TextArea ConquestsArea = new TextArea("",0,0,TextArea.SCROLLBARS_VERTICAL_ONLY);

     public static JLabel NameLabel = new JLabel();
     public static JLabel NameOutputLabel = new JLabel();
     public static JLabel HitpointsLabel = new JLabel();
     public static JLabel AttackLabel = new JLabel();
     public static JLabel DefenseLabel = new JLabel();
     public static JLabel ScoreLabel = new JLabel();
     public static JLabel HitpointOutputLabel = new JLabel();
     public static JLabel AttackOutputLabel = new JLabel();
     public static JLabel DefenseOutputLabel = new JLabel();
     public static JLabel ScoreOutputLabel = new JLabel();
     public static JTextField InputField = new JTextField();
     public static JButton HealButton = new JButton();
     public static JButton ActionButton = new JButton();
     public static JButton GoButton = new JButton();
     public static JButton NorthButton = new JButton();
     public static JButton SouthButton = new JButton();
     public static JButton EastButton = new JButton();
     public static JButton WestButton = new JButton();
     public static JLabel BorderLabel = new JLabel();
     public static JLabel DirectionLabel = new JLabel();
     public static JRadioButton HandToHandRadio = new JRadioButton();
     public static JRadioButton DaggerRadio = new JRadioButton();
     public static JRadioButton SwordRadio = new JRadioButton();
     public static JRadioButton LongBowRadio = new JRadioButton();
     public static JLabel RadioBorder = new JLabel();
     public static JLabel CombatLabel = new JLabel();
     public static JButton ScoresButton = new JButton();
     public static JButton HelpButton = new JButton();
     public static JButton LoadButton = new JButton();
     public static JButton SaveButton = new JButton();
     public static JButton StartButton = new JButton();
     public static JButton QuitButton = new JButton();
     public static JLabel MenuBorder = new JLabel();
     public static JLabel MenuLabel = new JLabel();
     public static JLabel InventoryLabel = new JLabel();
     public static JLabel ConquestsLabel = new JLabel();
     public static JLabel ViewLabel = new JLabel();
     public static JLabel ViewBorder = new JLabel();
     public static ButtonGroup AttackWeaponGroup = new ButtonGroup();

     public static boolean Continue = true;
     public static boolean successful = false;
     public static boolean Started = false;
     public static boolean LOCK = false;
     public static String choice = "";
     public static char WhatToDo = '#';

     //necessary to prevent image flicker
     MediaTracker TRACKER; 

     //Images
     Image DRAGONimage;
     Image CENTERimage;
     Image E1image;
     Image E2image;
     Image GIANTimage;
     Image HILLSimage;
     Image N1image;
     Image N2image;
     Image S1image;
     Image S2image;
     Image SHAMANimage;
     Image W1image;
     Image W2image;

     //Audio Clips
     public static AudioClip bowSOUND;
     public static AudioClip handSOUND;
     public static AudioClip knifeSOUND;
     public static AudioClip swordSOUND;
     public static AudioClip dragonSOUND;
     public static AudioClip giantSOUND;
     public static AudioClip mighty3SOUND;
     public static AudioClip themeSOUND;
     public static AudioClip thunderSOUND;

     Events Game;

     public static boolean isStandalone = false;


    //Constructor
    public HillsOfDarkness() {}


    //Component initialization
    public void init() 
    {
        this.setLayout(null);

        OutputArea.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 14));
        OutputArea.setBackground(Color.white);
        OutputArea.setForeground(new Color(171, 138, 217));
        OutputArea.setEditable(false);
        OutputArea.setText("\n\n\n  Welcome to Hills of Darkness.\n" +
                           "  Click the \"START\" button to continue.");
        OutputArea.setBounds(new Rectangle(4, 35, 324, 474));

        InventoryArea.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        InventoryArea.setBackground(Color.white);
        InventoryArea.setForeground(new Color(171, 138, 217));
        InventoryArea.setEditable(false);
        InventoryArea.setBounds(new Rectangle(486, 244, 103, 265));

        ConquestsArea.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        ConquestsArea.setBackground(Color.white);
        ConquestsArea.setForeground(new Color(171, 138, 217));
        ConquestsArea.setEditable(false);
        ConquestsArea.setBounds(new Rectangle(335, 327, 144, 73));


        this.setBackground(new Color(223, 243, 255));
        NameLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        NameLabel.setRequestFocusEnabled(false);
        NameLabel.setText("Name:");
        NameLabel.setBounds(new Rectangle(3, 13, 36, 14));
        NameOutputLabel.setBackground(Color.white);
        NameOutputLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                                                  12));
        NameOutputLabel.setForeground(new Color(171, 138, 217));
        NameOutputLabel.setBorder(BorderFactory.createLineBorder(Color.black));
        NameOutputLabel.setOpaque(true);
        NameOutputLabel.setRequestFocusEnabled(false);
        NameOutputLabel.setBounds(new Rectangle(42, 13, 286, 15));

        HitpointsLabel.setText("Hitpoints");
        HitpointsLabel.setBounds(new Rectangle(361, 0, 45, 14));
        HitpointsLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 10));

        AttackLabel.setText("Attack");
        AttackLabel.setBounds(new Rectangle(426, 0, 34, 14));
        AttackLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 10));

        DefenseLabel.setText("Defense");
        DefenseLabel.setBounds(new Rectangle(483, 0, 42, 14));
        DefenseLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 10));

        ScoreLabel.setText("Score");
        ScoreLabel.setBounds(new Rectangle(550, 0, 34, 14));
        ScoreLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 10));

        HitpointOutputLabel.setFont(new java.awt.Font("Trebuchet MS",
                Font.PLAIN, 12));
        HitpointOutputLabel.setBorder(BorderFactory.createLineBorder(Color.
                black));
        HitpointOutputLabel.setRequestFocusEnabled(false);
        HitpointOutputLabel.setBounds(new Rectangle(361, 12, 40, 14));
        AttackOutputLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                12));
        AttackOutputLabel.setBorder(BorderFactory.createLineBorder(Color.black));
        AttackOutputLabel.setRequestFocusEnabled(false);
        AttackOutputLabel.setBounds(new Rectangle(421, 12, 40, 14));

        DefenseOutputLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                12));
        DefenseOutputLabel.setBorder(BorderFactory.createLineBorder(Color.black));
        DefenseOutputLabel.setRequestFocusEnabled(false);
        DefenseOutputLabel.setBounds(new Rectangle(482, 13, 40, 14));

        ScoreOutputLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                12));
        ScoreOutputLabel.setBorder(BorderFactory.createLineBorder(Color.black));
        ScoreOutputLabel.setRequestFocusEnabled(false);
        ScoreOutputLabel.setBounds(new Rectangle(545, 13, 40, 14));
        InputField.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        InputField.setForeground(new Color(171, 138, 217));
        InputField.setBorder(BorderFactory.createLineBorder(Color.black));
        InputField.setBounds(new Rectangle(333, 33, 252, 21));
        HealButton.setBackground(new Color(171, 125, 253));
        HealButton.setBounds(new Rectangle(362, 58, 60, 23));
        HealButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        HealButton.setForeground(Color.white);
        HealButton.setText("HEAL");
        ActionButton.setBackground(new Color(171, 125, 253));
        ActionButton.setBounds(new Rectangle(444, 58, 70, 23));
        ActionButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 10));
        ActionButton.setForeground(Color.white);
        ActionButton.setText("ACTION");
        GoButton.setBackground(new Color(171, 125, 253));
        GoButton.setBounds(new Rectangle(535, 58, 50, 23));
        GoButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        GoButton.setForeground(Color.white);
        GoButton.setText("GO");

        NorthButton.setBackground(new Color(171, 125, 253));
        NorthButton.setBounds(new Rectangle(381, 110, 42, 23));
        NorthButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        NorthButton.setForeground(Color.white);
        NorthButton.setMaximumSize(new Dimension(45, 23));
        NorthButton.setMinimumSize(new Dimension(45, 23));
        NorthButton.setPreferredSize(new Dimension(45, 23));
        NorthButton.setText("N");
        SouthButton.setBackground(new Color(171, 125, 253));
        SouthButton.setBounds(new Rectangle(379, 158, 45, 23));
        SouthButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        SouthButton.setForeground(Color.white);
        SouthButton.setMaximumSize(new Dimension(45, 23));
        SouthButton.setMinimumSize(new Dimension(45, 23));
        SouthButton.setPreferredSize(new Dimension(45, 23));
        SouthButton.setText("S");
        EastButton.setBackground(new Color(171, 125, 253));
        EastButton.setBounds(new Rectangle(424, 134, 42, 23));
        EastButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        EastButton.setForeground(Color.white);
        EastButton.setMaximumSize(new Dimension(45, 23));
        EastButton.setMinimumSize(new Dimension(45, 23));
        EastButton.setPreferredSize(new Dimension(45, 23));
        EastButton.setText("E");
        WestButton.setBackground(new Color(171, 125, 253));
        WestButton.setBounds(new Rectangle(337, 134, 44, 23));
        WestButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        WestButton.setForeground(Color.white);
        WestButton.setSelectedIcon(null);
        WestButton.setText("W");
        BorderLabel.setBorder(BorderFactory.createLineBorder(Color.black));
        BorderLabel.setBounds(new Rectangle(333, 103, 139, 86));
        DirectionLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        DirectionLabel.setToolTipText("");
        DirectionLabel.setText("Direction");
        DirectionLabel.setBounds(new Rectangle(377, 87, 51, 14));
        HandToHandRadio.setBackground(new Color(223, 243, 255));
        HandToHandRadio.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                                                  11));
        HandToHandRadio.setRequestFocusEnabled(false);
        HandToHandRadio.setSelected(true);
        HandToHandRadio.setText("Hand To Hand");
        HandToHandRadio.setBounds(new Rectangle(487, 109, 93, 23));
        DaggerRadio.setText("Dagger");
        DaggerRadio.setBounds(new Rectangle(487, 137, 64, 23));
        DaggerRadio.setBackground(new Color(223, 243, 255));
        DaggerRadio.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                                              11));
        SwordRadio.setText("Sword");
        SwordRadio.setBounds(new Rectangle(487, 165, 62, 23));
        SwordRadio.setBackground(new Color(223, 243, 255));
        SwordRadio.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                                             11));
        LongBowRadio.setText("Long Bow");
        LongBowRadio.setBounds(new Rectangle(487, 192, 78, 23));
        LongBowRadio.setBackground(new Color(223, 243, 255));
        LongBowRadio.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN,
                                               11));
        RadioBorder.setBorder(BorderFactory.createLineBorder(Color.black));
        RadioBorder.setBounds(new Rectangle(479, 103, 108, 120));
        CombatLabel.setToolTipText("");
        CombatLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        CombatLabel.setText("Attack Weapons");
        CombatLabel.setBounds(new Rectangle(492, 88, 95, 14));
        ScoresButton.setBackground(new Color(171, 125, 253));
        ScoresButton.setBounds(new Rectangle(336, 424, 67, 23));
        ScoresButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        ScoresButton.setForeground(Color.white);
        ScoresButton.setText("SCORE");
        HelpButton.setBackground(new Color(171, 125, 253));
        HelpButton.setBounds(new Rectangle(408, 424, 67, 23));
        HelpButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        HelpButton.setForeground(Color.white);
        HelpButton.setText("HELP");
        LoadButton.setBackground(new Color(171, 125, 253));
        LoadButton.setBounds(new Rectangle(336, 452, 67, 23));
        LoadButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        LoadButton.setForeground(Color.white);
        LoadButton.setText("LOAD");
        SaveButton.setBackground(new Color(171, 125, 253));
        SaveButton.setBounds(new Rectangle(336, 480, 67, 23));
        SaveButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        SaveButton.setForeground(Color.white);
        SaveButton.setText("SAVE");
        StartButton.setBackground(new Color(171, 125, 253));
        StartButton.setBounds(new Rectangle(408, 452, 67, 23));
        StartButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        StartButton.setForeground(Color.white);
        StartButton.setText("START");
        QuitButton.setBackground(new Color(171, 125, 253));
        QuitButton.setBounds(new Rectangle(408, 480, 67, 23));
        QuitButton.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 11));
        QuitButton.setForeground(Color.white);
        QuitButton.setText("QUIT");
        MenuBorder.setBorder(BorderFactory.createLineBorder(Color.black));
        MenuBorder.setBounds(new Rectangle(333, 419, 146, 90));
        MenuLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        MenuLabel.setText("Menu");
        MenuLabel.setBounds(new Rectangle(387, 401, 41, 17));

        InventoryLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        InventoryLabel.setText("Inventory");
        InventoryLabel.setBounds(new Rectangle(504, 228, 57, 17));
        ConquestsLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        ConquestsLabel.setToolTipText("");
        ConquestsLabel.setText("Conquests");
        ConquestsLabel.setBounds(new Rectangle(374, 311, 57, 17));
        ViewLabel.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        ViewLabel.setToolTipText("");
        ViewLabel.setText("View");
        ViewLabel.setBounds(new Rectangle(387, 190, 33, 17));
        ViewBorder.setFont(new java.awt.Font("Trebuchet MS", Font.PLAIN, 12));
        ViewBorder.setBorder(BorderFactory.createLineBorder(Color.black));
        ViewBorder.setToolTipText("");
        ViewBorder.setBounds(new Rectangle(334, 206, 135, 98));
        this.add(NameOutputLabel);
        this.add(NameLabel);
        this.add(OutputArea);
        this.add(ConquestsArea);
        this.add(InventoryArea);
        this.add(AttackLabel);
        this.add(DefenseOutputLabel);
        this.add(DefenseLabel);
        this.add(HitpointOutputLabel);
        this.add(InputField);
        this.add(HealButton);
        this.add(GoButton);
        this.add(ActionButton);
        this.add(HitpointsLabel);
        this.add(ScoreOutputLabel);
        this.add(ScoreLabel);
        this.add(AttackOutputLabel);
        this.add(WestButton);
        this.add(EastButton);
        this.add(BorderLabel);
        this.add(SouthButton);
        this.add(NorthButton);
        this.add(DirectionLabel);
        this.add(CombatLabel);
        this.add(LongBowRadio);
        this.add(HandToHandRadio);
        this.add(DaggerRadio);
        this.add(SwordRadio);
        this.add(RadioBorder);
        this.add(ViewBorder);
        this.add(ViewLabel);
        this.add(InventoryLabel);
        this.add(HelpButton);
        this.add(ScoresButton);
        this.add(QuitButton);
        this.add(StartButton);
        this.add(LoadButton);
        this.add(SaveButton);
        this.add(MenuBorder);
        this.add(MenuLabel);
        this.add(ConquestsLabel);
        AttackWeaponGroup.add(HandToHandRadio);
        AttackWeaponGroup.add(DaggerRadio);
        AttackWeaponGroup.add(SwordRadio);
        AttackWeaponGroup.add(LongBowRadio);

        //If wanted to invoke function with mouse you'd add: 
        addMouseListener(this);
        addMouseMotionListener(this);

        //Must add ActionListener for button clicks. Handled in actionPerformed()
        HealButton.addActionListener(this);
        WestButton.addActionListener(this);
        NorthButton.addActionListener(this);
        EastButton.addActionListener(this);
        SouthButton.addActionListener(this);
        LongBowRadio.addActionListener(this);
        HandToHandRadio.addActionListener(this);
        DaggerRadio.addActionListener(this);
        SwordRadio.addActionListener(this);
        HelpButton.addActionListener(this);
        ScoresButton.addActionListener(this);
        QuitButton.addActionListener(this);
        StartButton.addActionListener(this);
        LoadButton.addActionListener(this);
        SaveButton.addActionListener(this);
        GoButton.addActionListener(this);
        ActionButton.addActionListener(this);

        TRACKER = new MediaTracker(this);

        bowSOUND = getAudioClip(getCodeBase(),"bow.au");
        handSOUND = getAudioClip(getCodeBase(),"hand.au");
        knifeSOUND = getAudioClip(getCodeBase(),"knife.au");
        swordSOUND = getAudioClip(getCodeBase(),"sword.au");
        dragonSOUND = getAudioClip(getCodeBase(),"dragon.au");
        giantSOUND = getAudioClip(getCodeBase(),"giant.au");
        mighty3SOUND = getAudioClip(getCodeBase(),"mighty3.au");
        themeSOUND = getAudioClip(getCodeBase(),"theme.au");
        thunderSOUND = getAudioClip(getCodeBase(),"thunder.au");

        DRAGONimage = getImage(getCodeBase(), "dragon.jpg");
        CENTERimage = getImage(getCodeBase(), "center.jpg");
        E1image = getImage(getCodeBase(), "E1.jpg");
        E2image = getImage(getCodeBase(), "E2.jpg");
        GIANTimage = getImage(getCodeBase(), "giant.jpg");
        HILLSimage = getImage(getCodeBase(), "hills.jpg");
        N1image = getImage(getCodeBase(), "N1.jpg");
        N2image = getImage(getCodeBase(), "N2.jpg");
        S1image = getImage(getCodeBase(), "S1.jpg");
        S2image = getImage(getCodeBase(), "S2.jpg");
        SHAMANimage = getImage(getCodeBase(), "SHAMAN.jpg");
        W1image = getImage(getCodeBase(), "W1.jpg");
        W2image = getImage(getCodeBase(), "W2.jpg");

        TRACKER.addImage(DRAGONimage,1);
        TRACKER.addImage(CENTERimage,2);
        TRACKER.addImage(E1image,3);
        TRACKER.addImage(E2image,4);
        TRACKER.addImage(GIANTimage,5);
        TRACKER.addImage(HILLSimage,6);
        TRACKER.addImage(N1image,7);
        TRACKER.addImage(N2image,8);
        TRACKER.addImage(S1image,9);
        TRACKER.addImage(S2image,10);
        TRACKER.addImage(SHAMANimage,11);
        TRACKER.addImage(W1image,12);
        TRACKER.addImage(W2image,13);

        try { TRACKER.waitForAll(); }
        catch(Exception e) {  }
    }

//-----------------------------------------------------------------------------

    public void paint(Graphics g)
    {
           super.paint(g); //Necessary for all other components

           switch(Game.location)
           {
                  case Events.INTRO : g.drawImage(HILLSimage, 338, 210, 127, 90, this);
                                      break;
                  case Events.CENTER1 : g.drawImage(CENTERimage, 338, 210, 127, 90, this);
                                        break;
                  case Events.N1 : g.drawImage(N1image, 338, 210, 127, 90, this);
                                   break;
                  case Events.N2 : g.drawImage(N2image, 338, 210, 127, 90, this);
                                      break;
                  case Events.S1 : g.drawImage(S1image, 338, 210, 127, 90, this);
                                 break;
                  case Events.S2 : g.drawImage(S2image, 338, 210, 127, 90, this);
                                 break;
                  case Events.E1 : g.drawImage(E1image, 338, 210, 127, 90, this);
                                 break;
                  case Events.E2 : g.drawImage(E2image, 338, 210, 127, 90, this);
                                 break;
                  case Events.W1 : g.drawImage(S1image, 338, 210, 127, 90, this);
                                 break;
                  case Events.W2 : g.drawImage(S2image, 338, 210, 127, 90, this);
                                 break;
                  case Events.SHAMAN : g.drawImage(SHAMANimage, 338, 210, 127, 90, this);
                                     break;
                 default : break;
            }

            switch(Game.FightImage)
            {
                   case 'd' : g.drawImage(DRAGONimage, 338, 210, 127, 90, this);
                                    break;
                   case 'g' : g.drawImage(GIANTimage, 338, 210, 127, 90, this);
                                    break;
                   default :  break;
            }
    }

//-----------------------------------------------------------------------------

    public void run()
    {

    }

    public void actionPerformed(ActionEvent e)
    {

    //*******************************************************************

        if(e.getSource().equals(StartButton))
        {
            if(Started == false)
            {
                InputField.setText("Enter your name HERE.");
                InputField.requestFocus(); //Changes Focus
                InputField.selectAll();

                ConquestsArea.setText("Loading...");

                Game = new Events(this);
                Game.InitializeGlobals();
                Game.LockButtons(false);
                Continue = true;
                Started = true;

            }//close if for "StartedGame=false"

            else
            {
                String NagMe = JOptionPane.showInputDialog(null,
                        "You are in the middle of a game. Are you sure?",
                        "no way").toLowerCase();

                  if(NagMe.equals("yes") || NagMe.equals("y"))
                  {
                      Game.InitializeGlobals(); //If user clicks again, initialize
                      StartButton.doClick();
                  }
            }//close else

        }//close if for StartButton

     //*******************************************************************

        if(e.getSource().equals(GoButton))
        {
            if(Started == true)
            {
                if(Game.NeedName == true)
                {
                    Game.CurrentPlayer.AskName();
                    Game.NeedName = false;
                }

                if(Continue == true)
                {
                     WEAPONS();

                     if(LOCK == false)
                     {
                         WhatToDo = '#';
                         Game.SwitchBoard();
                     }//close if for LOCK
                     else
                     {
                         //Begin else for "LOCK = true" (Locked)
                         choice = InputField.getText().toLowerCase();
                         WhatToDo = choice.charAt(0);
                         InputField.setText("");
                         InputField.requestFocus();

                         Game.SwitchBoard();

                         //If choice is valid, recursively call GO() to proceed to next function
                         if(WhatToDo == 'n' || WhatToDo == 's' ||
                         WhatToDo == 'e' || WhatToDo == 'w' ||
                         WhatToDo == 't' || WhatToDo == 'r' ||
                         WhatToDo == 'l' || WhatToDo == 'g')
                         {
                                   GoButton.doClick(); //recurseive call to function
                         }

                     }//close else for LOCK

                     OutputArea.setCaretPosition(0);

                }//close if for Continue

                else { QuitButton.doClick(); }

            }//close if started

            else
            {
                String WRITEME = OutputArea.getText() +
                "\n\n  Sorry, you can not press the \"GO\" button"
                + "\n  yet. You need  to click on the \"START\""
                + "\n  button to begin the game!";
                OutputArea.setText(WRITEME);
            }

        }//close if for GoButton

     //*******************************************************************

            if(e.getSource().equals(NorthButton))
            {
               InputField.setText("n");
               GoButton.doClick();
            }
        //*******************************************************************
             if(e.getSource().equals(SouthButton))
             {
                InputField.setText("s");
                GoButton.doClick();
             }
        //*******************************************************************
             if(e.getSource().equals(EastButton))
             {
                InputField.setText("e");
                GoButton.doClick();
             }
        //*******************************************************************
             if(e.getSource().equals(WestButton))
             {
                InputField.setText("w");
                GoButton.doClick();
             }

        //*******************************************************************

         if(e.getSource().equals(HealButton))
         {
            if(Started) { Game.CurrentPlayer.UseHealingPotion(); }
         }

         //*******************************************************************

         if(e.getSource().equals(HelpButton))
         {
            JOptionPane.showMessageDialog(null,
            "2006 - C. Germany - www.networkingprogramming.com\n\n" +
            "          Hills Of Darkness Instructions - HELP\n\n" +
            "The object of this game is to collect enough" +
            " items\nand gain enough experience to operate" +
            " the\ndimensional gateway and return home." +
            " You will\nalso need to find a key to activate" +
            " the gate\nmechanism. You may ask the village " +
            "shaman\nfor help and useful advice on your journey." +
            "\n\nFor every three opponents you defeat, \"1\" will" +
            "\nbe added to your Attack and Defense capabilities." +
            "\nThis represents the natural skill you acquire as" +
            "\na result of combat, and is independent of and in" +
            "\naddition to any defense or attack capabilities" +
            "\nyou gain through the use of armor and weapons. In" +
            "\naddition to your attack/defense skills acquired" +
            "\nthrough experience, if you find armor and weapons," +
            "\nthey will also add to your abilities.");
         }

        if(e.getSource().equals(QuitButton))
        {
             OutputArea.setText("\n\n\n        Good Bye!");
             String WRITEME = OutputArea.getText();
             boolean successful = Game.SaveHighScores();
             if(successful)
             {
                   WRITEME = WRITEME +
                   "\n\n  Current score saved to file successfully.";
             }
             else
             {
                 WRITEME = WRITEME +
                 "\n\n  Unable to save Current score successfully.";
             }

             OutputArea.setText(WRITEME);
             this.destroy();
             Started = false;
        }

        if(e.getSource().equals(ScoresButton))
        {
            //Call this statically so they can display scores even
            //if an Events object has not been instantiated. Hence:
            //"Events." in place of "Game."
            Events.DisplayHighScores();
        }

        if(e.getSource().equals(LoadButton))
        {
            if(Started)
            {
                boolean success = Game.LoadCharacter();
                if(success)
                {
                    OutputArea.setText( OutputArea.getText() +
                    "\n\n  Character Loaded!\n");
                }
                else
                {
                    OutputArea.setText( OutputArea.getText() +
                    "\n\n  Sorry, character could not be loaded.\n");
                }
            }
        }

        if(e.getSource().equals(SaveButton))
        {
            if(Started)
            {
                boolean success = Game.SaveCharacter();
                if(success)
                {
                    OutputArea.setText( OutputArea.getText() +
                    "\n\n  Character Saved!\n");
                }
                else
                {
                    OutputArea.setText( OutputArea.getText() +
                    "\n\n  Sorry, character could not be saved.\n");
                }
            }
        }

} //close actionPerformed function

//-----------------------------------------------------------------------------

    public void WEAPONS()
    {
       //Moved here so player can change weapons while in combat
       if(Continue && Started)
       {
           //Disable Radio Buttons if Player Doesn't Have the Weapon
           if(Game.CurrentPlayer.getDagger())
           { DaggerRadio.setEnabled(true); }
           else
           { DaggerRadio.setEnabled(false); }

           if(Game.CurrentPlayer.getSword())
           { SwordRadio.setEnabled(true); }
           else
           { SwordRadio.setEnabled(false); }

           if(Game.CurrentPlayer.getLongBow())
           { LongBowRadio.setEnabled(true); }
           else
           { LongBowRadio.setEnabled(false); }


           if(HandToHandRadio.isSelected())
           {
              Game.CurrentPlayer.setUseDagger(false);
              Game.CurrentPlayer.setUseSword(false);
              Game.CurrentPlayer.setUseLongBow(false);
           }

           if(DaggerRadio.isSelected())
           {
               if(Game.CurrentPlayer.getDagger())
               {
                  Game.CurrentPlayer.setUseDagger(true);
                  Game.CurrentPlayer.setUseSword(false);
                  Game.CurrentPlayer.setUseLongBow(false);
               }
           }

           if(SwordRadio.isSelected())
           {
                if(Game.CurrentPlayer.getSword())
                {
                     Game.CurrentPlayer.setUseSword(true);
                     Game.CurrentPlayer.setUseDagger(false);
                     Game.CurrentPlayer.setUseLongBow(false);
                }
            }

            if(LongBowRadio.isSelected())
            {
                if(Game.CurrentPlayer.getLongBow())
                {
                      Game.CurrentPlayer.setUseLongBow(true);
                      Game.CurrentPlayer.setUseDagger(false);
                      Game.CurrentPlayer.setUseSword(false);
                }
            }

       }//close weapons if

    }//close weapons function


    //The necessary methods for implementing MouseListener.
    public void mouseClicked(MouseEvent evt) {  }
    public void mouseReleased(MouseEvent evt) {  }
    public void mouseExited(MouseEvent evt) {   }
    public void mousePressed(MouseEvent evt)  {  }
    public void mouseEntered(MouseEvent evt)  {  }

    //The necessary methods for implementing MouseMotionListener.
    public void mouseDragged(MouseEvent e)  {  }
    public void mouseMoved(MouseEvent e)  {  }

    //The necessary method for implementing TextListener.
    public void textValueChanged(TextEvent t)  {   }


    public void refresh()
    {
           Graphics g = getGraphics();
           paint(g);
    }


}
