
public class CardPlayer
{
       //Globals
       public final int MaxHandSize = 20;

       //Overloaded Constructors
       public CardPlayer()
       {  }

       public CardPlayer(String NM)
       {
          NAME = NM;
       }

       public CardPlayer(String NM, String SEX, boolean DLR)
       {
              NAME = NM;
              GENDER = SEX;
              DEALER = DLR;
       }

//---------------------------------------------------------------------------

       public void Initialize()
       {
              NAME = "Anonymous";
              GENDER = "Female";
              Age = 20;
              Money = 100;
              NumCardsInHand = 0;
              TotalPtsInHand = 0;
              SCORE = 0;
              STAY = false;
              DEALER = false;          
       }

//---------------------------------------------------------------------------

       //Public accessors
       public void SetName(String X) { NAME = X; }
       public String GetName() { return NAME; }
       public void SetGender(String X) { GENDER = X; }
       public String GetGender() { return GENDER; }
       public void SetAge(int X) { Age = X; }
       public int GetAge() { return Age; }
       public void SetMoney(int X) { Money = X; }
       public int GetMoney() { return Money; }
       public void SetNumCards(int X) { NumCardsInHand = X; }
       public int GetNumCards() { return NumCardsInHand; }
       public void SetPoints(int X) { TotalPtsInHand = X; }
       public int GetPoints() { return TotalPtsInHand; }
       public void SetScore(int X) { SCORE = X; }
       public int GetScore() { return SCORE; }
       public void SetStay(boolean X) { STAY = X; }
       public boolean GetStay() { return STAY; }
       public void SetDealer(boolean X) { DEALER = X; }
       public boolean GetDealer() { return DEALER; }

//---------------------------------------------------------------------------

       //Private Data
       private String NAME = "Anonymous";
       private String GENDER = "Female";
       private int Age = 20;
       private int Money = 100;
       private int NumCardsInHand = 0;
       private int TotalPtsInHand = 0;
       private int SCORE = 0;
       private boolean STAY = false;
       private boolean DEALER = false;
       
       //Public Data
       public CARD[] HAND = new CARD[MaxHandSize];

}//close class
