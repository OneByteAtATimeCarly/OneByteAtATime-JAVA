import java.awt.Image;

public class CARD
{
       //Globals
       //The Card Values
       public static final int DEUCE = 2;
       public static final int THREE = 3;
       public static final int FOUR = 4;
       public static final int FIVE = 5;
       public static final int SIX = 6;
       public static final int SEVEN = 7;
       public static final int EIGHT = 8;
       public static final int NINE = 9;
       public static final int TEN = 10;
       public static final int JACK = 11;
       public static final int QUEEN = 12;
       public static final int KING = 13;
       public static final int ACE = 14;

       //The Faces
       public static final int SPADES = 0;
       public static final int HEARTS = 1;
       public static final int DIAMONDS = 2;
       public static final int CLUBS = 3;

//-----------------------------------------------------------------------------

       //Constructor
       public CARD()
       {
              TheCard = DEUCE;
              TheFace = HEARTS;
              Drawn = false;
       }

//-----------------------------------------------------------------------------

       //Overloaded Constructor
       public CARD(int card, int face)
       {
              TheCard = card;
              TheFace = face;
              Drawn = false;

              switch(TheCard)
              {
                  case DEUCE : PointValue = 2; break;
                  case THREE : PointValue = 3; break;
                  case FOUR : PointValue = 4; break;
                  case FIVE : PointValue = 5; break;
                  case SIX : PointValue = 6; break;
                  case SEVEN : PointValue = 7; break;
                  case EIGHT : PointValue = 8; break;
                  case NINE : PointValue = 9; break;
                  case TEN : PointValue = 10; break;
                  case JACK : PointValue = 10; break;
                  case QUEEN : PointValue = 10; break;
                  case KING : PointValue = 10; break;
                  case ACE : PointValue = 11; break;
                  default : break;
              }
              
       }

//-----------------------------------------------------------------------------

public String DisplayCard()
{
       String OUT = "\n     A ";

       switch(TheCard)
       {
          case DEUCE : OUT = OUT + "DEUCE of ";
                       switch(TheFace)
                       {
                          case SPADES : OUT = OUT + "SPADES";
                                        CardImage = BlackJackAngelina.TWO_spades;
                                        break;
                          case HEARTS : OUT = OUT + "HEARTS";
                                        CardImage = BlackJackAngelina.TWO_hearts;
                                        break;
                          case DIAMONDS : OUT = OUT + "DIAMONDS";
                                          CardImage = BlackJackAngelina.TWO_diamonds;
                                          break;
                          case CLUBS : OUT = OUT + "CLUBS";
                                       CardImage = BlackJackAngelina.TWO_clubs;
                                       break;
                          default : OUT = OUT + "ERROR!"; break;
                        }
                        break;

           case THREE : OUT = OUT + "THREE of ";
                        switch(TheFace)
                        {
                           case SPADES : OUT = OUT + "SPADES";
                                         CardImage = BlackJackAngelina.THREE_spades;
                                         break;
                           case HEARTS : OUT = OUT + "HEARTS";
                                         CardImage = BlackJackAngelina.THREE_hearts;
                                         break;
                           case DIAMONDS : OUT = OUT + "DIAMONDS";
                                           CardImage = BlackJackAngelina.THREE_diamonds;
                                           break;
                           case CLUBS : OUT = OUT + "CLUBS";
                                        CardImage = BlackJackAngelina.THREE_clubs;
                                        break;
                           default : OUT = OUT + "ERROR!"; break;
                          }
                          break;

          case FOUR :  OUT = OUT + "FOUR of ";
                        switch(TheFace)
                        {
                           case SPADES : OUT = OUT + "SPADES";
                                         CardImage = BlackJackAngelina.FOUR_spades;
                                         break;
                           case HEARTS : OUT = OUT + "HEARTS";
                                         CardImage = BlackJackAngelina.FOUR_hearts;
                                         break;
                           case DIAMONDS : OUT = OUT + "DIAMONDS";
                                           CardImage = BlackJackAngelina.FOUR_diamonds;
                                           break;
                           case CLUBS : OUT = OUT + "CLUBS";
                                        CardImage = BlackJackAngelina.FOUR_clubs;
                                        break;
                           default : OUT = OUT + "ERROR!"; break;
                        }
                        break;

          case FIVE : OUT = OUT + "FIVE of ";
                      switch(TheFace)
                      {
                         case SPADES : OUT = OUT + "SPADES";
                                       CardImage = BlackJackAngelina.FIVE_spades;
                                       break;
                         case HEARTS : OUT = OUT + "HEARTS";
                                       CardImage = BlackJackAngelina.FIVE_hearts;
                                       break;
                         case DIAMONDS : OUT = OUT + "DIAMONDS";
                                         CardImage = BlackJackAngelina.FIVE_diamonds;
                                         break;
                         case CLUBS : OUT = OUT + "CLUBS";
                                      CardImage = BlackJackAngelina.FIVE_clubs;
                                      break;
                         default : OUT = OUT + "ERROR!"; break;
                      }
                                         break;
          case SIX : OUT = OUT + "SIX of ";
                     switch(TheFace)
                     {
                        case SPADES : OUT = OUT + "SPADES";
                                      CardImage = BlackJackAngelina.SIX_spades;
                                      break;
                        case HEARTS : OUT = OUT + "HEARTS";
                                      CardImage = BlackJackAngelina.SIX_hearts;
                                      break;
                        case DIAMONDS : OUT = OUT + "DIAMONDS";
                                        CardImage = BlackJackAngelina.SIX_diamonds;
                                        break;
                        case CLUBS : OUT = OUT + "CLUBS";
                                     CardImage = BlackJackAngelina.SIX_clubs;
                                     break;
                        default : OUT = OUT + "ERROR!"; break;
                    }
                    break;
          case SEVEN : OUT = OUT + "SEVEN of ";
                       switch(TheFace)
                       {
                          case SPADES : OUT = OUT + "SPADES";
                                        CardImage = BlackJackAngelina.SEVEN_spades;
                                        break;
                          case HEARTS : OUT = OUT + "HEARTS";
                                        CardImage = BlackJackAngelina.SEVEN_hearts;
                                        break;
                          case DIAMONDS : OUT = OUT + "DIAMONDS";
                                          CardImage = BlackJackAngelina.SEVEN_diamonds;
                                          break;
                          case CLUBS : OUT = OUT + "CLUBS";
                                       CardImage = BlackJackAngelina.SEVEN_clubs;
                                       break;
                          default : OUT = OUT + "ERROR!"; break;
                       }
                       break;

          case EIGHT : OUT = OUT + "EIGHT of ";
                       switch(TheFace)
                       {
                          case SPADES : OUT = OUT + "SPADES";
                                        CardImage = BlackJackAngelina.EIGHT_spades;
                                        break;
                          case HEARTS : OUT = OUT + "HEARTS";
                                            CardImage = BlackJackAngelina.EIGHT_hearts;
                                            break;
                          case DIAMONDS : OUT = OUT + "DIAMONDS";
                                            CardImage = BlackJackAngelina.EIGHT_diamonds;
                                            break;
                          case CLUBS : OUT = OUT + "CLUBS";
                                            CardImage = BlackJackAngelina.EIGHT_clubs;
                                            break;
                          default : OUT = OUT + "ERROR!"; break;
                        }
                        break;

         case NINE : OUT = OUT + "NINE of ";
                     switch(TheFace)
                     {
                        case SPADES : OUT = OUT + "SPADES";
                                      CardImage = BlackJackAngelina.NINE_spades;
                                      break;
                        case HEARTS : OUT = OUT + "HEARTS";
                                      CardImage = BlackJackAngelina.NINE_hearts;
                                      break;
                        case DIAMONDS : OUT = OUT + "DIAMONDS";
                                        CardImage = BlackJackAngelina.NINE_diamonds;
                                        break;
                        case CLUBS : OUT = OUT + "CLUBS";
                                     CardImage = BlackJackAngelina.NINE_clubs;
                                     break;
                        default : OUT = OUT + "ERROR!"; break;
                     }
                     break;

        case TEN : OUT = OUT + "TEN of ";
                   switch(TheFace)
                   {
                      case SPADES : OUT = OUT + "SPADES";
                                    CardImage = BlackJackAngelina.TEN_spades;
                                    break;
                      case HEARTS : OUT = OUT + "HEARTS";
                                            CardImage = BlackJackAngelina.TEN_hearts;
                                            break;
                      case DIAMONDS : OUT = OUT + "DIAMONDS";
                                            CardImage = BlackJackAngelina.TEN_diamonds;
                                            break;
                      case CLUBS : OUT = OUT + "CLUBS";
                                            CardImage = BlackJackAngelina.TEN_clubs;
                                            break;
                      default : OUT = OUT + "ERROR!"; break;
                    }
                    break;

        case JACK :  OUT = OUT + "JACK of ";
                     switch(TheFace)
                     {
                        case SPADES : OUT = OUT + "SPADES";
                                      CardImage = BlackJackAngelina.JACK_spades;
                                      break;
                        case HEARTS : OUT = OUT + "HEARTS";
                                      CardImage = BlackJackAngelina.JACK_hearts;
                                      break;
                        case DIAMONDS : OUT = OUT + "DIAMONDS";
                                        CardImage = BlackJackAngelina.JACK_diamonds;
                                        break;
                        case CLUBS : OUT = OUT + "CLUBS";
                                     CardImage = BlackJackAngelina.JACK_clubs;
                                     break;
                        default : OUT = OUT + "ERROR!"; break;
                     }
                     break;

        case QUEEN : OUT = OUT + "QUEEN of ";
                     switch(TheFace)
                     {
                        case SPADES : OUT = OUT + "SPADES";
                                      CardImage = BlackJackAngelina.QUEEN_spades;
                                      break;
                        case HEARTS : OUT = OUT + "HEARTS";
                                      CardImage = BlackJackAngelina.QUEEN_hearts;
                                      break;
                        case DIAMONDS : OUT = OUT + "DIAMONDS";
                                        CardImage = BlackJackAngelina.QUEEN_diamonds;
                                        break;
                        case CLUBS : OUT = OUT + "CLUBS";
                                     CardImage = BlackJackAngelina.QUEEN_clubs;
                                     break;
                        default : OUT = OUT + "ERROR!"; break;
                     }
                     break;

        case KING : OUT = OUT + "KING of ";
                    switch(TheFace)
                    {
                       case SPADES : OUT = OUT + "SPADES";
                                     CardImage = BlackJackAngelina.KING_spades;
                                     break;
                       case HEARTS : OUT = OUT + "HEARTS";
                                     CardImage = BlackJackAngelina.KING_hearts;
                                     break;
                       case DIAMONDS : OUT = OUT + "DIAMONDS";
                                       CardImage = BlackJackAngelina.KING_diamonds;
                                       break;
                       case CLUBS : OUT = OUT + "CLUBS";
                                    CardImage = BlackJackAngelina.KING_clubs;
                                    break;
                       default : OUT = OUT + "ERROR!"; break;
                    }
                    break;

        case ACE : OUT = OUT + "ACE of ";
                   switch(TheFace)
                   {
                      case SPADES : OUT = OUT + "SPADES";
                                    CardImage = BlackJackAngelina.ACE_spades;
                                    break;
                      case HEARTS : OUT = OUT + "HEARTS";
                                    CardImage = BlackJackAngelina.ACE_hearts;
                                    break;
                      case DIAMONDS : OUT = OUT + "DIAMONDS";
                                      CardImage = BlackJackAngelina.ACE_diamonds;
                                      break;
                      case CLUBS : OUT = OUT + "CLUBS";
                                         CardImage = BlackJackAngelina.ACE_clubs;
                                         break;
                      default : OUT = OUT + "ERROR!"; break;
                   }
                   break;

         default : OUT = OUT + "ERROR!"; break;
       }

       OUT = OUT + ". Points = " + PointValue + ".";

       return OUT;
}

//-----------------------------------------------------------------------------

       //Public Accessors
       public int GetFace() { return TheFace; }
       public int GetCard() { return TheCard; }
       public int GetPointValue() { return PointValue; }
       public boolean GetDrawn() { return Drawn; }
       public Image GetImage() { return CardImage; }

       public void SetFace(int x) { TheFace = x; }
       public void SetCard(int x) { TheCard = x; }
       public void SetPointValue(int x) { PointValue = x; }
       public void SetDrawn(boolean x) { Drawn = x; }
       public void SetImage(Image x) { CardImage = x; }

//-----------------------------------------------------------------------------

       //Private Data Members
       private int TheFace;
       private int TheCard;
       private int PointValue = 0;
       private boolean Drawn = false;
       private Image CardImage;

}//close CARD class
