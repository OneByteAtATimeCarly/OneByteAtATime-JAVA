
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.image.BufferedImage;
import java.net.URL;
import java.util.Random;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class BlackJackAngelina extends javax.swing.JApplet
{
       //Globals
       public final int NUMCARDS = 13;
       public final int NUMFACES = 4;
       public final int NUMCARDSINDECK = 52;
       public final int MaxHandSize = 20;
       public final int NumCardsToStartWith = 2;
       public final int HouseLimit = 17;
       public final int MinimumBet = 5;
       public final int MaximumBet = 50;

       public Random PEACH;
       public String OUTPUT = " ";
       public boolean NeedName = true;
       public int ThePot = 0;
       public int TheBet = 0;

       //Build a Deck of CARDS
       public CARD[] DeckOfCards = new CARD[NUMCARDSINDECK];

       //Build the CardPlayers - For now just a DEALER and a PLAYER
       CardPlayer PLAYER = new CardPlayer();
       CardPlayer DEALER = new CardPlayer("Angelina","Female",true);

       public boolean DisplayAllDealerCards = false;
       public boolean CHEAT = false;
       public boolean STARTGAME = false;
       public boolean ANIMATECARDS = false;

//---------------------------------Declare Image Objects--------------------
       public boolean INTRO_Display = true;
       public boolean DrawBlank = false;
       public int DealerPhoto = 1;

       public static Image BACKGROUND;

       public static Image ACE_clubs;
       public static Image ACE_diamonds;
       public static Image ACE_hearts;
       public static Image ACE_spades;
       public static Image JACK_clubs;
       public static Image JACK_diamonds;
       public static Image JACK_hearts;
       public static Image JACK_spades;
       public static Image QUEEN_clubs;
       public static Image QUEEN_diamonds;
       public static Image QUEEN_hearts;
       public static Image QUEEN_spades;
       public static Image KING_clubs;
       public static Image KING_diamonds;
       public static Image KING_hearts;
       public static Image KING_spades;
       public static Image TWO_clubs;
       public static Image TWO_diamonds;
       public static Image TWO_hearts;
       public static Image TWO_spades;
       public static Image THREE_clubs;
       public static Image THREE_diamonds;
       public static Image THREE_hearts;
       public static Image THREE_spades;
       public static Image FOUR_clubs;
       public static Image FOUR_diamonds;
       public static Image FOUR_hearts;
       public static Image FOUR_spades;
       public static Image FIVE_clubs;
       public static Image FIVE_diamonds;
       public static Image FIVE_hearts;
       public static Image FIVE_spades;
       public static Image SIX_clubs;
       public static Image SIX_diamonds;
       public static Image SIX_hearts;
       public static Image SIX_spades;
       public static Image SEVEN_clubs;
       public static Image SEVEN_diamonds;
       public static Image SEVEN_hearts;
       public static Image SEVEN_spades;
       public static Image EIGHT_clubs;
       public static Image EIGHT_diamonds;
       public static Image EIGHT_hearts;
       public static Image EIGHT_spades;
       public static Image NINE_clubs;
       public static Image NINE_diamonds;
       public static Image NINE_hearts;
       public static Image NINE_spades;
       public static Image TEN_clubs;
       public static Image TEN_diamonds;
       public static Image TEN_hearts;
       public static Image TEN_spades;
       public static Image Joker;
       public static Image BlankCard;

       //The Dealer
       public static Image Angelina1;
       public static Image Angelina2;
       public static Image Angelina3;
       public static Image Angelina4;
       public static Image Angelina5;
       public static Image Angelina6;
       public static Image Angelina7;
       public static Image Angelina8;
       public static Image Angelina9;
       public static Image Angelina10;
       public static Image Angelina11;
       public static Image Angelina12;
       public static Image Angelina13;

       public Image AnimatedCards;

       //Declare MediaTracker to pre-load images
       MediaTracker TRACKER;

       //Sound - Part 1 - Add AudioClip Objects
       AudioClip Audio_Deal;
       AudioClip Audio_Shuffle;
       AudioClip Audio_Welcome;
       AudioClip Audio_DealerWins;
       AudioClip Audio_PlayerWins;
       AudioClip Audio_HitOrStay;
       AudioClip Audio_PlayerBusted;
       AudioClip Audio_DealerBusted;
       AudioClip Audio_Wager;
       AudioClip Audio_PlayerNailsIt;
       AudioClip Audio_DealerNailsIt;
       AudioClip Audio_TIE;

//---------------------------------------------------------------------------

     private URL Get_Location(String filename)
     {
             URL url = null;
             try { url = this.getClass().getResource(filename); }
             catch (Exception e) { /*STUFF*/ }
             return url;
     }

//---------------------------------------------------------------------------

    /** Initializes the applet BlackJackAngelina */
    public void init() {
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {
                public void run() {
                    initComponents();
                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        TA_Output.setText("\n Click the \"START\" button to begin a game.");

        B_Hit.setEnabled(false);
        B_Stay.setEnabled(false);
        B_Deal.setEnabled(false);
        B_Bet.setEnabled(false);
        B_Quit.setEnabled(false);

        SetUpCardImages();
        SetUpDealerImages();
        SetUpAudioFiles();

        try { TRACKER.waitForAll(); }
        catch(Exception e) {  }
        
        //Set Applet's Background Color
        Color BJ_BG_Color = new Color(0,135,0);
        Container BlackJack_BackGround = getContentPane();
        BlackJack_BackGround.setBackground(BJ_BG_Color);

        /*For JApplet Background Images
        To use a background Image in NetBeans, use a JLabel and set the "Icon"
        property to the background file. This will cause it to use an ImageIcon
        from the AWT. Then position the lable behind your other SWING
        components and set opacity as desired. Size it to the Applet's BG.
        Example:
         

        this.setBounds(0, 0, 725, 600);
        L_Background.setIcon(new javax.swing.ImageIcon(
         getClass().getResource("/BACKGROUND.jpg")));
        L_Background.setBounds(0, 0, getWidth(), getHeight());

       */
    }

//---------------------------------------------------------------------------

    public void SetUpCardImages()
    {
           //Set Up Image Objects
           TRACKER = new MediaTracker(this);

           ACE_clubs = getImage(Get_Location("CARDS/ACE_clubs.jpg"));
           ACE_diamonds = getImage(Get_Location("CARDS/ACE_diamonds.jpg"));
           ACE_hearts = getImage(Get_Location("CARDS/ACE_hearts.jpg"));
           ACE_spades = getImage(Get_Location("CARDS/ACE_spades.jpg"));
           JACK_clubs = getImage(Get_Location("CARDS/JACK_clubs.jpg"));
           JACK_diamonds = getImage(Get_Location("CARDS/JACK_diamonds.jpg"));
           JACK_hearts = getImage(Get_Location("CARDS/JACK_hearts.jpg"));
           JACK_spades = getImage(Get_Location("CARDS/JACK_spades.jpg"));
           QUEEN_clubs = getImage(Get_Location("CARDS/QUEEN_clubs.jpg"));
           QUEEN_diamonds = getImage(Get_Location("CARDS/QUEEN_diamonds.jpg"));
           QUEEN_hearts = getImage(Get_Location("CARDS/QUEEN_hearts.jpg"));
           QUEEN_spades = getImage(Get_Location("CARDS/QUEEN_spades.jpg"));
           KING_clubs = getImage(Get_Location("CARDS/KING_clubs.jpg"));
           KING_diamonds = getImage(Get_Location("CARDS/KING_diamonds.jpg"));
           KING_hearts = getImage(Get_Location("CARDS/KING_hearts.jpg"));
           KING_spades = getImage(Get_Location("CARDS/KING_spades.jpg"));
           TWO_clubs = getImage(Get_Location("CARDS/TWO_clubs.jpg"));
           TWO_diamonds = getImage(Get_Location("CARDS/TWO_diamonds.jpg"));
           TWO_hearts = getImage(Get_Location("CARDS/TWO_hearts.jpg"));
           TWO_spades = getImage(Get_Location("CARDS/TWO_spades.jpg"));
           THREE_clubs = getImage(Get_Location("CARDS/THREE_clubs.jpg"));
           THREE_diamonds = getImage(Get_Location("CARDS/THREE_diamonds.jpg"));
           THREE_hearts = getImage(Get_Location("CARDS/THREE_hearts.jpg"));
           THREE_spades = getImage(Get_Location("CARDS/THREE_spades.jpg"));
           FOUR_clubs = getImage(Get_Location("CARDS/FOUR_clubs.jpg"));
           FOUR_diamonds = getImage(Get_Location("CARDS/FOUR_diamonds.jpg"));
           FOUR_hearts = getImage(Get_Location("CARDS/FOUR_hearts.jpg"));
           FOUR_spades = getImage(Get_Location("CARDS/FOUR_spades.jpg"));
           FIVE_clubs = getImage(Get_Location("CARDS/FIVE_clubs.jpg"));
           FIVE_diamonds = getImage(Get_Location("CARDS/FIVE_diamonds.jpg"));
           FIVE_hearts = getImage(Get_Location("CARDS/FIVE_hearts.jpg"));
           FIVE_spades = getImage(Get_Location("CARDS/FIVE_spades.jpg"));
           SIX_clubs = getImage(Get_Location("CARDS/SIX_clubs.jpg"));
           SIX_diamonds = getImage(Get_Location("CARDS/SIX_diamonds.jpg"));
           SIX_hearts = getImage(Get_Location("CARDS/SIX_hearts.jpg"));
           SIX_spades = getImage(Get_Location("CARDS/SIX_spades.jpg"));
           SEVEN_clubs = getImage(Get_Location("CARDS/SEVEN_clubs.jpg"));
           SEVEN_diamonds = getImage(Get_Location("CARDS/SEVEN_diamonds.jpg"));
           SEVEN_hearts = getImage(Get_Location("CARDS/SEVEN_hearts.jpg"));
           SEVEN_spades = getImage(Get_Location("CARDS/SEVEN_spades.jpg"));
           EIGHT_clubs = getImage(Get_Location("CARDS/EIGHT_clubs.jpg"));
           EIGHT_diamonds = getImage(Get_Location("CARDS/EIGHT_diamonds.jpg"));
           EIGHT_hearts = getImage(Get_Location("CARDS/EIGHT_hearts.jpg"));
           EIGHT_spades = getImage(Get_Location("CARDS/EIGHT_spades.jpg"));
           NINE_clubs = getImage(Get_Location("CARDS/NINE_clubs.jpg"));
           NINE_diamonds = getImage(Get_Location("CARDS/NINE_diamonds.jpg"));
           NINE_hearts = getImage(Get_Location("CARDS/NINE_hearts.jpg"));
           NINE_spades = getImage(Get_Location("CARDS/NINE_spades.jpg"));
           TEN_clubs = getImage(Get_Location("CARDS/TEN_clubs.jpg"));
           TEN_diamonds = getImage(Get_Location("CARDS/TEN_diamonds.jpg"));
           TEN_hearts = getImage(Get_Location("CARDS/TEN_hearts.jpg"));
           TEN_spades = getImage(Get_Location("CARDS/TEN_spades.jpg"));
           Joker = getImage(Get_Location("CARDS/Joker.jpg"));
           BlankCard = getImage(Get_Location("CARDS/BlankCard.jpg"));

           AnimatedCards = getImage(Get_Location("Animations/Cards1.gif"));

              TRACKER.addImage(ACE_clubs,1);
              TRACKER.addImage(ACE_diamonds,2);
              TRACKER.addImage(ACE_hearts,3);
              TRACKER.addImage(ACE_spades,4);
              TRACKER.addImage(JACK_clubs,5);
              TRACKER.addImage(JACK_diamonds,6);
              TRACKER.addImage(JACK_hearts,7);
              TRACKER.addImage(JACK_spades,8);
              TRACKER.addImage(QUEEN_clubs,9);
              TRACKER.addImage(QUEEN_diamonds,10);
              TRACKER.addImage(QUEEN_hearts,11);
              TRACKER.addImage(QUEEN_spades,12);
              TRACKER.addImage(KING_clubs,13);
              TRACKER.addImage(KING_diamonds,14);
              TRACKER.addImage(KING_hearts,15);
              TRACKER.addImage(KING_spades,16);
              TRACKER.addImage(TWO_clubs,17);
              TRACKER.addImage(TWO_diamonds,18);
              TRACKER.addImage(TWO_hearts,19);
              TRACKER.addImage(TWO_spades,20);
              TRACKER.addImage(THREE_clubs,21);
              TRACKER.addImage(THREE_diamonds,22);
              TRACKER.addImage(THREE_hearts,23);
              TRACKER.addImage(THREE_spades,24);
              TRACKER.addImage(FOUR_clubs,25);
              TRACKER.addImage(FOUR_diamonds,26);
              TRACKER.addImage(FOUR_hearts,27);
              TRACKER.addImage(FOUR_spades,28);
              TRACKER.addImage(FIVE_clubs,29);
              TRACKER.addImage(FIVE_diamonds,30);
              TRACKER.addImage(FIVE_hearts,31);
              TRACKER.addImage(FIVE_spades,32);
              TRACKER.addImage(SIX_clubs,33);
              TRACKER.addImage(SIX_diamonds,34);
              TRACKER.addImage(SIX_hearts,35);
              TRACKER.addImage(SIX_spades,36);
              TRACKER.addImage(SEVEN_clubs,37);
              TRACKER.addImage(SEVEN_diamonds,38);
              TRACKER.addImage(SEVEN_hearts,39);
              TRACKER.addImage(SEVEN_spades,40);
              TRACKER.addImage(EIGHT_clubs,41);
              TRACKER.addImage(EIGHT_diamonds,42);
              TRACKER.addImage(EIGHT_hearts,43);
              TRACKER.addImage(EIGHT_spades,44);
              TRACKER.addImage(NINE_clubs,45);
              TRACKER.addImage(NINE_diamonds,46);
              TRACKER.addImage(NINE_hearts,47);
              TRACKER.addImage(NINE_spades,48);
              TRACKER.addImage(TEN_clubs,49);
              TRACKER.addImage(TEN_diamonds,50);
              TRACKER.addImage(TEN_hearts,51);
              TRACKER.addImage(TEN_spades,52);
              TRACKER.addImage(Joker,53);
              TRACKER.addImage(BlankCard,53);

              TRACKER.addImage(AnimatedCards,54);
    }

//----------------------------------------------------------------------------

    public void SetUpDealerImages()
    {
           Angelina1 = getImage(Get_Location("DEALER/Angelina1.jpg"));
           Angelina2 = getImage(Get_Location("DEALER/Angelina2.jpg"));
           Angelina3 = getImage(Get_Location("DEALER/Angelina3.jpg"));
           Angelina4 = getImage(Get_Location("DEALER/Angelina4.jpg"));
           Angelina5 = getImage(Get_Location("DEALER/Angelina5.jpg"));
           Angelina6 = getImage(Get_Location("DEALER/Angelina6.jpg"));
           Angelina7 = getImage(Get_Location("DEALER/Angelina7.jpg"));
           Angelina8 = getImage(Get_Location("DEALER/Angelina8.jpg"));
           Angelina9 = getImage(Get_Location("DEALER/Angelina9.jpg"));
           Angelina10 = getImage(Get_Location("DEALER/Angelina10.jpg"));
           Angelina11 = getImage(Get_Location("DEALER/Angelina11.jpg"));
           Angelina12 = getImage(Get_Location("DEALER/Angelina12.jpg"));
           Angelina13 = getImage(Get_Location("DEALER/Angelina13.jpg"));

              TRACKER.addImage(Angelina1,55);
              TRACKER.addImage(Angelina2,56);
              TRACKER.addImage(Angelina3,57);
              TRACKER.addImage(Angelina4,58);
              TRACKER.addImage(Angelina5,59);
              TRACKER.addImage(Angelina6,60);
              TRACKER.addImage(Angelina7,61);
              TRACKER.addImage(Angelina8,62);
              TRACKER.addImage(Angelina9,63);
              TRACKER.addImage(Angelina10,64);
              TRACKER.addImage(Angelina11,65);
              TRACKER.addImage(Angelina12,66);
              TRACKER.addImage(Angelina13,67);
    }
//---------------------------------------------------------------------------

public void SetUpAudioFiles()
{
       Audio_Deal = getAudioClip(Get_Location("Sounds/Deal.au"));
       Audio_Shuffle = getAudioClip(Get_Location("Sounds/Shuffle.au"));
       Audio_Welcome = getAudioClip(Get_Location("Sounds/Welcome.au"));
       Audio_DealerWins = getAudioClip(Get_Location("Sounds/DealerWins.au"));
       Audio_PlayerWins = getAudioClip(Get_Location("Sounds/PlayerWins.au"));
       Audio_HitOrStay = getAudioClip(Get_Location("Sounds/HitOrStay.au"));
       Audio_PlayerBusted = getAudioClip(Get_Location("Sounds/PlayerBusted.au"));
       Audio_DealerBusted = getAudioClip(Get_Location("Sounds/DealerBusted.au"));
       Audio_Wager = getAudioClip(Get_Location("Sounds/Wager.au"));
       Audio_PlayerNailsIt = getAudioClip(
                             Get_Location("Sounds/PlayerNailsIt.au"));
       Audio_DealerNailsIt = getAudioClip(
                             Get_Location("Sounds/DealerNailsIt.au"));
       Audio_TIE = getAudioClip(Get_Location("Sounds/Tie.au"));    
}

//----------------------------------------------------------------------------

public void ChangeAngelinaPix()
{
       DealerPhoto++;
       if(DealerPhoto > 13)
       { DealerPhoto = 1; }

       Graphics X = getGraphics();

       paint(X);
}

//---------------------------------------------------------------------------

public void DrawBlankCards()
{
       Graphics AppletBackground = getGraphics();

       //Dealer Card Positions
       AppletBackground.drawImage(BlankCard,25,55,60,100,this);   //1st Card
       AppletBackground.drawImage(BlankCard,88,55,60,100,this);   //2nd Card
       AppletBackground.drawImage(BlankCard,151,55,60,100,this);  //3rd Card
       AppletBackground.drawImage(BlankCard,214,55,60,100,this);  //4th Card

       //Player Card Positions  295
       AppletBackground.drawImage(BlankCard,395,55,60,100,this);  //1st Card
       AppletBackground.drawImage(BlankCard,458,55,60,100,this);  //2nd Card
       AppletBackground.drawImage(BlankCard,521,55,60,100,this);  //3rd Card
       AppletBackground.drawImage(BlankCard,584,55,60,100,this);  //4th Card

}

//---------------------------------------------------------------------------

    public void paint(Graphics ThePaintBrush)
    {
           super.paint(ThePaintBrush);
           
           ThePaintBrush.setColor(new Color(0, 0, 0));
           ThePaintBrush.drawRect(20, 43, 330, 133);  //Dealer Card Box
           ThePaintBrush.drawRect(390, 43, 330, 133); //Player Card Box
           ThePaintBrush.drawRect(385, 305, 50, 170); //Button Border Box

           DrawDealer();

           if(INTRO_Display)
           {
              ShowExampleHand();
              DrawSomeCards();
           }

           if(DrawBlank) { DrawBlankCards(); }

           if(ANIMATECARDS)
           {
               ThePaintBrush.drawImage(AnimatedCards,150,55,75,95,this);
               ThePaintBrush.drawImage(AnimatedCards,520,55,75,95,this);
           }
    }

//--------------------------------------------------------------------

public void DrawBlankHand()
{
       DrawBlank = true;
       Graphics AppletBackground = getGraphics();
       paint(AppletBackground);
       DrawBlank = false;
}

//--------------------------------------------------------------------

    public void ShowExampleHand()
    {       
           Graphics AppletBackground = getGraphics();

           //Dealer Card Positions
           AppletBackground.drawImage(Joker,25,55,60,100,this);          //1st 
           AppletBackground.drawImage(ACE_clubs,88,55,60,100,this);      //2nd 
           AppletBackground.drawImage(KING_hearts,151,55,60,100,this);   //3rd 
           AppletBackground.drawImage(FIVE_diamonds,214,55,60,100,this); //4th

           //Player Card Positions  295
           AppletBackground.drawImage(QUEEN_diamonds,395,55,60,100,this); //1st
           AppletBackground.drawImage(Joker,458,55,60,100,this);          //2nd
           AppletBackground.drawImage(JACK_clubs,521,55,60,100,this);     //3rd
           AppletBackground.drawImage(SEVEN_hearts,584,55,60,100,this);   //4th
    }

//--------------------------------------------------------------------

    //Just an Example of Using the drawPolygon and fillPolygon functions
    public void DrawSomeCards()
    {
           Graphics AppletBackground = getGraphics();
           
           DrawCard1(AppletBackground);
           DrawCard2(AppletBackground);
           DrawCard3(AppletBackground);
    }

//--------------------------------------------------------------------

public void DrawCard1(Graphics X)
{
           //1st Card - ACE of DIAMONDS
           X.setColor(Color.BLACK);
           X.drawRoundRect(30,300,60,95,12,12);
           X.setColor(Color.RED);

           //Dealer Top RIGHT
           int x1Points[] = {68,76,84,76,68};
           int y1Points[] = {320,308,320,332,320};
           X.drawPolygon(x1Points, y1Points, x1Points.length);

           //Dealer Top LEFT
           int x2Points[] = {33,41,49,41,33};
           int y2Points[] = {320,308,320,332,320};
           X.fillPolygon(x2Points, y2Points, x2Points.length);

           //Dealer Bottom RIGHT
           int x3Points[] = {68,76,84,76,68};
           int y3Points[] = {374,362,374,386,374};
           X.fillPolygon(x3Points, y3Points, x3Points.length);

           //Dealer Bottom LEFT
           int x4Points[] = {33,41,49,41,33};
           int y4Points[] = {374,362,374,386,374};
           X.drawPolygon(x4Points, y4Points, x4Points.length);

           X.setColor(Color.BLACK);
           X.drawString("ACE",50,350);
}

//--------------------------------------------------------------------

public void DrawCard2(Graphics X)
{
           //2nd DEALER Card - DIAMONDS
           X.setColor(Color.BLACK);
           X.fillRoundRect(95,300,60,95,12,12);
           X.setColor(Color.RED);

           //Dealer Top RIGHT
           int x5Points[] = {133,141,149,141,133};
           int y5Points[] = {320,308,320,332,320};
           X.drawPolygon(x5Points, y5Points, x5Points.length);

           //Dealer Top LEFT
           int x6Points[] = {98,106,114,106,98};
           int y6Points[] = {320,308,320,332,320};
           X.fillPolygon(x6Points, y6Points, x6Points.length);

           //Dealer Bottom RIGHT
           int x7Points[] = {133,141,149,141,133};
           int y7Points[] = {374,362,374,386,374};
           X.fillPolygon(x7Points, y7Points, x7Points.length);

           //Dealer Bottom LEFT
           int x8Points[] = {98,106,114,106,98};
           int y8Points[] = {374,362,374,386,374};
           X.drawPolygon(x8Points, y8Points, x8Points.length);

           X.setColor(Color.WHITE);
           X.drawString("KING",112,350);
}

//--------------------------------------------------------------------

public void DrawCard3(Graphics X)
{
           //3rd DEALER Card - DIAMONDS
           X.setColor(Color.BLACK);
           X.drawRoundRect(160,300,60,95,12,12);
           X.setColor(Color.RED);

           //Dealer Top RIGHT
           int x9Points[] = {198,206,214,206,198};
           int y9Points[] = {320,308,320,332,320};
           X.drawPolygon(x9Points, y9Points, x9Points.length);

           //Dealer Top LEFT
           int x10Points[] = {166,174,182,174,166};
           int y10Points[] = {320,308,320,332,320};
           X.fillPolygon(x10Points, y10Points, x10Points.length);

           //Dealer Bottom RIGHT
           int x11Points[] = {198,206,214,206,198};
           int y11Points[] = {374,362,374,386,374};
           X.fillPolygon(x11Points, y11Points, x11Points.length);

           //Dealer Bottom LEFT
           int x12Points[] = {166,174,182,174,166};
           int y12Points[] = {374,362,374,386,374};
           X.drawPolygon(x12Points, y12Points, x12Points.length);

           X.setColor(Color.BLACK);
           X.drawString("QUEEN",170,350);
}

//--------------------------------------------------------------------

    public void ClearBackground()
    {
           Graphics AppletBackground = getGraphics();
           AppletBackground.setColor(new Color(0, 135, 0));
           AppletBackground.fillRect(22, 45, 328, 131);  //DEALER box
           AppletBackground.fillRect(392, 45, 328, 131); //PLAYER box  
    }

//--------------------------------------------------------------------

public void DrawDealer()
{
       Graphics BJ_BG = getGraphics();
       
       switch(DealerPhoto)
       {
           case 1 : BJ_BG.drawImage(Angelina1,520,263,115,211,this); break;
           case 2 : BJ_BG.drawImage(Angelina2,520,263,115,211,this); break;
           case 3 : BJ_BG.drawImage(Angelina3,520,263,115,211,this); break;
           case 4 : BJ_BG.drawImage(Angelina4,520,263,115,211,this); break;
           case 5 : BJ_BG.drawImage(Angelina5,520,263,115,211,this); break;
           case 6 : BJ_BG.drawImage(Angelina6,520,263,115,211,this); break;
           case 7 : BJ_BG.drawImage(Angelina7,520,263,115,211,this); break;
           case 8 : BJ_BG.drawImage(Angelina8,520,263,115,211,this); break;
           case 9 : BJ_BG.drawImage(Angelina9,520,263,115,211,this); break;
           case 10 : BJ_BG.drawImage(Angelina10,520,263,115,211,this); break;
           case 11 : BJ_BG.drawImage(Angelina11,520,263,115,211,this); break;
           case 12 : BJ_BG.drawImage(Angelina12,520,263,115,211,this); break;
           case 13 : BJ_BG.drawImage(Angelina13,520,263,115,211,this); break;
       }
 
}

//--------------------------------------------------------------------

    public void Initialize()
    {
           DEALER.SetMoney(100);
           PLAYER.SetMoney(100);
           PLAYER.SetScore(0);
           DEALER.SetScore(0);
           TheBet = 0;

           UpdateHoldings();

           B_Start.setEnabled(true);
           B_Hit.setEnabled(false);
           B_Stay.setEnabled(false);
           B_Bet.setEnabled(false);
           B_Deal.setEnabled(false);

           //Start populating deck with DEUCES
           int CardType = CARD.DEUCE;

           //Populate the Deck Array With Card Values
           OUTPUT = "\n ---- Making 52 CARD Deck Now ----\n";

           //Populate Array of CARDs
           for(int CardInDeck = 0; CardInDeck < NUMCARDSINDECK; )
           {
               //For each card value give it 4 faces
               for(int CardFace = 0; CardFace < NUMFACES; CardFace++)
               {
                       DeckOfCards[CardInDeck] = new CARD(CardType,CardFace);
                       OUTPUT = OUTPUT + DeckOfCards[CardInDeck].DisplayCard();
                       CardInDeck++;
               }

                  CardType++;
           }

              OUTPUT = OUTPUT + "\n\n     ---- DONE! ----\n";

              TA_Output.setText(OUTPUT);
    }

//---------------------------------------------------------------------------

public void UpdateHoldings()
{
       L_PlayerHoldingsBox.setText(Integer.toString(PLAYER.GetMoney()));
       L_DealerHoldingsBox.setText(Integer.toString(DEALER.GetMoney()));
       L_ThePotBox.setText(Integer.toString(ThePot));
       L_TheBetBox.setText(Integer.toString(TheBet));
       L_DealerWinsBox.setText(Integer.toString(DEALER.GetScore()));
       L_PlayerWinsBox.setText(Integer.toString(PLAYER.GetScore()));
       L_PlayerHand.setText(PLAYER.GetName() + "'s Hand");
       L_PlayerHoldings.setText(PLAYER.GetName() + "'s Holdings");
       L_PlayerWins.setText(PLAYER.GetName() + "'s Wins");
}
//---------------------------------------------------------------------------

    public void Sequence()
    {

           if(DEALER.GetMoney() > MinimumBet && PLAYER.GetMoney() > MinimumBet)
           {
                  Game();
           }

           else
           {
               if(PLAYER.GetMoney() < MinimumBet)
               {
                    OUTPUT = OUTPUT + "\n\n Sorry, you can no longer make the "
                           + "\n minimum bet. Time to call it quits.";
               }

               else
               {
                    OUTPUT = OUTPUT + "\n\n Sorry, the House can no longer "
                           + "afford\n to play against someone with your "
                           + "talents.\n Well done! Go bankrupt some other "
                           + "casino.\n You win!";
               }

               OUTPUT = OUTPUT + "\n\n Click \"START\" to play again...";

               TA_Output.setText(OUTPUT);
               B_Start.setEnabled(true);
               B_Hit.setEnabled(false);
               B_Stay.setEnabled(false);
               B_Bet.setEnabled(false);
               B_Deal.setEnabled(false);
           }
    }

//----------------------------------------------------------------------------

 public void NewHand()
 {
        //Initialize Values for a Round
        DEALER.SetPoints(0);
        PLAYER.SetPoints(0);
        DEALER.SetNumCards(0);
        PLAYER.SetNumCards(0);
        DEALER.SetStay(false);
        PLAYER.SetStay(false);
        DisplayAllDealerCards = false;

        TA_Output.setText("\n Placing all CARDs back into the deck.");

        //Remove All CARDs from CardPlayer's HANDS
        for(int x = 0; x < MaxHandSize; x++)
        {
                    DEALER.HAND[x] = null;
                    PLAYER.HAND[x] = null;
        }

        //Reset DeckOfCards
        for(int CardInDeck = 0; CardInDeck < NUMCARDSINDECK; CardInDeck++)
        {
              DeckOfCards[CardInDeck].SetDrawn(false);
        }

 }//close function

//----------------------------------------------------------------------------

       public void Game()
       {
              NewHand();

              OUTPUT = "\n\n The Dealer shuffles the DECK and prepares \n"
                              + " to deal out the CARDs...\n"
                              + "\n Enter the amount you want to \n"
                              + " bet by clicking \"BET\".\n";

              TA_Output.setText(OUTPUT);
              B_Bet.setEnabled(true);

              DrawBlankHand();

              Audio_Shuffle.play();
       }

//----------------------------------------------------------------------

       public void DRAW(CardPlayer WHOEVER)
       {
              //Offset for fencepost
              int ACard = (PEACH.nextInt(NUMCARDSINDECK) + 1) - 1;

              //Find a Card the was not already Drawn
              while(DeckOfCards[ACard].GetDrawn())
              { ACard = (PEACH.nextInt(NUMCARDSINDECK) + 1) - 1; }

              //Mark Card as Drawn so it's no longer available
              DeckOfCards[ACard].SetDrawn(true);

              //Is the CardPlayer the DEALER?
              if(WHOEVER.GetDealer())
              {
                  DEALER.HAND[DEALER.GetNumCards()] = DeckOfCards[ACard];

                  DEALER.SetPoints(DEALER.GetPoints() +
                         DEALER.HAND[DEALER.GetNumCards()].GetPointValue());

                  DEALER.SetNumCards(DEALER.GetNumCards() + 1);
              }
              else
              {
                  PLAYER.HAND[PLAYER.GetNumCards()] = DeckOfCards[ACard];

                  PLAYER.SetPoints(PLAYER.GetPoints() +
                         PLAYER.HAND[PLAYER.GetNumCards()].GetPointValue());

                  PLAYER.SetNumCards(PLAYER.GetNumCards() + 1);
              }
       }

//----------------------------------------------------------------------------
       public void DisplayHand(CardPlayer WHOEVER)
       {
              Graphics AppletBackground = getGraphics();

              int Horizontal = 0;

              if(WHOEVER.GetDealer())
              {
                  OUTPUT = OUTPUT
                         + "\n " + DEALER.GetName() + "'s Hand (DEALER):";

                  Horizontal = 25; //Starting X position of 1st dealer card

                  if(DisplayAllDealerCards || CHEAT)
                  {
                      //Display all the Dealer's CARDs
                      for(int x = 0; x < MaxHandSize; x++)
                      {
                          if(DEALER.HAND[x]!= null)
                          {
                             OUTPUT = OUTPUT + DEALER.HAND[x].DisplayCard();
                             AppletBackground.drawImage(
                             DEALER.HAND[x].GetImage(),Horizontal,55,60,100,this);
                             Horizontal = Horizontal + 63; //(Move next card over)
                          }
                          else
                          { break; }
                      }

                      OUTPUT = OUTPUT + "\n " + DEALER.GetName()
                             + "'s total points = " + DEALER.GetPoints() + ".\n";

                  }
                  else
                  {
                      //Hide 1st CARD (Element 0)
                      OUTPUT = OUTPUT
                             + "\n     A Hidden CARD! What could it be?";

                      //1st Card is BlankCard
                      AppletBackground.drawImage(
                      BlankCard,Horizontal,55,60,100,this);
                      Horizontal = Horizontal + 63;

                      for(int x = 1; x < MaxHandSize; x++)
                      {
                          if(DEALER.HAND[x]!= null)
                          {
                             OUTPUT = OUTPUT + DEALER.HAND[x].DisplayCard();
                             AppletBackground.drawImage(
                             DEALER.HAND[x].GetImage(),Horizontal,55,60,100,this);
                             Horizontal = Horizontal + 63; //(Move next card over)
                          }
                          else
                          { break; }
                      }

                      OUTPUT = OUTPUT + "\n " + DEALER.GetName()
                             + "'s total points = ??? (HIDDEN).\n";
                  }
                  
              }//close if for DEALER
              
              else
              {   //If not DEALER must be PLAYER
                  OUTPUT = OUTPUT + "\n " + PLAYER.GetName() + "'s  Hand:";

                  Horizontal = 395; //Starting X position of 1st player card

                  for(int x = 0; x < MaxHandSize; x++)
                  {
                      if(PLAYER.HAND[x]!= null)
                      {
                          OUTPUT = OUTPUT + PLAYER.HAND[x].DisplayCard();
                          AppletBackground.drawImage(
                          PLAYER.HAND[x].GetImage(),Horizontal,55,60,100,this);
                          Horizontal = Horizontal + 63; //(Move next card over)
                      }
                      else { break; }
                  }

                  OUTPUT = OUTPUT + "\n " + PLAYER.GetName() + "'s total"
                  + " points = " + PLAYER.GetPoints() + ".\n";                  
              
              }//close else for PLAYER

              TA_Output.setText(OUTPUT);
              Audio_Deal.play();
       }

//---------------------------------------------------------------------------

        public void Deal()
        {
               //Player Goes First, play until Player or Dealer reaches 21,
               //Busts or both Player and Dealer decide to STAY
               UpdateHoldings();

                  OUTPUT = OUTPUT + "\n The DEALER, " + DEALER.GetName() 
                         + ", asks:\n\n" + "     " + PLAYER.GetName()
                         + ", do you want a HIT or will you STAY?\"\n\n"
                  + " Click a button to decide...";

                  TA_Output.setText(OUTPUT);

                  //Wait for button ActionEvent to proceed...
                  B_Hit.setEnabled(true);
                  B_Stay.setEnabled(true);
                  Audio_HitOrStay.play();

        }//close function
//---------------------------------------------------------------------------

public void DealerReaction()
{
       //Dealer Only Draws if Player Not Busted or Gets BlackJack (21).
       //PLAYER or DEALER stays by adding or removing those conditions.
       //In this example only the PLAYER can still draw if the DEALER
       //stays but the DEALER may not draw if the PLAYER stays.
       if(PLAYER.GetPoints() < 21 &&
          DEALER.GetPoints() < 21 &&
          !PLAYER.GetStay()
          )
       {
            if(DEALER.GetPoints() < HouseLimit)
            {
                 OUTPUT = OUTPUT + "\n     The Dealer decides to take a card.\n";
                 Hit(DEALER);
            }
            else
            {
                OUTPUT = OUTPUT + "\n     The Dealer decides to STAY.\n";
                DEALER.SetStay(true);
                DisplayHand(DEALER);
            }

            if(DEALER.GetPoints() < 21)
            { Deal(); }
            else
            { Determine_Winner(); }

       }//close if for Player Not Busted
       else
       {
           Determine_Winner();
       }

} //close DealerReaction function

//---------------------------------------------------------------------------

public void Determine_Winner()
{
       //Stop hiding Dealer's CARDs and POINTs
       DisplayAllDealerCards = true;

       OUTPUT = "\n Looks like that concludes this hand!" +
                "\n Closing HANDs:\n";

       DisplayHand(PLAYER);
       DisplayHand(DEALER);

         //***********************CONDITION 1**************************
         //Somebody NAILED it!
       if(PLAYER.GetPoints() == 21 || DEALER.GetPoints() == 21)
       {
              //If UNBELIEVEABLY there is a tie and BOTH NAIL it!
              if(PLAYER.GetPoints() == 21 && DEALER.GetPoints() == 21)
              {
                   OUTPUT = "\n Unthinkable! " + PLAYER.GetName()
                   + " and the DEALER both win NAILing 21!";
                   PLAYER.SetScore(PLAYER.GetScore() + 1);
                   DEALER.SetScore(DEALER.GetScore() + 1);
                   PLAYER.SetMoney(PLAYER.GetMoney() + (ThePot/2));
                   DEALER.SetMoney(DEALER.GetMoney() + (ThePot/2));
                   Audio_PlayerNailsIt.play();
                   Audio_DealerNailsIt.play();
              }
              //PLAYER NAILS it
              else if(PLAYER.GetPoints() == 21)
              {
                   OUTPUT = "\n " + PLAYER.GetName()
                   + " nails it and wins! A perfect 21!";
                   PLAYER.SetScore(PLAYER.GetScore() + 1);
                   PLAYER.SetMoney(PLAYER.GetMoney() + ThePot);
                   Audio_PlayerNailsIt.play();
              }
              //DEALER NAILS it
              else
              {
                   OUTPUT = OUTPUT + "\n " + DEALER.GetName()
                   + "(DEALER) nails it and wins! A perfect 21!";
                   DEALER.SetScore(DEALER.GetScore() + 1);
                   DEALER.SetMoney(DEALER.GetMoney() + ThePot);
                   Audio_DealerNailsIt.play();
              }

       }//close if somebody NAILS it

        //***********************CONDITION 2**************************
        //Somebody BUSTED!
       else if(PLAYER.GetPoints() > 21 || DEALER.GetPoints() > 21)
       {
             //Both the PLAYER and the DEALER BUSTED
             if(PLAYER.GetPoints() > 21 && DEALER.GetPoints() > 21)
             {
                   OUTPUT = OUTPUT + "\n     "
                   + PLAYER.GetName() + ", you AND the DEALER BUSTED!"
                   + "\n     NOBODY wins this round!";
                   Audio_PlayerBusted.play();
                   Audio_DealerBusted.play();
                   PLAYER.SetMoney(PLAYER.GetMoney() + (ThePot/2));
                   DEALER.SetMoney(DEALER.GetMoney() + (ThePot/2));
             }
             //PLAYER BUSTED
             else if(PLAYER.GetPoints() > 21)
             {
                   OUTPUT = OUTPUT + "\n     "
                   + PLAYER.GetName()
                   + ", you BUSTED! Sorry, you lost this round.";
                   Audio_PlayerBusted.play();
                   DEALER.SetScore(DEALER.GetScore() + 1);
                   DEALER.SetMoney(DEALER.GetMoney() + ThePot);
             }
             //DEALER BUSTED
             else
             {
                   OUTPUT = OUTPUT + "\n Dealer BUSTED. Woo-hoo!\n "
                   + PLAYER.GetName() + " wins this round.";
                   Audio_DealerBusted.play();
                   PLAYER.SetScore(PLAYER.GetScore() + 1);
                   PLAYER.SetMoney(PLAYER.GetMoney() + ThePot);
             }

       }//close if somebody BUSTED

       //***********************CONDITION 3**************************
       //PLAYER decides to STAY

       //Player STAYs, see whose hand is better
       else if(PLAYER.GetStay())
       {
            //It's a TIE
            if(PLAYER.GetPoints() == DEALER.GetPoints())
            {
               OUTPUT = OUTPUT + "\n Unbelieveable! "
                      + PLAYER.GetName() + " and the Dealer tie!";
               Audio_TIE.play();
                       //If a tie, give both a WIN, but neither gets the CASH!
               PLAYER.SetScore(PLAYER.GetScore() + 1);
               DEALER.SetScore(DEALER.GetScore() + 1);
               PLAYER.SetMoney(PLAYER.GetMoney() + (ThePot/2));
               DEALER.SetMoney(DEALER.GetMoney() + (ThePot/2));
           }
           //PLAYER has more points
           else if(PLAYER.GetPoints() > DEALER.GetPoints())
           {
                   OUTPUT = OUTPUT + "\n     " + PLAYER.GetName()
                          + "  wins this round with higher points!";
                   Audio_PlayerWins.play();
                   PLAYER.SetScore(PLAYER.GetScore() + 1);
                   PLAYER.SetMoney(PLAYER.GetMoney() + ThePot);
           }
           //DEALER has more points
           else
           {
                   OUTPUT = OUTPUT + "\n The Dealer wins this round!";
                   Audio_DealerWins.play();
                   DEALER.SetScore(DEALER.GetScore() + 1);
                   DEALER.SetMoney(DEALER.GetMoney() + ThePot);
           }

       }//close if PLAYER decides to STAY

       OUTPUT = OUTPUT + "\n\n This round of BlackJack is now complete!\n"
                                + " Click \"DEAL\" to continue...";
       TA_Output.setText(OUTPUT);
       ThePot = 0; //reset Pot
       TheBet = 0;

       UpdateHoldings();
       B_Deal.setEnabled(true);

}//close function SeeIfThereIsAWinner()

//---------------------------------------------------------------------------

     public void CheckForAces(CardPlayer WHOEVER)
     {
                 if(WHOEVER.GetPoints() > 21)
                 {
                    for(int x = 0; x < MaxHandSize; x++)
                    {
                       if(WHOEVER.HAND[x]!= null)
                       {
                           if(WHOEVER.HAND[x].GetCard() == CARD.ACE)
                           {
                               TA_Output.setText(
                               "\n This HAND is over 21 but an ACE was found!"
                               + "\n We'll convert the ACE from 11 points "
                               + "to 1 point!\n");
                               WHOEVER.HAND[x].SetPointValue(1);
                               break; //Set points of only 1st ACE to 1
                           }

                       }
                       else
                       { break; }

                    }//close for loop

                    //Recount Point values of cards after converting ACE 
                    WHOEVER.SetPoints(0);

                    for(int x = 0; x < MaxHandSize; x++)
                    {
                         if(WHOEVER.HAND[x]!= null)
                         {
                             WHOEVER.SetPoints(WHOEVER.GetPoints() +
                                     WHOEVER.HAND[x].GetPointValue());
                         }
                         else { break; }
                    }
                 }
     }//close 

//---------------------------------------------------------------------------

public void Hit(CardPlayer WHOEVER)
{     
              DRAW(WHOEVER);

              if(WHOEVER.GetDealer())
              {
                  CheckForAces(DEALER);

              }//close if WHOEVER == PLAYER

              //Then must be Dealer
              else
              {
                  CheckForAces(PLAYER);
              }

              DisplayHand(WHOEVER);

}//close Hit function

//---------------------------------------------------------------------------

    /** This method is called from within the init() method to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        L_Title = new javax.swing.JLabel();
        L_DealerHand = new javax.swing.JLabel();
        L_PlayerHand = new javax.swing.JLabel();
        L_DealerHoldings = new javax.swing.JLabel();
        L_DealerHoldingsBox = new javax.swing.JLabel();
        L_PlayerHoldings = new javax.swing.JLabel();
        L_PlayerHoldingsBox = new javax.swing.JLabel();
        L_TheBet = new javax.swing.JLabel();
        L_TheBetBox = new javax.swing.JLabel();
        L_ThePot = new javax.swing.JLabel();
        L_ThePotBox = new javax.swing.JLabel();
        SP_Output = new javax.swing.JScrollPane();
        TA_Output = new javax.swing.JTextArea();
        L_Commands = new javax.swing.JLabel();
        B_Deal = new javax.swing.JButton();
        B_Hit = new javax.swing.JButton();
        B_Stay = new javax.swing.JButton();
        B_Bet = new javax.swing.JButton();
        B_Help = new javax.swing.JButton();
        B_Quit = new javax.swing.JButton();
        B_Start = new javax.swing.JButton();
        B_Cheat = new javax.swing.JButton();
        L_Cheat = new javax.swing.JLabel();
        L_DealerWins = new javax.swing.JLabel();
        L_PlayerWins = new javax.swing.JLabel();
        L_DealerWinsBox = new javax.swing.JLabel();
        L_PlayerWinsBox = new javax.swing.JLabel();
        L_Background = new javax.swing.JLabel();

        getContentPane().setLayout(null);

        L_Title.setFont(new java.awt.Font("Blackadder ITC", 1, 30)); // NOI18N
        L_Title.setForeground(new java.awt.Color(255, 255, 255));
        L_Title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Title.setText("Black Jack Angelina");
        getContentPane().add(L_Title);
        L_Title.setBounds(224, 0, 300, 40);

        L_DealerHand.setFont(new java.awt.Font("Trebuchet MS", 0, 11)); // NOI18N
        L_DealerHand.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_DealerHand.setText("Dealer's Hand");
        getContentPane().add(L_DealerHand);
        L_DealerHand.setBounds(120, 28, 130, 14);

        L_PlayerHand.setFont(new java.awt.Font("Trebuchet MS", 0, 11)); // NOI18N
        L_PlayerHand.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerHand.setText("Player's Hand");
        getContentPane().add(L_PlayerHand);
        L_PlayerHand.setBounds(510, 28, 100, 14);

        L_DealerHoldings.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_DealerHoldings.setText("Dealer's Holdings");
        getContentPane().add(L_DealerHoldings);
        L_DealerHoldings.setBounds(25, 180, 83, 20);

        L_DealerHoldingsBox.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_DealerHoldingsBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_DealerHoldingsBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_DealerHoldingsBox);
        L_DealerHoldingsBox.setBounds(115, 180, 50, 20);

        L_PlayerHoldings.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_PlayerHoldings.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        L_PlayerHoldings.setText("Player's Holdings");
        getContentPane().add(L_PlayerHoldings);
        L_PlayerHoldings.setBounds(560, 180, 100, 20);

        L_PlayerHoldingsBox.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_PlayerHoldingsBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerHoldingsBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_PlayerHoldingsBox);
        L_PlayerHoldingsBox.setBounds(665, 180, 50, 20);

        L_TheBet.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_TheBet.setText("The Bet");
        getContentPane().add(L_TheBet);
        L_TheBet.setBounds(400, 180, 40, 20);

        L_TheBetBox.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_TheBetBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_TheBetBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_TheBetBox);
        L_TheBetBox.setBounds(440, 180, 50, 20);

        L_ThePot.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_ThePot.setText("The Pot");
        getContentPane().add(L_ThePot);
        L_ThePot.setBounds(265, 180, 40, 20);

        L_ThePotBox.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_ThePotBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_ThePotBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_ThePotBox);
        L_ThePotBox.setBounds(305, 180, 40, 20);

        SP_Output.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SP_Output.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        TA_Output.setColumns(20);
        TA_Output.setEditable(false);
        TA_Output.setFont(new java.awt.Font("Trebuchet MS", 0, 12));
        TA_Output.setRows(5);
        SP_Output.setViewportView(TA_Output);

        getContentPane().add(SP_Output);
        SP_Output.setBounds(5, 210, 360, 290);

        L_Commands.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_Commands.setText("Commands");
        getContentPane().add(L_Commands);
        L_Commands.setBounds(385, 290, 60, 14);

        B_Deal.setBackground(new java.awt.Color(0, 102, 255));
        B_Deal.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Deal.setLabel("DEAL");
        B_Deal.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Deal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_DealActionPerformed(evt);
            }
        });
        getContentPane().add(B_Deal);
        B_Deal.setBounds(390, 310, 40, 20);

        B_Hit.setBackground(new java.awt.Color(0, 102, 255));
        B_Hit.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Hit.setText("HIT");
        B_Hit.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Hit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_HitActionPerformed(evt);
            }
        });
        getContentPane().add(B_Hit);
        B_Hit.setBounds(390, 330, 40, 20);

        B_Stay.setBackground(new java.awt.Color(0, 102, 255));
        B_Stay.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Stay.setText("STAY");
        B_Stay.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Stay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_StayActionPerformed(evt);
            }
        });
        getContentPane().add(B_Stay);
        B_Stay.setBounds(390, 350, 40, 20);

        B_Bet.setBackground(new java.awt.Color(0, 102, 255));
        B_Bet.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Bet.setText("BET");
        B_Bet.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Bet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_BetActionPerformed(evt);
            }
        });
        getContentPane().add(B_Bet);
        B_Bet.setBounds(390, 370, 40, 20);

        B_Help.setBackground(new java.awt.Color(0, 102, 255));
        B_Help.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Help.setText("HELP");
        B_Help.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_HelpActionPerformed(evt);
            }
        });
        getContentPane().add(B_Help);
        B_Help.setBounds(390, 390, 40, 20);

        B_Quit.setBackground(new java.awt.Color(0, 102, 255));
        B_Quit.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Quit.setText("QUIT");
        B_Quit.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Quit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_QuitActionPerformed(evt);
            }
        });
        getContentPane().add(B_Quit);
        B_Quit.setBounds(390, 430, 40, 20);

        B_Start.setBackground(new java.awt.Color(0, 102, 255));
        B_Start.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        B_Start.setText("START");
        B_Start.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_StartActionPerformed(evt);
            }
        });
        getContentPane().add(B_Start);
        B_Start.setBounds(390, 410, 40, 20);

        B_Cheat.setBackground(new java.awt.Color(0, 102, 255));
        B_Cheat.setFont(new java.awt.Font("Trebuchet MS", 0, 10));
        B_Cheat.setText("CHEAT");
        B_Cheat.setMargin(new java.awt.Insets(2, 2, 2, 2));
        B_Cheat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_CheatActionPerformed(evt);
            }
        });
        getContentPane().add(B_Cheat);
        B_Cheat.setBounds(390, 450, 40, 20);

        L_Cheat.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_Cheat.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        getContentPane().add(L_Cheat);
        L_Cheat.setBounds(390, 270, 150, 14);

        L_DealerWins.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_DealerWins.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_DealerWins.setText("Dealer Wins");
        getContentPane().add(L_DealerWins);
        L_DealerWins.setBounds(380, 220, 70, 14);

        L_PlayerWins.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_PlayerWins.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerWins.setText("Player Wins");
        getContentPane().add(L_PlayerWins);
        L_PlayerWins.setBounds(450, 220, 120, 14);

        L_DealerWinsBox.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_DealerWinsBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_DealerWinsBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_DealerWinsBox);
        L_DealerWinsBox.setBounds(390, 238, 50, 20);

        L_PlayerWinsBox.setFont(new java.awt.Font("Trebuchet MS", 0, 11));
        L_PlayerWinsBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerWinsBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_PlayerWinsBox);
        L_PlayerWinsBox.setBounds(485, 238, 50, 20);
        getContentPane().add(L_Background);
        L_Background.setBounds(0, 10, 0, 0);
    }// </editor-fold>//GEN-END:initComponents

    private void B_HelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_HelpActionPerformed

String MESSAGE = "\n         "
+ PLAYER.GetName() + ", this is a short, fast card game of luck and skill."
+ "\n          The dealer will start you with two cards from the deck."
+ "\n          Your goal is to draw cards to get as close to the number"
+ "\n          21 as possible. If you go over 21, you are BUSTED. If you"
+ "\n          get closer to 21 than the dealer but not over, you win."
+ "\n          The card values are:\n"
+ "\n             DEUCES = 2          EIGHT = 8"
+ "\n             THREE =  3          NINE =  9"
+ "\n             FOUR =   4          TEN =   10 "
+ "\n             FIVE =   5          JACK =  10"
+ "\n             SIX =    6          QUEEN = 10"
+ "\n             SEVEN =  7          KING =  10\n"
+ "\n                       ACE =   11 or 1\n"
+ "\n          ACEs are 1 or 11 depending on which value is advantageous."
+ "\n\n          Activating the CHEAT allows you to see all the dealer's cards,"
+ "\n          giving you an unfair advantage. Normally, one of the Dealer's"
+ "\n          cards is hidden, making the game more challenging.";

        JOptionPane.showMessageDialog(null, MESSAGE);
    }//GEN-LAST:event_B_HelpActionPerformed

    private void B_StartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_StartActionPerformed

            if(STARTGAME)
            {
                B_Start.setEnabled(false);
                INTRO_Display = false; //Turn off example hands and cards
                Sequence();
                STARTGAME = false;
            }
            else
            {
                PEACH = new Random();
                DrawBlankHand();
                Audio_Welcome.play();
                TA_Output.setText("\n Welcome to Casino Angelique!");

                if(NeedName)
                {
                   PLAYER.SetName(
                   JOptionPane.showInputDialog(null,
                           "What is your name, player?"));
                   NeedName = false;
                }

                Initialize();
                STARTGAME = true;
                
                TA_Output.append("\n     Click \"START\" to continue...");

            }//close else for if STARTGAME
    }//GEN-LAST:event_B_StartActionPerformed

    private void B_CheatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_CheatActionPerformed

        if(CHEAT)
        { 
            CHEAT = false;
            TA_Output.append("\n CHEAT deactivated.");
            L_Cheat.setText("");
        }
        else
        {
          CHEAT = true;
          TA_Output.append("\n CHEAT activated!"); 
          L_Cheat.setForeground(new java.awt.Color(255, 0, 51));
          L_Cheat.setFont(new java.awt.Font("Comic Sans MS", 0, 11));
          L_Cheat.setText(PLAYER.GetName() + " is CHEATING!");
        }
    }//GEN-LAST:event_B_CheatActionPerformed

    private void B_DealActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_DealActionPerformed

            ClearBackground();
            ChangeAngelinaPix();  
            Sequence();
            B_Deal.setEnabled(false);
    }//GEN-LAST:event_B_DealActionPerformed

    private void B_BetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_BetActionPerformed

        ClearBackground();
        
        //Show Animated GIF Hand While PLAYER enters BET
        ANIMATECARDS = true;
        Graphics BG = getGraphics();
        paint(BG);
        
        Audio_Wager.play();
        String BET =
                JOptionPane.showInputDialog(null, "How much will you wager?");

        //Turn off Animated GIF Hand
        ANIMATECARDS = false;
        paint(BG);
        AnimatedCards.flush();

        OUTPUT  = " "; //clear String

        try { TheBet = Integer.parseInt(BET); }
        catch(NumberFormatException X)
        { 
            OUTPUT = OUTPUT + "\n   Sorry, but \"" + BET + "\" was not an option!"
                            + "\n   Guess you bet nothing for this hand...\n";
            TheBet = 0;
        }

        if(TheBet > PLAYER.GetMoney() || TheBet > DEALER.GetMoney())
        {
              if(TheBet > PLAYER.GetMoney())
              {
                  OUTPUT = OUTPUT + "\n\n   You don't have that much money!";
              }
              else
              {
                  OUTPUT = OUTPUT
                         + "\n\n   The dealer doesn't have that much money!";
                  OUTPUT = OUTPUT + "\n   Prepare for a beating...";
              }

              if(PLAYER.GetMoney() - 5 > 0 && DEALER.GetMoney() - 5 > 0)
              {
                  TheBet = 5;
                  OUTPUT = OUTPUT + "\n   Moving the ante up $5...";
              }
              else
              { TheBet = 0; }

        }//close if THEBET > PlayerMoney or DealerMoney

        ThePot = ThePot + (TheBet*2);
        PLAYER.SetMoney(PLAYER.GetMoney() - TheBet);
        DEALER.SetMoney(DEALER.GetMoney() - TheBet);

        B_Hit.setEnabled(true);
        B_Stay.setEnabled(true);
        B_Bet.setEnabled(false);

        OUTPUT = OUTPUT + "\n   You bet " + TheBet + " dollars.";
        OUTPUT = OUTPUT + "\n   Adding " + (TheBet*2) + " to the POT.\n";

        TA_Output.setText(OUTPUT);
        UpdateHoldings();

        //Dealer and Player Start Hand By Drawing 2 Cards Each
        for(int x = 0; x < NumCardsToStartWith; x++)
        {
                DRAW(PLAYER);
                DRAW(DEALER);
        }

        DisplayHand(PLAYER);
        DisplayHand(DEALER);
        
        Deal();

        TA_Output.setCaretPosition(0); //scroll back top top

       
    }//GEN-LAST:event_B_BetActionPerformed

    private void B_HitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_HitActionPerformed

            ChangeAngelinaPix();
            OUTPUT = "\n\n    " + PLAYER.GetName() + " requests a HIT!\n";
            B_Hit.setEnabled(false);
            B_Stay.setEnabled(false);
            Hit(PLAYER);
            DealerReaction();
            TA_Output.setCaretPosition(0); //scroll back top top
    }//GEN-LAST:event_B_HitActionPerformed

    private void B_StayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_StayActionPerformed

            ChangeAngelinaPix();
            OUTPUT = "\n   " + PLAYER.GetName() + " decides to STAY!\n";
            B_Hit.setEnabled(false);
            B_Stay.setEnabled(false);
            PLAYER.SetStay(true);
            DisplayHand(PLAYER);
            DealerReaction();
            TA_Output.setCaretPosition(0); //scroll back top top  
    }//GEN-LAST:event_B_StayActionPerformed

    private void B_QuitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_QuitActionPerformed

           B_Start.setEnabled(true);
           B_Hit.setEnabled(false);
           B_Stay.setEnabled(false);
           B_Deal.setEnabled(false);
           B_Bet.setEnabled(false);
           NeedName = true;
    }//GEN-LAST:event_B_QuitActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton B_Bet;
    private javax.swing.JButton B_Cheat;
    private javax.swing.JButton B_Deal;
    private javax.swing.JButton B_Help;
    private javax.swing.JButton B_Hit;
    private javax.swing.JButton B_Quit;
    private javax.swing.JButton B_Start;
    private javax.swing.JButton B_Stay;
    private javax.swing.JLabel L_Background;
    private javax.swing.JLabel L_Cheat;
    private javax.swing.JLabel L_Commands;
    private javax.swing.JLabel L_DealerHand;
    private javax.swing.JLabel L_DealerHoldings;
    private javax.swing.JLabel L_DealerHoldingsBox;
    private javax.swing.JLabel L_DealerWins;
    private javax.swing.JLabel L_DealerWinsBox;
    private javax.swing.JLabel L_PlayerHand;
    private javax.swing.JLabel L_PlayerHoldings;
    private javax.swing.JLabel L_PlayerHoldingsBox;
    private javax.swing.JLabel L_PlayerWins;
    private javax.swing.JLabel L_PlayerWinsBox;
    private javax.swing.JLabel L_TheBet;
    private javax.swing.JLabel L_TheBetBox;
    private javax.swing.JLabel L_ThePot;
    private javax.swing.JLabel L_ThePotBox;
    private javax.swing.JLabel L_Title;
    private javax.swing.JScrollPane SP_Output;
    public static javax.swing.JTextArea TA_Output;
    // End of variables declaration//GEN-END:variables

}
