public class LIGER extends LifeForm
{
       public LIGER() 
       { 
              System.out.println("\n\tCreating a LION + TIGER = LIGER.");
              SetSpecies("LIGER");
       }
       
}