public class HONKEY extends LifeForm
{
       public HONKEY()
       { 
              System.out.println("\n\tCreating a HIPPO + DONKEY = HONKEY.");
              SetSpecies("HONKEY");
       }

}