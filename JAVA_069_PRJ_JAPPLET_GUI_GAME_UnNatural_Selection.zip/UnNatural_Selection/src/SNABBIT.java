public class SNABBIT extends LifeForm
{
       public SNABBIT()
       {
              System.out.println("\n\tCreating a SNAKE + RABBIT = SNABBIT.");
              SetSpecies("SNABBIT");
       }
       
}