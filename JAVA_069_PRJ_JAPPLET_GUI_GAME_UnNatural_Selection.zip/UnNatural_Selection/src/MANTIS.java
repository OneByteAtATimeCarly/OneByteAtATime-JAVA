public class MANTIS extends LifeForm
{
       public MANTIS()
       {
              System.out.println("\n\tCreating a MANTIS.");
              SetSpecies("MANTIS");
       }
       
}