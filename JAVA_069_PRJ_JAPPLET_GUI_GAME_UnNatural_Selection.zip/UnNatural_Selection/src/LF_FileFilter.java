//FileFilter for LifeForm Objects, for use with FileChooser

import java.io.*;

class LF_FileFilter extends javax.swing.filechooser.FileFilter {
    public boolean accept(File f) {
        return f.isDirectory() || f.getName().toLowerCase().endsWith(".lf");
    }
    
    public String getDescription() {
        return ".LF files";
    }
}
