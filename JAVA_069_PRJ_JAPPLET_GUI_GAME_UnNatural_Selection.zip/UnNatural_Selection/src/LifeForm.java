//LifeForm ADT Base class for "UnNatural Selection"

//Required Packages
import javax.swing.*;
import java.io.*;
import java.util.Random;

public class LifeForm
{
       //Globals
       public LineNumberReader INPUT = new LineNumberReader(new InputStreamReader(System.in));
       Random COCONUT = new Random();
       public final int MaxPoints = 1000;
       public final int Max_Speed_Weight = 100;
       public final int Max_Spec_Ability_Energy = 100;
       public final int Max_Damage = 150;
       public boolean Dodged = false;
       public boolean Spec_Automatic = false;
       public boolean Total_Mass_Defense = false;

//-----------------------------------------------------------------------------------------------------
       //Overloaded Constructors
       public LifeForm()
       { 
           UnNaturalSelection.TA_MainOutput.setText(
           UnNaturalSelection.TA_MainOutput.getText() +        
           "\n Creating ADT LifeForm object."); 
       }

//-----------------------------------------------------------------------------------------------------

       public void COPY(LifeForm COPY)
       {
              //Simulate a copy constructor, would be nice if we could 
              //overload the assignment operator (=) like in C++. If only...
              COPY.SetATK(ATK);
              COPY.SetDEF(DEF);
              COPY.SetSTR(STR);
              COPY.SetDEX(DEX);
              COPY.SetHP(HP);
              COPY.SetSPEED(SPEED);
              COPY.SetWEIGHT(WEIGHT);
              COPY.SetAGE(AGE);
              COPY.SetEXP(EXP);
              COPY.SetLVL(LVL);
              COPY.SetSpecies(Species);
              COPY.SetOrigin(Origin);
              COPY.SetDesc(Desc);
              COPY.SetSpec_Attack(Spec_Attack);
              COPY.SetSpec_Defense(Spec_Defense);
              COPY.Set_Use_Spec_Attack(Use_Spec_Attack);              
              COPY.Set_Use_Spec_Defense(Use_Spec_Defense);
              COPY.SetSpec_Attack_Damage(Spec_Attack_Damage);
              COPY.SetSpec_Defense_Damage(Spec_Defense_Damage);
              COPY.SetSpecial_Ability_Energy(Special_Ability_Energy);
              COPY.Set_LF_Image(LF_Image);
              COPY.Set_LF_Sound(LF_Sound);
              COPY.SetOpponentStatus(OpponentStatus);
              COPY.SetName(Name);
              COPY.SetGender(Gender);
              COPY.SetCreator(Creator);
              COPY.Set_LF_Image(LF_Image);
       }

//-----------------------------------------------------------------------------------------------------

       public void DisplayStats()
       {
              if(OpponentStatus == 1)
              {
                 UnNaturalSelection.L_Out_OP1_HP.setText(Integer.toString(HP));
                 UnNaturalSelection.L_Out_OP1_ATK.setText(Integer.toString(ATK));
                 UnNaturalSelection.L_Out_OP1_DEF.setText(Integer.toString(DEF));        
                 UnNaturalSelection.L_Out_OP1_STR.setText(Integer.toString(STR));        
                 UnNaturalSelection.L_Out_OP1_DEX.setText(Integer.toString(DEX));        
                 UnNaturalSelection.L_Out_OP1_WEIGHT.setText(Integer.toString(WEIGHT));        
                 UnNaturalSelection.L_Out_OP1_SPEED.setText(Integer.toString(SPEED));
                 UnNaturalSelection.L_Out_OP1_AGE.setText(Integer.toString(AGE));
                 UnNaturalSelection.L_Out_OP1_EXP.setText(Integer.toString(EXP));
                 UnNaturalSelection.L_Out_OP1_LVL.setText(Integer.toString(LVL));
                 UnNaturalSelection.L_Out_OP1_ME.setText(Integer.toString(Special_Ability_Energy));
                 UnNaturalSelection.L_Out_OP1_SpecAttack.setText(Spec_Attack);
                 UnNaturalSelection.L_Out_OP1_SpecAttackDmg.setText(Integer.toString(Spec_Attack_Damage));
                 UnNaturalSelection.L_Out_OP1_SpecDefense.setText(Spec_Defense);
                 UnNaturalSelection.L_Out_OP1_SpecDefAmt.setText(Integer.toString(Spec_Defense_Damage));
                 UnNaturalSelection.L_Out__OP1_Desc.setText(Desc);
                 UnNaturalSelection.L_Out_OP1_Species.setText(Species);
                 UnNaturalSelection.L_Out_OP1_Creator.setText(Creator);
                 UnNaturalSelection.L_Out_OP1_Name.setText(Name);        
                 UnNaturalSelection.L_Out_OP1_Gender.setText(Gender);        
                 UnNaturalSelection.L_Out_OP1_Origin.setText(Origin);
              }
              else if(OpponentStatus == 2)
              {
                 UnNaturalSelection.L_Out_OP2_HP.setText(Integer.toString(HP));
                 UnNaturalSelection.L_Out_OP2_ATK.setText(Integer.toString(ATK));
                 UnNaturalSelection.L_Out_OP2_DEF.setText(Integer.toString(DEF));        
                 UnNaturalSelection.L_Out_OP2_STR.setText(Integer.toString(STR));        
                 UnNaturalSelection.L_Out_OP2_DEX.setText(Integer.toString(DEX));        
                 UnNaturalSelection.L_Out_OP2_WEIGHT.setText(Integer.toString(WEIGHT));        
                 UnNaturalSelection.L_Out_OP2_SPEED.setText(Integer.toString(SPEED));
                 UnNaturalSelection.L_Out_OP2_AGE.setText(Integer.toString(AGE));
                 UnNaturalSelection.L_Out_OP2_EXP.setText(Integer.toString(EXP));
                 UnNaturalSelection.L_Out_OP2_LVL.setText(Integer.toString(LVL));
                 UnNaturalSelection.L_Out_OP2_ME.setText(Integer.toString(Special_Ability_Energy));
                 UnNaturalSelection.L_Out_OP2_SpecAttack.setText(Spec_Attack);
                 UnNaturalSelection.L_Out_OP2_SpecAttackDmg.setText(Integer.toString(Spec_Attack_Damage));
                 UnNaturalSelection.L_Out_OP2_SpecDefense.setText(Spec_Defense);
                 UnNaturalSelection.L_Out_OP2_SpecDefAmt.setText(Integer.toString(Spec_Defense_Damage));
                 UnNaturalSelection.L_Out__OP2_Desc.setText(Desc);
                 UnNaturalSelection.L_Out_OP2_Species.setText(Species);
                 UnNaturalSelection.L_Out_OP2_Creator.setText(Creator);
                 UnNaturalSelection.L_Out_OP2_Name.setText(Name);        
                 UnNaturalSelection.L_Out_OP2_Gender.setText(Gender);        
                 UnNaturalSelection.L_Out_OP2_Origin.setText(Origin);                 
              }
 }

//-----------------------------------------------------------------------------------------------------
       
       public void Attack(LifeForm opponent)
       {
              int damage = COCONUT.nextInt(Max_Damage) + 1;
              int STR_damage = COCONUT.nextInt(1000) + 1;
              int DEX_dodge = COCONUT.nextInt(1000) + 1;
              String choice = " ";
              String OUTPUT = " ";
              
               //Display OUTPUT in appropriate section of form/Accumulate Text
               if(OpponentStatus == 1)
               {
                    OUTPUT = UnNaturalSelection.TA_Opponent1.getText(); 
               }
               else
               {
                    OUTPUT = UnNaturalSelection.TA_Opponent2.getText();
               }              
              
              damage = damage + ATK + (WEIGHT/4);
              
              OUTPUT = OUTPUT + "\n\n-----------------------------";
              OUTPUT = OUTPUT + "\n\n " + Name + " attacks " + opponent.GetName() + ".";                  
            
              //-----------------------------------------------------------------------------

              if(Special_Ability_Energy > 0)
              {
                  if(Spec_Automatic)
                  {
                       Use_Spec_Attack = true;
                       Use_Spec_Defense = true;
                  }

                  else
                  {
                      while(choice.charAt(0) != 'd' &&
                            choice.charAt(0) != 'a' &&
                            choice.charAt(0) != 'n' &&
                            choice.charAt(0) != 's'
                           )
                      {
                          OUTPUT = OUTPUT + "\n Special Ability Energy\n Remaining: " + 
                                   Special_Ability_Energy;
                          OUTPUT = OUTPUT + "\n\n Choose one of " + Name + 
                                   "'s\n special abilities:\n";
                          OUTPUT = OUTPUT + "\n (A)ttack ability:\n  " + Spec_Attack
                                          + "\n  Point Cost:" + Spec_Attack_Damage;
                          OUTPUT = OUTPUT + "\n\n (D)efense ability:\n  " + Spec_Defense
                                          + "\n  Point Cost:" + Spec_Defense_Damage;
                          OUTPUT = OUTPUT + "\n\n (N)o ability";
                          OUTPUT = OUTPUT + "\n\n (S)elect Abilities Automatically";

                          choice = JOptionPane.showInputDialog(null, 
                                  Name + ", choose a special ability:\n" +
                                 "\n (A)ttack ability: " + Spec_Attack +
                                 "\n  Point Cost:" + Spec_Attack_Damage + "\n" +
                                 "\n (D)efense ability: " + Spec_Defense +
                                 "\n  Point Cost:" + Spec_Defense_Damage + "\n" +
                                 "\n (N)o ability\n" +
                                 "\n (S)elect Abilities Automatically\n\n");
                          
                          choice.toLowerCase();
                          
                          switch(choice.charAt(0))
                          {
                               case 'd' : Use_Spec_Defense = true;
                                          break;
                               case 'a' : Use_Spec_Attack = true;
                                          break;
                               case 'n' : break;
                               case 's' : Spec_Automatic = true;
                                          Use_Spec_Attack = true;
                                          Use_Spec_Defense = true;
                                          break;
                               default :  UnNaturalSelection.TA_MainOutput.setText(
                                          "\n That was an invalid choice...");
                                          break;
                          }//close switch

                      }//close while loop
                  
                  }//close else

                  if(Use_Spec_Attack)
                  {
                      OUTPUT = OUTPUT + "\n\n Employing special attack\n \"" + Spec_Attack +
                                        "\" for " + Spec_Attack_Damage + 
                                        "\n additional points\n of damage.";
                      
                      Special_Ability_Energy = Special_Ability_Energy - Spec_Attack_Damage;
                      damage = damage + Spec_Attack_Damage;
                      Use_Spec_Attack = false;
                  }

              }//close if

              else
              { 
                OUTPUT = OUTPUT + 
                "\n  No special abilities available -\n  not enough energy!\n"; 
              }

              //------------------------------------------------------------------------------------

              if(STR > STR_damage)
              {
                 OUTPUT = OUTPUT + "\n  " + Name + 
                 "'s incredible strength\n  produces Double Damage!";
                 damage = damage * 2;
              }

              if(((opponent.GetDEX() * 3) / 4) > DEX_dodge)
              {
                 OUTPUT = OUTPUT + "\n\n " + opponent.GetName() + 
                 "'s smooth dexterity\n allows him to dodge\n the attack!";
                 Dodged = true;
                 damage = 0;
              }

              OUTPUT = OUTPUT + "\n\n Before attack:\n " + Name + ":" + HP + "\n "
                     + opponent.GetName() + ":" + opponent.GetHP() + "\n";

              int Defense_By_Mass = COCONUT.nextInt(800)+ 1;

              if(WEIGHT > Defense_By_Mass)
              {
                  int Energy_Absorbed = COCONUT.nextInt(opponent.GetWEIGHT())+ 1;
                  
                  OUTPUT = OUTPUT + "\n " + opponent.GetName() + 
                         "'s incredible mass absorbs\n  " + Energy_Absorbed + 
                         " points of energy from\n  " + Name + "'s blow.\n";
                  
                  if(damage - Energy_Absorbed > 0) 
                  { damage = damage - Energy_Absorbed; }
                  else 
                  { 
                    damage = 0;
                    Total_Mass_Defense = true;
                  }

              }

              if(damage - opponent.GetDEF() > 0)
              {
                 OUTPUT = OUTPUT + "\n " + opponent.GetName() + 
                        "'s defense blocks " + opponent.GetDEF() +
                        "\n points of damage from the\n total of: " + damage + ".\n";
                 
                 damage = damage - opponent.GetDEF();
                 
                 OUTPUT = OUTPUT + "\n " + opponent.GetName() + " receives "
                        + damage + " points\n of remaining damage.";
              }
              else
              {
                 if(!Dodged && !Total_Mass_Defense)
                 {
                     OUTPUT = OUTPUT + "\n " + opponent.GetName() + 
                            "'s massive DEFENSE\n completely blocks " + 
                            Name + "'s\n damage. Merely a scratch.";
                     
                     damage = 1;
                 }

                 Dodged = false;
                 Total_Mass_Defense = false;
              }

              //Don't Use Special Defense Unless Necessary
              if(opponent.Get_Use_Spec_Defense())
              {
                  if(damage > 0)
                  {
                      OUTPUT = OUTPUT + "\n\n " + opponent.GetName() + 
                             " employs the special\n defense of " +
                             opponent.GetSpec_Defense() + 
                             ",\n thus reducing damage by " + 
                             opponent.GetSpec_Defense_Damage() + ".";
                      
                      opponent.SetSpecial_Ability_Energy(
                      opponent.GetSpecial_Ability_Energy() -
                      opponent.GetSpec_Defense_Damage());

                      if(damage - opponent.GetSpec_Defense_Damage() > 0)
                      { damage = damage - opponent.GetSpec_Defense_Damage(); }
                      else { damage = 0; }

                  }
                  else
                  {
                      OUTPUT = OUTPUT + 
                             "\n Special defense ability\n not required!";

                  }

                  opponent.Set_Use_Spec_Defense(false);

              }

              if(opponent.GetHP() - damage > 0)
              {  opponent.SetHP(opponent.GetHP() - damage); }
              else
              { opponent.SetHP(0); }

              OUTPUT = OUTPUT + "\n\n After attack: \n " + Name + ":" + 
                       HP + "\n " + opponent.GetName() + ":" + 
                       opponent.GetHP();

              //OUTPUT = OUTPUT + "\n\n  ------------------------\n";

               int SecondAttack = COCONUT.nextInt(1000) + 1;

               if(SPEED / 2 > SecondAttack)
               {
                     OUTPUT = OUTPUT + "\n\t" + Name + 
                            "'s nimble speed allows a second attack!\n";
                     Attack(opponent);
               }

               //Display OUTPUT in appropriate section of form
               if(OpponentStatus == 1)
               {                    
                   UnNaturalSelection.TA_Opponent1.setText(OUTPUT); 
               }
               else
               {
                    UnNaturalSelection.TA_Opponent2.setText(OUTPUT);              
               }
          
              //Example: Special Method based on a species
              /*
              if(Species.equals("LIGER"))
              {
                 //Attack method for a LIGER   (LION + TIGER)
              }
              */
       }

//-----------------------------------------------------------------------------------------------------

       //Public Accessors
       public int GetATK() { return ATK; }
       public void SetATK(int x) { ATK = x; }
       public int GetDEF() { return DEF; }
       public void SetDEF(int x) { DEF = x; }
       public int GetSTR() { return STR; }
       public void SetSTR(int x) { STR = x; }
       public int GetDEX() { return DEX; }
       public void SetDEX(int x) { DEX = x; }
       public int GetHP() { return HP; }
       public void SetHP(int x) { HP = x; }

       //Data Members
       private int ATK = 0;
       private int DEF = 0;
       private int STR = 0;
       private int DEX = 0;
       private int HP = 100;

       //Public Accessors
       public int GetSPEED() { return SPEED; }
       public void SetSPEED(int x) { SPEED = x; }
       public int GetWEIGHT() { return WEIGHT; }
       public void SetWEIGHT(int x) { WEIGHT = x; }
       public int GetAGE() { return AGE; }
       public void SetAGE(int x) { AGE = x; }
       public int GetEXP() { return EXP; }
       public void SetEXP(int x) { EXP = x; }
       public int GetLVL() { return LVL; }
       public void SetLVL(int x) { LVL = x; }
       public int GetOpponentStatus() { return OpponentStatus; }
       public void SetOpponentStatus(int x) { OpponentStatus = x; }
       public String Get_LF_Image() { return LF_Image; }
       public void Set_LF_Image(String x) { LF_Image = x; }
       public String Get_LF_Sound() { return LF_Sound; }
       public void Set_LF_Sound(String x) { LF_Sound = x; }
       public String GetSpecies() { return Species; }
       public void SetSpecies(String x) { Species = x; }
       public String GetOrigin() { return Origin; }
       public void SetOrigin(String x) { Origin = x; }
       public String GetDesc() { return Desc; }
       public void SetDesc(String x) { Desc = x; }
   
       private int SPEED = 0;
       private int WEIGHT = 0;
       private int AGE = 1;
       private int EXP = 1;
       private int LVL = 1;
       private String Species = "LifeForm";
       private String Origin = "???";
       private String Desc = "???";

       //Public Accessors
       public String GetName() { return Name; }
       public void SetName(String x) { Name = x; }
       public String GetGender() { return Gender; }
       public void SetGender(String x) { Gender = x; }
       public String GetCreator() { return Creator; }
       public void SetCreator(String x) { Creator = x; }
       
       //AudioClip Object Battle  Sound
       private String Name = "No_Name_Yet";
       private String Gender = "No_Sex";
       private String Creator = "No_One";

       //Public Accessors
       public String GetSpec_Attack() { return Spec_Attack; }
       public void SetSpec_Attack(String x) { Spec_Attack = x; }
       public String GetSpec_Defense() { return Spec_Defense; }
       public void SetSpec_Defense(String x) { Spec_Defense = x; }
       public int GetSpec_Attack_Damage() { return Spec_Attack_Damage; }
       public void SetSpec_Attack_Damage(int x) { Spec_Attack_Damage = x; }
       public int GetSpec_Defense_Damage() { return Spec_Defense_Damage; }
       public void SetSpec_Defense_Damage(int x) { Spec_Defense_Damage = x; }
       public int GetSpecial_Ability_Energy() { return Special_Ability_Energy; }
       public void SetSpecial_Ability_Energy(int x) { Special_Ability_Energy = x; }

       public void Set_Use_Spec_Attack(boolean x) { Use_Spec_Attack = x; }
       public void Set_Use_Spec_Defense(boolean x) { Use_Spec_Defense = x; }
       public boolean Get_Use_Spec_Attack() { return Use_Spec_Attack; }
       public boolean Get_Use_Spec_Defense() { return Use_Spec_Defense; }

       //Special Abilities
       private String Spec_Attack = "???";
       private String Spec_Defense = "???";
       private boolean Use_Spec_Attack = false;
       private boolean Use_Spec_Defense = false;
       private int Spec_Attack_Damage = 0;
       private int Spec_Defense_Damage = 0;
       private int Special_Ability_Energy = Max_Spec_Ability_Energy;
       private String LF_Image = "No_Image_Assigned";
       private String LF_Sound = "No_Audio_Assigned";
       private int OpponentStatus = 1;
}

