package GameFunctions;

//FileFilter for Conspiracy Objects, for use with JFileChooser

import java.io.*;

class PirateFilter extends javax.swing.filechooser.FileFilter {

      public boolean accept(File f)
      {
        return f.isDirectory() || f.getName().toLowerCase().endsWith(".pirate");
      }

      public String getDescription()
      {
        return "Pirate Arena! files";
      }
}
