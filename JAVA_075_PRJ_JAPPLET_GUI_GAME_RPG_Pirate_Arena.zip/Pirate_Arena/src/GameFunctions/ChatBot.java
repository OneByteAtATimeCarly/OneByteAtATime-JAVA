//Pirate Arena ChatBot - from Conspiracy! - 2010 Charles Germany (07/01/2010)

package GameFunctions;

import Interface.*;
import java.lang.reflect.Array;
import java.util.*;
import javax.swing.JOptionPane;

public class ChatBot
{
       public static String BotName = "BotenAnna";
       public static String BotNeed = "BanYouSoHard";
       public final static String PunctuationMarks = "?!.;,";
       public final static int NumPossibleReplies = 4;
       public static String BotsLastResponse = "InMyEyesYouWillAlwaysBeABot";
       public static Random RN = new Random();

       public ChatBot()
       {
                 INTERFACE.TA_Output.setText("\n Building a ChatBot.");
       }

       public ChatBot(String NAME, String NEED)
       {
                INTERFACE.TA_Output.setText("\n Building a ChatBot.");

              DATA[0][1] = " My name is " + NAME;
              DATA[0][2] = " You can call me " + NAME;
              DATA[0][3] =
              " My name is who? My name is what?\n My name is "
              + NAME + " SlimShady!";
              DATA[1][1] = " Why, I'm " + NAME + ", ofcourse!";
              DATA[1][4] = " My name is " + NAME + "!";
              DATA[4][1] = " I want you to get me the\n "
                           + NEED + ", please.";
              DATA[4][2] = " I DESPERATELY need the " + NEED + ".";
              DATA[4][3] = " What I truly want, more than anything\n" +
                           " else in this entire world, is a\n " +
                           NEED + ".";
              DATA[4][4] = " If only I had the " + NEED + "!";
              DATA[5][1] = " I NEED the\n " + NEED + ". Badly!";
              DATA[5][2] = " I truly need the " + NEED + ".";
              DATA[5][3] = " My life is truly incomplete and\n" +
                           " without meaning until I get the\n " +
                           NEED + ".";
              DATA[5][4] = " If only I had the " + NEED + "!";
       }

       public static String DATA[][] =
       {
              {  "what is your name",
                 " My name is " + BotName,
                 " You can call me " + BotName,
                 " My name is who? My name is what?\n My name is "
                 + BotName + " SlimShady!",
                 " Why do you want to know my name?" },

              { "who are you",
                " Why, I'm " + BotName + ", ofcourse!",
                " I think you KNOW who I am, silly!",
                " Do you really want to know me?",
                " My name is " + BotName + "!" },

              { "what are you",
                " I'm anything you want me to be.",
                " That's insulting. You don't know?",
                " Do you really want to know that?",
                " I am what I am, nothing more, nothing less." },

              { "how are you",
                " I'm just fine. Thanks for asking!",
                " You really care about me?\n That's sweet!",
                " Why do you want to know how\n I am doing?",
                " I think I'm o.k. - as far as I know." },

              { "what do you want",
                " I want you to get me the\n " + BotNeed + ", please.",
                " I DESPERATELY need the " + BotNeed + ".",
                " What I truly want, more than anything\n" +
                " else in this entire world, is a\n " +
                BotNeed + ".",
                " If only I had the " + BotNeed + "!"},

              { "what do you need",
                "I NEED the\n " + BotNeed + ". Badly!",
                "I truly need the " + BotNeed + ".",
                " My life is truly incomplete and\n" +
                " without meaning until I get the\n " +
                BotNeed + ".",
                " If only I had the " + BotNeed + "!"},

              { "why are you here",
                " No, why are YOU here?",
                " I'm here... just because!",
                " Why is ANYONE here? Can we ever truly know?",
                " Just seemed like a good spot to be..."},

              {  "hi",
                 " Hi there!",
                 " How are you?",
                 " Hello!",
                 " Hi!"},

              {  "hello",
                 " Hi there!",
                 " How are you?",
                 " Hello!",
                 " Hi!" },

              { "i love you",
                " I love you too.",
                " Me too - with all my heart!",
                " Do you really love me?",
                " You are SOOO sweet!" },

              { "i want you",
                " I desire you too.",
                " I think I'd like that.",
                " Do you REALLY want me?",
                " You don't know what you want!" },

              { "i like you",
                " Cause I'm so likeable, right?",
                " I like me too!",
                " I like you as well.",
                " Let's be close friends!" },

              { "i hate you",
                " Well, I DON'T hate you...",
                " You wound me...",
                " Why? What did I ever do to you?",
                " You are so mean to me." },

              { "i do not like you",
                " That really hurts!",
                " You didn't have to say so.",
                " Better an honest enemy than\n a false friend.",
                " You are cruel and petty." },

              { "are you real",
                " Well, are YOU real?",
                " You're talking to me - duh!",
                " I'm as real as you want\n me to be (wink).",
                " Completely, totally and equivocably." },

              { "what is the meaning of life",
                " 42 - duh!",
                " You mean, there actually is\n a meaning?",
                " I never figured that out...",
                " I wish I knew the answer to that." }
        };
//-------------------------------------------------------------------
        public static boolean IsItAPunctuationMark(char P)
        {
                return PunctuationMarks.indexOf(P) != -1;
        }
//-------------------------------------------------------------------
        public static Vector SearchDATA(String InputExpression)
        {
               Vector<String> REPLY = new Vector<String>(NumPossibleReplies);

               //Search for matching expression (1st element of 1st dimension)
               for(int i = 0; i < DATA.length; ++i)
               {
                  if(DATA[i][0].equalsIgnoreCase(InputExpression))
                  {
                     //If found add Possible Replies to a Vector
                     for(int j = 1; j <= NumPossibleReplies; ++j)
                     {
                           REPLY.add(DATA[i][j]);
                     }
                     break;
                  }
                }
                return REPLY;
        }
//-------------------------------------------------------------------

        public static String FilterInput(String InputExpression)
        {
               StringBuffer TEMP = new StringBuffer(InputExpression.length());

               char PreviousCharacter = 0;

               for(int i = 0; i < InputExpression.length(); ++i)
               {
                   //Ignore spaces if 2 spaces are in a row
                   if(InputExpression.charAt(i) == ' ' &&
                      PreviousCharacter == ' ')
                   {
                      continue;
                   }
                   //Ignore punctuation marks
                   else if(!IsItAPunctuationMark(InputExpression.charAt(i)))
                   {
                        //Add it ONLY if it's NOT apunctuation mark
                        TEMP.append(InputExpression.charAt(i));
                   }
                   //Save last character to compare if next makes 2 spaces
                   PreviousCharacter = InputExpression.charAt(i);
               }
               //Return string minus extra spaces and punctuation
               return TEMP.toString();
        }

//-------------------------------------------------------------------

        public static void Respond(String PlayersInput)
        {
               String BotResponse = "";
               int RandomResponse = 0;

               Vector<String> BotsPossibleResponses =
                              new Vector<String>(NumPossibleReplies);

               BotsPossibleResponses = SearchDATA(PlayersInput);

               //Generate random response if no match found
               if(BotsPossibleResponses.isEmpty())
               {
                   RandomResponse = RN.nextInt(10) + 1;
                  
                   if(RandomResponse > 6)
                   {
                       INTERFACE.TA_Output.append(
                               " What do you mean by,\n \"" +
                                        PlayersInput + "\"?");
                   }
                   else
                   {
                       RandomResponse = RN.nextInt(6) + 1;

                       switch(RandomResponse)
                       {
                           case 1 : INTERFACE.TA_Output.append(
                                    "Whatever...");
                                    break;
                           case 2 : INTERFACE.TA_Output.append(
                                    "Back at cha!");
                                    break;
                           case 3 : INTERFACE.TA_Output.append(
                                    "That's a mystery to me.");
                                    break;
                           case 4 : INTERFACE.TA_Output.append(
                                    "That makes no sense to me.");
                                    break;
                           case 5:  INTERFACE.TA_Output.append(
                                    "That's not important now.");
                                    break;
                           case 6:  INTERFACE.TA_Output.append(
                                    "Ask me a question...");
                                    break;

                       }//close switch

                   }//close inner else (random catch all)

               }//close outer if (No match found)

               //Respond with random but RELATED match to player's input
               else
               {
                   RandomResponse = RN.nextInt(NumPossibleReplies);

                   BotResponse = BotsPossibleResponses.elementAt(RandomResponse);

                   //If same as last reponse give different reponse
                   if(BotResponse.equals(BotsLastResponse))
                   {
                      BotsPossibleResponses.removeElementAt(RandomResponse);
                      RandomResponse = RN.nextInt(NumPossibleReplies-1);
                      BotResponse = BotsPossibleResponses.elementAt(RandomResponse);
                   }

                   //Save response so don't give 2 of same in a row
                   BotsLastResponse = BotResponse;
                  
                   INTERFACE.TA_Output.append(BotResponse);

               }//close else
        }

//-------------------------------------------------------------------

        public static void Converse()
        {
               int RandomResponse = 0;

                   INTERFACE.TA_Output.append("\n\n>");

                   GameFunctions.InputPane("What would you like to say?");
                   String PlayersInput = GameFunctions.CHOICE;

                   PlayersInput = PlayersInput.toLowerCase();
                   PlayersInput = FilterInput(PlayersInput);

                   //Exit if player decides to quit
                   if(PlayersInput.isEmpty())
                   {
                       INTERFACE.TA_Output.append(
                       "What do you want? You've said NOTHING.");
                   }
                   else if(PlayersInput.equals("cheat"))
                   {
                       GameFunctions.PLAYER.CHEAT();
                       INTERFACE.TA_Output.setText(
                       "CHEATER, CHEATER, pumpkin eater!");
                   }
                   else if(PlayersInput.equals("bye"))
                   {
                      INTERFACE.TA_Output.append(
                      "Ok, see you around!");
                      GameFunctions.CHOICE = "";
                      INTERFACE.TA_Output.append(
                      "\n\n Click \"GO\" to continue.");
                   }
                   else if(PlayersInput.equals("good"))
                   {
                      INTERFACE.TA_Output.append(" That's nice!");
                   }
                   else if(PlayersInput.equals("bad"))
                   {
                      INTERFACE.TA_Output.append(" That's awful...");
                   }
                   else if(PlayersInput.equals("whatever"))
                   {
                      INTERFACE.TA_Output.append(" As if!");
                   }
                   //Check for PROFANITY words
                   else if(PlayersInput.contains("shit") ||
                           PlayersInput.contains("bitch") ||
                           PlayersInput.contains("bastard") ||
                           PlayersInput.contains("fuck") ||
                           PlayersInput.contains("sex") ||
                           PlayersInput.contains("ass") ||
                           PlayersInput.contains("ass hole") ||
                           PlayersInput.contains("dick") ||
                           PlayersInput.contains("pussy") ||
                           PlayersInput.contains("fag") ||
                           PlayersInput.contains("faggot")
                           )
                   {
                      INTERFACE.TA_Output.append(
                      " No need to be a potty mouth!");
                   }
                   else if(!PlayersInput.equals("i like you") &&
                           PlayersInput.contains("i like"))
                   {
                           RandomResponse = RN.nextInt(2) + 1;

                           if(RandomResponse == 1)
                           {
                               INTERFACE.TA_Output.append(
                               " I like that you like that!");
                           }
                           else
                           {
                              INTERFACE.TA_Output.append(
                               " I can SEE that!");
                           }
                   }
                   else if(!PlayersInput.equals("i hate you") &&
                           PlayersInput.contains("i hate"))
                   {
                           RandomResponse = RN.nextInt(2) + 1;

                           if(RandomResponse == 1)
                           {
                               INTERFACE.TA_Output.append(
                               " I hate that FOR you.");
                           }
                           else
                           {
                              INTERFACE.TA_Output.append(
                               " Why do you hate things?");
                           }
                   }
                   //If nothing in DATA matches player's input
                   else
                   {
                      Respond(PlayersInput);
                   }

        }//close function
       
//-------------------------------------------------------------------

}//close class
