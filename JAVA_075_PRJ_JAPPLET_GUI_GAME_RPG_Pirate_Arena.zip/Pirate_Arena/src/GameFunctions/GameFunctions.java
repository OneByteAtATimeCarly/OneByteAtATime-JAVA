//Main Game functions class and Globals
package GameFunctions;
import BattleField.*;
import java.io.*;
import Interface.*;
import Characters.*;
import Levels.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class GameFunctions 
{      
       //Globals and POINTERS (yes)
       public static FIGHTER PLAYER;
       public static FIGHTER FRIEND;
       public static FIGHTER CPU;
       public static OpponentFrame OPVIEW;
       public static PolyBATTLEFIELD BFIELD;
       public static INTERFACE GUI;
       public static Graphics G;
       
       public static Random IMPROBABILITY;
       public static int DIALOG = 0; 
       public static boolean NewGame = true;
       public static Level1 GAME;
       public static final int INTRO = 1000;
       public static int CombatRound = 0;
       public static int PlayerStart = Level1.C1;
       public static String CHOICE = " ";
       public static boolean FoundSomething = false;
       public static boolean EnableSave = false;
       
       //Location Tracking
       //public static int LOCATION = INTRO;
       public static int LOCATION = INTRO;
       public static char ORIENTATION = ' ';
       public static int ROW = 0;
       public static int COLUMN = 0;
     
//-----------------------------------------------------------------------------
       //Constructor
       public GameFunctions(INTERFACE X) 
       { 
              INTERFACE.TA_Output.append(
              "\n\n Building a GameFunctions object!");
              GUI = X;
              GAME = new Level1();
       }

//-----------------------------------------------------------------------------                     
       
    public static void EnableNavigation()
    {
           INTERFACE.B_North.setEnabled(true);
           INTERFACE.B_South.setEnabled(true);
           INTERFACE.B_East.setEnabled(true);
           INTERFACE.B_West.setEnabled(true);
           INTERFACE.LB_Inventory.setEnabled(true);
           INTERFACE.CB_Abilities.setEnabled(true);
           INTERFACE.B_Use.setEnabled(true);
    }       

//-----------------------------------------------------------------------------                  
    
    public static void DisableNavigation()
    {
           INTERFACE.B_North.setEnabled(false);
           INTERFACE.B_South.setEnabled(false);
           INTERFACE.B_East.setEnabled(false);
           INTERFACE.B_West.setEnabled(false);          
    }     
    
//-----------------------------------------------------------------------------              
 
    public static void BuildEnemy1()
    {
           CPU = new SHAPESHIFTER();
           CPU.SetName("T9000");
           CPU.SetGender("Male");
           CPU.SetFighterImage("OP_ShapeShifter.jpg");
           CPU.SetHealth(400);
           CPU.SetSpeed(6);
           CPU.SetStrength(4);
           CPU.SetEnergy(1000);
           CPU.SetSize(8);
           CPU.SetWeight(250);
           CPU.SetAttack(10);
           CPU.SetDefense(10);
           CPU.SetMaxDamage(200);           
           CPU.SetNanoRegenerate(true);
           CPU.SetShapeShift(true);        
    }

//-----------------------------------------------------------------------------              
 
    public static void BuildEnemy2()
    {
           CPU = new DESTROYER();
           CPU.SetName("T5000");
           CPU.SetGender("Female");
           CPU.SetFighterImage("OP_Destroyer.jpg");
           CPU.SetHealth(300);
           CPU.SetSpeed(3);
           CPU.SetStrength(7);
           CPU.SetEnergy(500);
           CPU.SetSize(15);
           CPU.SetWeight(3000);           
           CPU.SetAttack(8);
           CPU.SetDefense(5);
           CPU.SetMaxDamage(100);           
           CPU.SetBeamCannon(true);
           CPU.SetEmpShield(true);        
    } 
    
//-----------------------------------------------------------------------------              
 
    public static void BuildEnemy3()
    {
           CPU = new GENMOD();
           CPU.SetName("Jack");
           CPU.SetGender("Male");
           CPU.SetFighterImage("OP_GenMod.jpg");
           CPU.SetHealth(200);
           CPU.SetSpeed(5);
           CPU.SetStrength(5);
           CPU.SetEnergy(300);
           CPU.SetSize(9);
           CPU.SetWeight(200);
           CPU.SetAttack(5);
           CPU.SetDefense(3);
           CPU.SetMaxDamage(75);           
           CPU.SetEmpWave(true);
           CPU.SetHeatShield(true);        
    } 
 
//-----------------------------------------------------------------------------                                    
    
    public static void BuildEnemy4()
    {
           CPU = new PSY();
           CPU.SetName("Jill");
           CPU.SetGender("Female");
           CPU.SetFighterImage("OP_Psy.jpg");
           CPU.SetHealth(500);
           CPU.SetSpeed(7);
           CPU.SetStrength(3);
           CPU.SetEnergy(2000);
           CPU.SetSize(6);
           CPU.SetWeight(140);
           CPU.SetAttack(12);
           CPU.SetDefense(30);
           CPU.SetMaxDamage(225);           
           CPU.SetTelekinesis(true);
           CPU.SetBioField(true);        
    }    
    
//-----------------------------------------------------------------------------                  

    public static void BuildShopKeeper()
    {
           FRIEND = new GENMOD();
           FRIEND.SetName("Johnny");
           FRIEND.SetGender("Male");
           FRIEND.SetFighterImage("ShopKeeper.jpg");
           FRIEND.SetHealth(100);
           FRIEND.SetSpeed(3);
           FRIEND.SetStrength(4);
           FRIEND.SetEnergy(100);
           FRIEND.SetSize(8);
           FRIEND.SetWeight(180);
           FRIEND.SetAttack(1);
           FRIEND.SetDefense(1);
           FRIEND.SetMaxDamage(50);           
           FRIEND.SetEmpWave(false);
           FRIEND.SetHeatShield(true);
           FRIEND.SetIsFriend(true);
    }    

//-----------------------------------------------------------------------------
    
       public static void Sequence()
       {
              if(NewGame)
              {
                 CreateCharacter();
              }
              else
              {
                  GAME.SwitchBoard();
              }
       }
       
//-----------------------------------------------------------------------------       
       
       public static void CreateCharacter()
       { 
              int NUM = 0;
              
              switch(DIALOG)
              {
                  case 0 : INTERFACE.TA_Output.setText(
                           " What type of FIGHTER will you\n create?\n" +
                           "\n (D)estroyer AI" +
                           "\n (S)hapeShifter AI" +
                           "\n (G)enmod Terrestrial" +
                           "\n (P)sy Terrestrial\n" +
                           "\n Enter option. Click \"GO\" to continue.");
                  
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_3_ChooseClass.play(); }
                           
                           DIALOG++;
                           break;
                  case 1 : INTERFACE.TA_Output.setText("");
                           
                           CHOICE = INTERFACE.TF_Input.getText();
                  
                           if(CHOICE.isEmpty()) { CHOICE = " "; }
                           CHOICE = CHOICE.toLowerCase(); 
                           
                           if(CHOICE.charAt(0) == 'd' ||
                              CHOICE.charAt(0) == 's' ||
                              CHOICE.charAt(0) == 'g' ||
                              CHOICE.charAt(0) == 'p' 
                             )
                           { 
                              switch(CHOICE.charAt(0))
                              {
                                  case 'd' : PLAYER = new DESTROYER(); break;
                                  case 's' : PLAYER = new SHAPESHIFTER(); break;
                                  case 'g' : PLAYER = new GENMOD(); break;
                                  case 'p' : PLAYER = new PSY(); break;
                              }
                              
                              PLAYER.SetIsPlayer(true);
                              
                              INTERFACE.TA_Output.append(
                              "\n\n FIGHTER hierarchy created!" +
                              "\n Click \"GO\" to continue.");
                              
                              if(INTERFACE.PlayNarration) 
                              { INTERFACE.CR_4_FighterCreated.play(); }
                              
                              INTERFACE.TF_Input.setText("");
                              DIALOG++; 
                           }
                           else
                           {
                               INTERFACE.TA_Output.setText(
                               "\n Invalid option. Click \"GO\" and\n" +
                               " choose again...");
                               INTERFACE.TF_Input.setText("");
                               DIALOG--;
                           }            
                           break;
 
                  case 2 : INTERFACE.TA_Output.setText(
                           "What will you name your FIGHTER?" +
                           "\n\n Enter name and click \"GO\".");
                  
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_5_NameFighter.play(); }
                  
                           DIALOG++;
                           break;
                  case 3 : CHOICE = INTERFACE.TF_Input.getText();
                           if(CHOICE.isEmpty()) { CHOICE = "NoName"; }
                           PLAYER.SetName(CHOICE);
                           PLAYER.DisplayStats();
                           INTERFACE.TF_Input.setText("");
                           INTERFACE.TA_Output.setText(
                           "\n FIGHTER named!" +
                           "\n\n Click \"GO\" to continue.");
                           
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_6_FighterNamed.play(); }
                           
                           DIALOG++;
                           break;
                  case 4 : INTERFACE.TA_Output.setText(
                           "Choose a GENDER for your FIGHTER:");
                           INTERFACE.TF_Input.setText("");
                           
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_7_ChooseGender.play(); }
                           
                           DIALOG++;
                           break;
                  case 5 : CHOICE = INTERFACE.TF_Input.getText();
                  
                           if(CHOICE.isEmpty()) { CHOICE = " "; }
                           CHOICE = CHOICE.toLowerCase();
                      
                           if(CHOICE.charAt(0) == 'm' || CHOICE.charAt(0) == 'f')
                           {
                               switch(CHOICE.charAt(0))
                               {
                                   case 'm' : PLAYER.SetGender("Male"); break;
                                   case 'f' : PLAYER.SetGender("Female");break;
                               }
                               INTERFACE.TA_Output.setText(
                               "\n\n GENDER for FIGHTER is now set." +
                               "\n Click \"GO\" to continue.");
                               INTERFACE.TF_Input.setText("");
                               
                               if(INTERFACE.PlayNarration) 
                               { INTERFACE.CR_8_GenderSet.play(); }
                               
                               DIALOG++;
                               PLAYER.DisplayStats();
                           }
                           else
                           {
                               INTERFACE.TA_Output.setText(
                               "\n Invalid option. Click \"GO\" and\n" +
                               " choose Male or Female...");
                               INTERFACE.TF_Input.setText("");
                               DIALOG--; 
                           }
                           break;
                      
                  case 6 : INTERFACE.TA_Output.setText(
                           "\n Select the BODY shape for your" +
                           "\n FIGHTER. Bodies that are thin" +
                           "\n and svelte possess more SPEED" +
                           "\n and allow for faster, more " +
                           "\n numerous attacks and a greater" +
                           "\n ability to dodge an opponent's" +
                           "\n attack.\n" +
                           "\n Bodies that are stout and heavy" +
                           "\n possess STRENGTH - the ability" + 
                           "\n to do more damage at once in an" +
                           "\n atttack and the endurance to" +
                           "\n absorb more damage in defense.\n" +
                           "\n You have 10 points total to" +
                           "\n allocate between these two " +
                           "\n characteristics, and increasing" +
                           "\n one comes at the expense of" +
                           "\n the other attribute.\n" +
                           "\n Click \"GO\" to continue...");
                  
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_9_AllocateSpeed.play(); }
                  
                           DIALOG++;
                           break;
                  case 7 : INTERFACE.TA_Output.setText(
                           "\n How many points will you allocate" +
                           "\n for SPEED?\n" +
                           "\n Enter an amount between 1" +
                           "\n and 10 and click \"GO\".\n" +
                           "\n Note: Remaining points go to\n STRENGTH.");
                           INTERFACE.TF_Input.setText("");
                           CHOICE = " ";
                           NUM = 0;
                           
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_10_HowManyPoints.play(); }
                           
                           DIALOG++;
                           break;   
                  case 8 : CHOICE = INTERFACE.TF_Input.getText();
                           if(CHOICE.isEmpty()) 
                           {   
                               INTERFACE.TA_Output.setText(
                               "\n INPUT was empty. Try again.\n");                               
                               CHOICE = " "; 
                               DIALOG--;
                           }
                           else
                           {
                               try 
                               { 
                                   NUM = Integer.parseInt(CHOICE);
                                   
                                   if(NUM < 1)
                                   {
                                     INTERFACE.TA_Output.setText(
                                     "\n That's too low. Minimum is 1.\n Try again.");
                                     DIALOG--;
                                   }
                                   else if(NUM > 10)
                                   {
                                     INTERFACE.TA_Output.setText(
                                     "\n That's too high. Maximum is 10.\n Try again.");
                                     DIALOG--;
                                   }
                                   else
                                   {
                                     INTERFACE.TA_Output.setText(
                                      "\n Setting SPEED to " + NUM + ".");
                                     PLAYER.SetSpeed(NUM);
                                     PLAYER.SetStrength(10 - NUM);
                                     PLAYER.DisplayStats();
                                     DIALOG++;
                                   }                                    
                               }
                               catch(NumberFormatException X) 
                               { 
                                  INTERFACE.TA_Output.setText(
                                  "\n " + CHOICE + " is not a number!" + 
                                  "\n Try again.");
                                  DIALOG--;
                               }                                          
                           }

                           INTERFACE.TA_Output.append(
                           "\n\n Click \"GO\" to continue.");
                           break;
                  case 9 : INTERFACE.TA_Output.setText(
                           "\n\n Ready to play!\n" +
                           "\n Click \"GO\" to continue.");
                  
                           if(INTERFACE.PlayNarration) 
                           { INTERFACE.CR_11_ReadyToPlay.play(); }
                  
                           NewGame = false;
                           EnableSave = true;
                           LOCATION = PlayerStart;
                           ORIENTATION = 'n';
                           EnableNavigation();
                           break;    
                  default : INTERFACE.TA_Output.setText(
                           "\n Character creation sequence error!");
              }
              
       }

//-----------------------------------------------------------------------------       
  
       public void CreateCPU()
       {
              CPU = new FIGHTER();
              CPU.SetName("Player Hater");
       }
       
//-----------------------------------------------------------------------------       
  
       public void CreateFriend()
       {
              FRIEND = new FIGHTER();
              FRIEND.SetName("Possee");
       }   
            
//-----------------------------------------------------------------------------       
        
       
       public static boolean FIND(String DESC, String LOC, boolean FoundIt, int Amt)
       {
              if(FoundIt)
              {
                  INTERFACE.TA_Output.setText(
                  "\n Now empty, here is where" +
                  "\n you previously found " + DESC + ".");
                  
                  return true;
              }
              else
              {
                 INTERFACE.TA_Output.setText(
                 "\n You find: " + DESC + "!" +
                 "\n It is " + LOC + "." +
                 "\n\n Do you want to pick it up?" + 
                 "\n (y)es or (n)o");
                 
                 InputPane("Do you want to pick up the " + DESC + "?");
                 
                 if(CHOICE.isEmpty()) { CHOICE = " "; }
                 CHOICE = CHOICE.toLowerCase();
                 
                 switch(CHOICE.charAt(0))
                 {
                      case 'y' : INTERFACE.TA_Output.setText(
                                 "\n Adding " + DESC + " to inventory!");
                      
                                 if(DESC.equals("Key1")) 
                                 { PLAYER.SetKey1(true); }
                                 
                                 if(DESC.equals("Key2")) 
                                 { PLAYER.SetKey2(true); }
                                 
                                 if(DESC.equals("Key3")) 
                                 { PLAYER.SetKey3(true); }
                                 
                                 if(DESC.equals("Key4")) 
                                 { PLAYER.SetKey4(true); }
                                 
                                 if(DESC.equals("JackKnife")) 
                                 { 
                                    PLAYER.SetJackKnife(true);
                                    INTERFACE.RB_Weapon1.setText("JackKnife"); 
                                    INTERFACE.RB_Weapon1.setEnabled(true);
                                 }
                                 
                                 if(DESC.equals("Sword")) 
                                 {  
                                    PLAYER.SetSword(true);
                                    INTERFACE.RB_Weapon2.setText("Sword"); 
                                    INTERFACE.RB_Weapon2.setEnabled(true); 
                                 }
                                 
                                 if(DESC.equals("Glock")) 
                                 { 
                                     PLAYER.SetGlock(true);
                                     INTERFACE.RB_Weapon3.setText("Glock"); 
                                     INTERFACE.RB_Weapon3.setEnabled(true);
                                 }
                                 
                                 if(DESC.equals("Armor")) 
                                 { 
                                     PLAYER.SetArmor(true);
                                 }
                                 
                                 if(DESC.equals("Grenade")) 
                                 { 
                                     PLAYER.SetGrenades(PLAYER.GetGrenades() + Amt);
                                     INTERFACE.RB_Weapon4.setText("Grenade"); 
                                     INTERFACE.RB_Weapon4.setEnabled(true);
                                 }
                                 
                                 if(DESC.equals("GlockAmmo")) 
                                 { PLAYER.SetAmmo(PLAYER.GetAmmo() + Amt); }
                                 
                                 if(DESC.equals("MedKit")) 
                                 { PLAYER.SetMedKits(PLAYER.GetMedKits() + Amt); }
                                 
                                 PLAYER.DisplayStats();
                                 PLAYER.DisplayStats();
                                 INTERFACE.TA_Output.append(
                                 "\n\n Click \"GO\" to continue!");
                                 return true;
                                 
                      case 'n' : INTERFACE.TA_Output.setText(
                                 "\n O.k., you decide to leave it...");
                                 INTERFACE.TA_Output.append(
                                 "\n\n Click \"GO\" to continue!");
                                 return false;
                                    
                     default :  INTERFACE.TA_Output.setText(
                                "\n Invalid option. Click \"GO\" and\n" +
                                " choose yes or no..."); 
                                 return false;
                 }
              }               
       }
       
//-----------------------------------------------------------------------------       

       public static void SaveGame()
       {  
              try
              {
                 File SAVEDGAME = new File(PLAYER.GetName() + ".pirate");
                 FileOutputStream DATA = new FileOutputStream(SAVEDGAME);
                 PrintStream SAVE = new PrintStream(DATA);
                 
                 //1. Serialze the PLAYER object---------------------
                 
                 //A) PLAYER Attributes
                 SAVE.println(PLAYER.GetCharClass());
                 SAVE.println(PLAYER.GetName());
                 SAVE.println(PLAYER.GetGender());
                 SAVE.println(PLAYER.GetSpcAtk());
                 SAVE.println(PLAYER.GetSpcDef());
                 SAVE.println(PLAYER.GetFighterImage());
                 SAVE.println(PLAYER.GetHealth());
                 SAVE.println(PLAYER.GetSpeed());
                 SAVE.println(PLAYER.GetStrength());
                 SAVE.println(PLAYER.GetEnergy());
                 SAVE.println(PLAYER.GetAttack());
                 SAVE.println(PLAYER.GetDefense());
                 SAVE.println(PLAYER.GetSize());
                 SAVE.println(PLAYER.GetWeight());
                 SAVE.println(PLAYER.GetMaxDamage());
                 SAVE.println(PLAYER.GetMoney());
                 SAVE.println(PLAYER.GetLevel());
                 SAVE.println(PLAYER.GetIsPlayer());
                 SAVE.println(PLAYER.GetIsFriend());
                 SAVE.println(PLAYER.GetIsEnemy());
                 
                 //B) PLAYER Abilities
                 SAVE.println(PLAYER.GetUpload());
                 SAVE.println(PLAYER.GetDuplicate());
                 SAVE.println(PLAYER.GetBeamCannon());
                 SAVE.println(PLAYER.GetEmpShield());
                 SAVE.println(PLAYER.GetEmpWave());
                 SAVE.println(PLAYER.GetHeatShield());
                 SAVE.println(PLAYER.GetTelekinesis());
                 SAVE.println(PLAYER.GetBioField());
                 SAVE.println(PLAYER.GetNanoRegenerate());
                 SAVE.println(PLAYER.GetShapeShift());
                 
                 //C) PLAYER Inventory
                 SAVE.println(PLAYER.GetKey1());
                 SAVE.println(PLAYER.GetKey2());
                 SAVE.println(PLAYER.GetKey3());
                 SAVE.println(PLAYER.GetKey4());
                 SAVE.println(PLAYER.GetJackKnife());
                 SAVE.println(PLAYER.GetSword());
                 SAVE.println(PLAYER.GetGlock());
                 SAVE.println(PLAYER.GetAmmo());
                 SAVE.println(PLAYER.GetGrenades());
                 SAVE.println(PLAYER.GetArmor());
                 SAVE.println(PLAYER.GetMedKits());
                 
                 //2. Serialize Level Environment Data ---------------------
                 SAVE.println(Level1.FoundKey1);
                 SAVE.println(Level1.FoundKey2);
                 SAVE.println(Level1.FoundKey3);
                 SAVE.println(Level1.FoundKey4);
                 SAVE.println(Level1.Arena1_Unlocked);
                 SAVE.println(Level1.Arena2_Unlocked);
                 SAVE.println(Level1.Arena3_Unlocked);
                 SAVE.println(Level1.Arena4_Unlocked);
                 SAVE.println(Level1.FoundGlock);
                 SAVE.println(Level1.FoundGlockAmmo1);
                 SAVE.println(Level1.FoundSword);
                 SAVE.println(Level1.FoundJackKnife);
                 SAVE.println(Level1.FoundArmor);                 
                 SAVE.println(Level1.FoundMedKit1);
                 SAVE.println(Level1.FoundMedKit2);
                 SAVE.println(Level1.FoundMedKit3);
                 SAVE.println(Level1.FoughtENEMY1);
                 SAVE.println(Level1.FoughtENEMY2);
                 SAVE.println(Level1.FoughtENEMY3);
                 SAVE.println(Level1.FoughtENEMY4);
                 SAVE.println(Level1.FoundMoney1);
                 SAVE.println(Level1.FoundMoney2);
                 SAVE.println(Level1.FoundMoney3);
                 SAVE.println(Level1.FoundMoney4);
                 
                 //3. Save PLAYER Location
                 SAVE.println(LOCATION);
                 SAVE.println(ORIENTATION);
                 SAVE.println(ROW);    //for future use (grids)
                 SAVE.println(COLUMN); //for future use (grids)
                 
                 SAVE.close();
                 DATA.close();
                 
                 JOptionPane.showMessageDialog(null,"Game Saved Successfully!");
              }
              catch(IOException X) 
              { JOptionPane.showMessageDialog(null, "File Access Error!"); }
              
       }
       
//-----------------------------------------------------------------------------       

       public static void LoadGame()
       {
              String CharacterClass = "UNKNOWN";
              JFileChooser Pirate_Chooser = new JFileChooser();
              File Pirate_File;
              
              Pirate_Chooser.setDialogTitle(
              "Pirate Arena! - 2011 - Charles Germany:  " +
              "Load a saved PIRATE!");

              Pirate_Chooser.setApproveButtonText("Load PIRATE!");
              Pirate_Chooser.setBackground(new java.awt.Color(255,255,255));
              Pirate_Chooser.setForeground(new java.awt.Color(0,0,0));
              Pirate_Chooser.setFileFilter(new PirateFilter()); 
              
              int PLAYER_CHOICE = Pirate_Chooser.showOpenDialog(GUI);
             
              if(PLAYER_CHOICE == JFileChooser.APPROVE_OPTION)
               {
                  Pirate_File = Pirate_Chooser.getSelectedFile();
                  INTERFACE.TA_Output.setText(
                  "Loading " + Pirate_File.getName() + "...");
                 
                 try
                 {
                    FileInputStream DATA = new FileInputStream(Pirate_File);
                    InputStreamReader DATASTREAM = new InputStreamReader(DATA);
                    BufferedReader LOAD = new BufferedReader(DATASTREAM);

                    CharacterClass = LOAD.readLine();
                  
                    if(CharacterClass.equals("DESTROYER")) { PLAYER = new DESTROYER(); }
                    else if(CharacterClass.equals("GENMOD")) { PLAYER = new GENMOD(); }
                    else if(CharacterClass.equals("PSY")) { PLAYER = new PSY(); }
                    else if(CharacterClass.equals("SHAPESHIFTER")) { PLAYER = new SHAPESHIFTER(); }
                    else 
                    { 
                       JOptionPane.showMessageDialog(null, 
                       "CHEATER! You've been hacking your SaveGame files!"); 
                    }

                    //1. Load serialized PLAYER Data
                  
                    //A) Read PLAYER attributes data CONVERT to right data type
                    PLAYER.SetName(LOAD.readLine());
                    PLAYER.SetGender(LOAD.readLine());
                    PLAYER.SetSpcAtk(LOAD.readLine());
                    PLAYER.SetSpcDef(LOAD.readLine());
                    PLAYER.SetFighterImage(LOAD.readLine());
                    PLAYER.SetHealth(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetSpeed(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetStrength(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetEnergy(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetAttack(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetDefense(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetSize(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetWeight(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetMaxDamage(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetMoney(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetLevel(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetIsPlayer(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetIsFriend(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetIsEnemy(Boolean.parseBoolean(LOAD.readLine()));  
                    
                    //B) Read PLAYER abilities and CONVERT to right data type
                    PLAYER.SetUpload(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetDuplicate(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetBeamCannon(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetEmpShield(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetEmpWave(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetHeatShield(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetTelekinesis(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetBioField(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetNanoRegenerate(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetShapeShift(Boolean.parseBoolean(LOAD.readLine()));
                  
                    //C) Read PLAYER inventory and convert to right data type
                    PLAYER.SetKey1(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetKey2(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetKey3(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetKey4(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetJackKnife(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetSword(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetGlock(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetAmmo(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetGrenades(Integer.parseInt(LOAD.readLine()));
                    PLAYER.SetArmor(Boolean.parseBoolean(LOAD.readLine()));
                    PLAYER.SetMedKits(Integer.parseInt(LOAD.readLine()));

                    //2. Load Environment Data
                    Level1.FoundKey1 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundKey2 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundKey3 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundKey4 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.Arena1_Unlocked = Boolean.parseBoolean(LOAD.readLine());
                    Level1.Arena2_Unlocked = Boolean.parseBoolean(LOAD.readLine());
                    Level1.Arena3_Unlocked = Boolean.parseBoolean(LOAD.readLine());
                    Level1.Arena4_Unlocked = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundGlock = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundGlockAmmo1 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundSword = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundJackKnife = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundArmor = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMedKit1 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMedKit2 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMedKit3 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoughtENEMY1 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoughtENEMY2 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoughtENEMY3 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoughtENEMY4 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMoney1 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMoney2 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMoney3 = Boolean.parseBoolean(LOAD.readLine());
                    Level1.FoundMoney4 = Boolean.parseBoolean(LOAD.readLine());
                  
                    //3. Load PLAYER location data
                    LOCATION = Integer.parseInt(LOAD.readLine());
                    ORIENTATION =  LOAD.readLine().charAt(0);
                    ROW = Integer.parseInt(LOAD.readLine());
                    COLUMN = Integer.parseInt(LOAD.readLine());
                  
                    LOAD.close();
                    DATASTREAM.close();
                    DATA.close();
                   
                    JOptionPane.showMessageDialog(null,"Game Loaded Successfully!");
                  
                    //Note: Figure out whether to go static or instance here.
                    //GAME = new Level1(GUI);
                    //Initialize and prepare GAME and INTERFACE
                    EnableSave = true;
                    EnableNavigation();
                    INTERFACE.B_Start.setEnabled(false);
                    NewGame = false;
                    
                    INTERFACE.TA_Output.setFont(new java.awt.Font("Comic Sans MS", 0, 14));
                    INTERFACE.TA_Output.setForeground(new java.awt.Color(255, 255, 255));
                    CHOICE = "";
                    
                    PLAYER.DisplayStats();
                    if(INTERFACE.PlayMusic) { INTERFACE.ThemeMusic.loop(); }
                    
                    GAME = new Level1();
                    GAME.SwitchBoard();
                    
                }
                catch(IOException X) 
                { 
                    JOptionPane.showMessageDialog(null,"File Access Error!");
                }      
              }
              else
              {
                  INTERFACE.TA_Output.setText("\n LOAD Game canceled!");
              }
       }       
       
//-----------------------------------------------------------------------------
       
       public static void InputPane(String QUESTION)
       {
              JFrame X = new JFrame();
              CHOICE = FancyDialog.getString(X,QUESTION);
       }     
       
//-----------------------------------------------------------------------------              

public static void AUTOSCROLL()
{
   INTERFACE.TA_Output.setCaretPosition(
   INTERFACE.TA_Output.getDocument().getLength());
}       

//-----------------------------------------------------------------------------              
       
public static void WAIT(int SECONDS)
{
       try { Thread.sleep(SECONDS * 1000); }
       catch(Exception e) {
       INTERFACE.TA_Output.setText("WAIT problem."); }
}    

//-----------------------------------------------------------------------------              

       public static void CreateBattleField()
       {
              BFIELD = new PolyBATTLEFIELD(PLAYER,CPU);
              BFIELD.setVisible(true);
              G = BFIELD.getGraphics();
              BFIELD.start();
              GUI.repaint();
                  
              SwingWorker BANANA = new SwingWorker()
              {
                   //----------------------------     
                   public Object construct()
                   {      
                          try 
                          {   
                              for(;;)
                              { 
                                  BFIELD.update(G);
                                  Thread.sleep(20);
                              }
                          }
                          catch(Exception e) 
                          { e.printStackTrace(); }
                                   
                          return 0;
                   }
                      //-----------------------------
                         public void finished()
                         {      
                                BFIELD.setVisible(false);
                                BFIELD.dispose();
                         }
                          //------------------------------           
              };

              BANANA.start(); 
               
       }

//-----------------------------------------------------------------------------

public static void Combat(final FIGHTER Opponent1, final FIGHTER Opponent2)
{
       SwingWorker BANANA = new SwingWorker()
       {
        //-------------------------------------------------------------------     
            public Object construct()
            {
                   CombatRound = 1;
                   DisableNavigation();
                   INTERFACE.B_Attack.setEnabled(true);
                   INTERFACE.B_Defend.setEnabled(true);
                   
                   INTERFACE.ThemeMusic.stop();
                   if(INTERFACE.PlayMusic) { INTERFACE.FightSong.loop(); }
                   
                   OPVIEW = new OpponentFrame();
                   OPVIEW.setVisible(true);
                   
                   CreateBattleField();

                   Opponent1.DisplayStats();
                   Opponent2.DisplayStats();
                   BattleSequence(Opponent1, Opponent2);
                   return 0;
            }
            
        //-------------------------------------------------------------------
            
            public void finished()
            {
                   EnableNavigation();
                   INTERFACE.B_Attack.setEnabled(false);
                   INTERFACE.B_Defend.setEnabled(false);
                
                   if(Opponent1.GetHealth() > 0)
                      {
                          INTERFACE.TA_Output.setText(
                          "\n   The winner of this battle is:\n    " +
                          Opponent1.GetName() + "!\n\n    " +
                          Opponent2.GetName() + " suffers humiliating defeat."      );
                      }

                      else
                      {
                          INTERFACE.TA_Output.setText(
                          "\n   The winner of this battle is:\n   " +
                          Opponent2.GetName() + "!\n\n   " +
                          Opponent1.GetName() + " suffers humiliating defeat."      );
                      }
                      
                      PLAYER.DisplayStats();

                      if(GameFunctions.PLAYER.GetHealth() < 1)
                      {
                         INTERFACE.TA_Output.append(
                         "\n   You did not survive." +
                         "\n   GAME OVER!");
                         DisableNavigation();
                         INTERFACE.B_GO.setEnabled(false);
                      }
                      else
                      {
                          INTERFACE.TA_Output.append(
                          "\n\n    Amazingly, you survived..." +        
                          "\n\n   Click \"GO\" to continue...");
                      }

                      INTERFACE.FightSong.stop();
                      if(INTERFACE.PlayMusic) { INTERFACE.VictorySong.play(); }
                      
                      OPVIEW.setVisible(false);
                      OPVIEW.dispose();
                      
                      BFIELD.setVisible(false);
                      BFIELD.dispose();
                      
                      INTERFACE.TF_Input.requestFocus();
                      GUI.repaint();
                      WAIT(5);
                      INTERFACE.VictorySong.stop();
                      if(INTERFACE.PlayMusic) { INTERFACE.ThemeMusic.loop(); }
            }
          //-------------------------------------------------------------------           
            };

            BANANA.start();
}

//-----------------------------------------------------------------------------                     

    public static void BattleSequence(FIGHTER Opponent1, FIGHTER Opponent2)
    {
           IMPROBABILITY = new Random();
           int FirstAttack = 0;

           while(Opponent1.GetHealth() > 0 && Opponent2.GetHealth() > 0)
           {
                 INTERFACE.TA_Output.setText(
                 "\n   Total " +
                 "\n   Mortal" +
                 "\n   Combat!" +
                 "\n   Round " +
                 CombatRound + "!\n");

                 WAIT(3);

                 FirstAttack = IMPROBABILITY.nextInt(10) + 1;

                 if(Opponent1.GetSpeed() > Opponent2.GetSpeed())
                 { FirstAttack = FirstAttack + 2; }
                 else { FirstAttack = FirstAttack - 2; }

                 if(FirstAttack > 5)
                 {
                      INTERFACE.TA_Output.setText(
                      "  Due to a" +
                      "\n  combination" +
                      "\n  of SPEED and" +
                      "\n  CHANCE:\n  " +
                      Opponent1.GetName() +
                      "\n  makes the" +
                      "\n  FIRST\n  ATTACK!");

                      WAIT(4);

                      if(Opponent1.GetHealth() > 0)
                      {
                         Opponent1.Attack(Opponent2);
                         WAIT(2);
                      }

                      if(Opponent2.GetHealth() > 0)
                      {
                         INTERFACE.TA_Output.setText(
                         "\n  " + Opponent2.GetName() +
                         "\n  survives the" +
                         "\n  ONSLAUGHT\n  and" +
                         "\n  COUNTER\n  ATTACKS!");

                         WAIT(3);
                         Opponent2.Attack(Opponent1);
                         //GUI.repaint();
                         //OPVIEW.repaint();
                         WAIT(2);
                      }

                 }
                 else
                 {
                      INTERFACE.TA_Output.setText(
                      "  Due to a" +
                      "\n  combination" +
                      "\n  of SPEED and" +
                      "\n  CHANCE:\n  " +
                      Opponent2.GetName() +
                      "\n  makes the" +
                      "\n  FIRST\n  ATTACK!");

                      WAIT(4);

                      if(Opponent2.GetHealth() > 0)
                      {
                         Opponent2.Attack(Opponent1);
                         WAIT(2);
                      }

                       if(Opponent1.GetHealth() > 0)
                       {
                         INTERFACE.TA_Output.setText(
                         "\n  " + Opponent1.GetName() +
                         "\n  survives the" +
                         "\n  ONSLAUGHT\n  and" +
                         "\n  COUNTER\n  ATTACKS!");

                         WAIT(3);

                         Opponent1.Attack(Opponent2);
                         WAIT(2);
                       }

                   }

                 CombatRound++;
             }
    }

//-----------------------------------------------------------------------------                     

       public static void FancyPane1()
       {      
              JLabel Z = new JLabel("TEST");
              Z.setFont(new Font("Comic Sans MS", Font.BOLD, 32));
              Z.setForeground(Color.white);
              
              JPanel PANEL = new JPanel();              
              PANEL.add(Z);
              PANEL.setBackground(Color.BLUE);
              PANEL.setForeground(Color.WHITE);
              PANEL.setMinimumSize(new Dimension(200,200));
              
              JFrame BOX = new JFrame();
              
              JOptionPane.showMessageDialog(BOX,PANEL);   
       }
       
//-----------------------------------------------------------------------------       

       public static void FancyPane2()
       {
              UIManager um = new UIManager();
              um.put("OptionPane.messageForeground", new Color(255,0,0));
              um.put("OptionPane.messageFont",new Font("Comic Sans MS", Font.BOLD, 32));
              um.put("OptionPane.buttonFont", new Font("Verdana", Font.BOLD, 22));

              JOptionPane MESSAGE = new JOptionPane("SuperCalaFrajalisticExpeAlaDocius");
              
              MagicColorPane(MESSAGE,new Color(0,0,0));
              
              JDialog MESS = MESSAGE.createDialog(null, "Urgent Message!");
              MESS.setLocation(900,150);
              MESS.setVisible(true);           
       }
       
//-----------------------------------------------------------------------------       

       public static void FancyPane3()
       {
              UIManager um = new UIManager();
              um.put("OptionPane.messageForeground", new Color(255,0,0));
              um.put("OptionPane.messageFont",new Font("Comic Sans MS", Font.BOLD, 32));
              um.put("OptionPane.buttonFont", new Font("Verdana", Font.BOLD, 22));
              String TEMP = JOptionPane.showInputDialog("What is your name?");
       }

//-----------------------------------------------------------------------------                     
          
//Helper functions for background-colored JOPtionPanes
  public static void MagicColorPane(JOptionPane OptPane, Color CLR) 
  {
         OptPane.setBackground(CLR);
         
         for(Iterator i = getComponents(OptPane).iterator(); i.hasNext();) 
         {
             Component comp = (Component)i.next();
             if (comp instanceof JPanel) 
             {
                 comp.setBackground(CLR);
             }
         }
  }

  public final static Collection getComponents(Container CONT) 
  {
         Collection components = new Vector();
         Component[] comp = CONT.getComponents();
         
         for(int i = 0, n = comp.length; i < n; i++)
         {
             components.add(comp[i]);
             if (comp[i] instanceof Container)
             {
                  components.addAll(getComponents((Container) comp[i]));
             }
         }
         
         return components;
  }       

//-----------------------------------------------------------------------------       
  
 /*
 Notes: Below lines don't work. A BUG in Java. Must use helper fuctions above
        as a work around.
 um.put("OptionPane.background", new ColorUIResource(0,0,0));
 um.put("Panel.background", new ColorUIResource(0,0,0));
 */
}
