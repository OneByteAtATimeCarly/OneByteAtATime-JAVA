package Interface;
import GameFunctions.*;
import Levels.*;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.URL;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class INTERFACE extends javax.swing.JFrame implements KeyListener {

       //Globals
       GameFunctions GF;
       public static MediaTracker TRACKER;
       public static Image VIEW;
       public static boolean Wearing = false;
       public static Graphics GUI;
       
       //Menu
       JMenuBar PirateMenuBar;
       JMenu PirateMenu;
       JMenuItem PirateMenuItem;
       
       //Sound
       public static boolean PlayNarration = false;
       public static boolean PlayMusic= true;
       public static boolean PlaySoundEffects = true;
       //SOUND EFFECTS and Background MUSIC-------
       public static AudioClip ThemeMusic;
       public static AudioClip FightSong;
       public static AudioClip VictorySong;
       public static AudioClip SE_ButtonClick;
       public static AudioClip SE_HandToHand;
       public static AudioClip SE_JackKnife;
       public static AudioClip SE_Sword;
       public static AudioClip SE_Gun;
       public static AudioClip SE_Grenade;
       public static AudioClip SE_Whah;
       public static AudioClip SE_Key;
       public static AudioClip SE_Ammo;       
       public static AudioClip SE_Wind;
       public static AudioClip SE_Water;
       public static AudioClip SE_FootSteps;
       public static AudioClip SE_Hum;
       public static AudioClip SE_ChaChing;       
       
     //NARRATION - Character Creation------------
       public static AudioClip CR_0_HELP;
       public static AudioClip CR_1_WelcomeStart;
       public static AudioClip CR_2_CreateAFighter;
       public static AudioClip CR_3_ChooseClass;
       public static AudioClip CR_4_FighterCreated;
       public static AudioClip CR_5_NameFighter;
       public static AudioClip CR_6_FighterNamed;
       public static AudioClip CR_7_ChooseGender;
       public static AudioClip CR_8_GenderSet;
       public static AudioClip CR_9_AllocateSpeed;
       public static AudioClip CR_10_HowManyPoints;
       public static AudioClip CR_11_ReadyToPlay;
     //NARRATION - Game Navigation--------------- 
       public static AudioClip N_C1;
       public static AudioClip N_N1;
       public static AudioClip N_N1_Hall;
       public static AudioClip N_N2;
       public static AudioClip N_N2_Hall;
       public static AudioClip N_S1;
       public static AudioClip N_S1_Hall;
       public static AudioClip N_S2;
       public static AudioClip N_S2_Hall;
       public static AudioClip N_E1;
       public static AudioClip N_E1_Hall;
       public static AudioClip N_E2;
       public static AudioClip N_E2_Hall;
       public static AudioClip N_W1;
       public static AudioClip N_W1_Hall;
       public static AudioClip N_W2;
       public static AudioClip N_W2_Hall;
       public static AudioClip N_Arena;
       public static AudioClip N_Arena1Finished;
       public static AudioClip N_ArenaCorridor;
       public static AudioClip N_SeeAWall;
       public static AudioClip N_TryKey;
       public static AudioClip N_NeedAKey;
       //-------------------------------  
       
    /** Creates new form TEST */
    public INTERFACE() 
    {
        initComponents();
        
        //Get the screen size
        Toolkit toolkit =  Toolkit.getDefaultToolkit();
        Dimension SCREEN = toolkit.getScreenSize();
        
        //Size the JFrame's background as desired
        this.setSize(new Dimension(605,570));
        this.setLocation((SCREEN.width/4),(SCREEN.height/4) - 100);
        
        TF_Input.addKeyListener(this);
        
        //Set the JFrame's Background Color
        Color BG_Color = new Color(0,0,135);
        Container BackGround = getContentPane();
        BackGround.setBackground(BG_Color);
        
        this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        
        //To use a background Image in NetBeans, use a JLabel. Example:
        //ImageIcon BackGroundImage = new ImageIcon(getClass().getResource("/IMAGES/background.jpg"));
        //L_Background.setIcon(BackGroundImage);
        //L_Background.setLocation(0,0);
        //L_Background.setSize(new Dimension(600,560));
        
        TA_Output.setFont(new java.awt.Font("Comic Sans MS", 0, 25));
        TA_Output.setForeground(new java.awt.Color(255, 0, 0));
        TA_Output.setText("    Welcome to\n    Pirate Arena!\n\n" +
                          "    Click \"START\"\n    to begin.");
        
        SetupMenuBar();
        DisableButtons();  
        SetupAudio();
        if(PlayNarration) { CR_1_WelcomeStart.play(); }
        
    }

//-----------------------------------------------------------------------------    

public void SetupMenuBar()
{
           PirateMenuBar = new JMenuBar();

           //File Menu-------------------------------------
           PirateMenu = new JMenu("File");
           PirateMenu.setMnemonic(KeyEvent.VK_F);
           PirateMenu.getAccessibleContext().setAccessibleDescription(
           "Pirae Arena! File Menu");
           PirateMenuBar.add(PirateMenu);

           PirateMenuItem = new JMenuItem("Load", KeyEvent.VK_L);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_L, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Load a PIRATE!");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { B_Load.doClick(); } } );
           PirateMenu.add(PirateMenuItem);

           PirateMenuItem = new JMenuItem("Save", KeyEvent.VK_S);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_S, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Save a PIRATE!");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { B_Save.doClick(); } } );
           PirateMenu.add(PirateMenuItem);

           PirateMenuItem = new JMenuItem("Quit", KeyEvent.VK_Q);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_Q, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Quit Pirate Arena!");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { B_Quit.doClick(); } } );
           PirateMenu.add(PirateMenuItem);

           //Help Menu-------------------------------------
           PirateMenu = new JMenu("Help");
           PirateMenu.setMnemonic(KeyEvent.VK_H);
           PirateMenu.getAccessibleContext().setAccessibleDescription(
           "Pirate Arena! Help");
           PirateMenuBar.add(PirateMenu);

           PirateMenuItem = new JMenuItem("Assistance", KeyEvent.VK_A);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_A, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Pirate Arena! Assistance");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { B_Help.doClick(); } } );
           PirateMenu.add(PirateMenuItem);

           PirateMenuItem = new JMenuItem("About", KeyEvent.VK_B);
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "About Pirate Arena!");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           { JOptionPane.showMessageDialog(null,
             "Pirate Arena!\n2011 Charles Germany\nAaargh!!!"); }
           } );
           PirateMenu.add(PirateMenuItem);

           //Sound Menu--------------------------------
           PirateMenu = new JMenu("Sound");
           PirateMenu.setMnemonic(KeyEvent.VK_S);
           PirateMenu.getAccessibleContext().setAccessibleDescription(
           "Pirate Arena! Sound");
           PirateMenuBar.add(PirateMenu);
           //1-------
           PirateMenuItem = new JMenuItem("Narration |ON|OFF|", KeyEvent.VK_N);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_N, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Turn Narration ON or OFF");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {  if(PlayNarration)
              {
                 PlayNarration = false;
                 JOptionPane.showMessageDialog(null,
                 "Pirate Arena! narration has been turned OFF.");
              }
              else
              {  
                 PlayNarration = true; 
                 JOptionPane.showMessageDialog(null,
                 "Pirate Arena! narration has been turned ON.");}
              } } );
           PirateMenu.add(PirateMenuItem);
           //2-------
           PirateMenuItem = new JMenuItem("Music |ON|OFF|", KeyEvent.VK_M);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_M, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Turn Music ON or OFF");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {  if(PlayMusic)
              {
                 PlayMusic = false;
                 ThemeMusic.stop();
                 FightSong.stop();
                 JOptionPane.showMessageDialog(null,
                 "Pirate Arena! music has been turned off.");
              }
              else
              {
                 PlayMusic = true;
                 ThemeMusic.loop();
                 JOptionPane.showMessageDialog(null,
                 "Pirate Arena! music has been turned on.");
              }
           }
           } );
           PirateMenu.add(PirateMenuItem);
           //3-------
           PirateMenuItem = new JMenuItem("Sound Effects |ON|OFF|",
                                KeyEvent.VK_S);
           PirateMenuItem.setAccelerator(KeyStroke.getKeyStroke(
           KeyEvent.VK_S, ActionEvent.ALT_MASK));
           PirateMenuItem.getAccessibleContext().setAccessibleDescription(
           "Turn Sound Effects On or Off");
           PirateMenuItem.addActionListener(new ActionListener()
           { public void actionPerformed(ActionEvent event)
           {  if(PlaySoundEffects == true)
              {
                 PlaySoundEffects = false;
                 JOptionPane.showMessageDialog(null,
                 "Pirate Arena! sound effects have been turned OFF.");
              }
              else
              {
                 PlaySoundEffects = true;
                 JOptionPane.showMessageDialog(null,
                 "Pirate Arena! sound effects have been turned ON.");
              }
           }
           } );
           PirateMenu.add(PirateMenuItem);
           
           //Web Menu---------------------------
           PirateMenu = new JMenu("Web");
           PirateMenu.setMnemonic(KeyEvent.VK_W);
           PirateMenu.getAccessibleContext().setAccessibleDescription(
           "NetworkingProgramming.com");
           PirateMenuBar.add(PirateMenu);

           HYPERLINK NP = new HYPERLINK("  NetworkingProgramming  ",
           "http://www.networkingprogramming.com");
           PirateMenu.add(NP);

           this.setJMenuBar(PirateMenuBar);
     
}    

//-----------------------------------------------------------------------------    

    public void SetupAudio()
    { 
           ThemeMusic = Applet.newAudioClip(Get_Location("/AUDIO/PirateTheme.au"));
           FightSong = Applet.newAudioClip(Get_Location("/AUDIO/MortalKombat.au"));
           VictorySong = Applet.newAudioClip(Get_Location("/AUDIO/KungFuFighting.au"));
           SE_ButtonClick = Applet.newAudioClip(Get_Location("/AUDIO/ButtonClick.au"));
           SE_HandToHand = Applet.newAudioClip(Get_Location("/AUDIO/HandToHand.au"));
           SE_JackKnife = Applet.newAudioClip(Get_Location("/AUDIO/JackKnife.au"));
           SE_Sword = Applet.newAudioClip(Get_Location("/AUDIO/Sword.au"));
           SE_Gun = Applet.newAudioClip(Get_Location("/AUDIO/Gun.au"));
           SE_Grenade = Applet.newAudioClip(Get_Location("/AUDIO/Grenade.au"));
           SE_Whah = Applet.newAudioClip(Get_Location("/AUDIO/whah.au"));
           SE_Key = Applet.newAudioClip(Get_Location("/AUDIO/Key.au"));
           SE_Ammo = Applet.newAudioClip(Get_Location("/AUDIO/Ammo.au"));
           SE_Wind = Applet.newAudioClip(Get_Location("/AUDIO/Wind.au"));
           SE_Water = Applet.newAudioClip(Get_Location("/AUDIO/Water.au"));
           SE_FootSteps = Applet.newAudioClip(Get_Location("/AUDIO/FootSteps.au"));
           SE_Hum = Applet.newAudioClip(Get_Location("/AUDIO/ElectronicHum.au"));
           SE_ChaChing = Applet.newAudioClip(Get_Location("/AUDIO/Ring.au"));
           
           CR_0_HELP = Applet.newAudioClip(Get_Location("/AUDIO/0_HELP.au"));
           CR_1_WelcomeStart = Applet.newAudioClip(Get_Location("/AUDIO/1_WelcomeStart.au"));
           CR_2_CreateAFighter = Applet.newAudioClip(Get_Location("/AUDIO/2_CreateAFighter.au"));
           CR_3_ChooseClass = Applet.newAudioClip(Get_Location("/AUDIO/3_ChooseClass.au"));
           CR_4_FighterCreated = Applet.newAudioClip(Get_Location("/AUDIO/4_FighterCreated.au"));
           CR_5_NameFighter = Applet.newAudioClip(Get_Location("/AUDIO/5_NameFighter.au"));
           CR_6_FighterNamed = Applet.newAudioClip(Get_Location("/AUDIO/6_FighterNamed.au"));
           CR_7_ChooseGender = Applet.newAudioClip(Get_Location("/AUDIO/7_ChooseGender.au"));
           CR_8_GenderSet = Applet.newAudioClip(Get_Location("/AUDIO/8_GenderSet.au"));
           CR_9_AllocateSpeed = Applet.newAudioClip(Get_Location("/AUDIO/9_AllocateSpeed.au"));
           CR_10_HowManyPoints = Applet.newAudioClip(Get_Location("/AUDIO/10_HowManyPoints.au"));
           CR_11_ReadyToPlay = Applet.newAudioClip(Get_Location("/AUDIO/11_ReadyToPlay.au"));
           
           N_C1 = Applet.newAudioClip(Get_Location("/AUDIO/N_C1.au"));
           N_N1 = Applet.newAudioClip(Get_Location("/AUDIO/N_N1.au"));
           N_N1_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_N1_Hall.au"));
           N_N2 = Applet.newAudioClip(Get_Location("/AUDIO/N_N2.au"));
           N_N2_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_N2_Hall.au"));
           N_S1 = Applet.newAudioClip(Get_Location("/AUDIO/N_S1.au"));
           N_S1_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_S1_Hall.au"));
           N_S2 = Applet.newAudioClip(Get_Location("/AUDIO/N_S2.au"));
           N_S2_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_S2_Hall.au"));
           N_E1 = Applet.newAudioClip(Get_Location("/AUDIO/N_E1.au"));
           N_E1_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_E1_Hall.au"));
           N_E2 = Applet.newAudioClip(Get_Location("/AUDIO/N_E2.au"));
           N_E2_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_E2_Hall.au"));
           N_W1 = Applet.newAudioClip(Get_Location("/AUDIO/N_W1.au"));
           N_W1_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_W1_Hall.au"));
           N_W2 = Applet.newAudioClip(Get_Location("/AUDIO/N_W2.au"));
           N_W2_Hall = Applet.newAudioClip(Get_Location("/AUDIO/N_W2_Hall.au"));
           N_Arena = Applet.newAudioClip(Get_Location("/AUDIO/N_Arena.au"));
           N_Arena1Finished = Applet.newAudioClip(Get_Location("/AUDIO/N_Arena1Finished.au"));
           N_ArenaCorridor = Applet.newAudioClip(Get_Location("/AUDIO/N_ArenaCorridor.au"));
           N_SeeAWall = Applet.newAudioClip(Get_Location("/AUDIO/N_SeeAWall.au"));
           N_TryKey = Applet.newAudioClip(Get_Location("/AUDIO/N_TryKey.au"));
           N_NeedAKey = Applet.newAudioClip(Get_Location("/AUDIO/N_NeedAKey.au"));
    }
    
 //-----------------------------------------------------------------------------    
     
    public URL Get_Location(String filename)
    {
           URL url = null;
           try { url = this.getClass().getResource(filename); }
           catch (Exception e) { /*STUFF*/ }
           return url;
    }    
    
 //-----------------------------------------------------------------------------   

    public void paint(Graphics X)
    {
           super.paint(X);
           UpdateView();
           DrawMap();
           DrawPlayerPosition();
    }
    
//-----------------------------------------------------------------------------

     public void DrawPlayerPosition()
     {
            Graphics X = getGraphics();
            X.setColor(Color.green);
            
            switch(GameFunctions.LOCATION)
            {
                 case Level1.C1 : X.fillOval(100,320,10,10);
                                  break;
                 case Level1.N1HALL : X.fillOval(100,305,10,10);
                                  break;    
                 case Level1.N1 : X.fillOval(100,290,10,10);
                                  break;
                 case Level1.N2HALL : X.fillOval(100,275,10,10);
                                  break;  
                 case Level1.N2 : X.fillOval(100,260,10,10);
                                  break;                     
                 case Level1.S1HALL : X.fillOval(100,335,10,10);
                                  break;
                 case Level1.S1 : X.fillOval(100,350,10,10);
                                  break; 
                 case Level1.S2HALL : X.fillOval(100,365,10,10);
                                  break;    
                 case Level1.S2 : X.fillOval(100,380,10,10);
                                  break;                         
                 case Level1.E1HALL : X.fillOval(115,320,10,10);
                                      break;    
                 case Level1.E1 : X.fillOval(130,320,10,10);
                                  break;
                 case Level1.E2HALL : X.fillOval(145,320,10,10);
                                      break;
                 case Level1.E2 : X.fillOval(160,320,10,10);
                                  break; 
                 case Level1.A3HALL : X.fillOval(162,302,10,10);
                                  break; 
                 case Level1.A4HALL : X.fillOval(160,340,10,10);
                                  break; 
                 case Level1.W1HALL : X.fillOval(85,320,10,10);
                                  break;    
                 case Level1.W1 : X.fillOval(70,320,10,10);
                                  break;
                 case Level1.W2HALL : X.fillOval(55,320,10,10);
                                  break;
                 case Level1.W2 : X.fillOval(40,320,10,10);
                                  break;
                 case Level1.A1HALL : X.fillOval(40,300,10,10);
                                  break;
                 case Level1.A2HALL : X.fillOval(40,340,10,10);
                                  break; 
                 case Level1.A1 : X.fillOval(40,277,10,10);
                                  break;
                 case Level1.A2 : X.fillOval(40,368,10,10);
                                  break;
                 case Level1.A3 : X.fillOval(161,277,10,10);
                                  break;
                 case Level1.A4 : X.fillOval(161,368,10,10);
                                  break;   
            }
     }

//-----------------------------------------------------------------------------
    
    public void DrawMap()
    {
           Graphics X = getGraphics();
        
           X.setColor(Color.white);
           
           //Draw C1
           X.fillRect(95,315,20,20);
           
           //Draw N1
           X.fillRect(95,285,20,20);
           
           //Draw N2
           X.fillRect(95,255,20,20);
           
           //Draw S1
           X.fillRect(95,345,20,20);
           
           //Draw S2
           X.fillRect(95,375,20,20);
           
           //Draw E1
           X.fillRect(125,315,20,20);
           
           //Draw E2
           X.fillRect(155,315,20,20);
           
           //Draw W1
           X.fillRect(65,315,20,20);
           
           //Draw W2
           X.fillRect(35,315,20,20);
           
           X.setColor(Color.white);
           
           //Draw C1 Hallway to N1
           X.drawLine(100,315,100,305);
           X.drawLine(110,315,110,305);
           
           //Draw N1 Hallway to N2
           X.drawLine(100,285,100,275);
           X.drawLine(110,285,110,275);
           
           //Draw C1 Hallway to S1
           X.drawLine(100,335,100,345);
           X.drawLine(110,335,110,345);           

           //Draw S1 Hallway to S2
           X.drawLine(100,365,100,375);
           X.drawLine(110,365,110,375);
           
           //Draw C1 Hallway to W1
           X.drawLine(95,320,85,320);
           X.drawLine(95,330,85,330);          
           
           //Draw W1 Hallway to W2
           X.drawLine(65,320,55,320);
           X.drawLine(65,330,55,330);
           
           //Draw C1 Hallway to E1
           X.drawLine(115,320,125,320);
           X.drawLine(115,330,125,330);
           
           //Draw E1 Hallway to E2
           X.drawLine(145,320,155,320);
           X.drawLine(145,330,155,330);
           
           //RECTANGLE
           //int[] XCORDS = {35,  65, 65, 35, 35};
           //int[] YCORDS = {255,255,275,275,255};
           
           //TRIANGLE - WIDE
           //int[] XCORDS = {25,  55, 85, 25};
           //int[] YCORDS = {285,265,285,285};
           
           //TRIANGLE - NARROW
           //int[] XCORDS = {35,  45, 55, 35};
           //int[] YCORDS = {295,265,295,295};
           
           X.setColor(Color.red);
           
           //OCTAGON ARENA 1 (Upper Left)
           int[] XCORDS1 = {38,  53, 63, 63,  53, 38,  28,  28};
           int[] YCORDS1 = {265,265,275,290, 300,300, 290, 275};
           X.fillPolygon(XCORDS1, YCORDS1, XCORDS1.length);
           
           //OCTAGON ARENA 2 (Upper Right)
           int[] XCORDS2 = {159,  174, 184, 184,  174, 159,  149,  149};
           int[] YCORDS2 = {265,265,275,290, 300,300, 290, 275};
           X.fillPolygon(XCORDS2, YCORDS2, XCORDS2.length);
           
           //OCTAGON ARENA 3 (Lower Left)
           int[] XCORDS3 = {38,  53, 63, 63,  53, 38,  28,  28};
           int[] YCORDS3 = {355,355,365,380, 390,390, 380, 365};
           X.fillPolygon(XCORDS3, YCORDS3, XCORDS3.length);
           
           //OCTAGON ARENA 4 (Lower Right)
           int[] XCORDS4 = {159,  174, 184, 184,  174, 159,  149,  149};
           int[] YCORDS4 = {355,355,365,380, 390,390, 380, 365};
           X.fillPolygon(XCORDS4, YCORDS4, XCORDS4.length);  
           
           X.setColor(Color.white);
           
           //Draw W2 Hallway to AR1
           X.drawLine(40,315,40,300);
           X.drawLine(50,315,50,300);
           
           //Draw W2 Hallway to AR2
           X.drawLine(40,355,40,335);
           X.drawLine(50,355,50,335);
           
           //Draw E2 Hallway to AR3
           X.drawLine(160,315,160,300);
           X.drawLine(170,315,170,300);
           
           //Draw E2 Hallway to AR4
           X.drawLine(160,355,160,335);
           X.drawLine(170,355,170,335);           
    }
    
 //-----------------------------------------------------------------------------
 
    public void UpdateView()
    {
           Graphics X = getGraphics();
        
           switch(GameFunctions.LOCATION)
           {
               case GameFunctions.INTRO : VIEW = getToolkit().getImage(Get_Location(
                                          "/IMAGES/Pirate.jpg"));
                                          break;
                   
               case Level1.C1 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/C1_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/C1_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/C1_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/C1_W.jpg"));
                                               break;    
                                }
                                break; 
                   
               case Level1.N1 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N1_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N1_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N1_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N1_W.jpg"));
                                               break;    
                                }
                                break; 
                   
               case Level1.S1 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S1_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S1_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S1_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S1_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.E1 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E1_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E1_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E1_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E1_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.W1 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W1_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W1_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W1_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W1_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.N2 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N2_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N2_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N2_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/N2_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.S2 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S2_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S2_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S2_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/S2_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.E2 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E2_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E2_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E2_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/E2_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.W2 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W2_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W2_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W2_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/W2_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.A1 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena1_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena1_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena1_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena1_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.A2 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena2_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena2_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena2_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena2_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.A3 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena3_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena3_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena3_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena3_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.A4 : switch(GF.ORIENTATION)
                                {
                                    case 'n' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena4_N.jpg"));
                                               break;
                                        
                                    case 's' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena4_S.jpg"));
                                               break;
                                        
                                    case 'e' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena4_E.jpg"));
                                               break;
                                        
                                    case 'w' : VIEW = getToolkit().getImage(
                                               Get_Location("/IMAGES/VIEW/Arena4_W.jpg"));
                                               break;    
                                }
                                break;
                   
               case Level1.N1HALL : switch(GF.ORIENTATION)
                                    {
                                       case 'n' : VIEW = getToolkit().getImage(
                                                  Get_Location("/IMAGES/VIEW/N1Hall_N.jpg"));
                                                  break;
                                        
                                       case 's' : VIEW = getToolkit().getImage(
                                                  Get_Location("/IMAGES/VIEW/N1Hall_S.jpg"));
                                                  break;
                                        
                                       case 'e' : VIEW = getToolkit().getImage(
                                                  Get_Location("/IMAGES/VIEW/N1Hall_E.jpg"));
                                                  break;
                                        
                                       case 'w' : VIEW = getToolkit().getImage(
                                                  Get_Location("/IMAGES/VIEW/N1Hall_W.jpg"));
                                                  break;    
                                   }
                                   break;
                   
              case Level1.N2HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/N2Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/N2Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/N2Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/N2Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                   
              case Level1.S1HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S1Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S1Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S1Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S1Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                   
              case Level1.S2HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S2Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S2Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S12Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/S2Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                  
              case Level1.E1HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E1Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E1Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E1Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E1Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                  
              case Level1.E2HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E2Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E2Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E2Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/E2Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                  
              case Level1.W1HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W1Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W1Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W1Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W1Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                   
              case Level1.W2HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W2Hall_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W2Hall_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W2Hall_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/W2Hall_W.jpg"));
                                                 break;    
                                   }
                                   break;
                   
              case Level1.A1HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A1Corridor_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A1Corridor_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A1Corridor_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A1Corridor_W.jpg"));
                                                 break;    
                                   }
                                   break;
                  
              case Level1.A2HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A2Corridor_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A2Corridor_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A2Corridor_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A2Corridor_W.jpg"));
                                                 break;    
                                   }
                                   break;
                  
              case Level1.A3HALL: switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A3Corridor_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A3Corridor_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A3Corridor_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A3Corridor_W.jpg"));
                                                 break;    
                                   }
                                   break;
                  
              case Level1.A4HALL : switch(GF.ORIENTATION)
                                   {
                                      case 'n' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A4Corridor_N.jpg"));
                                                 break;
                                        
                                      case 's' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A4Corridor_S.jpg"));
                                                 break;
                                        
                                      case 'e' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A4Corridor_E.jpg"));
                                                 break;
                                        
                                      case 'w' : VIEW = getToolkit().getImage(
                                                 Get_Location("/IMAGES/VIEW/A4Corridor_W.jpg"));
                                                 break;    
                                   }
                                   break;    
                   
               default : JOptionPane.showMessageDialog(null,"NAVIGATION ERROR!");
           }    
           
           X.drawImage(VIEW,12,84,273,165,this);
    }  
    
//-----------------------------------------------------------------------------    
    
    public void DisableButtons()
    {
           B_North.setEnabled(false);
           B_South.setEnabled(false);
           B_East.setEnabled(false);
           B_West.setEnabled(false);
           B_GO.setEnabled(false);
           B_Pause.setEnabled(false);
           B_Alt.setEnabled(false);
           B_Look.setEnabled(false);
           B_Use.setEnabled(false);
           B_Attack.setEnabled(false);
           B_Defend.setEnabled(false);
           RB_Weapon1.setEnabled(false);
           RB_Weapon2.setEnabled(false);
           RB_Weapon3.setEnabled(false);
           RB_Weapon4.setEnabled(false);
           S_Charge.setEnabled(false);
           CB_Abilities.setEnabled(false);
           LB_Inventory.setEnabled(false);        
    }

//-----------------------------------------------------------------------------

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BG_Weapons = new javax.swing.ButtonGroup();
        BG_Navigation_NavView = new javax.swing.ButtonGroup();
        L_Title = new javax.swing.JLabel();
        P_PlayerStats = new javax.swing.JPanel();
        L_PlayerName = new javax.swing.JLabel();
        L_PlayerNameBox = new javax.swing.JLabel();
        L_GenderBox = new javax.swing.JLabel();
        L_Gender = new javax.swing.JLabel();
        L_ClassBox = new javax.swing.JLabel();
        L_Class = new javax.swing.JLabel();
        L_Health = new javax.swing.JLabel();
        L_HealthBox = new javax.swing.JLabel();
        L_AtkBox = new javax.swing.JLabel();
        L_Atk = new javax.swing.JLabel();
        L_DefBox = new javax.swing.JLabel();
        L_Def = new javax.swing.JLabel();
        L_SpeedBox = new javax.swing.JLabel();
        L_Speed = new javax.swing.JLabel();
        L_StrengthBox = new javax.swing.JLabel();
        L_Strength = new javax.swing.JLabel();
        L_Size = new javax.swing.JLabel();
        L_SizeBox = new javax.swing.JLabel();
        L_WeightBox = new javax.swing.JLabel();
        L_Weight = new javax.swing.JLabel();
        L_EnergyBox = new javax.swing.JLabel();
        L_Energy = new javax.swing.JLabel();
        L_MaxDamage = new javax.swing.JLabel();
        L_MaxDamageBox = new javax.swing.JLabel();
        TF_Input = new javax.swing.JTextField();
        L_Output = new javax.swing.JLabel();
        SP_MainOutput = new javax.swing.JScrollPane();
        TA_Output = new javax.swing.JTextArea();
        L_Input = new javax.swing.JLabel();
        L_FrontViewLabel = new javax.swing.JLabel();
        L_FrontView = new javax.swing.JLabel();
        L_MapBox = new javax.swing.JLabel();
        P_NavButtons = new javax.swing.JPanel();
        B_East = new javax.swing.JButton();
        B_North = new javax.swing.JButton();
        B_South = new javax.swing.JButton();
        B_West = new javax.swing.JButton();
        B_GO = new javax.swing.JButton();
        L_Map = new javax.swing.JLabel();
        P_LoadSave = new javax.swing.JPanel();
        B_Pause = new javax.swing.JButton();
        B_Start = new javax.swing.JButton();
        B_Quit = new javax.swing.JButton();
        B_Help = new javax.swing.JButton();
        B_Load = new javax.swing.JButton();
        B_Save = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        B_Attack = new javax.swing.JButton();
        B_Defend = new javax.swing.JButton();
        B_Look = new javax.swing.JButton();
        B_Use = new javax.swing.JButton();
        B_Alt = new javax.swing.JButton();
        CB_Abilities = new javax.swing.JComboBox();
        L_Inventory = new javax.swing.JLabel();
        SP_Abilities = new javax.swing.JScrollPane();
        LB_Inventory = new javax.swing.JList();
        L_Abilities = new javax.swing.JLabel();
        P_MonExpLvl = new javax.swing.JPanel();
        L_Ammo = new javax.swing.JLabel();
        L_Level = new javax.swing.JLabel();
        L_Money = new javax.swing.JLabel();
        L_AmmoBox = new javax.swing.JLabel();
        L_MoneyBox = new javax.swing.JLabel();
        L_LevelBox = new javax.swing.JLabel();
        PB_HealthBar = new javax.swing.JProgressBar();
        L_Charge = new javax.swing.JLabel();
        S_Charge = new javax.swing.JSlider();
        L_HealthBar = new javax.swing.JLabel();
        P_Weapons = new javax.swing.JPanel();
        RB_Weapon4 = new javax.swing.JRadioButton();
        RB_Weapon1 = new javax.swing.JRadioButton();
        RB_Weapon2 = new javax.swing.JRadioButton();
        RB_Weapon3 = new javax.swing.JRadioButton();
        L_Weapons = new javax.swing.JLabel();
        L_SpcAtk = new javax.swing.JLabel();
        L_SpcDef = new javax.swing.JLabel();
        L_SpcAtkBox = new javax.swing.JLabel();
        L_SpcDefBox = new javax.swing.JLabel();
        L_Background = new javax.swing.JLabel();
        P_NavView = new javax.swing.JPanel();
        RB_Navigation_View = new javax.swing.JRadioButton();
        RB_Navigation_Nav = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowStateListener(new java.awt.event.WindowStateListener() {
            public void windowStateChanged(java.awt.event.WindowEvent evt) {
                formWindowStateChanged(evt);
            }
        });
        getContentPane().setLayout(null);

        L_Title.setFont(new java.awt.Font("Blade Runner Movie Font", 0, 14));
        L_Title.setForeground(new java.awt.Color(255, 0, 51));
        L_Title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Title.setText("Pirate Arena!");
        L_Title.setToolTipText("");
        getContentPane().add(L_Title);
        L_Title.setBounds(50, 3, 190, 15);

        P_PlayerStats.setBackground(new java.awt.Color(0, 0, 0));
        P_PlayerStats.setForeground(new java.awt.Color(255, 255, 255));
        P_PlayerStats.setLayout(null);

        L_PlayerName.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_PlayerName.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerName.setText("Name:");
        L_PlayerName.setToolTipText("");
        P_PlayerStats.add(L_PlayerName);
        L_PlayerName.setBounds(10, 11, 40, 11);

        L_PlayerNameBox.setForeground(new java.awt.Color(51, 255, 0));
        L_PlayerNameBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerNameBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_PlayerNameBox);
        L_PlayerNameBox.setBounds(50, 11, 220, 14);

        L_GenderBox.setForeground(new java.awt.Color(51, 255, 0));
        L_GenderBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_GenderBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_GenderBox);
        L_GenderBox.setBounds(50, 29, 75, 14);

        L_Gender.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Gender.setForeground(new java.awt.Color(255, 255, 255));
        L_Gender.setText("Gender:");
        L_Gender.setToolTipText("");
        P_PlayerStats.add(L_Gender);
        L_Gender.setBounds(10, 30, 40, 11);

        L_ClassBox.setFont(new java.awt.Font("Tahoma", 0, 10));
        L_ClassBox.setForeground(new java.awt.Color(51, 255, 0));
        L_ClassBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_ClassBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_ClassBox);
        L_ClassBox.setBounds(50, 46, 75, 14);

        L_Class.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Class.setForeground(new java.awt.Color(255, 255, 255));
        L_Class.setText("Class:");
        L_Class.setToolTipText("");
        P_PlayerStats.add(L_Class);
        L_Class.setBounds(10, 48, 40, 11);

        L_Health.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Health.setForeground(new java.awt.Color(255, 255, 255));
        L_Health.setText("Health:");
        L_Health.setToolTipText("");
        P_PlayerStats.add(L_Health);
        L_Health.setBounds(10, 65, 40, 11);

        L_HealthBox.setForeground(new java.awt.Color(51, 255, 0));
        L_HealthBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_HealthBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_HealthBox);
        L_HealthBox.setBounds(50, 63, 75, 14);

        L_AtkBox.setForeground(new java.awt.Color(51, 255, 0));
        L_AtkBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_AtkBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_AtkBox);
        L_AtkBox.setBounds(50, 81, 75, 14);

        L_Atk.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Atk.setForeground(new java.awt.Color(255, 255, 255));
        L_Atk.setText("Atk:");
        L_Atk.setToolTipText("");
        P_PlayerStats.add(L_Atk);
        L_Atk.setBounds(10, 83, 40, 11);

        L_DefBox.setForeground(new java.awt.Color(51, 255, 0));
        L_DefBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_DefBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_DefBox);
        L_DefBox.setBounds(50, 98, 75, 14);

        L_Def.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Def.setForeground(new java.awt.Color(255, 255, 255));
        L_Def.setText("Def:");
        L_Def.setToolTipText("");
        P_PlayerStats.add(L_Def);
        L_Def.setBounds(10, 100, 40, 11);

        L_SpeedBox.setForeground(new java.awt.Color(51, 255, 0));
        L_SpeedBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_SpeedBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_SpeedBox);
        L_SpeedBox.setBounds(190, 28, 80, 14);

        L_Speed.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Speed.setForeground(new java.awt.Color(255, 255, 255));
        L_Speed.setText("Speed:");
        L_Speed.setToolTipText("");
        P_PlayerStats.add(L_Speed);
        L_Speed.setBounds(140, 30, 40, 11);

        L_StrengthBox.setForeground(new java.awt.Color(51, 255, 0));
        L_StrengthBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_StrengthBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_StrengthBox);
        L_StrengthBox.setBounds(190, 45, 80, 14);

        L_Strength.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Strength.setForeground(new java.awt.Color(255, 255, 255));
        L_Strength.setText("Strength:");
        L_Strength.setToolTipText("");
        P_PlayerStats.add(L_Strength);
        L_Strength.setBounds(140, 47, 50, 11);

        L_Size.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Size.setForeground(new java.awt.Color(255, 255, 255));
        L_Size.setText("Size:");
        L_Size.setToolTipText("");
        P_PlayerStats.add(L_Size);
        L_Size.setBounds(140, 66, 30, 11);

        L_SizeBox.setForeground(new java.awt.Color(51, 255, 0));
        L_SizeBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_SizeBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_SizeBox);
        L_SizeBox.setBounds(164, 64, 30, 14);

        L_WeightBox.setForeground(new java.awt.Color(51, 255, 0));
        L_WeightBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_WeightBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_WeightBox);
        L_WeightBox.setBounds(240, 64, 30, 14);

        L_Weight.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Weight.setForeground(new java.awt.Color(255, 255, 255));
        L_Weight.setText("Weight:");
        L_Weight.setToolTipText("");
        P_PlayerStats.add(L_Weight);
        L_Weight.setBounds(200, 66, 40, 11);

        L_EnergyBox.setForeground(new java.awt.Color(51, 255, 0));
        L_EnergyBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnergyBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_EnergyBox);
        L_EnergyBox.setBounds(180, 82, 90, 14);

        L_Energy.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Energy.setForeground(new java.awt.Color(255, 255, 255));
        L_Energy.setText("Energy:");
        L_Energy.setToolTipText("");
        P_PlayerStats.add(L_Energy);
        L_Energy.setBounds(140, 84, 40, 11);

        L_MaxDamage.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_MaxDamage.setForeground(new java.awt.Color(255, 255, 255));
        L_MaxDamage.setText("Max Dmg:");
        L_MaxDamage.setToolTipText("");
        P_PlayerStats.add(L_MaxDamage);
        L_MaxDamage.setBounds(140, 101, 50, 11);

        L_MaxDamageBox.setForeground(new java.awt.Color(51, 255, 0));
        L_MaxDamageBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_MaxDamageBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_PlayerStats.add(L_MaxDamageBox);
        L_MaxDamageBox.setBounds(190, 99, 80, 14);

        getContentPane().add(P_PlayerStats);
        P_PlayerStats.setBounds(310, 5, 280, 120);

        TF_Input.setFont(new java.awt.Font("Comic Sans MS", 0, 9));
        TF_Input.setForeground(new java.awt.Color(255, 0, 0));
        TF_Input.setToolTipText("");
        getContentPane().add(TF_Input);
        TF_Input.setBounds(305, 144, 285, 20);

        L_Output.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Output.setForeground(new java.awt.Color(255, 0, 0));
        L_Output.setText("Output");
        L_Output.setToolTipText("");
        getContentPane().add(L_Output);
        L_Output.setBounds(430, 166, 34, 11);

        SP_MainOutput.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SP_MainOutput.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        TA_Output.setBackground(new java.awt.Color(0, 0, 0));
        TA_Output.setColumns(20);
        TA_Output.setEditable(false);
        TA_Output.setFont(new java.awt.Font("Comic Sans MS", 0, 9));
        TA_Output.setForeground(new java.awt.Color(255, 255, 255));
        TA_Output.setLineWrap(true);
        TA_Output.setRows(5);
        SP_MainOutput.setViewportView(TA_Output);

        getContentPane().add(SP_MainOutput);
        SP_MainOutput.setBounds(305, 180, 290, 216);

        L_Input.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Input.setForeground(new java.awt.Color(255, 0, 0));
        L_Input.setText("Input");
        L_Input.setToolTipText("");
        getContentPane().add(L_Input);
        L_Input.setBounds(430, 128, 34, 11);

        L_FrontViewLabel.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_FrontViewLabel.setForeground(new java.awt.Color(255, 255, 255));
        L_FrontViewLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_FrontViewLabel.setText("Front View");
        L_FrontViewLabel.setToolTipText("");
        getContentPane().add(L_FrontViewLabel);
        L_FrontViewLabel.setBounds(98, 12, 80, 20);

        L_FrontView.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_FrontView);
        L_FrontView.setBounds(4, 30, 280, 170);

        L_MapBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(L_MapBox);
        L_MapBox.setBounds(16, 208, 170, 150);

        P_NavButtons.setBackground(new java.awt.Color(0, 0, 0));
        P_NavButtons.setAlignmentX(0.0F);
        P_NavButtons.setAlignmentY(0.0F);
        P_NavButtons.setFont(new java.awt.Font("Tahoma", 0, 9));
        P_NavButtons.setLayout(null);

        B_East.setBackground(new java.awt.Color(0, 51, 255));
        B_East.setFont(new java.awt.Font("Verdana", 0, 8));
        B_East.setForeground(new java.awt.Color(255, 255, 255));
        B_East.setText("E");
        B_East.setToolTipText("");
        B_East.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_East.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_EastActionPerformed(evt);
            }
        });
        P_NavButtons.add(B_East);
        B_East.setBounds(66, 25, 34, 15);

        B_North.setBackground(new java.awt.Color(0, 51, 255));
        B_North.setFont(new java.awt.Font("Verdana", 0, 8));
        B_North.setForeground(new java.awt.Color(255, 255, 255));
        B_North.setText("N");
        B_North.setToolTipText("");
        B_North.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_North.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_NorthActionPerformed(evt);
            }
        });
        P_NavButtons.add(B_North);
        B_North.setBounds(34, 5, 34, 15);

        B_South.setBackground(new java.awt.Color(0, 51, 255));
        B_South.setFont(new java.awt.Font("Verdana", 0, 8));
        B_South.setForeground(new java.awt.Color(255, 255, 255));
        B_South.setText("S");
        B_South.setToolTipText("");
        B_South.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_South.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_SouthActionPerformed(evt);
            }
        });
        P_NavButtons.add(B_South);
        B_South.setBounds(34, 44, 34, 15);

        B_West.setBackground(new java.awt.Color(0, 51, 255));
        B_West.setFont(new java.awt.Font("Verdana", 0, 8));
        B_West.setForeground(new java.awt.Color(255, 255, 255));
        B_West.setText("W");
        B_West.setToolTipText("");
        B_West.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_West.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_WestActionPerformed(evt);
            }
        });
        P_NavButtons.add(B_West);
        B_West.setBounds(0, 25, 36, 15);

        B_GO.setBackground(new java.awt.Color(0, 51, 255));
        B_GO.setFont(new java.awt.Font("Verdana", 0, 8));
        B_GO.setForeground(new java.awt.Color(255, 255, 255));
        B_GO.setText("G");
        B_GO.setToolTipText("");
        B_GO.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_GO.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_GOActionPerformed(evt);
            }
        });
        P_NavButtons.add(B_GO);
        B_GO.setBounds(33, 25, 36, 15);

        getContentPane().add(P_NavButtons);
        P_NavButtons.setBounds(194, 208, 102, 70);

        L_Map.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Map.setForeground(new java.awt.Color(255, 51, 51));
        L_Map.setText("MAP");
        L_Map.setToolTipText("");
        getContentPane().add(L_Map);
        L_Map.setBounds(90, 360, 30, 11);

        P_LoadSave.setBackground(new java.awt.Color(0, 0, 0));
        P_LoadSave.setLayout(null);

        B_Pause.setBackground(new java.awt.Color(0, 51, 255));
        B_Pause.setFont(new java.awt.Font("Tahoma", 0, 8));
        B_Pause.setForeground(new java.awt.Color(255, 255, 255));
        B_Pause.setText("PAUSE");
        B_Pause.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Pause.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_PauseActionPerformed(evt);
            }
        });
        P_LoadSave.add(B_Pause);
        B_Pause.setBounds(52, 50, 50, 15);

        B_Start.setBackground(new java.awt.Color(0, 51, 255));
        B_Start.setFont(new java.awt.Font("Tahoma", 0, 8));
        B_Start.setForeground(new java.awt.Color(255, 255, 255));
        B_Start.setText("START");
        B_Start.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_StartActionPerformed(evt);
            }
        });
        P_LoadSave.add(B_Start);
        B_Start.setBounds(1, 10, 52, 15);

        B_Quit.setBackground(new java.awt.Color(0, 51, 255));
        B_Quit.setFont(new java.awt.Font("Tahoma", 0, 8));
        B_Quit.setForeground(new java.awt.Color(255, 255, 255));
        B_Quit.setText("QUIT");
        B_Quit.setToolTipText("");
        B_Quit.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Quit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_QuitActionPerformed(evt);
            }
        });
        P_LoadSave.add(B_Quit);
        B_Quit.setBounds(1, 30, 52, 15);

        B_Help.setBackground(new java.awt.Color(0, 51, 255));
        B_Help.setFont(new java.awt.Font("Tahoma", 0, 8));
        B_Help.setForeground(new java.awt.Color(255, 255, 255));
        B_Help.setText("HELP");
        B_Help.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Help.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_HelpActionPerformed(evt);
            }
        });
        P_LoadSave.add(B_Help);
        B_Help.setBounds(1, 50, 52, 15);

        B_Load.setBackground(new java.awt.Color(0, 51, 255));
        B_Load.setFont(new java.awt.Font("Tahoma", 0, 8));
        B_Load.setForeground(new java.awt.Color(255, 255, 255));
        B_Load.setText("LOAD");
        B_Load.setToolTipText("");
        B_Load.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Load.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_LoadActionPerformed(evt);
            }
        });
        P_LoadSave.add(B_Load);
        B_Load.setBounds(52, 10, 50, 15);

        B_Save.setBackground(new java.awt.Color(0, 51, 255));
        B_Save.setFont(new java.awt.Font("Tahoma", 0, 8));
        B_Save.setForeground(new java.awt.Color(255, 255, 255));
        B_Save.setText("SAVE");
        B_Save.setToolTipText("");
        B_Save.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_SaveActionPerformed(evt);
            }
        });
        P_LoadSave.add(B_Save);
        B_Save.setBounds(52, 30, 50, 15);

        getContentPane().add(P_LoadSave);
        P_LoadSave.setBounds(194, 308, 102, 70);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(null);

        B_Attack.setBackground(new java.awt.Color(255, 0, 0));
        B_Attack.setFont(new java.awt.Font("Verdana", 0, 8));
        B_Attack.setForeground(new java.awt.Color(255, 255, 255));
        B_Attack.setText("ATTACK");
        B_Attack.setToolTipText("");
        B_Attack.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Attack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_AttackActionPerformed(evt);
            }
        });
        jPanel2.add(B_Attack);
        B_Attack.setBounds(151, 2, 60, 15);

        B_Defend.setBackground(new java.awt.Color(255, 0, 0));
        B_Defend.setFont(new java.awt.Font("Verdana", 0, 8));
        B_Defend.setForeground(new java.awt.Color(255, 255, 255));
        B_Defend.setText("DEFEND");
        B_Defend.setToolTipText("");
        B_Defend.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Defend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_DefendActionPerformed(evt);
            }
        });
        jPanel2.add(B_Defend);
        B_Defend.setBounds(210, 2, 62, 15);

        B_Look.setBackground(new java.awt.Color(0, 51, 255));
        B_Look.setFont(new java.awt.Font("Verdana", 0, 8));
        B_Look.setForeground(new java.awt.Color(255, 255, 255));
        B_Look.setText("LOOK");
        B_Look.setToolTipText("");
        B_Look.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Look.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_LookActionPerformed(evt);
            }
        });
        jPanel2.add(B_Look);
        B_Look.setBounds(51, 2, 50, 15);

        B_Use.setBackground(new java.awt.Color(255, 0, 0));
        B_Use.setFont(new java.awt.Font("Verdana", 0, 8));
        B_Use.setForeground(new java.awt.Color(255, 255, 255));
        B_Use.setText("USE");
        B_Use.setToolTipText("");
        B_Use.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Use.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_UseActionPerformed(evt);
            }
        });
        jPanel2.add(B_Use);
        B_Use.setBounds(101, 2, 50, 15);

        B_Alt.setBackground(new java.awt.Color(0, 51, 255));
        B_Alt.setFont(new java.awt.Font("Verdana", 0, 8));
        B_Alt.setForeground(new java.awt.Color(255, 255, 255));
        B_Alt.setText("ALT");
        B_Alt.setToolTipText("");
        B_Alt.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_Alt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_AltActionPerformed(evt);
            }
        });
        jPanel2.add(B_Alt);
        B_Alt.setBounds(1, 2, 50, 15);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(10, 386, 274, 20);

        CB_Abilities.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(CB_Abilities);
        CB_Abilities.setBounds(10, 430, 140, 24);

        L_Inventory.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Inventory.setForeground(new java.awt.Color(255, 0, 0));
        L_Inventory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Inventory.setText("Inventory");
        L_Inventory.setToolTipText("");
        getContentPane().add(L_Inventory);
        L_Inventory.setBounds(186, 410, 70, 11);

        SP_Abilities.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SP_Abilities.setFont(new java.awt.Font("Tahoma", 0, 9));

        LB_Inventory.setBackground(new java.awt.Color(0, 0, 0));
        LB_Inventory.setFont(new java.awt.Font("Tahoma", 0, 9));
        LB_Inventory.setForeground(new java.awt.Color(255, 255, 255));
        LB_Inventory.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        LB_Inventory.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                LB_InventoryValueChanged(evt);
            }
        });
        SP_Abilities.setViewportView(LB_Inventory);

        getContentPane().add(SP_Abilities);
        SP_Abilities.setBounds(160, 422, 120, 90);

        L_Abilities.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Abilities.setForeground(new java.awt.Color(255, 0, 0));
        L_Abilities.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Abilities.setText("Abilities");
        L_Abilities.setToolTipText("");
        getContentPane().add(L_Abilities);
        L_Abilities.setBounds(45, 416, 70, 11);

        P_MonExpLvl.setBackground(new java.awt.Color(0, 0, 0));
        P_MonExpLvl.setLayout(null);

        L_Ammo.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Ammo.setForeground(new java.awt.Color(255, 255, 255));
        L_Ammo.setText("Ammo");
        L_Ammo.setToolTipText("");
        P_MonExpLvl.add(L_Ammo);
        L_Ammo.setBounds(56, 5, 30, 11);

        L_Level.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Level.setForeground(new java.awt.Color(255, 255, 255));
        L_Level.setText("Level");
        L_Level.setToolTipText("");
        P_MonExpLvl.add(L_Level);
        L_Level.setBounds(104, 5, 22, 11);

        L_Money.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Money.setForeground(new java.awt.Color(255, 255, 255));
        L_Money.setText("Money");
        L_Money.setToolTipText("");
        P_MonExpLvl.add(L_Money);
        L_Money.setBounds(12, 5, 29, 11);

        L_AmmoBox.setForeground(new java.awt.Color(51, 255, 0));
        L_AmmoBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_AmmoBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_MonExpLvl.add(L_AmmoBox);
        L_AmmoBox.setBounds(50, 20, 40, 12);

        L_MoneyBox.setForeground(new java.awt.Color(51, 255, 0));
        L_MoneyBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_MoneyBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_MonExpLvl.add(L_MoneyBox);
        L_MoneyBox.setBounds(6, 20, 40, 12);

        L_LevelBox.setForeground(new java.awt.Color(51, 255, 0));
        L_LevelBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_LevelBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        P_MonExpLvl.add(L_LevelBox);
        L_LevelBox.setBounds(95, 20, 40, 12);

        getContentPane().add(P_MonExpLvl);
        P_MonExpLvl.setBounds(10, 460, 140, 50);

        PB_HealthBar.setBackground(new java.awt.Color(255, 0, 51));
        PB_HealthBar.setFont(new java.awt.Font("Tahoma", 0, 9));
        PB_HealthBar.setForeground(new java.awt.Color(255, 0, 51));
        PB_HealthBar.setToolTipText("");
        PB_HealthBar.setValue(100);
        getContentPane().add(PB_HealthBar);
        PB_HealthBar.setBounds(336, 400, 240, 16);

        L_Charge.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Charge.setForeground(new java.awt.Color(255, 0, 0));
        L_Charge.setText("CHARGE");
        L_Charge.setToolTipText("");
        getContentPane().add(L_Charge);
        L_Charge.setBounds(292, 443, 40, 20);

        S_Charge.setBackground(new java.awt.Color(0, 0, 0));
        S_Charge.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(S_Charge);
        S_Charge.setBounds(338, 445, 240, 16);

        L_HealthBar.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_HealthBar.setForeground(new java.awt.Color(255, 0, 0));
        L_HealthBar.setText("HEALTH");
        L_HealthBar.setToolTipText("");
        getContentPane().add(L_HealthBar);
        L_HealthBar.setBounds(292, 398, 40, 20);

        P_Weapons.setBackground(new java.awt.Color(0, 0, 0));
        P_Weapons.setLayout(null);

        RB_Weapon4.setBackground(new java.awt.Color(0, 0, 0));
        BG_Weapons.add(RB_Weapon4);
        RB_Weapon4.setFont(new java.awt.Font("Tahoma", 0, 8));
        RB_Weapon4.setForeground(new java.awt.Color(255, 255, 255));
        RB_Weapon4.setText("Weapon 4");
        P_Weapons.add(RB_Weapon4);
        RB_Weapon4.setBounds(200, 20, 60, 23);

        RB_Weapon1.setBackground(new java.awt.Color(0, 0, 0));
        BG_Weapons.add(RB_Weapon1);
        RB_Weapon1.setFont(new java.awt.Font("Tahoma", 0, 8));
        RB_Weapon1.setForeground(new java.awt.Color(255, 255, 255));
        RB_Weapon1.setText("Weapon 1");
        P_Weapons.add(RB_Weapon1);
        RB_Weapon1.setBounds(2, 20, 60, 23);

        RB_Weapon2.setBackground(new java.awt.Color(0, 0, 0));
        BG_Weapons.add(RB_Weapon2);
        RB_Weapon2.setFont(new java.awt.Font("Tahoma", 0, 8));
        RB_Weapon2.setForeground(new java.awt.Color(255, 255, 255));
        RB_Weapon2.setText("Weapon 2");
        P_Weapons.add(RB_Weapon2);
        RB_Weapon2.setBounds(70, 20, 60, 23);

        RB_Weapon3.setBackground(new java.awt.Color(0, 0, 0));
        BG_Weapons.add(RB_Weapon3);
        RB_Weapon3.setFont(new java.awt.Font("Tahoma", 0, 8));
        RB_Weapon3.setForeground(new java.awt.Color(255, 255, 255));
        RB_Weapon3.setText("Weapon 3");
        P_Weapons.add(RB_Weapon3);
        RB_Weapon3.setBounds(140, 20, 60, 23);

        L_Weapons.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_Weapons.setForeground(new java.awt.Color(255, 255, 255));
        L_Weapons.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Weapons.setText("Weapons");
        L_Weapons.setToolTipText("");
        P_Weapons.add(L_Weapons);
        L_Weapons.setBounds(100, 3, 70, 11);

        getContentPane().add(P_Weapons);
        P_Weapons.setBounds(296, 465, 280, 44);

        L_SpcAtk.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_SpcAtk.setForeground(new java.awt.Color(255, 0, 0));
        L_SpcAtk.setText("Spc Atk:");
        L_SpcAtk.setToolTipText("");
        getContentPane().add(L_SpcAtk);
        L_SpcAtk.setBounds(292, 425, 40, 11);

        L_SpcDef.setFont(new java.awt.Font("Tahoma", 0, 9));
        L_SpcDef.setForeground(new java.awt.Color(255, 0, 0));
        L_SpcDef.setText("Spc Def:");
        L_SpcDef.setToolTipText("");
        getContentPane().add(L_SpcDef);
        L_SpcDef.setBounds(440, 425, 40, 11);

        L_SpcAtkBox.setBackground(new java.awt.Color(0, 0, 0));
        L_SpcAtkBox.setFont(new java.awt.Font("Tahoma", 0, 10));
        L_SpcAtkBox.setForeground(new java.awt.Color(51, 255, 0));
        L_SpcAtkBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_SpcAtkBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        L_SpcAtkBox.setOpaque(true);
        getContentPane().add(L_SpcAtkBox);
        L_SpcAtkBox.setBounds(335, 420, 100, 20);

        L_SpcDefBox.setBackground(new java.awt.Color(0, 0, 0));
        L_SpcDefBox.setFont(new java.awt.Font("Tahoma", 0, 10));
        L_SpcDefBox.setForeground(new java.awt.Color(51, 255, 0));
        L_SpcDefBox.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_SpcDefBox.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        L_SpcDefBox.setOpaque(true);
        getContentPane().add(L_SpcDefBox);
        L_SpcDefBox.setBounds(480, 420, 100, 20);
        getContentPane().add(L_Background);
        L_Background.setBounds(0, 0, 20, 10);

        P_NavView.setBackground(new java.awt.Color(0, 0, 0));
        P_NavView.setAlignmentX(0.0F);
        P_NavView.setAlignmentY(0.0F);
        P_NavView.setFont(new java.awt.Font("Tahoma", 0, 9));
        P_NavView.setLayout(null);

        BG_Navigation_NavView.add(RB_Navigation_View);
        RB_Navigation_View.setFont(new java.awt.Font("Tahoma", 0, 9));
        RB_Navigation_View.setForeground(new java.awt.Color(255, 255, 255));
        RB_Navigation_View.setText("VIEW");
        RB_Navigation_View.setOpaque(false);
        RB_Navigation_View.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_Navigation_ViewActionPerformed(evt);
            }
        });
        P_NavView.add(RB_Navigation_View);
        RB_Navigation_View.setBounds(0, 5, 60, 15);

        BG_Navigation_NavView.add(RB_Navigation_Nav);
        RB_Navigation_Nav.setFont(new java.awt.Font("Tahoma", 0, 9)); // NOI18N
        RB_Navigation_Nav.setForeground(new java.awt.Color(255, 255, 255));
        RB_Navigation_Nav.setSelected(true);
        RB_Navigation_Nav.setText("NAV");
        RB_Navigation_Nav.setOpaque(false);
        RB_Navigation_Nav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RB_Navigation_NavActionPerformed(evt);
            }
        });
        P_NavView.add(RB_Navigation_Nav);
        RB_Navigation_Nav.setBounds(50, 5, 50, 15);

        getContentPane().add(P_NavView);
        P_NavView.setBounds(194, 280, 102, 26);

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void B_EastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_EastActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        
        GF.ORIENTATION = 'e';
        
        if(RB_Navigation_Nav.isSelected())
        {
           GF.CHOICE = "e";
           GF.Sequence(); 
        }

        repaint();
}//GEN-LAST:event_B_EastActionPerformed

private void B_NorthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_NorthActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        
        GF.ORIENTATION = 'n';
        
        if(RB_Navigation_Nav.isSelected())
        {
           GF.CHOICE = "n";
           GF.Sequence(); 
        }

        repaint();
}//GEN-LAST:event_B_NorthActionPerformed

private void B_SouthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_SouthActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        
        GF.ORIENTATION = 's';
        
        if(RB_Navigation_Nav.isSelected())
        {
           GF.CHOICE = "s";
           GF.Sequence(); 
        }

        repaint();
}//GEN-LAST:event_B_SouthActionPerformed

private void B_WestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_WestActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        
        GF.ORIENTATION = 'w';
        
        if(RB_Navigation_Nav.isSelected())
        {
           GF.CHOICE = "w";
           GF.Sequence(); 
        }

        repaint();
}//GEN-LAST:event_B_WestActionPerformed

private void B_GOActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_GOActionPerformed
             if(PlaySoundEffects) { SE_ButtonClick.play(); }
             GF.CHOICE = TF_Input.getText();
             GF.Sequence();
             TF_Input.setText("");
             TF_Input.requestFocus();
             repaint();
}//GEN-LAST:event_B_GOActionPerformed

private void B_PauseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_PauseActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
}//GEN-LAST:event_B_PauseActionPerformed

private void B_StartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_StartActionPerformed
             if(PlaySoundEffects) { SE_ButtonClick.play(); }
             if(PlayMusic) { ThemeMusic.loop(); }
             if(PlayNarration) { CR_2_CreateAFighter.play(); }
             
             TA_Output.setFont(new java.awt.Font("Comic Sans MS", 0, 14));
             TA_Output.setForeground(new java.awt.Color(255, 255, 255));
             TA_Output.setText(" You are a FIGHTER in Arena World!" +
                               "\n Your objective is to defeat all" +
                               "\n of your opponents and earn the" +
                               "\n privelege to participate in the" +
                               "\n ULTIMATE tournament!" +
                               "\n\n Click \"G\" to create a new FIGHTER" +
                               "\n or you may load one you have already" +
                               "\n created by clicking \"LOAD\".");
             
              B_GO.setEnabled(true);
              B_Start.setEnabled(false);
              TF_Input.requestFocus();
              GF = new GameFunctions(this);
             
}//GEN-LAST:event_B_StartActionPerformed

private void B_QuitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_QuitActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        FightSong.stop();
        ThemeMusic.stop();
        this.setVisible(false);
        this.dispose();
}//GEN-LAST:event_B_QuitActionPerformed

private void B_HelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_HelpActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        if(PlayNarration) { CR_0_HELP.play(); }
        String MESSAGE =
        "                    Pirate Arena!            2011 Charles Germany                       HELP\n" +     
        "\nYou are a FIGHTER in the fantastical, pan-dimensional inter-galactic Pirate Arena! Your objective" +
        "\nis to defeat all of your opponents and earn the privelege to participate as a notorious member" +
        "\nof the ill-fated motley crew who will be chosen to raid the imperial flag ship of the Reetah" + 
        "\nArmada. This is a dangerous, nearly suicidal endeavor and as such only those pirates who" +
        "\n\"keep to the code\" and prove themselves as the most worthy of adversaries will be chosen to" +
        "\npartake in the pirate guild's greatest last stand against the oppresion of the Reetah.\n" +
        "\nFame, fortune, glory and unlimited notoriety await you on the most historic and epic raid ever" +
        "\nplanned by the guild against the merciless Reetah empire. IF you proove yourself...\n" +
        "\nTo begin the game click \"START\". At this point you must choose which CLASS of character to" +
        "\nplay as: an AI or a Biologic.\n" +
        "\nAs an AI you can choose: 1.DESTROYER  or  2.SHAPESHIFTER \n" +
        "\nAs a BIOLOGIC you can choose: 1.GENMOD  or  2.PSY \n" +
        "\nNext, choose your GENDER: male or female. Then, name your character. Then, choose how to" +
        "\nallocate SPEED and STRENGTH. You have a total of 10 points. Greater speed allows the possibility" +
        "\nof extra attacks, but comes at the expense of STRENGTH, so there is less damage done per attack." +
        "\nConversely, greater STRENGTH will allow more damage per attack but you will get fewer of them.\n" +
        "\nYou will have to leverage your chosen CLASS's strengths and manage its subsequent weaknesses.\n" +
        "\nAs you travel through each map of each level, navigation options will be displayed in 4 cardinal" +
        "\ndirections - N,S,E,W. Even if you can not move in a particular direction, use the NAV buttons to" +
        "\nexplore all 4 cardinal directions in each sector and room, investigating each wall, nook and" +
        "\ncranny. In doing so you will find clues to help you solve puzzles, powerups, tools, and weapons." +
        "\nAs you interact with the environment you will also gain abilities that correspond to your" +
        "\nCHARACTER class. Aarrrgh!";
        
        JOptionPane.showMessageDialog(
        null,MESSAGE,"Conspiracy!",JOptionPane.INFORMATION_MESSAGE);
        
        TF_Input.requestFocus();

}//GEN-LAST:event_B_HelpActionPerformed

private void B_LoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_LoadActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        TA_Output.setText("\n Loading Game!");
        GameFunctions.LoadGame();       
}//GEN-LAST:event_B_LoadActionPerformed

private void B_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_SaveActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        if(GameFunctions.EnableSave)
        {
            TA_Output.setText("\n Saving Game!");
            GameFunctions.SaveGame();
        }
        else
        {
            TA_Output.setText(" Sorry, you must" +
                              "\n either CREATE a" +
                              "\n character or LOAD" +
                              "\n one before you can" +
                              "\n SAVE anything.");
        }
}//GEN-LAST:event_B_SaveActionPerformed

private void B_AttackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_AttackActionPerformed
 
        if(GameFunctions.PLAYER.AttackWindow)
        {
             if(RB_Weapon1.isSelected())
             { 
                 if(PlaySoundEffects) { SE_JackKnife.play();  } 
                 TA_Output.append("\n Stab!");
                 GameFunctions.PLAYER.Damage += 2;
             }
             else if(RB_Weapon2.isSelected())
             { 
                 if(PlaySoundEffects) { SE_Sword.play(); }
                 TA_Output.append("\n Slash!");
                 GameFunctions.PLAYER.Damage += 4;
             }
             else if(RB_Weapon3.isSelected())
             { 
                  if(GameFunctions.PLAYER.GetAmmo() > 0)
                  { 
                       if(PlaySoundEffects) { SE_Gun.play(); }
                       TA_Output.append("\n Shoot!");
                       GameFunctions.PLAYER.SetAmmo(
                       GameFunctions.PLAYER.GetAmmo()-1);
                       GameFunctions.PLAYER.Damage += 6;
                       GameFunctions.PLAYER.DisplayStats();
                  }
                  else
                  {
                       TA_Output.append("\n No more bullets."); 
                  } 
             }
             else if(RB_Weapon4.isSelected())
             {    
                  if(GameFunctions.PLAYER.GetGrenades() > 0)
                  { 
                       if(PlaySoundEffects) { SE_Grenade.play(); }
                       TA_Output.append("\n Ka Pow!!");
                       GameFunctions.PLAYER.SetGrenades(
                       GameFunctions.PLAYER.GetGrenades()-1);
                       GameFunctions.PLAYER.Damage += 8;
                       GameFunctions.PLAYER.DisplayStats();
                  }
                  else
                  {
                       TA_Output.append("\n No more grenades."); 
                  }                  
             }
             else
             {   
                    if(PlaySoundEffects) { SE_HandToHand.play(); }
                    TA_Output.append("\n Punch!");
                    GameFunctions.PLAYER.Damage++;
             }
         }
         else
         {
             TA_Output.append("\n You Missed!");
             if(PlaySoundEffects) { SE_Whah.play(); }
             
             if(RB_Weapon3.isSelected())
             { 
                  if(GameFunctions.PLAYER.GetAmmo() > 0)
                  { 
                       if(PlaySoundEffects) { SE_Gun.play(); }
                       GameFunctions.PLAYER.SetAmmo(
                       GameFunctions.PLAYER.GetAmmo()-1);
                       GameFunctions.PLAYER.DisplayStats();
                  }
                  else
                  {
                       TA_Output.append(" And you're out of bullets."); 
                  } 
             }
             else if(RB_Weapon4.isSelected())
             { 
                  if(GameFunctions.PLAYER.GetGrenades() > 0)
                  { 
                       if(PlaySoundEffects) { SE_Grenade.play(); }
                       GameFunctions.PLAYER.SetGrenades(
                       GameFunctions.PLAYER.GetGrenades()-1);
                       GameFunctions.PLAYER.DisplayStats();
                  }
                  else
                  {
                       TA_Output.append(" And you're out of grenades."); 
                  } 
             }             
             
         }
        
         TA_Output.setCaretPosition(
         TA_Output.getDocument().getLength());
}//GEN-LAST:event_B_AttackActionPerformed

private void B_DefendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_DefendActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
        TA_Output.append("\n Defend!");
}//GEN-LAST:event_B_DefendActionPerformed

private void B_LookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_LookActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
}//GEN-LAST:event_B_LookActionPerformed

private void B_UseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_UseActionPerformed
        
        String CHOICE = "";
        Object TEMP = LB_Inventory.getSelectedValue();

        //BulletProofing...
        if(TEMP != null) { CHOICE = TEMP.toString(); }
              
          //------------------------------------k-------
              if(CHOICE.contains("Key1"))
              {
                  TA_Output.setText(
                  "\n\n You now hold in your hand" +
                  "\n the KEY1 access key.");
                  if(PlaySoundEffects) { SE_Key.play(); }
              }    
          //-----------------------------------k--------
              if(CHOICE.contains("Key2"))
              {
                  TA_Output.setText(
                  "\n\n You now hold in your hand" +
                  "\n the KEY2 access key.");
                  if(PlaySoundEffects) { SE_Key.play(); }
              } 
          //-----------------------------------k--------
              if(CHOICE.contains("Key3"))
              {
                  TA_Output.setText(
                  "\n\n You now hold in your hand" +
                  "\n the KEY3 access key.");
                  if(PlaySoundEffects) { SE_Key.play(); }
              }
          //-----------------------------------k--------
              if(CHOICE.contains("Key4"))
              {
                  TA_Output.setText(
                  "\n\n You now hold in your hand" +
                  "\n the KEY4 access key.");
                  if(PlaySoundEffects) { SE_Key.play(); }
              }      
          //-----------------------------------k--------
              if(CHOICE.contains("Jack Knife"))
              {
                  TA_Output.setText(
                  "\n\n You equip yourself with the" +
                  "\n incredibly long Jack Knife.");
                  RB_Weapon1.setSelected(true);
                  if(PlaySoundEffects) { SE_JackKnife.play(); }
              }
          //-------------------------------------------
              if(CHOICE.contains("Sword"))
              {
                  TA_Output.setText(
                  "\n\n You equip yourself with the" +
                  "\n Sword of Omens!");
                  RB_Weapon2.setSelected(true);
                  if(PlaySoundEffects) { SE_Sword.play(); }
              }
          //-------------------------------------------
              if(CHOICE.contains("Glock"))
              {
                  TA_Output.setText(
                  "\n\n You equip yourself with the" +
                  "\n stealthy black Glock.");
                  RB_Weapon3.setSelected(true);
                  if(PlaySoundEffects) { SE_Gun.play(); }
              }
          //-------------------------------------------
              if(CHOICE.contains("G Ammo"))
              {
                  TA_Output.setText(
                  "\n\n You hold a clip of" +
                  "\n ammunition in your hand.");
                  if(PlaySoundEffects) { SE_Ammo.play(); }
              }
         //-------------------------------------------
              if(CHOICE.contains("Grenades"))
              {
                 TA_Output.setText(
                 "\n\n You equip yourself with a " +
                 "\n concussion grenade.");
                 RB_Weapon4.setSelected(true);
                 if(PlaySoundEffects) { SE_Grenade.play(); }
              }              
          //-------------------------------------------
              if(CHOICE.contains("Armor"))
              {
                  if(!Wearing)
                  {
                      TA_Output.setText(
                      "\n You put on the body armor.");
                      GameFunctions.PLAYER.SetDefense(
                      GameFunctions.PLAYER.GetDefense() + 5);
                      Wearing = true;
                      GameFunctions.PLAYER.DisplayStats();
                  }
                  else
                  {
                      TA_Output.setText(
                      "\n You take off the body armor.");
                      GameFunctions.PLAYER.SetDefense(
                      GameFunctions.PLAYER.GetDefense() - 5);
                      Wearing = false;
                      GameFunctions.PLAYER.DisplayStats();
                  }
              }
          //-------------------------------------------
              if(CHOICE.contains("MedKits"))
              {
                     TA_Output.setText(
                     "\n\n You stimulate yourself with" +
                     "\n a MedKit adding 25 to health!");
                     GameFunctions.PLAYER.SetMedKits(
                     GameFunctions.PLAYER.GetMedKits() - 1);
                     GameFunctions.PLAYER.SetHealth(
                     GameFunctions.PLAYER.GetHealth() + 25);
                     GameFunctions.PLAYER.DisplayStats();
              }
}//GEN-LAST:event_B_UseActionPerformed

private void B_AltActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_AltActionPerformed
        if(PlaySoundEffects) { SE_ButtonClick.play(); }
}//GEN-LAST:event_B_AltActionPerformed

//-----------------------------------------------------------------------------
public void keyReleased(java.awt.event.KeyEvent X) {   }
public void keyTyped(java.awt.event.KeyEvent X) {   }
public void keyPressed(java.awt.event.KeyEvent X) 
{   
       switch(X.getKeyCode()) 
       {
             case KeyEvent.VK_UP : B_North.doClick(); break;
             case KeyEvent.VK_DOWN : B_South.doClick(); break;
             case KeyEvent.VK_RIGHT : B_East.doClick(); break;
             case KeyEvent.VK_LEFT : B_West.doClick(); break;
             case KeyEvent.VK_ENTER : B_GO.doClick(); break;    
             default : break;
       }
}
//-----------------------------------------------------------------------------

private void formWindowStateChanged(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowStateChanged
 
         if(this.getState()==1)
         {   //Minimized                                         
         }
         else if(this.getState()==0)
         {
            //Maximized
         }
}//GEN-LAST:event_formWindowStateChanged

private void LB_InventoryValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_LB_InventoryValueChanged
        TF_Input.requestFocus();
}//GEN-LAST:event_LB_InventoryValueChanged

private void RB_Navigation_NavActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_Navigation_NavActionPerformed
        TF_Input.requestFocus();
}//GEN-LAST:event_RB_Navigation_NavActionPerformed

private void RB_Navigation_ViewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RB_Navigation_ViewActionPerformed
        TF_Input.requestFocus();
}//GEN-LAST:event_RB_Navigation_ViewActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(INTERFACE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(INTERFACE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(INTERFACE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(INTERFACE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new INTERFACE().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BG_Navigation_NavView;
    private javax.swing.ButtonGroup BG_Weapons;
    public static javax.swing.JButton B_Alt;
    public static javax.swing.JButton B_Attack;
    public static javax.swing.JButton B_Defend;
    public static javax.swing.JButton B_East;
    public static javax.swing.JButton B_GO;
    private javax.swing.JButton B_Help;
    public static javax.swing.JButton B_Load;
    public static javax.swing.JButton B_Look;
    public static javax.swing.JButton B_North;
    private javax.swing.JButton B_Pause;
    private javax.swing.JButton B_Quit;
    public static javax.swing.JButton B_Save;
    public static javax.swing.JButton B_South;
    public static javax.swing.JButton B_Start;
    public static javax.swing.JButton B_Use;
    public static javax.swing.JButton B_West;
    public static javax.swing.JComboBox CB_Abilities;
    public static javax.swing.JList LB_Inventory;
    private javax.swing.JLabel L_Abilities;
    private javax.swing.JLabel L_Ammo;
    public static javax.swing.JLabel L_AmmoBox;
    private javax.swing.JLabel L_Atk;
    public static javax.swing.JLabel L_AtkBox;
    public static javax.swing.JLabel L_Background;
    private javax.swing.JLabel L_Charge;
    private javax.swing.JLabel L_Class;
    public static javax.swing.JLabel L_ClassBox;
    private javax.swing.JLabel L_Def;
    public static javax.swing.JLabel L_DefBox;
    private javax.swing.JLabel L_Energy;
    public static javax.swing.JLabel L_EnergyBox;
    private javax.swing.JLabel L_FrontView;
    private javax.swing.JLabel L_FrontViewLabel;
    private javax.swing.JLabel L_Gender;
    public static javax.swing.JLabel L_GenderBox;
    private javax.swing.JLabel L_Health;
    private javax.swing.JLabel L_HealthBar;
    public static javax.swing.JLabel L_HealthBox;
    private javax.swing.JLabel L_Input;
    private javax.swing.JLabel L_Inventory;
    private javax.swing.JLabel L_Level;
    public static javax.swing.JLabel L_LevelBox;
    private javax.swing.JLabel L_Map;
    private javax.swing.JLabel L_MapBox;
    private javax.swing.JLabel L_MaxDamage;
    public static javax.swing.JLabel L_MaxDamageBox;
    private javax.swing.JLabel L_Money;
    public static javax.swing.JLabel L_MoneyBox;
    private javax.swing.JLabel L_Output;
    private javax.swing.JLabel L_PlayerName;
    public static javax.swing.JLabel L_PlayerNameBox;
    private javax.swing.JLabel L_Size;
    public static javax.swing.JLabel L_SizeBox;
    private javax.swing.JLabel L_SpcAtk;
    public static javax.swing.JLabel L_SpcAtkBox;
    private javax.swing.JLabel L_SpcDef;
    public static javax.swing.JLabel L_SpcDefBox;
    private javax.swing.JLabel L_Speed;
    public static javax.swing.JLabel L_SpeedBox;
    private javax.swing.JLabel L_Strength;
    public static javax.swing.JLabel L_StrengthBox;
    private javax.swing.JLabel L_Title;
    private javax.swing.JLabel L_Weapons;
    private javax.swing.JLabel L_Weight;
    public static javax.swing.JLabel L_WeightBox;
    public static javax.swing.JProgressBar PB_HealthBar;
    private javax.swing.JPanel P_LoadSave;
    private javax.swing.JPanel P_MonExpLvl;
    private javax.swing.JPanel P_NavButtons;
    private javax.swing.JPanel P_NavView;
    private javax.swing.JPanel P_PlayerStats;
    private javax.swing.JPanel P_Weapons;
    public static javax.swing.JRadioButton RB_Navigation_Nav;
    public static javax.swing.JRadioButton RB_Navigation_View;
    public static javax.swing.JRadioButton RB_Weapon1;
    public static javax.swing.JRadioButton RB_Weapon2;
    public static javax.swing.JRadioButton RB_Weapon3;
    public static javax.swing.JRadioButton RB_Weapon4;
    private javax.swing.JScrollPane SP_Abilities;
    private javax.swing.JScrollPane SP_MainOutput;
    public static javax.swing.JSlider S_Charge;
    public static javax.swing.JTextArea TA_Output;
    public static javax.swing.JTextField TF_Input;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
