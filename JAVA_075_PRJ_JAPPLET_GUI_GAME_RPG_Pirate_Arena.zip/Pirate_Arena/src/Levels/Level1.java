package Levels;
import Interface.*;
import GameFunctions.*;
import Characters.*;
import java.awt.Graphics;
import java.net.URL;
import javax.swing.JApplet;
import javax.swing.JFrame;

public class Level1 
{
       //Globals
    
       //Location Constants
       public static final int C1 = 0;
       public static final int N1 = 1;
       public static final int N1HALL = 2;
       public static final int N2 = 3;
       public static final int N2HALL = 4;
       public static final int S1 = 5;
       public static final int S1HALL = 6;
       public static final int S2 = 7;
       public static final int S2HALL = 8;
       public static final int E1 = 9;
       public static final int E1HALL = 10;
       public static final int E2 = 11;
       public static final int E2HALL = 12;
       public static final int W1 = 13;
       public static final int W1HALL = 14;
       public static final int W2 = 15;
       public static final int W2HALL = 16;
       public static final int A1 = 17;
       public static final int A2 = 18;
       public static final int A3 = 19;
       public static final int A4 = 20;
       public static final int A1HALL = 21;
       public static final int A2HALL = 22;
       public static final int A3HALL = 23;
       public static final int A4HALL = 24;
       
       //Level 1 Environment Data
       public static boolean FoundKey1 = false;
       public static boolean FoundKey2 = false;
       public static boolean FoundKey3 = false;
       public static boolean FoundKey4 = false;
       
       public static boolean Arena1_Unlocked = false;
       public static boolean Arena2_Unlocked = false;
       public static boolean Arena3_Unlocked = false;
       public static boolean Arena4_Unlocked = false;       
       
       public static boolean FoundGlock = false;
       public static boolean FoundGlockAmmo1 = false;
       public static boolean FoundSword = false;
       public static boolean FoundJackKnife = false;
       public static boolean FoundArmor = false;
       
       public static boolean FoundMedKit1 = false;
       public static boolean FoundMedKit2 = false;
       public static boolean FoundMedKit3 = false;
       
       public static boolean FoughtENEMY1 = false;
       public static boolean FoughtENEMY2 = false;
       public static boolean FoughtENEMY3 = false;
       public static boolean FoughtENEMY4 = false;
       
       public static boolean FoundMoney1 = false;
       public static boolean FoundMoney2 = false;
       public static boolean FoundMoney3 = false;
       public static boolean FoundMoney4 = false;
    
//-----------------------------------------------------------------
      //Constructor
      public Level1() 
      { 
             INTERFACE.TA_Output.append("\n\n Building a Level1 object!");
             GameFunctions.BuildShopKeeper();
      }
 //-----------------------------------------------------------------
 
    public URL Get_Location(String filename)
    {
           URL url = null;
           try { url = this.getClass().getResource(filename); }
           catch (Exception e) { /*STUFF*/ }
           return url;
    }       
    
 //-----------------------------------------------------------------
      
    public void SwitchBoard()
    {
           switch(GameFunctions.LOCATION)
           {
               case C1 : Center1(); break;
               case N1 : North1(); break;
               case N1HALL : North_1_Hall(); break; 
               case N2 : North2(); break;    
               case N2HALL : North_2_Hall(); break;
               case S1 : South1(); break;
               case S1HALL : South_1_Hall(); break; 
               case S2 : South2(); break;
               case S2HALL : South_2_Hall(); break;    
               case E1 : East1(); break;
               case E1HALL : East_1_Hall(); break;  
               case E2 : East2(); break;
               case E2HALL : East_2_Hall(); break;    
               case W1 : West1(); break;
               case W1HALL : West_1_Hall(); break;
               case W2 : West2(); break;
               case W2HALL : West_2_Hall(); break;    
               case A1 : Arena1(); break;
               case A2 : Arena2(); break;
               case A3 : Arena3(); break;
               case A4 : Arena4(); break;
               case A1HALL : Arena_1_Hall(); break;
               case A2HALL : Arena_2_Hall(); break;
               case A3HALL : Arena_3_Hall(); break;
               case A4HALL : Arena_4_Hall(); break;       
           }
           
           INTERFACE.TF_Input.requestFocus();
    }
    
//-----------------------------------------------------------------

public void Center1()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location CENTER1!\n (PlayerStart)\n" +
          "\n You may go: N, S, E, W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_C1.play(); }
          if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_FootSteps.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = N1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = S1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : GameFunctions.LOCATION = E1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'w' : GameFunctions.LOCATION = W1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------

public void North1()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location NORTH1!" +
          "\n You see a table against the" + 
          "\n NORTH wall." +
          "\n\n You may go: N,S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_N1.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = N2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = N1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }    
}
    
//-----------------------------------------------------------------
    
public void South1()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location SOUTH1!\n" +
          "\n You may go: N,S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_S1.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = S1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = S2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;    
               case '~' : INTERFACE.TA_Output.setText(
                          "\n A fairy appears and gives you" +
                          "\n god-like powers... CHEATER!");
                          GameFunctions.PLAYER.CHEAT();
                          break;   
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }     
}

//----------------------------------------------------------------- 

public void East1()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location EAST1!\n" +
          "\n You may go: E,W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_E1.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 's' : FoundGlock = GameFunctions.FIND(
                          "Glock", "inside a file cabinet", FoundGlock, 0);
                          break;
               case 'e' : GameFunctions.LOCATION = E2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'w' : GameFunctions.LOCATION = E1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       } 
}

//-----------------------------------------------------------------

public void West1()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location WEST1!\n" +
          "\n You may go: E,W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_W1.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : FoundGlockAmmo1 = GameFunctions.FIND(
                          "GlockAmmo", "sitting on a table", FoundGlockAmmo1, 10);
                          break;
               case 's' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 'e' : GameFunctions.LOCATION = W1HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break; 
               case 'w' : GameFunctions.LOCATION = W2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       } 
}

//-----------------------------------------------------------------

public void North2()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location NORTH2!\n" +
          "\n You may go: only South"); 
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_N2.play(); }
          if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Hum.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : FoundJackKnife = GameFunctions.FIND(
                          "JackKnife", "in a silver box", FoundJackKnife, 0);
                          break;
               case 's' : GameFunctions.LOCATION = N2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break; 
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       } 
}

//-----------------------------------------------------------------

public void South2()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location SOUTH2!\n" +
          "\n You may go: only North"); 
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_S2.play(); }
          if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Hum.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = S2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : FoundKey1 = GameFunctions.FIND(
                          "Key1", "sitting on a table", FoundKey1, 0);
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!"); 
                          break; 
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       } 
}

//-----------------------------------------------------------------

public void West2()
{
       String SELECTION = "";
       Object TEMP = null;
    
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location WEST2!" +
          "\n You see pipes feeding into a pool" + 
          "\n and hear the sound of trickling water...\n" +        
          "\n You may go: N,S,E"); 
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_W2.play(); }
          if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Water.play(); } 
       }
       else
       {           
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : SELECTION = "";
                          TEMP = INTERFACE.LB_Inventory.getSelectedValue();
                          //BulletProofing...
                          if(TEMP != null) { SELECTION = TEMP.toString(); }
                          if(SELECTION.length() > 3) { SELECTION = SELECTION.substring(3); }
                          
                          if(Arena1_Unlocked)
                          {
                              GameFunctions.LOCATION = A1HALL;
                              GameFunctions.CHOICE = "";
                              SwitchBoard();
                          }
                          else if(GameFunctions.PLAYER.GetKey1())
                          {
                               if(SELECTION.equals("Key1"))
                               {    
                                    Arena1_Unlocked = true;
                                    GameFunctions.LOCATION = A1HALL;
                                    GameFunctions.CHOICE = "";
                                    SwitchBoard();
                               }
                               else
                               {
                                   INTERFACE.TA_Output.setText(
                                   " Your AI tablet flashes with" +
                                   "\n an urgent message suggestion." +
                                   "\n You look down at its display...\n" +
                                   "\n The door is locked but you HAVE" +
                                   "\n a key! Try selecting \"KEY1\" from" +
                                   "\n inventory. My analysis indicates" + 
                                   "\n that this is the most likely key" + 
                                   "\n to unlock this door. Try again!");
                                   
                                   if(INTERFACE.PlayNarration)
                                   { INTERFACE.N_TryKey.play(); }
                               }
                          }
                          else
                          {
                             INTERFACE.TA_Output.setText(
                             "\n Your AI tablet flashes with" +
                             "\n a blinking message:\n" +        
                             "\n The door is locked!" +
                             "\n You need a KEY...");
                             
                             if(INTERFACE.PlayNarration)
                             { INTERFACE.N_NeedAKey.play(); }
                          }
                          break; 
               case 's' : SELECTION = "";
                          TEMP = INTERFACE.LB_Inventory.getSelectedValue();
                          //BulletProofing...
                          if(TEMP != null) { SELECTION = TEMP.toString(); }
                          if(SELECTION.length() > 3) { SELECTION = SELECTION.substring(3); }
                          
                          if(Arena2_Unlocked)
                          {
                              GameFunctions.LOCATION = A2HALL;
                              GameFunctions.CHOICE = "";
                              SwitchBoard();
                          }
                          else if(GameFunctions.PLAYER.GetKey2())
                          {
                               if(SELECTION.equals("Key2"))
                               {    
                                    Arena2_Unlocked = true;
                                    GameFunctions.LOCATION = A2HALL;
                                    GameFunctions.CHOICE = "";
                                    SwitchBoard();
                               }
                               else
                               {
                                   INTERFACE.TA_Output.setText(
                                   " Your AI tablet flashes with" +
                                   "\n an urgent message suggestion." +
                                   "\n You look down at its display...\n" +
                                   "\n The door is locked but you HAVE" +
                                   "\n a key! Try selecting \"KEY2\" from" +
                                   "\n inventory. My analysis indicates" + 
                                   "\n that this is the most likely key" + 
                                   "\n to unlock this door. Try again!");
                                   
                                   if(INTERFACE.PlayNarration)
                                   { INTERFACE.N_TryKey.play(); }
                               }
                          }
                          else
                          {
                             INTERFACE.TA_Output.setText(
                             "\n Your AI tablet flashes with" +
                             "\n a blinking message:\n" +        
                             "\n The door is locked!" +
                             "\n You need a KEY...");
                             
                             if(INTERFACE.PlayNarration)
                             { INTERFACE.N_NeedAKey.play(); }
                          }
                          break;
               case 'e' : GameFunctions.LOCATION = W2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break; 
               case 'w' : FoundSword = GameFunctions.FIND(
                          "Sword", "next to a suit or armor", FoundSword, 0);
                          break;
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       } 
}

//-----------------------------------------------------------------

public void East2()
{
       String SELECTION = "";
       Object TEMP = null;
    
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location EAST2!" +
          "\n You see pipes feeding into a fountain" + 
          "\n and hear the sound of flowing water...\n" +        
          "\n You may go: N,S,W"); 
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_E2.play(); }
          
          if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Water.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : SELECTION = "";
                          TEMP = INTERFACE.LB_Inventory.getSelectedValue();
                          //BulletProofing...
                          if(TEMP != null) { SELECTION = TEMP.toString(); }
                          if(SELECTION.length() > 3) { SELECTION = SELECTION.substring(3); }
                          
                          if(Arena3_Unlocked)
                          {
                              GameFunctions.LOCATION = A3HALL;
                              GameFunctions.CHOICE = "";
                              SwitchBoard();
                          }
                          else if(GameFunctions.PLAYER.GetKey3())
                          {
                               if(SELECTION.equals("Key3"))
                               {    
                                    Arena3_Unlocked = true;
                                    GameFunctions.LOCATION = A3HALL;
                                    GameFunctions.CHOICE = "";
                                    SwitchBoard();
                               }
                               else
                               {
                                   INTERFACE.TA_Output.setText(
                                   " Your AI tablet flashes with" +
                                   "\n an urgent message suggestion." +
                                   "\n You look down at its display...\n\n" +
                                   "\n The door is locked but you HAVE" +
                                   "\n a key! Try selecting \"KEY3\" from" +
                                   "\n inventory. My analysis indicates" + 
                                   "\n that this is the most likely key" + 
                                   "\n to unlock this door. Try again!");
                                   
                                   if(INTERFACE.PlayNarration)
                                   { INTERFACE.N_TryKey.play(); }
                               }
                          }
                          else
                          {
                             INTERFACE.TA_Output.setText(
                             "\n Your AI tablet flashes with" +
                             "\n a blinking message:\n" +        
                             "\n The door is locked!" +
                             "\n You need a KEY...");
                             
                             if(INTERFACE.PlayNarration)
                             { INTERFACE.N_NeedAKey.play(); }
                          }
                          break; 
               case 's' : SELECTION = "";
                          TEMP = INTERFACE.LB_Inventory.getSelectedValue();
                          //BulletProofing...
                          if(TEMP != null) { SELECTION = TEMP.toString(); }
                          if(SELECTION.length() > 3) { SELECTION = SELECTION.substring(3); }
                          
                          if(Arena4_Unlocked)
                          {
                             GameFunctions.LOCATION = A4HALL;
                             GameFunctions.CHOICE = "";
                             SwitchBoard(); 
                          }
                          else if(GameFunctions.PLAYER.GetKey4())
                          {
                               if(SELECTION.equals("Key4"))
                               {    
                                    Arena4_Unlocked = true;
                                    GameFunctions.LOCATION = A4HALL;
                                    GameFunctions.CHOICE = "";
                                    SwitchBoard();
                               }
                               else
                               {
                                   INTERFACE.TA_Output.setText(
                                   " Your AI tablet beeps and" +
                                   "\n speaks in a synthesized voice:\n" +
                                   "\n The door is locked but you HAVE" +
                                   "\n a key! Try selecting \"KEY4\" from" +
                                   "\n inventory. My analysis indicates" + 
                                   "\n that this is the most likely key" + 
                                   "\n to unlock this door. Try again!");
                                   
                                   if(INTERFACE.PlayNarration)
                                   { INTERFACE.N_TryKey.play(); }
                               }
                          }
                          else
                          {
                             INTERFACE.TA_Output.setText(
                             "\n Your AI tablet flashes with" +
                             "\n a blinking message:\n" +        
                             "\n The door is locked!" +
                             "\n You need a KEY...");
                             
                             if(INTERFACE.PlayNarration)
                             { INTERFACE.N_NeedAKey.play(); }
                          }
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          break;
               case 'w' : GameFunctions.LOCATION = E2HALL;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break; 
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       } 
}

//-----------------------------------------------------------------

public void Arena1()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location ARENA1!" +
          "\n You may go: only South");

          if(INTERFACE.PlayNarration) { INTERFACE.N_Arena.play(); }
          
          if(!FoughtENEMY1)
          {
              GameFunctions.BuildEnemy1();
              GameFunctions.Combat(GameFunctions.PLAYER, GameFunctions.CPU);
              FoughtENEMY1 = true;
          }
          else
          {
              INTERFACE.TA_Output.append(
              "\n\n You see a smoldering pile of" + 
              "\n EMP-fried nanotechnology..." + 
              "\n\n To the WEST a man is standing" +
              "\nbehind a table and waving at you.");
              
              if(!FoundMoney1)
              {
                  if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_ChaChing.play(); }
                  INTERFACE.TA_Output.append("\n\n You find 400 dollars!");
                  GameFunctions.PLAYER.SetMoney(
                  GameFunctions.PLAYER.GetMoney() + 400);
                  GameFunctions.PLAYER.DisplayInventory();
                  FoundMoney1 = true;
              }
              
              if(INTERFACE.PlayNarration) { INTERFACE.N_Arena1Finished.play(); }
          }
          
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : FoundKey2 = GameFunctions.FIND(
                          "Key2", "hanging on the wall", FoundKey2, 0);
                          break;
               case 's' : GameFunctions.LOCATION = W2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : FoundMedKit1 = GameFunctions.FIND(
                          "MedKit", "inside a file cabinet", FoundMedKit1, 2);
                          break;
               case 'w' : FriendFrame  X = new FriendFrame();
                          X.setVisible(true);
                          break;
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }        
}

//-----------------------------------------------------------------

public void Arena2()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location ARENA2!\n" +
          "\n You may go: only North");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_Arena.play(); }
          
          if(!FoughtENEMY2)
          {
              GameFunctions.BuildEnemy2();
              GameFunctions.Combat(GameFunctions.PLAYER, GameFunctions.CPU);
              
              FoughtENEMY2 = true;
          }
          else
          {
              INTERFACE.TA_Output.append(
              "\n\n You see the remains of" + 
              "\n a defeated robo-arachnid...");
              
              if(!FoundMoney2)
              {
                  if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_ChaChing.play(); }
                  INTERFACE.TA_Output.append("\n\n You find 600 dollars!");
                  GameFunctions.PLAYER.SetMoney(
                  GameFunctions.PLAYER.GetMoney() + 600);
                  GameFunctions.PLAYER.DisplayInventory();
                  FoundMoney2 = true;
              }
              
              if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Wind.play(); }
          }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = W2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : FoundMedKit2 = GameFunctions.FIND(
                          "MedKit", "inside a file cabinet", FoundMedKit2, 1);
                          break;
               case 'e' : FoundArmor = GameFunctions.FIND(
                          "Armor", "on the floor", FoundArmor, 0);
                          break;
               case 'w' : FoundKey3 = GameFunctions.FIND(
                          "Key3", "hanging on the wall", FoundKey3, 0);
                          break;
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }        
}

//-----------------------------------------------------------------

public void Arena3()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location ARENA3!\n" +
          "\n You may go: only South");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_Arena.play(); }
          
          if(!FoughtENEMY3)
          {
              GameFunctions.BuildEnemy3();
              GameFunctions.Combat(GameFunctions.PLAYER, GameFunctions.CPU);
              
              FoughtENEMY3 = true;
          }
          else
          {
              INTERFACE.TA_Output.append(
              "\n\n You see the bloody remains" + 
              "\n of a defeated, naughty mutant...");
              
              if(!FoundMoney3)
              {
                  if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_ChaChing.play(); }
                  INTERFACE.TA_Output.append("\n\n You find 2000 dollars!");
                  GameFunctions.PLAYER.SetMoney(
                  GameFunctions.PLAYER.GetMoney() + 2000);
                  GameFunctions.PLAYER.DisplayInventory();
                  FoundMoney3 = true;
              }
              
              if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Wind.play(); }
          }          
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          if(INTERFACE.PlayNarration)
                             { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 's' : GameFunctions.LOCATION = E2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : FoundKey4 = GameFunctions.FIND(
                          "Key4", "hanging on the wall", FoundKey4, 0);
                          break;
               case 'w' : FoundMedKit3 = GameFunctions.FIND(
                          "MedKit", "on an old wooden table", FoundMedKit3, 2);
                          break;
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }        
}

//-----------------------------------------------------------------

public void Arena4()
{
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are standing in location ARENA4!\n" +
          "\n You may go: only South"); 
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_Arena.play(); }
          
          if(!FoughtENEMY4)
          {
              GameFunctions.BuildEnemy4();
              GameFunctions.Combat(GameFunctions.PLAYER, GameFunctions.CPU);
              
              FoughtENEMY4 = true;
          }
          else
          {
              INTERFACE.TA_Output.append(
              "\n\n You see a corpse, all that" + 
              "\n remains after your battle with" + 
              "\n the PSY...");
              
              INTERFACE.TA_Output.append(
              "\n\n If only I had coded a Level 2" + 
              "\n you could go to the next level now...");
              
              if(!FoundMoney4)
              {
                  if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_ChaChing.play(); }
                  INTERFACE.TA_Output.append("\n\n You find 5000 dollars!");
                  GameFunctions.PLAYER.SetMoney(
                  GameFunctions.PLAYER.GetMoney() + 5000);
                  GameFunctions.PLAYER.DisplayInventory();
                  FoundMoney4 = true;
              }
              
              if(INTERFACE.PlaySoundEffects) { INTERFACE.SE_Wind.play(); }
          }          
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = E2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          if(INTERFACE.PlayNarration)
                           { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          if(INTERFACE.PlayNarration)
                          { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see a wall!");
                          if(INTERFACE.PlayNarration)
                          { INTERFACE.N_SeeAWall.play(); }
                          break;
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }        
}

//-----------------------------------------------------------------

public void North_1_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the N1 hallway.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_N1_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = N1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = C1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the N1 hallway east wall." +
                          "\n A statue stands against it.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the N1 hallway west wall." +
                          "\n A statue stands against it.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------
public void North_2_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the N2 hallway.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_N2_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = N2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = N1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the N2 hallway east wall." +
                          "\n A large tapestry hangs on it.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the N2 hallway west wall." +
                          "\n It contains a water fountain.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------

public void South_1_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the S1 hallway.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_S1_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = C1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = S1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the S1 hallway east wall." +
                          "\n A statue stands againt it.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the S1 hallway west wall." +
                          "\n A statue stands against it.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------
public void South_2_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the S2 hallway.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_S2_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = S1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = S2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the S2 hallway east wall." +
                          "\n A large tapestry hangs on it.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the S2 hallway west wall." +
                          "\n It contains a water fountain.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------

public void East_1_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the E1 hallway.\n" +
          "\n You may go: E,W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_E1_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : INTERFACE.TA_Output.setText(
                          "\n You see the E1 hallway north wall." +
                          "\n There are two tables against it.");
                          if(INTERFACE.PlayNarration)
                           { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 's' : INTERFACE.TA_Output.setText(
                          "\n You see the E1 hallway south wall.");
                          if(INTERFACE.PlayNarration)
                          { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 'e' : GameFunctions.LOCATION = E1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'w' : GameFunctions.LOCATION = C1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------
public void East_2_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the E2 hallway.\n" +
          "\n You may go: E,W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_E2_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : INTERFACE.TA_Output.setText(
                          "\n You see the E2 hallway north wall." +
                          "\n A large book shelf lines it.");
                          if(INTERFACE.PlayNarration)
                          { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 's' : INTERFACE.TA_Output.setText(
                          "\n You see the E2 hallway south wall." +
                          "\n Two small end tables sit against it.");
                          if(INTERFACE.PlayNarration)
                          { INTERFACE.N_SeeAWall.play(); }
                          break;
               case 'e' : GameFunctions.LOCATION = E2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'w' : GameFunctions.LOCATION = E1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------


public void West_1_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the W1 hallway.\n" +
          "\n You may go: E,W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_W1_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : INTERFACE.TA_Output.setText(
                          "\n You see the W1 hallway north wall." +
                          "\n Two bright red shields adorn the wall.");
                          break;
               case 's' : INTERFACE.TA_Output.setText(
                          "\n You see the W1 hallway south wall.");
                          break;
               case 'e' : GameFunctions.LOCATION = C1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'w' : GameFunctions.LOCATION = W1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------
public void West_2_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the W2 hallway.\n" +
          "\n You may go: E,W");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_W2_Hall.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : INTERFACE.TA_Output.setText(
                          "\n You see the W2 hallway north wall.");
                          break;
               case 's' : INTERFACE.TA_Output.setText(
                          "\n You see the W2 hallway south wall.");
                          break;
               case 'e' : GameFunctions.LOCATION = W1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'w' : GameFunctions.LOCATION = W2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    
    
//-----------------------------------------------------------------

public void Arena_1_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the Arena1 corridor.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_ArenaCorridor.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = A1;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = W2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena1 corridor east wall." +
                          "\n Ancient weapons and body armor line it.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena1 corridor west wall." +
                          "\n Gilded trophies are set within pillars.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
}    

//-----------------------------------------------------------------

public void Arena_2_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the Arena2 corridor.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_ArenaCorridor.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = W2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = A2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena2 corridor east wall." +
                          "\n Statues of ancient wariors stand here.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena2 corridor west wall." +
                          "\n A large, locked chest insets the middle.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
} 

//-----------------------------------------------------------------

public void Arena_3_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the Arena3 corridor.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_ArenaCorridor.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = A3;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = E2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena3 corridor east wall." +
                          "\n It is lined with titanium plates.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena3 corridor west wall." +
                          "\n It contains a deactivated portal.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
} 

//-----------------------------------------------------------------

public void Arena_4_Hall()
{      
       if(GameFunctions.CHOICE.isEmpty())
       {
          INTERFACE.TA_Output.setText(
          "\n You are now in the Arena4 corridor.\n" +
          "\n You may go: N, S");
          
          if(INTERFACE.PlayNarration) { INTERFACE.N_ArenaCorridor.play(); }
       }
       else
       {
           switch(GameFunctions.CHOICE.charAt(0))
           {
               case 'n' : GameFunctions.LOCATION = E2;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 's' : GameFunctions.LOCATION = A4;
                          GameFunctions.CHOICE = "";
                          SwitchBoard();
                          break;
               case 'e' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena4 corridor east wall." +
                          "\n Rotting corpses are strewn about.");
                          break;
               case 'w' : INTERFACE.TA_Output.setText(
                          "\n You see the Arena4 corridor west wall." +
                          "\n The skeletal remains of a LARGE FIGHTER.");
                          break;    
               default : INTERFACE.TA_Output.setText(
                         "\n Invalid option...");
           }
       }       
} 

//-----------------------------------------------------------------

}
