//PROECTILE Polygon
package BattleField;
import java.awt.*;
import java.awt.Rectangle;

public class PolyPROJECTILE extends PolyENTITY
{
//-----------------------------------------------------------------------------     
       //Constructor  
       public PolyPROJECTILE() 
       {
              Set_Shape(new Rectangle(0, 0, 2, 2));
              Set_Collision_Geometry(4);
              Set_Active(false);
       } 
//-----------------------------------------------------------------------------     
       //Public Accessors
       public boolean GetBounced() { return BOUNCED; }
       public void SetBounced(boolean X) { BOUNCED = X; }
       
       //Private Data
       private boolean BOUNCED = false;
}
