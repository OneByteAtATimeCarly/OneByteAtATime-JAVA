package BattleField;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * PolyMENU.java
 *
 * Created on Nov 19, 2011, 6:08:57 PM
 */
/**
 *
 * @author cgermany
 */
public class PolyMENU extends javax.swing.JFrame {

       //Globals
       public static PolyBATTLEFIELD BFIELD;
    
    /** Creates new form PolyMENU */
    public PolyMENU(PolyBATTLEFIELD X) 
    {
        initComponents();
        this.setTitle("PolyMadness!        Preferences, Options and Settings       2011 Charles Germany");
        BFIELD = X;
        
        this.setSize(new Dimension(537,534));
        this.setLocation(10,10);
        
        //Set the JApplet's Background Color
        Color BG_Color = new Color(50,135,100);
        Container JApplet_BackGround = getContentPane();
        JApplet_BackGround.setBackground(BG_Color); 
        
        this.setDefaultCloseOperation(this.DISPOSE_ON_CLOSE);
        
        FetchGlobals();
    }
//-----------------------------------------------------------------------------
    public void FetchGlobals()
    {
    //---A1. Player Color----------------------------------------------

        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.WHITE))
        { CB_PlayerColor.setSelectedItem("White"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.BLUE))
        { CB_PlayerColor.setSelectedItem("Blue"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.CYAN))
        { CB_PlayerColor.setSelectedItem("Cyan"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.GRAY))
        { CB_PlayerColor.setSelectedItem("Gray"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.LIGHT_GRAY))
        { CB_PlayerColor.setSelectedItem("Gray (light)"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.DARK_GRAY))
        { CB_PlayerColor.setSelectedItem("Gray (dark)"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.GREEN))
        { CB_PlayerColor.setSelectedItem("Green"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.ORANGE))
        { CB_PlayerColor.setSelectedItem("Orange"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.PINK))
        { CB_PlayerColor.setSelectedItem("Pink"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.RED))
        { CB_PlayerColor.setSelectedItem("Red"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.MAGENTA))
        { CB_PlayerColor.setSelectedItem("Magenta"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.BLACK))
        { CB_PlayerColor.setSelectedItem("Black"); }
        if(PolyBATTLEFIELDApplet.Color_Player.equals(Color.YELLOW))
        { CB_PlayerColor.setSelectedItem("Yellow"); }

    //---A2. Enemy Color-----------------------------------------------

        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.WHITE))
        { CB_EnemyColor.setSelectedItem("White"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.BLUE))
        { CB_EnemyColor.setSelectedItem("Blue"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.CYAN))
        { CB_EnemyColor.setSelectedItem("Cyan"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.GRAY))
        { CB_EnemyColor.setSelectedItem("Gray"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.LIGHT_GRAY))
        { CB_EnemyColor.setSelectedItem("Gray (light)"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.DARK_GRAY))
        { CB_EnemyColor.setSelectedItem("Gray (dark)"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.GREEN))
        { CB_EnemyColor.setSelectedItem("Green"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.ORANGE))
        { CB_EnemyColor.setSelectedItem("Orange"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.PINK))
        { CB_EnemyColor.setSelectedItem("Pink"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.RED))
        { CB_EnemyColor.setSelectedItem("Red"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.MAGENTA))
        { CB_EnemyColor.setSelectedItem("Magenta"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.BLACK))
        { CB_EnemyColor.setSelectedItem("Black"); }
        if(PolyBATTLEFIELDApplet.Color_Enemy.equals(Color.YELLOW))
        { CB_EnemyColor.setSelectedItem("Yellow"); }        
        
    //---A3. Enemy Projectile Color-----------------------------------------------
        
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.WHITE))
        { CB_EnemyProjectileColor.setSelectedItem("White"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.BLUE))
        { CB_EnemyProjectileColor.setSelectedItem("Blue"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.CYAN))
        { CB_EnemyProjectileColor.setSelectedItem("Cyan"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.GRAY))
        { CB_EnemyProjectileColor.setSelectedItem("Gray"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.LIGHT_GRAY))
        { CB_EnemyProjectileColor.setSelectedItem("Gray (light)"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.DARK_GRAY))
        { CB_EnemyProjectileColor.setSelectedItem("Gray (dark)"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.GREEN))
        { CB_EnemyProjectileColor.setSelectedItem("Green"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.ORANGE))
        { CB_EnemyProjectileColor.setSelectedItem("Orange"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.PINK))
        { CB_EnemyProjectileColor.setSelectedItem("Pink"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.RED))
        { CB_EnemyProjectileColor.setSelectedItem("Red"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.MAGENTA))
        { CB_EnemyProjectileColor.setSelectedItem("Magenta"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.BLACK))
        { CB_EnemyProjectileColor.setSelectedItem("Black"); }
        if(PolyBATTLEFIELDApplet.Color_EnemyProjectile.equals(Color.YELLOW))
        { CB_EnemyProjectileColor.setSelectedItem("Yellow"); } 
        
    //---A4. Player Projectile Color-----------------------------------------------
        
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.WHITE))
        { CB_PlayerProjectileColor.setSelectedItem("White"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.BLUE))
        { CB_PlayerProjectileColor.setSelectedItem("Blue"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.CYAN))
        { CB_PlayerProjectileColor.setSelectedItem("Cyan"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.GRAY))
        { CB_PlayerProjectileColor.setSelectedItem("Gray"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.LIGHT_GRAY))
        { CB_PlayerProjectileColor.setSelectedItem("Gray (light)"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.DARK_GRAY))
        { CB_PlayerProjectileColor.setSelectedItem("Gray (dark)"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.GREEN))
        { CB_PlayerProjectileColor.setSelectedItem("Green"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.ORANGE))
        { CB_PlayerProjectileColor.setSelectedItem("Orange"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.PINK))
        { CB_PlayerProjectileColor.setSelectedItem("Pink"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.RED))
        { CB_PlayerProjectileColor.setSelectedItem("Red"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.MAGENTA))
        { CB_PlayerProjectileColor.setSelectedItem("Magenta"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.BLACK))
        { CB_PlayerProjectileColor.setSelectedItem("Black"); }
        if(PolyBATTLEFIELDApplet.Color_PlayerProjectile.equals(Color.YELLOW))
        { CB_PlayerProjectileColor.setSelectedItem("Yellow"); }  

    //---B1. Player Shape-----------------------------------------------      

        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.OCTAGON)
        { CB_PlayerShape.setSelectedItem("Octagon"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.RECTANGLETINY)
        { CB_PlayerShape.setSelectedItem("Rectangle (small)"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.RECTANGLE)
        { CB_PlayerShape.setSelectedItem("Rectangle (large)"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.TRIANGLETINY)
        { CB_PlayerShape.setSelectedItem("Triangle (tiny)"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.TRIANGLENARROW)
        { CB_PlayerShape.setSelectedItem("Triangle (narrow)"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.TRIANGLEWIDE)
        { CB_PlayerShape.setSelectedItem("Triangle (wide)"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.SPIRAL)
        { CB_PlayerShape.setSelectedItem("Spiral"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.BOWTIE)
        { CB_PlayerShape.setSelectedItem("BowTie"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.STAR)
        { CB_PlayerShape.setSelectedItem("Star"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.HEXASTAR)
        { CB_PlayerShape.setSelectedItem("HexaStar"); }
        if(PolyBATTLEFIELDApplet.Shape_Player == PolyENTITY.ODDPOLYGON)
        { CB_PlayerShape.setSelectedItem("Odd Polygon"); }
              
    //---B2. Enemy Shape-----------------------------------------------
        
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.OCTAGON)
        { CB_EnemyShape.setSelectedItem("Octagon"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.RECTANGLETINY)
        { CB_EnemyShape.setSelectedItem("Rectangle (small)"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.RECTANGLE)
        { CB_EnemyShape.setSelectedItem("Rectangle (large)"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.TRIANGLETINY)
        { CB_EnemyShape.setSelectedItem("Triangle (tiny)"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.TRIANGLENARROW)
        { CB_EnemyShape.setSelectedItem("Triangle (narrow)"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.TRIANGLEWIDE)
        { CB_EnemyShape.setSelectedItem("Triangle (wide)"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.SPIRAL)
        { CB_EnemyShape.setSelectedItem("Spiral"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.BOWTIE)
        { CB_EnemyShape.setSelectedItem("BowTie"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.STAR)
        { CB_EnemyShape.setSelectedItem("Star"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.HEXASTAR)
        { CB_EnemyShape.setSelectedItem("HexaStar"); }
        if(PolyBATTLEFIELDApplet.Shape_Enemy == PolyENTITY.ODDPOLYGON)
        { CB_EnemyShape.setSelectedItem("Odd Polygon"); }         
        
    //---B3. Enemy Projectile Shape-----------------------------------------------
        
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.OCTAGON)
        { CB_EnemyProjectileShape.setSelectedItem("Octagon"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.RECTANGLETINY)
        { CB_EnemyProjectileShape.setSelectedItem("Rectangle (small)"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.RECTANGLE)
        { CB_EnemyProjectileShape.setSelectedItem("Rectangle (large)"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.TRIANGLETINY)
        { CB_EnemyProjectileShape.setSelectedItem("Triangle (tiny)"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.TRIANGLENARROW)
        { CB_EnemyProjectileShape.setSelectedItem("Triangle (narrow)"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.TRIANGLEWIDE)
        { CB_EnemyProjectileShape.setSelectedItem("Triangle (wide)"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.SPIRAL)
        { CB_EnemyProjectileShape.setSelectedItem("Spiral"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.BOWTIE)
        { CB_EnemyProjectileShape.setSelectedItem("BowTie"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.STAR)
        { CB_EnemyProjectileShape.setSelectedItem("Star"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.HEXASTAR)
        { CB_EnemyProjectileShape.setSelectedItem("HexaStar"); }
        if(PolyBATTLEFIELDApplet.Shape_EnemyProjectile == PolyENTITY.ODDPOLYGON)
        { CB_EnemyProjectileShape.setSelectedItem("Odd Polygon"); }               
                
    //---B4. Player Projectile Shape-----------------------------------------------
        
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.OCTAGON)
        { CB_PlayerProjectileShape.setSelectedItem("Octagon"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.RECTANGLETINY)
        { CB_PlayerProjectileShape.setSelectedItem("Rectangle (small)"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.RECTANGLE)
        { CB_PlayerProjectileShape.setSelectedItem("Rectangle (large)"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.TRIANGLETINY)
        { CB_PlayerProjectileShape.setSelectedItem("Triangle (tiny)"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.TRIANGLENARROW)
        { CB_PlayerProjectileShape.setSelectedItem("Triangle (narrow)"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.TRIANGLEWIDE)
        { CB_PlayerProjectileShape.setSelectedItem("Triangle (wide)"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.SPIRAL)
        { CB_PlayerProjectileShape.setSelectedItem("Spiral"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.BOWTIE)
        { CB_PlayerProjectileShape.setSelectedItem("BowTie"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.STAR)
        { CB_PlayerProjectileShape.setSelectedItem("Star"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.HEXASTAR)
        { CB_PlayerProjectileShape.setSelectedItem("HexaStar"); }
        if(PolyBATTLEFIELDApplet.Shape_PlayerProjectile == PolyENTITY.ODDPOLYGON)
        { CB_PlayerProjectileShape.setSelectedItem("Odd Polygon"); }       

    //---C1. Player Physics-----------------------------------------------
        
         if(PolyBATTLEFIELDApplet.Physics_Player == PolyBATTLEFIELDApplet.BOUNCE)
         { CB_PlayerPhysics.setSelectedItem("BOUNCE"); }
         if(PolyBATTLEFIELDApplet.Physics_Player == PolyBATTLEFIELDApplet.WRAP)
         { CB_PlayerPhysics.setSelectedItem("WRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_Player == PolyBATTLEFIELDApplet.TRAP)
         { CB_PlayerPhysics.setSelectedItem("TRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_Player == PolyBATTLEFIELDApplet.KILL)
         { CB_PlayerPhysics.setSelectedItem("KILL"); }
        
    //---C2. Enemy Physics-----------------------------------------------
        
         if(PolyBATTLEFIELDApplet.Physics_Enemy == PolyBATTLEFIELDApplet.BOUNCE)
         { CB_EnemyPhysics.setSelectedItem("BOUNCE"); }
         if(PolyBATTLEFIELDApplet.Physics_Enemy == PolyBATTLEFIELDApplet.WRAP)
         { CB_EnemyPhysics.setSelectedItem("WRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_Enemy == PolyBATTLEFIELDApplet.TRAP)
         { CB_EnemyPhysics.setSelectedItem("TRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_Enemy == PolyBATTLEFIELDApplet.KILL)
         { CB_EnemyPhysics.setSelectedItem("KILL"); }       
         
    //---C3. Enemy Projectile Physics-----------------------------------------------
        
         if(PolyBATTLEFIELDApplet.Physics_EnemyProjectile == PolyBATTLEFIELDApplet.BOUNCE)
         { CB_EnemyProjectilePhysics.setSelectedItem("BOUNCE"); }
         if(PolyBATTLEFIELDApplet.Physics_EnemyProjectile == PolyBATTLEFIELDApplet.WRAP)
         { CB_EnemyProjectilePhysics.setSelectedItem("WRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_EnemyProjectile == PolyBATTLEFIELDApplet.TRAP)
         { CB_EnemyProjectilePhysics.setSelectedItem("TRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_EnemyProjectile == PolyBATTLEFIELDApplet.KILL)
         { CB_EnemyProjectilePhysics.setSelectedItem("KILL"); }        
        
    //---C4. Player Projectile Physics-----------------------------------------------

         if(PolyBATTLEFIELDApplet.Physics_PlayerProjectile == PolyBATTLEFIELDApplet.BOUNCE)
         { CB_PlayerProjectilePhysics.setSelectedItem("BOUNCE"); }
         if(PolyBATTLEFIELDApplet.Physics_PlayerProjectile == PolyBATTLEFIELDApplet.WRAP)
         { CB_PlayerProjectilePhysics.setSelectedItem("WRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_PlayerProjectile == PolyBATTLEFIELDApplet.TRAP)
         { CB_PlayerProjectilePhysics.setSelectedItem("TRAP"); }
         if(PolyBATTLEFIELDApplet.Physics_PlayerProjectile == PolyBATTLEFIELDApplet.KILL)
         { CB_PlayerProjectilePhysics.setSelectedItem("KILL"); }       
                        
    //---D1. Player Solid or Hollow-----------------------------------------------
        
         if(PolyBATTLEFIELDApplet.HollowPlayer == true)
         { CB_PlayerHollowOrSolid.setSelectedItem("Hollow"); }
         if(PolyBATTLEFIELDApplet.HollowPlayer == false)
         { CB_PlayerHollowOrSolid.setSelectedItem("Solid"); }
        
    //---D2. Enemy Solid or Hollow-----------------------------------------------

         if(PolyBATTLEFIELDApplet.HollowEnemies == true)
         { CB_EnemyHollowOrSolid.setSelectedItem("Hollow"); }
         if(PolyBATTLEFIELDApplet.HollowEnemies == false)
         { CB_EnemyHollowOrSolid.setSelectedItem("Solid"); }    
        
    //---D3. Enemy Projectiles Solid or Hollow-----------------------------------------------

         if(PolyBATTLEFIELDApplet.HollowEnemyProjectiles == true)
         { CB_EnemyProjectileHollowOrSolid.setSelectedItem("Hollow"); }
         if(PolyBATTLEFIELDApplet.HollowEnemyProjectiles == false)
         { CB_EnemyProjectileHollowOrSolid.setSelectedItem("Solid"); }          
        
    //---D4. Player Projectiles Solid or Hollow-----------------------------------------------

         if(PolyBATTLEFIELDApplet.HollowPlayerProjectiles == true)
         { CB_PlayerProjectileHollowOrSolid.setSelectedItem("Hollow"); }
         if(PolyBATTLEFIELDApplet.HollowPlayerProjectiles == false)
         { CB_PlayerProjectileHollowOrSolid.setSelectedItem("Solid"); }        
        
    //---E1. Background Color -------------------------------------------------

        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.WHITE))
        { CB_BackgroundColor.setSelectedItem("White"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.BLUE))
        { CB_BackgroundColor.setSelectedItem("Blue"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.CYAN))
        { CB_BackgroundColor.setSelectedItem("Cyan"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.GRAY))
        { CB_BackgroundColor.setSelectedItem("Gray"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.LIGHT_GRAY))
        { CB_BackgroundColor.setSelectedItem("Gray (light)"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.DARK_GRAY))
        { CB_BackgroundColor.setSelectedItem("Gray (dark)"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.GREEN))
        { CB_BackgroundColor.setSelectedItem("Green"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.ORANGE))
        { CB_BackgroundColor.setSelectedItem("Orange"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.PINK))
        { CB_BackgroundColor.setSelectedItem("Pink"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.RED))
        { CB_BackgroundColor.setSelectedItem("Red"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.MAGENTA))
        { CB_BackgroundColor.setSelectedItem("Magenta"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.BLACK))
        { CB_BackgroundColor.setSelectedItem("Black"); }
        if(PolyBATTLEFIELDApplet.Color_Background.equals(Color.YELLOW))
        { CB_BackgroundColor.setSelectedItem("Yellow"); }

    //---F1. Enemy Attack Style -------------------------------------------------

         if(PolyBATTLEFIELDApplet.EnemyAttackStyle == PolyBATTLEFIELDApplet.MINES)
         { CB_EnemyAttackStyle.setSelectedItem("MINES"); }
         if(PolyBATTLEFIELDApplet.EnemyAttackStyle == PolyBATTLEFIELDApplet.MINES)
         { CB_EnemyAttackStyle.setSelectedItem("MISSLES"); }

    //---G1. Number of Enemies -------------------------------------------------
        
        if(PolyBATTLEFIELDApplet.NumEnemies == 1)
        { CB_NumEnemies.setSelectedItem("1"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 2)
        { CB_NumEnemies.setSelectedItem("2"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 3)
        { CB_NumEnemies.setSelectedItem("3"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 4)
        { CB_NumEnemies.setSelectedItem("4"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 5)
        { CB_NumEnemies.setSelectedItem("5"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 6)
        { CB_NumEnemies.setSelectedItem("6"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 7)
        { CB_NumEnemies.setSelectedItem("7"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 8)
        { CB_NumEnemies.setSelectedItem("8"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 9)
        { CB_NumEnemies.setSelectedItem("9"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 10)
        { CB_NumEnemies.setSelectedItem("10"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 11)
        { CB_NumEnemies.setSelectedItem("11"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 12)
        { CB_NumEnemies.setSelectedItem("12"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 13)
        { CB_NumEnemies.setSelectedItem("13"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 14)
        { CB_NumEnemies.setSelectedItem("14"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 15)
        { CB_NumEnemies.setSelectedItem("15"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 16)
        { CB_NumEnemies.setSelectedItem("16"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 17)
        { CB_NumEnemies.setSelectedItem("17"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 18)
        { CB_NumEnemies.setSelectedItem("18"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 19)
        { CB_NumEnemies.setSelectedItem("19"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 20)
        { CB_NumEnemies.setSelectedItem("20"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 21)
        { CB_NumEnemies.setSelectedItem("21"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 22)
        { CB_NumEnemies.setSelectedItem("22"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 23)
        { CB_NumEnemies.setSelectedItem("23"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 24)
        { CB_NumEnemies.setSelectedItem("24"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 25)
        { CB_NumEnemies.setSelectedItem("25"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 26)
        { CB_NumEnemies.setSelectedItem("26"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 27)
        { CB_NumEnemies.setSelectedItem("27"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 28)
        { CB_NumEnemies.setSelectedItem("28"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 29)
        { CB_NumEnemies.setSelectedItem("29"); }
        if(PolyBATTLEFIELDApplet.NumEnemies == 30)
        { CB_NumEnemies.setSelectedItem("30"); }        
    
    //---H1. Enemy Fire -------------------------------------------------
         
         if(PolyBATTLEFIELDApplet.EnemyFire == true) 
         { RB_EnemyFire_On.setSelected(true); }
         if(PolyBATTLEFIELDApplet.EnemyFire == false) 
         { RB_EnemyFire_Off.setSelected(true); }
         
    //---I1. Friendly Fire -------------------------------------------------
         
         if(PolyBATTLEFIELDApplet.FriendlyFire == true) 
         { RB_FriendlyFire_On.setSelected(true); }
         if(PolyBATTLEFIELDApplet.FriendlyFire == false) 
         { RB_FriendlyFire_Off.setSelected(true); }
         
    //---J1. Movement -------------------------------------------------
         
         if(PolyBATTLEFIELDApplet.MicroGravity == true) 
         { RB_MicroGravity.setSelected(true); }
         if(PolyBATTLEFIELDApplet.MicroGravity == false) 
         { RB_AntiInertia.setSelected(true); }   
               
    //---K1. Special -------------------------------------------------
         
         if(PolyBATTLEFIELDApplet.RainbowColors == true)
         { CHECK_RainbowColors.setSelected(true); }
         else if(PolyBATTLEFIELDApplet.RainbowColors == false)
         { CHECK_RainbowColors.setSelected(false); }
         
         if(PolyBATTLEFIELDApplet.MixedShapes == true)
         { CHECK_MixedShapes.setSelected(true); }
         else if(PolyBATTLEFIELDApplet.MixedShapes == false)
         { CHECK_MixedShapes.setSelected(false); }
         
    //---L1. Number of Player Projectiles -------------------------------------
        
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 1)
        { CB_NumPlayerProjectiles.setSelectedItem("1"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 2)
        { CB_NumPlayerProjectiles.setSelectedItem("2"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 3)
        { CB_NumPlayerProjectiles.setSelectedItem("3"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 4)
        { CB_NumPlayerProjectiles.setSelectedItem("4"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 5)
        { CB_NumPlayerProjectiles.setSelectedItem("5"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 6)
        { CB_NumPlayerProjectiles.setSelectedItem("6"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 7)
        { CB_NumPlayerProjectiles.setSelectedItem("7"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 8)
        { CB_NumPlayerProjectiles.setSelectedItem("8"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 9)
        { CB_NumPlayerProjectiles.setSelectedItem("9"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 10)
        { CB_NumPlayerProjectiles.setSelectedItem("10"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 11)
        { CB_NumPlayerProjectiles.setSelectedItem("11"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 12)
        { CB_NumPlayerProjectiles.setSelectedItem("12"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 13)
        { CB_NumPlayerProjectiles.setSelectedItem("13"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 14)
        { CB_NumPlayerProjectiles.setSelectedItem("14"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 15)
        { CB_NumPlayerProjectiles.setSelectedItem("15"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 16)
        { CB_NumPlayerProjectiles.setSelectedItem("16"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 17)
        { CB_NumPlayerProjectiles.setSelectedItem("17"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 18)
        { CB_NumPlayerProjectiles.setSelectedItem("18"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 19)
        { CB_NumPlayerProjectiles.setSelectedItem("19"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 20)
        { CB_NumPlayerProjectiles.setSelectedItem("20"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 21)
        { CB_NumPlayerProjectiles.setSelectedItem("21"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 22)
        { CB_NumPlayerProjectiles.setSelectedItem("22"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 23)
        { CB_NumPlayerProjectiles.setSelectedItem("23"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 24)
        { CB_NumPlayerProjectiles.setSelectedItem("24"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 25)
        { CB_NumPlayerProjectiles.setSelectedItem("25"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 26)
        { CB_NumPlayerProjectiles.setSelectedItem("26"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 27)
        { CB_NumPlayerProjectiles.setSelectedItem("27"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 28)
        { CB_NumPlayerProjectiles.setSelectedItem("28"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 29)
        { CB_NumPlayerProjectiles.setSelectedItem("29"); }
        if(PolyBATTLEFIELDApplet.NumPlayerProjectiles == 30)
        { CB_NumPlayerProjectiles.setSelectedItem("30"); }
        
    //---L2. Number of Enemy Projectiles --------------------------------------

        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 1)
        { CB_NumEnemyProjectiles.setSelectedItem("1"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 2)
        { CB_NumEnemyProjectiles.setSelectedItem("2"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 3)
        { CB_NumEnemyProjectiles.setSelectedItem("3"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 4)
        { CB_NumEnemyProjectiles.setSelectedItem("4"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 5)
        { CB_NumEnemyProjectiles.setSelectedItem("5"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 6)
        { CB_NumEnemyProjectiles.setSelectedItem("6"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 7)
        { CB_NumEnemyProjectiles.setSelectedItem("7"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 8)
        { CB_NumEnemyProjectiles.setSelectedItem("8"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 9)
        { CB_NumEnemyProjectiles.setSelectedItem("9"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 10)
        { CB_NumEnemyProjectiles.setSelectedItem("10"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 11)
        { CB_NumEnemyProjectiles.setSelectedItem("11"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 12)
        { CB_NumEnemyProjectiles.setSelectedItem("12"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 13)
        { CB_NumEnemyProjectiles.setSelectedItem("13"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 14)
        { CB_NumEnemyProjectiles.setSelectedItem("14"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 15)
        { CB_NumEnemyProjectiles.setSelectedItem("15"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 16)
        { CB_NumEnemyProjectiles.setSelectedItem("16"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 17)
        { CB_NumEnemyProjectiles.setSelectedItem("17"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 18)
        { CB_NumEnemyProjectiles.setSelectedItem("18"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 19)
        { CB_NumEnemyProjectiles.setSelectedItem("19"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 20)
        { CB_NumEnemyProjectiles.setSelectedItem("20"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 21)
        { CB_NumEnemyProjectiles.setSelectedItem("21"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 22)
        { CB_NumEnemyProjectiles.setSelectedItem("22"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 23)
        { CB_NumEnemyProjectiles.setSelectedItem("23"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 24)
        { CB_NumEnemyProjectiles.setSelectedItem("24"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 25)
        { CB_NumEnemyProjectiles.setSelectedItem("25"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 26)
        { CB_NumEnemyProjectiles.setSelectedItem("26"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 27)
        { CB_NumEnemyProjectiles.setSelectedItem("27"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 28)
        { CB_NumEnemyProjectiles.setSelectedItem("28"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 29)
        { CB_NumEnemyProjectiles.setSelectedItem("29"); }
        if(PolyBATTLEFIELDApplet.NumEnemyProjectiles == 30)
        { CB_NumEnemyProjectiles.setSelectedItem("30"); }
        
                
    //---M1. Number of Collisions Allowed Per Game ----------------------------

        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 1)
        { CB_NumCollisions.setSelectedItem("1"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 2)
        { CB_NumCollisions.setSelectedItem("2"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 3)
        { CB_NumCollisions.setSelectedItem("3"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 4)
        { CB_NumCollisions.setSelectedItem("4"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 5)
        { CB_NumCollisions.setSelectedItem("5"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 6)
        { CB_NumCollisions.setSelectedItem("6"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 7)
        { CB_NumCollisions.setSelectedItem("7"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 8)
        { CB_NumCollisions.setSelectedItem("8"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 9)
        { CB_NumCollisions.setSelectedItem("9"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 10)
        { CB_NumCollisions.setSelectedItem("10"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 11)
        { CB_NumCollisions.setSelectedItem("11"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 12)
        { CB_NumCollisions.setSelectedItem("12"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 13)
        { CB_NumCollisions.setSelectedItem("13"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 14)
        { CB_NumCollisions.setSelectedItem("14"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 15)
        { CB_NumCollisions.setSelectedItem("15"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 16)
        { CB_NumCollisions.setSelectedItem("16"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 17)
        { CB_NumCollisions.setSelectedItem("17"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 18)
        { CB_NumCollisions.setSelectedItem("18"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 19)
        { CB_NumCollisions.setSelectedItem("19"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 20)
        { CB_NumCollisions.setSelectedItem("20"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 21)
        { CB_NumCollisions.setSelectedItem("21"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 22)
        { CB_NumCollisions.setSelectedItem("22"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 23)
        { CB_NumCollisions.setSelectedItem("23"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 24)
        { CB_NumCollisions.setSelectedItem("24"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 25)
        { CB_NumCollisions.setSelectedItem("25"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 26)
        { CB_NumCollisions.setSelectedItem("26"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 27)
        { CB_NumCollisions.setSelectedItem("27"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 28)
        { CB_NumCollisions.setSelectedItem("28"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 29)
        { CB_NumCollisions.setSelectedItem("29"); }
        if(PolyBATTLEFIELDApplet.CollisionsAllowed == 30)
        { CB_NumCollisions.setSelectedItem("30"); }       
        
    //---N1. Show Collision Geometry ------------------------------------------
       
         if(PolyBATTLEFIELDApplet.ShowCollisionGeometry == true)
         { RB_ShowCollisionGeometry_On.setSelected(true); }
         if(PolyBATTLEFIELDApplet.ShowCollisionGeometry == false)
         { RB_ShowCollisionGeometry_Off.setSelected(true); }

    //---O1. Show Player Info -------------------------------------------------
         
         if(PolyBATTLEFIELDApplet.ShowPlayerInfo == true)
         { RB_ShowPlayerInfo_On.setSelected(true); }
         if(PolyBATTLEFIELDApplet.ShowPlayerInfo == false)
         { RB_ShowPlayerInfo_Off.setSelected(true); }
         
    //---P1. Sound Effects ----------------------------------------------------
         
         if(PolyBATTLEFIELDApplet.SOUNDEFFECTS == true)
         { RB_SoundEffects_On.setSelected(true); }
         if(PolyBATTLEFIELDApplet.SOUNDEFFECTS == false)
         { RB_SoundEffects_Off.setSelected(true); }  

    //---Q1. Music ----------------------------------------------------
         if(PolyBATTLEFIELDApplet.BACKGROUNDMUSIC == true)
         { RB_Music_On.setSelected(true); }
         if(PolyBATTLEFIELDApplet.BACKGROUNDMUSIC == false)
         { RB_Music_Off.setSelected(true); }
         
    //---R1. NumEnemiesFiring -------------------------------------------------        
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 1)
        { CB_NumEnemiesFiring.setSelectedItem("2"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 3)
        { CB_NumEnemiesFiring.setSelectedItem("3"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 4)
        { CB_NumEnemiesFiring.setSelectedItem("4"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 5)
        { CB_NumEnemiesFiring.setSelectedItem("5"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 6)
        { CB_NumEnemiesFiring.setSelectedItem("6"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 7)
        { CB_NumEnemiesFiring.setSelectedItem("7"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 8)
        { CB_NumEnemiesFiring.setSelectedItem("8"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 9)
        { CB_NumEnemiesFiring.setSelectedItem("9"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 10)
        { CB_NumEnemiesFiring.setSelectedItem("10"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 11)
        { CB_NumEnemiesFiring.setSelectedItem("11"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 12)
        { CB_NumEnemiesFiring.setSelectedItem("12"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 13)
        { CB_NumEnemiesFiring.setSelectedItem("13"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 14)
        { CB_NumEnemiesFiring.setSelectedItem("14"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 15)
        { CB_NumEnemiesFiring.setSelectedItem("15"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 16)
        { CB_NumEnemiesFiring.setSelectedItem("16"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 17)
        { CB_NumEnemiesFiring.setSelectedItem("17"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 18)
        { CB_NumEnemiesFiring.setSelectedItem("18"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 19)
        { CB_NumEnemiesFiring.setSelectedItem("19"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 20)
        { CB_NumEnemiesFiring.setSelectedItem("20"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 21)
        { CB_NumEnemiesFiring.setSelectedItem("21"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 22)
        { CB_NumEnemiesFiring.setSelectedItem("22"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 23)
        { CB_NumEnemiesFiring.setSelectedItem("23"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 24)
        { CB_NumEnemiesFiring.setSelectedItem("24"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 25)
        { CB_NumEnemiesFiring.setSelectedItem("25"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 26)
        { CB_NumEnemiesFiring.setSelectedItem("26"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 27)
        { CB_NumEnemiesFiring.setSelectedItem("27"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 28)
        { CB_NumEnemiesFiring.setSelectedItem("28"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 29)
        { CB_NumEnemiesFiring.setSelectedItem("29"); }
        if(PolyBATTLEFIELDApplet.NumEnemiesFiring == 30)
        { CB_NumEnemiesFiring.setSelectedItem("30"); }                
    }
//-----------------------------------------------------------------------------    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BG_EnemyFire = new javax.swing.ButtonGroup();
        BG_FriendlyFire = new javax.swing.ButtonGroup();
        BG_Movement = new javax.swing.ButtonGroup();
        BG_ShowCollisionGeometry = new javax.swing.ButtonGroup();
        BG_ShowPlayerInfo = new javax.swing.ButtonGroup();
        BG_SoundEffects = new javax.swing.ButtonGroup();
        BG_Music = new javax.swing.ButtonGroup();
        L_TItle = new javax.swing.JLabel();
        PAN_ShowCollisionGeometry = new javax.swing.JPanel();
        RB_ShowCollisionGeometry_Off = new javax.swing.JRadioButton();
        RB_ShowCollisionGeometry_On = new javax.swing.JRadioButton();
        L_ShowCollisionGeometry = new javax.swing.JLabel();
        PAN_FriendlyFire = new javax.swing.JPanel();
        RB_FriendlyFire_Off = new javax.swing.JRadioButton();
        RB_FriendlyFire_On = new javax.swing.JRadioButton();
        L_FriendlyFire = new javax.swing.JLabel();
        PAN_Physics = new javax.swing.JPanel();
        CB_PlayerPhysics = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerPhysics = new javax.swing.JLabel();
        CB_EnemyPhysics = new javax.swing.JComboBox();
        javax.swing.JLabel L_EnemyPhysics = new javax.swing.JLabel();
        CB_EnemyProjectilePhysics = new javax.swing.JComboBox();
        CB_PlayerProjectilePhysics = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerProjectilePhysics = new javax.swing.JLabel();
        javax.swing.JLabel L_EnemyProjectilePhysics = new javax.swing.JLabel();
        L_Physics = new javax.swing.JLabel();
        PAN_EnemyAttackStyle = new javax.swing.JPanel();
        javax.swing.JLabel L_EnemyAttackStyle = new javax.swing.JLabel();
        CB_EnemyAttackStyle = new javax.swing.JComboBox();
        PAN_Shapes = new javax.swing.JPanel();
        CB_PlayerShape = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerShape = new javax.swing.JLabel();
        CB_EnemyShape = new javax.swing.JComboBox();
        javax.swing.JLabel L_EnemyShape = new javax.swing.JLabel();
        CB_EnemyProjectileShape = new javax.swing.JComboBox();
        CB_PlayerProjectileShape = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerProjectileShape = new javax.swing.JLabel();
        javax.swing.JLabel L_EnemyProjectileShape = new javax.swing.JLabel();
        L_ShapeTitle = new javax.swing.JLabel();
        PAN_Colors = new javax.swing.JPanel();
        CB_PlayerColor = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerColor = new javax.swing.JLabel();
        CB_EnemyColor = new javax.swing.JComboBox();
        javax.swing.JLabel L_EnemyColor = new javax.swing.JLabel();
        CB_EnemyProjectileColor = new javax.swing.JComboBox();
        CB_PlayerProjectileColor = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerProjectileColor = new javax.swing.JLabel();
        javax.swing.JLabel L_EnemyProjectileColor = new javax.swing.JLabel();
        L_Colors = new javax.swing.JLabel();
        PAN_BackgroundColor = new javax.swing.JPanel();
        javax.swing.JLabel L_BackgroundColor = new javax.swing.JLabel();
        CB_BackgroundColor = new javax.swing.JComboBox();
        PAN_SolidOrHollow = new javax.swing.JPanel();
        CB_PlayerHollowOrSolid = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerHollowOrSolid = new javax.swing.JLabel();
        CB_EnemyHollowOrSolid = new javax.swing.JComboBox();
        javax.swing.JLabel L_EnemyHollowOrSolid = new javax.swing.JLabel();
        CB_EnemyProjectileHollowOrSolid = new javax.swing.JComboBox();
        CB_PlayerProjectileHollowOrSolid = new javax.swing.JComboBox();
        javax.swing.JLabel L_PlayerProjectileHollowOrSolid = new javax.swing.JLabel();
        javax.swing.JLabel L_EnemyProjectileHollowOrSolid = new javax.swing.JLabel();
        L_SolidOrHollow = new javax.swing.JLabel();
        PAN_Special = new javax.swing.JPanel();
        L_EnemyFire1 = new javax.swing.JLabel();
        CHECK_RainbowColors = new javax.swing.JCheckBox();
        CHECK_MixedShapes = new javax.swing.JCheckBox();
        B_CommitChanges = new javax.swing.JButton();
        PAN_Movement = new javax.swing.JPanel();
        L_Movement = new javax.swing.JLabel();
        RB_AntiInertia = new javax.swing.JRadioButton();
        RB_MicroGravity = new javax.swing.JRadioButton();
        PAN_NumEnemies = new javax.swing.JPanel();
        javax.swing.JLabel L_NumEnemies = new javax.swing.JLabel();
        CB_NumEnemies = new javax.swing.JComboBox();
        PAN_NumEnemyProjectiles = new javax.swing.JPanel();
        javax.swing.JLabel L_NumEnemyProjectiles = new javax.swing.JLabel();
        CB_NumEnemyProjectiles = new javax.swing.JComboBox();
        PAN_NumPlayerProjectiles = new javax.swing.JPanel();
        javax.swing.JLabel L_NumPlayerProjectiles = new javax.swing.JLabel();
        CB_NumPlayerProjectiles = new javax.swing.JComboBox();
        PAN_NumCollisions = new javax.swing.JPanel();
        javax.swing.JLabel L_NumCollisions = new javax.swing.JLabel();
        CB_NumCollisions = new javax.swing.JComboBox();
        PAN_EnemyFire = new javax.swing.JPanel();
        RB_EnemyFire_Off = new javax.swing.JRadioButton();
        RB_EnemyFire_On = new javax.swing.JRadioButton();
        L_EnemyFire = new javax.swing.JLabel();
        PAN_ShowPlayerInfo = new javax.swing.JPanel();
        RB_ShowPlayerInfo_Off = new javax.swing.JRadioButton();
        RB_ShowPlayerInfo_On = new javax.swing.JRadioButton();
        L_ShowPlayerInfo = new javax.swing.JLabel();
        PAN_SoundEffects = new javax.swing.JPanel();
        RB_SoundEffects_Off = new javax.swing.JRadioButton();
        RB_SoundEffects_On = new javax.swing.JRadioButton();
        L_SoundEffects = new javax.swing.JLabel();
        PAN_Music = new javax.swing.JPanel();
        RB_Music_Off = new javax.swing.JRadioButton();
        RB_Music_On = new javax.swing.JRadioButton();
        L_Music = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        PAN_NumEnemiesFiring = new javax.swing.JPanel();
        javax.swing.JLabel L_NumEnemiesFiring = new javax.swing.JLabel();
        CB_NumEnemiesFiring = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().setLayout(null);

        L_TItle.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        L_TItle.setForeground(new java.awt.Color(255, 255, 255));
        L_TItle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_TItle.setText("PolyMadness! Preferences and Settings");
        getContentPane().add(L_TItle);
        L_TItle.setBounds(120, 0, 290, 20);

        PAN_ShowCollisionGeometry.setBackground(new java.awt.Color(0, 0, 0));
        PAN_ShowCollisionGeometry.setForeground(new java.awt.Color(255, 255, 255));
        PAN_ShowCollisionGeometry.setLayout(null);

        BG_ShowCollisionGeometry.add(RB_ShowCollisionGeometry_Off);
        RB_ShowCollisionGeometry_Off.setForeground(new java.awt.Color(255, 255, 255));
        RB_ShowCollisionGeometry_Off.setSelected(true);
        RB_ShowCollisionGeometry_Off.setText("Off");
        RB_ShowCollisionGeometry_Off.setOpaque(false);
        PAN_ShowCollisionGeometry.add(RB_ShowCollisionGeometry_Off);
        RB_ShowCollisionGeometry_Off.setBounds(60, 17, 50, 23);

        BG_ShowCollisionGeometry.add(RB_ShowCollisionGeometry_On);
        RB_ShowCollisionGeometry_On.setForeground(new java.awt.Color(255, 255, 255));
        RB_ShowCollisionGeometry_On.setText("On");
        RB_ShowCollisionGeometry_On.setOpaque(false);
        PAN_ShowCollisionGeometry.add(RB_ShowCollisionGeometry_On);
        RB_ShowCollisionGeometry_On.setBounds(10, 17, 50, 23);

        L_ShowCollisionGeometry.setForeground(new java.awt.Color(255, 255, 255));
        L_ShowCollisionGeometry.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_ShowCollisionGeometry.setText("Show Collision Geo");
        PAN_ShowCollisionGeometry.add(L_ShowCollisionGeometry);
        L_ShowCollisionGeometry.setBounds(5, 2, 110, 14);

        getContentPane().add(PAN_ShowCollisionGeometry);
        PAN_ShowCollisionGeometry.setBounds(398, 198, 120, 40);

        PAN_FriendlyFire.setBackground(new java.awt.Color(0, 0, 0));
        PAN_FriendlyFire.setForeground(new java.awt.Color(255, 255, 255));
        PAN_FriendlyFire.setLayout(null);

        BG_FriendlyFire.add(RB_FriendlyFire_Off);
        RB_FriendlyFire_Off.setForeground(new java.awt.Color(255, 255, 255));
        RB_FriendlyFire_Off.setSelected(true);
        RB_FriendlyFire_Off.setText("Off");
        RB_FriendlyFire_Off.setOpaque(false);
        PAN_FriendlyFire.add(RB_FriendlyFire_Off);
        RB_FriendlyFire_Off.setBounds(60, 17, 50, 23);

        BG_FriendlyFire.add(RB_FriendlyFire_On);
        RB_FriendlyFire_On.setForeground(new java.awt.Color(255, 255, 255));
        RB_FriendlyFire_On.setText("On");
        RB_FriendlyFire_On.setOpaque(false);
        PAN_FriendlyFire.add(RB_FriendlyFire_On);
        RB_FriendlyFire_On.setBounds(10, 17, 50, 23);

        L_FriendlyFire.setForeground(new java.awt.Color(255, 255, 255));
        L_FriendlyFire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_FriendlyFire.setText("Friendly Fire");
        PAN_FriendlyFire.add(L_FriendlyFire);
        L_FriendlyFire.setBounds(15, 2, 70, 14);

        getContentPane().add(PAN_FriendlyFire);
        PAN_FriendlyFire.setBounds(10, 308, 120, 40);

        PAN_Physics.setBackground(new java.awt.Color(0, 0, 0));
        PAN_Physics.setForeground(new java.awt.Color(255, 255, 255));
        PAN_Physics.setLayout(null);

        CB_PlayerPhysics.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "BOUNCE", "WRAP", "TRAP", "KILL" }));
        PAN_Physics.add(CB_PlayerPhysics);
        CB_PlayerPhysics.setBounds(10, 40, 100, 22);

        L_PlayerPhysics.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerPhysics.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerPhysics.setText("Player Physics");
        PAN_Physics.add(L_PlayerPhysics);
        L_PlayerPhysics.setBounds(14, 25, 90, 14);

        CB_EnemyPhysics.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "BOUNCE", "WRAP", "TRAP", "KILL" }));
        PAN_Physics.add(CB_EnemyPhysics);
        CB_EnemyPhysics.setBounds(10, 86, 100, 22);

        L_EnemyPhysics.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyPhysics.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyPhysics.setText("Enemy Physics");
        L_EnemyPhysics.setToolTipText("");
        PAN_Physics.add(L_EnemyPhysics);
        L_EnemyPhysics.setBounds(14, 70, 90, 14);

        CB_EnemyProjectilePhysics.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "TRAP", "BOUNCE", "WRAP", "KILL" }));
        CB_EnemyProjectilePhysics.setSelectedIndex(3);
        PAN_Physics.add(CB_EnemyProjectilePhysics);
        CB_EnemyProjectilePhysics.setBounds(10, 138, 100, 22);

        CB_PlayerProjectilePhysics.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "TRAP", "BOUNCE", "WRAP", "KILL" }));
        CB_PlayerProjectilePhysics.setSelectedIndex(3);
        PAN_Physics.add(CB_PlayerProjectilePhysics);
        CB_PlayerProjectilePhysics.setBounds(10, 186, 100, 22);

        L_PlayerProjectilePhysics.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerProjectilePhysics.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerProjectilePhysics.setText("Player Proj. Physics");
        L_PlayerProjectilePhysics.setToolTipText("");
        PAN_Physics.add(L_PlayerProjectilePhysics);
        L_PlayerProjectilePhysics.setBounds(0, 170, 120, 14);

        L_EnemyProjectilePhysics.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyProjectilePhysics.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyProjectilePhysics.setText("Enemy Proj. Physics");
        L_EnemyProjectilePhysics.setToolTipText("");
        PAN_Physics.add(L_EnemyProjectilePhysics);
        L_EnemyProjectilePhysics.setBounds(0, 120, 120, 14);

        L_Physics.setForeground(new java.awt.Color(255, 255, 255));
        L_Physics.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Physics.setText("Polygon Physics");
        L_Physics.setToolTipText("");
        PAN_Physics.add(L_Physics);
        L_Physics.setBounds(0, 4, 120, 14);

        getContentPane().add(PAN_Physics);
        PAN_Physics.setBounds(270, 30, 120, 230);

        PAN_EnemyAttackStyle.setBackground(new java.awt.Color(0, 0, 0));
        PAN_EnemyAttackStyle.setLayout(null);

        L_EnemyAttackStyle.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyAttackStyle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyAttackStyle.setText("Enemy Attack Style");
        L_EnemyAttackStyle.setToolTipText("");
        PAN_EnemyAttackStyle.add(L_EnemyAttackStyle);
        L_EnemyAttackStyle.setBounds(13, 12, 93, 14);

        CB_EnemyAttackStyle.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MISSLES", "MINES" }));
        PAN_EnemyAttackStyle.add(CB_EnemyAttackStyle);
        CB_EnemyAttackStyle.setBounds(13, 34, 90, 22);

        getContentPane().add(PAN_EnemyAttackStyle);
        PAN_EnemyAttackStyle.setBounds(10, 416, 120, 82);

        PAN_Shapes.setBackground(new java.awt.Color(0, 0, 0));
        PAN_Shapes.setForeground(new java.awt.Color(255, 255, 255));
        PAN_Shapes.setLayout(null);

        CB_PlayerShape.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Octagon", "Rectangle (small)", "Rectangle (large)", "Triangle (tiny)", "Triangle (narrow)", "Triangle (wide)", "Spiral", "BowTie", "Star", "HexaStar", "Odd Polygon" }));
        PAN_Shapes.add(CB_PlayerShape);
        CB_PlayerShape.setBounds(10, 40, 100, 22);

        L_PlayerShape.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerShape.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerShape.setText("Player Shape");
        PAN_Shapes.add(L_PlayerShape);
        L_PlayerShape.setBounds(14, 25, 90, 14);

        CB_EnemyShape.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Octagon", "Rectangle (small)", "Rectangle (large)", "Triangle (tiny)", "Triangle (narrow)", "Triangle (wide)", "Spiral", "BowTie", "Star", "HexaStar", "Odd Polygon" }));
        PAN_Shapes.add(CB_EnemyShape);
        CB_EnemyShape.setBounds(10, 86, 100, 22);

        L_EnemyShape.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyShape.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyShape.setText("Enemy Shape");
        L_EnemyShape.setToolTipText("");
        PAN_Shapes.add(L_EnemyShape);
        L_EnemyShape.setBounds(14, 70, 90, 14);

        CB_EnemyProjectileShape.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Octagon", "Rectangle (small)", "Rectangle (large)", "Triangle (tiny)", "Triangle (narrow)", "Triangle (wide)", "Spiral", "BowTie", "Star", "HexaStar", "Odd Polygon" }));
        PAN_Shapes.add(CB_EnemyProjectileShape);
        CB_EnemyProjectileShape.setBounds(10, 138, 100, 22);

        CB_PlayerProjectileShape.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Octagon", "Rectangle (small)", "Rectangle (large)", "Triangle (tiny)", "Triangle (narrow)", "Triangle (wide)", "Spiral", "BowTie", "Star", "HexaStar", "Odd Polygon" }));
        PAN_Shapes.add(CB_PlayerProjectileShape);
        CB_PlayerProjectileShape.setBounds(10, 186, 100, 22);

        L_PlayerProjectileShape.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerProjectileShape.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerProjectileShape.setText("Player Proj. Shape");
        L_PlayerProjectileShape.setToolTipText("");
        PAN_Shapes.add(L_PlayerProjectileShape);
        L_PlayerProjectileShape.setBounds(0, 170, 120, 14);

        L_EnemyProjectileShape.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyProjectileShape.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyProjectileShape.setText("Enemy Proj. Shape");
        L_EnemyProjectileShape.setToolTipText("");
        PAN_Shapes.add(L_EnemyProjectileShape);
        L_EnemyProjectileShape.setBounds(0, 120, 120, 14);

        L_ShapeTitle.setForeground(new java.awt.Color(255, 255, 255));
        L_ShapeTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_ShapeTitle.setText("Polygon Shapes");
        L_ShapeTitle.setToolTipText("");
        PAN_Shapes.add(L_ShapeTitle);
        L_ShapeTitle.setBounds(0, 4, 120, 14);

        getContentPane().add(PAN_Shapes);
        PAN_Shapes.setBounds(140, 30, 120, 230);

        PAN_Colors.setBackground(new java.awt.Color(0, 0, 0));
        PAN_Colors.setForeground(new java.awt.Color(255, 255, 255));
        PAN_Colors.setLayout(null);

        CB_PlayerColor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "White", "Blue", "Cyan", "Gray", "Gray (light)", "Gray (dark)", "Green", "Orange", "Pink", "Red", "Magenta", "Black", "Yellow" }));
        PAN_Colors.add(CB_PlayerColor);
        CB_PlayerColor.setBounds(10, 40, 100, 22);

        L_PlayerColor.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerColor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerColor.setText("Player Color");
        L_PlayerColor.setToolTipText("");
        PAN_Colors.add(L_PlayerColor);
        L_PlayerColor.setBounds(14, 25, 90, 14);

        CB_EnemyColor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "White", "Blue", "Cyan", "Gray", "Gray (light)", "Gray (dark)", "Green", "Orange", "Pink", "Red", "Magenta", "Black", "Yellow" }));
        CB_EnemyColor.setSelectedIndex(9);
        PAN_Colors.add(CB_EnemyColor);
        CB_EnemyColor.setBounds(10, 86, 100, 22);

        L_EnemyColor.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyColor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyColor.setText("Enemy Color");
        L_EnemyColor.setToolTipText("");
        PAN_Colors.add(L_EnemyColor);
        L_EnemyColor.setBounds(14, 70, 90, 14);

        CB_EnemyProjectileColor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "White", "Blue", "Cyan", "Gray", "Gray (light)", "Gray (dark)", "Green", "Orange", "Pink", "Red", "Magenta", "Black", "Yellow" }));
        CB_EnemyProjectileColor.setSelectedIndex(9);
        PAN_Colors.add(CB_EnemyProjectileColor);
        CB_EnemyProjectileColor.setBounds(10, 138, 100, 22);

        CB_PlayerProjectileColor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "White", "Blue", "Cyan", "Gray", "Gray (light)", "Gray (dark)", "Green", "Orange", "Pink", "Red", "Magenta", "Black", "Yellow" }));
        CB_PlayerProjectileColor.setSelectedIndex(10);
        PAN_Colors.add(CB_PlayerProjectileColor);
        CB_PlayerProjectileColor.setBounds(10, 186, 100, 22);

        L_PlayerProjectileColor.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerProjectileColor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerProjectileColor.setText("Player Proj. Color");
        L_PlayerProjectileColor.setToolTipText("");
        PAN_Colors.add(L_PlayerProjectileColor);
        L_PlayerProjectileColor.setBounds(0, 170, 120, 14);

        L_EnemyProjectileColor.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyProjectileColor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyProjectileColor.setText("Enemy Proj. Color");
        L_EnemyProjectileColor.setToolTipText("");
        PAN_Colors.add(L_EnemyProjectileColor);
        L_EnemyProjectileColor.setBounds(0, 120, 120, 14);

        L_Colors.setForeground(new java.awt.Color(255, 255, 255));
        L_Colors.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Colors.setText("Polygon Colors");
        L_Colors.setToolTipText("");
        PAN_Colors.add(L_Colors);
        L_Colors.setBounds(0, 4, 120, 14);

        getContentPane().add(PAN_Colors);
        PAN_Colors.setBounds(10, 30, 120, 230);

        PAN_BackgroundColor.setBackground(new java.awt.Color(0, 0, 0));

        L_BackgroundColor.setForeground(new java.awt.Color(255, 255, 255));
        L_BackgroundColor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_BackgroundColor.setText("Background Color");
        L_BackgroundColor.setToolTipText("");
        PAN_BackgroundColor.add(L_BackgroundColor);

        CB_BackgroundColor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Black", "Blue", "Cyan", "Gray", "Gray (light)", "Gray (dark)", "Green", "Orange", "Pink", "Red", "Magenta", "White", "Yellow" }));
        PAN_BackgroundColor.add(CB_BackgroundColor);

        getContentPane().add(PAN_BackgroundColor);
        PAN_BackgroundColor.setBounds(10, 352, 120, 60);

        PAN_SolidOrHollow.setBackground(new java.awt.Color(0, 0, 0));
        PAN_SolidOrHollow.setForeground(new java.awt.Color(255, 255, 255));
        PAN_SolidOrHollow.setLayout(null);

        CB_PlayerHollowOrSolid.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Hollow", "Solid" }));
        PAN_SolidOrHollow.add(CB_PlayerHollowOrSolid);
        CB_PlayerHollowOrSolid.setBounds(10, 40, 100, 22);

        L_PlayerHollowOrSolid.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerHollowOrSolid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerHollowOrSolid.setText("Player");
        L_PlayerHollowOrSolid.setToolTipText("");
        PAN_SolidOrHollow.add(L_PlayerHollowOrSolid);
        L_PlayerHollowOrSolid.setBounds(14, 25, 90, 14);

        CB_EnemyHollowOrSolid.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Hollow", "Solid" }));
        PAN_SolidOrHollow.add(CB_EnemyHollowOrSolid);
        CB_EnemyHollowOrSolid.setBounds(10, 86, 100, 22);

        L_EnemyHollowOrSolid.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyHollowOrSolid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyHollowOrSolid.setText("Enemy");
        L_EnemyHollowOrSolid.setToolTipText("");
        PAN_SolidOrHollow.add(L_EnemyHollowOrSolid);
        L_EnemyHollowOrSolid.setBounds(14, 70, 90, 14);

        CB_EnemyProjectileHollowOrSolid.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Hollow", "Solid" }));
        PAN_SolidOrHollow.add(CB_EnemyProjectileHollowOrSolid);
        CB_EnemyProjectileHollowOrSolid.setBounds(10, 138, 100, 22);

        CB_PlayerProjectileHollowOrSolid.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Hollow", "Solid" }));
        PAN_SolidOrHollow.add(CB_PlayerProjectileHollowOrSolid);
        CB_PlayerProjectileHollowOrSolid.setBounds(10, 186, 100, 22);

        L_PlayerProjectileHollowOrSolid.setForeground(new java.awt.Color(255, 255, 255));
        L_PlayerProjectileHollowOrSolid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_PlayerProjectileHollowOrSolid.setText("Player Projectiles");
        L_PlayerProjectileHollowOrSolid.setToolTipText("");
        PAN_SolidOrHollow.add(L_PlayerProjectileHollowOrSolid);
        L_PlayerProjectileHollowOrSolid.setBounds(0, 170, 120, 14);

        L_EnemyProjectileHollowOrSolid.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyProjectileHollowOrSolid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyProjectileHollowOrSolid.setText("Enemy Projectiles");
        L_EnemyProjectileHollowOrSolid.setToolTipText("");
        PAN_SolidOrHollow.add(L_EnemyProjectileHollowOrSolid);
        L_EnemyProjectileHollowOrSolid.setBounds(0, 120, 120, 14);

        L_SolidOrHollow.setForeground(new java.awt.Color(255, 255, 255));
        L_SolidOrHollow.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_SolidOrHollow.setText("Solid or Hollow");
        L_SolidOrHollow.setToolTipText("");
        PAN_SolidOrHollow.add(L_SolidOrHollow);
        L_SolidOrHollow.setBounds(10, 4, 100, 14);

        getContentPane().add(PAN_SolidOrHollow);
        PAN_SolidOrHollow.setBounds(140, 264, 120, 234);

        PAN_Special.setBackground(new java.awt.Color(0, 0, 0));
        PAN_Special.setForeground(new java.awt.Color(255, 255, 255));
        PAN_Special.setLayout(null);

        L_EnemyFire1.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyFire1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyFire1.setText("Special");
        L_EnemyFire1.setToolTipText("");
        PAN_Special.add(L_EnemyFire1);
        L_EnemyFire1.setBounds(25, 0, 70, 14);

        CHECK_RainbowColors.setForeground(new java.awt.Color(255, 255, 255));
        CHECK_RainbowColors.setSelected(true);
        CHECK_RainbowColors.setText("Rainbow Colors");
        CHECK_RainbowColors.setToolTipText("");
        CHECK_RainbowColors.setOpaque(false);
        PAN_Special.add(CHECK_RainbowColors);
        CHECK_RainbowColors.setBounds(2, 20, 120, 23);

        CHECK_MixedShapes.setForeground(new java.awt.Color(255, 255, 255));
        CHECK_MixedShapes.setSelected(true);
        CHECK_MixedShapes.setText("Mixed Shapes");
        CHECK_MixedShapes.setToolTipText("");
        CHECK_MixedShapes.setOpaque(false);
        PAN_Special.add(CHECK_MixedShapes);
        CHECK_MixedShapes.setBounds(2, 40, 120, 23);

        getContentPane().add(PAN_Special);
        PAN_Special.setBounds(270, 264, 120, 66);

        B_CommitChanges.setBackground(new java.awt.Color(255, 0, 51));
        B_CommitChanges.setFont(new java.awt.Font("Tahoma", 0, 24));
        B_CommitChanges.setText("COMMIT");
        B_CommitChanges.setToolTipText("");
        B_CommitChanges.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        B_CommitChanges.setMargin(new java.awt.Insets(0, 0, 0, 0));
        B_CommitChanges.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                B_CommitChangesActionPerformed(evt);
            }
        });
        getContentPane().add(B_CommitChanges);
        B_CommitChanges.setBounds(398, 414, 120, 84);

        PAN_Movement.setBackground(new java.awt.Color(0, 0, 0));
        PAN_Movement.setForeground(new java.awt.Color(255, 255, 255));
        PAN_Movement.setLayout(null);

        L_Movement.setForeground(new java.awt.Color(255, 255, 255));
        L_Movement.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Movement.setText("Movement");
        L_Movement.setToolTipText("");
        PAN_Movement.add(L_Movement);
        L_Movement.setBounds(24, 2, 70, 14);

        RB_AntiInertia.setBackground(new java.awt.Color(0, 0, 0));
        BG_Movement.add(RB_AntiInertia);
        RB_AntiInertia.setForeground(new java.awt.Color(255, 255, 255));
        RB_AntiInertia.setText("Anti-Inertia");
        RB_AntiInertia.setToolTipText("");
        RB_AntiInertia.setOpaque(false);
        PAN_Movement.add(RB_AntiInertia);
        RB_AntiInertia.setBounds(3, 35, 120, 23);

        RB_MicroGravity.setBackground(new java.awt.Color(0, 0, 0));
        BG_Movement.add(RB_MicroGravity);
        RB_MicroGravity.setForeground(new java.awt.Color(255, 255, 255));
        RB_MicroGravity.setSelected(true);
        RB_MicroGravity.setText("Micro-Gravity");
        RB_MicroGravity.setToolTipText("");
        RB_MicroGravity.setOpaque(false);
        PAN_Movement.add(RB_MicroGravity);
        RB_MicroGravity.setBounds(3, 18, 120, 23);

        getContentPane().add(PAN_Movement);
        PAN_Movement.setBounds(270, 333, 120, 60);

        PAN_NumEnemies.setBackground(new java.awt.Color(0, 0, 0));
        PAN_NumEnemies.setLayout(null);

        L_NumEnemies.setForeground(new java.awt.Color(255, 255, 255));
        L_NumEnemies.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_NumEnemies.setText("Num of Enemies");
        L_NumEnemies.setToolTipText("");
        PAN_NumEnemies.add(L_NumEnemies);
        L_NumEnemies.setBounds(0, 2, 120, 14);

        CB_NumEnemies.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" }));
        CB_NumEnemies.setSelectedIndex(10);
        PAN_NumEnemies.add(CB_NumEnemies);
        CB_NumEnemies.setBounds(36, 20, 48, 22);

        getContentPane().add(PAN_NumEnemies);
        PAN_NumEnemies.setBounds(270, 396, 120, 50);

        PAN_NumEnemyProjectiles.setBackground(new java.awt.Color(0, 0, 0));
        PAN_NumEnemyProjectiles.setLayout(null);

        L_NumEnemyProjectiles.setForeground(new java.awt.Color(255, 255, 255));
        L_NumEnemyProjectiles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_NumEnemyProjectiles.setText("Num of Enemy Proj.");
        L_NumEnemyProjectiles.setToolTipText("");
        PAN_NumEnemyProjectiles.add(L_NumEnemyProjectiles);
        L_NumEnemyProjectiles.setBounds(2, 5, 120, 14);

        CB_NumEnemyProjectiles.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" }));
        CB_NumEnemyProjectiles.setSelectedIndex(19);
        PAN_NumEnemyProjectiles.add(CB_NumEnemyProjectiles);
        CB_NumEnemyProjectiles.setBounds(36, 24, 48, 22);

        getContentPane().add(PAN_NumEnemyProjectiles);
        PAN_NumEnemyProjectiles.setBounds(398, 86, 120, 50);

        PAN_NumPlayerProjectiles.setBackground(new java.awt.Color(0, 0, 0));
        PAN_NumPlayerProjectiles.setLayout(null);

        L_NumPlayerProjectiles.setForeground(new java.awt.Color(255, 255, 255));
        L_NumPlayerProjectiles.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_NumPlayerProjectiles.setText("Num of Player Proj.");
        L_NumPlayerProjectiles.setToolTipText("");
        PAN_NumPlayerProjectiles.add(L_NumPlayerProjectiles);
        L_NumPlayerProjectiles.setBounds(3, 5, 120, 14);

        CB_NumPlayerProjectiles.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" }));
        CB_NumPlayerProjectiles.setSelectedIndex(9);
        PAN_NumPlayerProjectiles.add(CB_NumPlayerProjectiles);
        CB_NumPlayerProjectiles.setBounds(36, 24, 48, 22);

        getContentPane().add(PAN_NumPlayerProjectiles);
        PAN_NumPlayerProjectiles.setBounds(398, 30, 120, 50);

        PAN_NumCollisions.setBackground(new java.awt.Color(0, 0, 0));
        PAN_NumCollisions.setLayout(null);

        L_NumCollisions.setForeground(new java.awt.Color(255, 255, 255));
        L_NumCollisions.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_NumCollisions.setText("Collisions Allowed");
        L_NumCollisions.setToolTipText("");
        PAN_NumCollisions.add(L_NumCollisions);
        L_NumCollisions.setBounds(-2, 5, 120, 14);

        CB_NumCollisions.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" }));
        CB_NumCollisions.setSelectedIndex(3);
        PAN_NumCollisions.add(CB_NumCollisions);
        CB_NumCollisions.setBounds(36, 24, 48, 22);

        getContentPane().add(PAN_NumCollisions);
        PAN_NumCollisions.setBounds(398, 142, 120, 50);

        PAN_EnemyFire.setBackground(new java.awt.Color(0, 0, 0));
        PAN_EnemyFire.setForeground(new java.awt.Color(255, 255, 255));
        PAN_EnemyFire.setLayout(null);

        BG_EnemyFire.add(RB_EnemyFire_Off);
        RB_EnemyFire_Off.setForeground(new java.awt.Color(255, 255, 255));
        RB_EnemyFire_Off.setSelected(true);
        RB_EnemyFire_Off.setText("Off");
        RB_EnemyFire_Off.setOpaque(false);
        PAN_EnemyFire.add(RB_EnemyFire_Off);
        RB_EnemyFire_Off.setBounds(60, 17, 50, 23);

        BG_EnemyFire.add(RB_EnemyFire_On);
        RB_EnemyFire_On.setForeground(new java.awt.Color(255, 255, 255));
        RB_EnemyFire_On.setText("On");
        RB_EnemyFire_On.setOpaque(false);
        PAN_EnemyFire.add(RB_EnemyFire_On);
        RB_EnemyFire_On.setBounds(10, 17, 50, 23);

        L_EnemyFire.setForeground(new java.awt.Color(255, 255, 255));
        L_EnemyFire.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_EnemyFire.setText("Enemy Fire");
        PAN_EnemyFire.add(L_EnemyFire);
        L_EnemyFire.setBounds(15, 2, 70, 14);

        getContentPane().add(PAN_EnemyFire);
        PAN_EnemyFire.setBounds(10, 264, 120, 40);

        PAN_ShowPlayerInfo.setBackground(new java.awt.Color(0, 0, 0));
        PAN_ShowPlayerInfo.setForeground(new java.awt.Color(255, 255, 255));
        PAN_ShowPlayerInfo.setLayout(null);

        BG_ShowPlayerInfo.add(RB_ShowPlayerInfo_Off);
        RB_ShowPlayerInfo_Off.setForeground(new java.awt.Color(255, 255, 255));
        RB_ShowPlayerInfo_Off.setSelected(true);
        RB_ShowPlayerInfo_Off.setText("Off");
        RB_ShowPlayerInfo_Off.setOpaque(false);
        PAN_ShowPlayerInfo.add(RB_ShowPlayerInfo_Off);
        RB_ShowPlayerInfo_Off.setBounds(60, 17, 50, 23);

        BG_ShowPlayerInfo.add(RB_ShowPlayerInfo_On);
        RB_ShowPlayerInfo_On.setForeground(new java.awt.Color(255, 255, 255));
        RB_ShowPlayerInfo_On.setText("On");
        RB_ShowPlayerInfo_On.setOpaque(false);
        PAN_ShowPlayerInfo.add(RB_ShowPlayerInfo_On);
        RB_ShowPlayerInfo_On.setBounds(10, 17, 50, 23);

        L_ShowPlayerInfo.setForeground(new java.awt.Color(255, 255, 255));
        L_ShowPlayerInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_ShowPlayerInfo.setText("Show Player Info");
        PAN_ShowPlayerInfo.add(L_ShowPlayerInfo);
        L_ShowPlayerInfo.setBounds(5, 2, 110, 14);

        getContentPane().add(PAN_ShowPlayerInfo);
        PAN_ShowPlayerInfo.setBounds(398, 244, 120, 40);

        PAN_SoundEffects.setBackground(new java.awt.Color(0, 0, 0));
        PAN_SoundEffects.setForeground(new java.awt.Color(255, 255, 255));
        PAN_SoundEffects.setLayout(null);

        BG_SoundEffects.add(RB_SoundEffects_Off);
        RB_SoundEffects_Off.setForeground(new java.awt.Color(255, 255, 255));
        RB_SoundEffects_Off.setText("Off");
        RB_SoundEffects_Off.setOpaque(false);
        PAN_SoundEffects.add(RB_SoundEffects_Off);
        RB_SoundEffects_Off.setBounds(60, 17, 50, 23);

        BG_SoundEffects.add(RB_SoundEffects_On);
        RB_SoundEffects_On.setForeground(new java.awt.Color(255, 255, 255));
        RB_SoundEffects_On.setSelected(true);
        RB_SoundEffects_On.setText("On");
        RB_SoundEffects_On.setOpaque(false);
        PAN_SoundEffects.add(RB_SoundEffects_On);
        RB_SoundEffects_On.setBounds(10, 17, 50, 23);

        L_SoundEffects.setForeground(new java.awt.Color(255, 255, 255));
        L_SoundEffects.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_SoundEffects.setText("Sound Effects");
        PAN_SoundEffects.add(L_SoundEffects);
        L_SoundEffects.setBounds(5, 2, 110, 14);

        getContentPane().add(PAN_SoundEffects);
        PAN_SoundEffects.setBounds(398, 290, 120, 40);

        PAN_Music.setBackground(new java.awt.Color(0, 0, 0));
        PAN_Music.setForeground(new java.awt.Color(255, 255, 255));
        PAN_Music.setLayout(null);

        BG_Music.add(RB_Music_Off);
        RB_Music_Off.setForeground(new java.awt.Color(255, 255, 255));
        RB_Music_Off.setText("Off");
        RB_Music_Off.setOpaque(false);
        PAN_Music.add(RB_Music_Off);
        RB_Music_Off.setBounds(60, 17, 50, 23);

        BG_Music.add(RB_Music_On);
        RB_Music_On.setForeground(new java.awt.Color(255, 255, 255));
        RB_Music_On.setSelected(true);
        RB_Music_On.setText("On");
        RB_Music_On.setOpaque(false);
        PAN_Music.add(RB_Music_On);
        RB_Music_On.setBounds(10, 17, 50, 23);

        L_Music.setForeground(new java.awt.Color(255, 255, 255));
        L_Music.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_Music.setText("Music");
        PAN_Music.add(L_Music);
        L_Music.setBounds(5, 2, 110, 14);

        getContentPane().add(PAN_Music);
        PAN_Music.setBounds(398, 336, 120, 40);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14));
        jButton1.setText("CANCEL");
        jButton1.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(398, 384, 120, 23);

        PAN_NumEnemiesFiring.setBackground(new java.awt.Color(0, 0, 0));
        PAN_NumEnemiesFiring.setLayout(null);

        L_NumEnemiesFiring.setForeground(new java.awt.Color(255, 255, 255));
        L_NumEnemiesFiring.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        L_NumEnemiesFiring.setText("Num Enemies Firing");
        L_NumEnemiesFiring.setToolTipText("");
        PAN_NumEnemiesFiring.add(L_NumEnemiesFiring);
        L_NumEnemiesFiring.setBounds(0, 2, 120, 14);

        CB_NumEnemiesFiring.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" }));
        CB_NumEnemiesFiring.setSelectedIndex(5);
        PAN_NumEnemiesFiring.add(CB_NumEnemiesFiring);
        CB_NumEnemiesFiring.setBounds(36, 20, 48, 22);

        getContentPane().add(PAN_NumEnemiesFiring);
        PAN_NumEnemiesFiring.setBounds(270, 448, 120, 50);

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void B_CommitChangesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_B_CommitChangesActionPerformed

        String CHOICE = " ";
        Object TEMP;

    //---A1. Player Color----------------------------------------------
        TEMP = CB_PlayerColor.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }
    
        if(CHOICE.equals("White"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.WHITE; } 
        if(CHOICE.equals("Blue"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.BLUE; }
        if(CHOICE.equals("Cyan"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.CYAN; }
        if(CHOICE.equals("Gray"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.GRAY; }
        if(CHOICE.equals("Gray (light)"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.LIGHT_GRAY; }
        if(CHOICE.equals("Gray (dark)"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.DARK_GRAY; }
        if(CHOICE.equals("Green"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.GREEN; }
        if(CHOICE.equals("Orange"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.ORANGE; }
        if(CHOICE.equals("Pink"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.PINK; }
        if(CHOICE.equals("Red"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.RED; }
        if(CHOICE.equals("Magenta"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.MAGENTA; }
        if(CHOICE.equals("Black"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.BLACK; }
        if(CHOICE.equals("Yellow"))
        { PolyBATTLEFIELDApplet.Color_Player = Color.YELLOW; }

    //---A2. Enemy Color-----------------------------------------------
        TEMP = CB_EnemyColor.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }
    
        if(CHOICE.equals("White"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.WHITE; } 
        if(CHOICE.equals("Blue"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.BLUE; }
        if(CHOICE.equals("Cyan"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.CYAN; }
        if(CHOICE.equals("Gray"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.GRAY; }
        if(CHOICE.equals("Gray (light)"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.LIGHT_GRAY; }
        if(CHOICE.equals("Gray (dark)"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.DARK_GRAY; }
        if(CHOICE.equals("Green"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.GREEN; }
        if(CHOICE.equals("Orange"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.ORANGE; }
        if(CHOICE.equals("Pink"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.PINK; }
        if(CHOICE.equals("Red"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.RED; }
        if(CHOICE.equals("Magenta"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.MAGENTA; }
        if(CHOICE.equals("Black"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.BLACK; }
        if(CHOICE.equals("Yellow"))
        { PolyBATTLEFIELDApplet.Color_Enemy = Color.YELLOW; }
        
    //---A3. Enemy Projectile Color-----------------------------------------------
         TEMP = CB_EnemyProjectileColor.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }
    
        if(CHOICE.equals("White"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.WHITE; } 
        if(CHOICE.equals("Blue"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.BLUE; }
        if(CHOICE.equals("Cyan"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.CYAN; }
        if(CHOICE.equals("Gray"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.GRAY; }
        if(CHOICE.equals("Gray (light)"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.LIGHT_GRAY; }
        if(CHOICE.equals("Gray (dark)"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.DARK_GRAY; }
        if(CHOICE.equals("Green"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.GREEN; }
        if(CHOICE.equals("Orange"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.ORANGE; }
        if(CHOICE.equals("Pink"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.PINK; }
        if(CHOICE.equals("Red"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.RED; }
        if(CHOICE.equals("Magenta"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.MAGENTA; }
        if(CHOICE.equals("Black"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.BLACK; }
        if(CHOICE.equals("Yellow"))
        { PolyBATTLEFIELDApplet.Color_EnemyProjectile = Color.YELLOW; }
        
    //---A4. Player Projectile Color-----------------------------------------------
         TEMP = CB_PlayerProjectileColor.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }
    
        if(CHOICE.equals("White"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.WHITE; } 
        if(CHOICE.equals("Blue"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.BLUE; }
        if(CHOICE.equals("Cyan"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.CYAN; }
        if(CHOICE.equals("Gray"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.GRAY; }
        if(CHOICE.equals("Gray (light)"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.LIGHT_GRAY; }
        if(CHOICE.equals("Gray (dark)"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.DARK_GRAY; }
        if(CHOICE.equals("Green"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.GREEN; }
        if(CHOICE.equals("Orange"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.ORANGE; }
        if(CHOICE.equals("Pink"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.PINK; }
        if(CHOICE.equals("Red"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.RED; }
        if(CHOICE.equals("Magenta"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.MAGENTA; }
        if(CHOICE.equals("Black"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.BLACK; }
        if(CHOICE.equals("Yellow"))
        { PolyBATTLEFIELDApplet.Color_PlayerProjectile = Color.YELLOW; } 
        
    //---B1. Player Shape-----------------------------------------------
         TEMP = CB_PlayerShape.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Octagon"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.OCTAGON; }
        if(CHOICE.equals("Rectangle (small)"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.RECTANGLETINY; }
        if(CHOICE.equals("Rectangle (large)"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.RECTANGLE; }
        if(CHOICE.equals("Triangle (tiny)"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.TRIANGLETINY; }
        if(CHOICE.equals("Triangle (narrow)"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.TRIANGLENARROW; }
        if(CHOICE.equals("Triangle (wide)"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.TRIANGLEWIDE; }
        if(CHOICE.equals("Spiral"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.SPIRAL; }
        if(CHOICE.equals("BowTie"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.BOWTIE; }
        if(CHOICE.equals("Star"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.STAR; }
        if(CHOICE.equals("HexaStar"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.HEXASTAR; }
        if(CHOICE.equals("Odd Polygon"))
        { PolyBATTLEFIELDApplet.Shape_Player = PolyENTITY.ODDPOLYGON; }
              
    //---B2. Enemy Shape-----------------------------------------------
         TEMP = CB_EnemyShape.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Octagon"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.OCTAGON; }
        if(CHOICE.equals("Rectangle (small)"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.RECTANGLETINY; }
        if(CHOICE.equals("Rectangle (large)"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.RECTANGLE; }
        if(CHOICE.equals("Triangle (tiny)"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.TRIANGLETINY; }
        if(CHOICE.equals("Triangle (narrow)"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.TRIANGLENARROW; }
        if(CHOICE.equals("Triangle (wide)"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.TRIANGLEWIDE; }
        if(CHOICE.equals("Spiral"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.SPIRAL; }
        if(CHOICE.equals("BowTie"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.BOWTIE; }
        if(CHOICE.equals("Star"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.STAR; }
        if(CHOICE.equals("HexaStar"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.HEXASTAR; }
        if(CHOICE.equals("Odd Polygon"))
        { PolyBATTLEFIELDApplet.Shape_Enemy = PolyENTITY.ODDPOLYGON; }
        
    //---B3. Enemy Projectile Shape-----------------------------------------------
         TEMP = CB_EnemyProjectileShape.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Octagon"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.OCTAGON; }
        if(CHOICE.equals("Rectangle (small)"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.RECTANGLETINY; }
        if(CHOICE.equals("Rectangle (large)"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.RECTANGLE; }
        if(CHOICE.equals("Triangle (tiny)"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.TRIANGLETINY; }
        if(CHOICE.equals("Triangle (narrow)"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.TRIANGLENARROW; }
        if(CHOICE.equals("Triangle (wide)"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.TRIANGLEWIDE; }
        if(CHOICE.equals("Spiral"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.SPIRAL; }
        if(CHOICE.equals("BowTie"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.BOWTIE; }
        if(CHOICE.equals("Star"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.STAR; }
        if(CHOICE.equals("HexaStar"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.HEXASTAR; }
        if(CHOICE.equals("Odd Polygon"))
        { PolyBATTLEFIELDApplet.Shape_EnemyProjectile = PolyENTITY.ODDPOLYGON; }        
                
    //---B4. Player Projectile Shape-----------------------------------------------
         TEMP = CB_PlayerProjectileShape.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Octagon"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.OCTAGON; }
        if(CHOICE.equals("Rectangle (small)"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.RECTANGLETINY; }
        if(CHOICE.equals("Rectangle (large)"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.RECTANGLE; }
        if(CHOICE.equals("Triangle (tiny)"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.TRIANGLETINY; }
        if(CHOICE.equals("Triangle (narrow)"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.TRIANGLENARROW; }
        if(CHOICE.equals("Triangle (wide)"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.TRIANGLEWIDE; }
        if(CHOICE.equals("Spiral"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.SPIRAL; }
        if(CHOICE.equals("BowTie"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.BOWTIE; }
        if(CHOICE.equals("Star"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.STAR; }
        if(CHOICE.equals("HexaStar"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.HEXASTAR; }
        if(CHOICE.equals("Odd Polygon"))
        { PolyBATTLEFIELDApplet.Shape_PlayerProjectile = PolyENTITY.ODDPOLYGON; }
        
        
    //---C1. Player Physics-----------------------------------------------
         TEMP = CB_PlayerPhysics.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("BOUNCE"))
        { PolyBATTLEFIELDApplet.Physics_Player = PolyBATTLEFIELDApplet.BOUNCE; }
        if(CHOICE.equals("WRAP"))
        { PolyBATTLEFIELDApplet.Physics_Player = PolyBATTLEFIELDApplet.WRAP; }
        if(CHOICE.equals("TRAP"))
        { PolyBATTLEFIELDApplet.Physics_Player = PolyBATTLEFIELDApplet.TRAP; }
        if(CHOICE.equals("KILL"))
        { PolyBATTLEFIELDApplet.Physics_Player = PolyBATTLEFIELDApplet.KILL; }
        
    //---C2. Enemy Physics-----------------------------------------------
         TEMP = CB_EnemyPhysics.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("BOUNCE"))
        { PolyBATTLEFIELDApplet.Physics_Enemy = PolyBATTLEFIELDApplet.BOUNCE; }
        if(CHOICE.equals("WRAP"))
        { PolyBATTLEFIELDApplet.Physics_Enemy = PolyBATTLEFIELDApplet.WRAP; }
        if(CHOICE.equals("TRAP"))
        { PolyBATTLEFIELDApplet.Physics_Enemy = PolyBATTLEFIELDApplet.TRAP; }
        if(CHOICE.equals("KILL"))
        { PolyBATTLEFIELDApplet.Physics_Enemy = PolyBATTLEFIELDApplet.KILL; }
         
    //---C3. Enemy Projectile Physics-----------------------------------------------
         TEMP = CB_EnemyProjectilePhysics.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("BOUNCE"))
        { PolyBATTLEFIELDApplet.Physics_EnemyProjectile = PolyBATTLEFIELDApplet.BOUNCE; }
        if(CHOICE.equals("WRAP"))
        { PolyBATTLEFIELDApplet.Physics_EnemyProjectile = PolyBATTLEFIELDApplet.WRAP; }
        if(CHOICE.equals("TRAP"))
        { PolyBATTLEFIELDApplet.Physics_EnemyProjectile = PolyBATTLEFIELDApplet.TRAP; }
        if(CHOICE.equals("KILL"))
        { PolyBATTLEFIELDApplet.Physics_EnemyProjectile = PolyBATTLEFIELDApplet.KILL; }
        
    //---C4. Player Projectile Physics-----------------------------------------------
         TEMP = CB_PlayerProjectilePhysics.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("BOUNCE"))
        { PolyBATTLEFIELDApplet.Physics_PlayerProjectile = PolyBATTLEFIELDApplet.BOUNCE; }
        if(CHOICE.equals("WRAP"))
        { PolyBATTLEFIELDApplet.Physics_PlayerProjectile = PolyBATTLEFIELDApplet.WRAP; }
        if(CHOICE.equals("TRAP"))
        { PolyBATTLEFIELDApplet.Physics_PlayerProjectile = PolyBATTLEFIELDApplet.TRAP; }
        if(CHOICE.equals("KILL"))
        { PolyBATTLEFIELDApplet.Physics_PlayerProjectile = PolyBATTLEFIELDApplet.KILL; }
        
    //---D1. Player Solid or Hollow-----------------------------------------------
         TEMP = CB_PlayerHollowOrSolid.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Hollow"))
        { PolyBATTLEFIELDApplet.HollowPlayer = true; }
        if(CHOICE.equals("Solid"))
        { PolyBATTLEFIELDApplet.HollowPlayer = false; }
        
    //---D2. Enemy Solid or Hollow-----------------------------------------------
         TEMP = CB_EnemyHollowOrSolid.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Hollow"))
        { PolyBATTLEFIELDApplet.HollowEnemies = true; }
        if(CHOICE.equals("Solid"))
        { PolyBATTLEFIELDApplet.HollowEnemies = false; }     
        
    //---D3. Enemy Projectiles Solid or Hollow-----------------------------------------------
         TEMP = CB_EnemyProjectileHollowOrSolid.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Hollow"))
        { PolyBATTLEFIELDApplet.HollowEnemyProjectiles = true; }
        if(CHOICE.equals("Solid"))
        { PolyBATTLEFIELDApplet.HollowEnemyProjectiles = false; }  
        
    //---D4. Player Projectiles Solid or Hollow-----------------------------------------------
         TEMP = CB_PlayerProjectileHollowOrSolid.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("Hollow"))
        { PolyBATTLEFIELDApplet.HollowPlayerProjectiles= true; }
        if(CHOICE.equals("Solid"))
        { PolyBATTLEFIELDApplet.HollowPlayerProjectiles = false; }         
        
    //---E1. Background Color -------------------------------------------------
         TEMP = CB_BackgroundColor.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("White"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.WHITE; } 
        if(CHOICE.equals("Blue"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.BLUE; }
        if(CHOICE.equals("Cyan"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.CYAN; }
        if(CHOICE.equals("Gray"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.GRAY; }
        if(CHOICE.equals("Gray (light)"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.LIGHT_GRAY; }
        if(CHOICE.equals("Gray (dark)"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.DARK_GRAY; }
        if(CHOICE.equals("Green"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.GREEN; }
        if(CHOICE.equals("Orange"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.ORANGE; }
        if(CHOICE.equals("Pink"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.PINK; }
        if(CHOICE.equals("Red"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.RED; }
        if(CHOICE.equals("Magenta"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.MAGENTA; }
        if(CHOICE.equals("Black"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.BLACK; }
        if(CHOICE.equals("Yellow"))
        { PolyBATTLEFIELDApplet.Color_Background = Color.YELLOW; } 
      
    //---F1. Enemy Attack Style -------------------------------------------------
         TEMP = CB_EnemyAttackStyle.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("MINES"))
        { PolyBATTLEFIELDApplet.EnemyAttackStyle = PolyBATTLEFIELDApplet.MINES; } 
        if(CHOICE.equals("MISSLES"))
        { PolyBATTLEFIELDApplet.EnemyAttackStyle = PolyBATTLEFIELDApplet.MISSLES; }
 
    //---G1. Number of Enemies -------------------------------------------------
         TEMP = CB_NumEnemies.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("1")) { PolyBATTLEFIELDApplet.NumEnemies = 1; }
        if(CHOICE.equals("2")) { PolyBATTLEFIELDApplet.NumEnemies = 2; }
        if(CHOICE.equals("3")) { PolyBATTLEFIELDApplet.NumEnemies = 3; }
        if(CHOICE.equals("4")) { PolyBATTLEFIELDApplet.NumEnemies = 4; }
        if(CHOICE.equals("5")) { PolyBATTLEFIELDApplet.NumEnemies = 5; }
        if(CHOICE.equals("6")) { PolyBATTLEFIELDApplet.NumEnemies = 6; }
        if(CHOICE.equals("7")) { PolyBATTLEFIELDApplet.NumEnemies = 7; }
        if(CHOICE.equals("8")) { PolyBATTLEFIELDApplet.NumEnemies = 8; }
        if(CHOICE.equals("9")) { PolyBATTLEFIELDApplet.NumEnemies = 9; }
        if(CHOICE.equals("10")) { PolyBATTLEFIELDApplet.NumEnemies = 10; }
        if(CHOICE.equals("11")) { PolyBATTLEFIELDApplet.NumEnemies = 11; }
        if(CHOICE.equals("12")) { PolyBATTLEFIELDApplet.NumEnemies = 12; }
        if(CHOICE.equals("13")) { PolyBATTLEFIELDApplet.NumEnemies = 13; }
        if(CHOICE.equals("14")) { PolyBATTLEFIELDApplet.NumEnemies = 14; }
        if(CHOICE.equals("15")) { PolyBATTLEFIELDApplet.NumEnemies = 15; }
        if(CHOICE.equals("16")) { PolyBATTLEFIELDApplet.NumEnemies = 16; }
        if(CHOICE.equals("17")) { PolyBATTLEFIELDApplet.NumEnemies = 17; }
        if(CHOICE.equals("18")) { PolyBATTLEFIELDApplet.NumEnemies = 18; }
        if(CHOICE.equals("19")) { PolyBATTLEFIELDApplet.NumEnemies = 19; }
        if(CHOICE.equals("20")) { PolyBATTLEFIELDApplet.NumEnemies = 20; }
        if(CHOICE.equals("21")) { PolyBATTLEFIELDApplet.NumEnemies = 21; }
        if(CHOICE.equals("22")) { PolyBATTLEFIELDApplet.NumEnemies = 22; }
        if(CHOICE.equals("23")) { PolyBATTLEFIELDApplet.NumEnemies = 23; }
        if(CHOICE.equals("24")) { PolyBATTLEFIELDApplet.NumEnemies = 24; }
        if(CHOICE.equals("25")) { PolyBATTLEFIELDApplet.NumEnemies = 25; }
        if(CHOICE.equals("26")) { PolyBATTLEFIELDApplet.NumEnemies = 26; }
        if(CHOICE.equals("27")) { PolyBATTLEFIELDApplet.NumEnemies = 27; }
        if(CHOICE.equals("28")) { PolyBATTLEFIELDApplet.NumEnemies = 28; }
        if(CHOICE.equals("29")) { PolyBATTLEFIELDApplet.NumEnemies = 29; }
        if(CHOICE.equals("30")) { PolyBATTLEFIELDApplet.NumEnemies = 30; }
        
    //---H1. Enemy Fire -------------------------------------------------
         
         if(RB_EnemyFire_On.isSelected()) { PolyBATTLEFIELDApplet.EnemyFire = true; }
         if(RB_EnemyFire_Off.isSelected()) { PolyBATTLEFIELDApplet.EnemyFire = false; }
         
    //---I1. Friendly Fire -------------------------------------------------
         
         if(RB_FriendlyFire_On.isSelected()) { PolyBATTLEFIELDApplet.FriendlyFire = true; }
         if(RB_FriendlyFire_Off.isSelected()) { PolyBATTLEFIELDApplet.FriendlyFire = false; }
         
    //---J1. Movement -------------------------------------------------
         
         if(RB_MicroGravity.isSelected()) { PolyBATTLEFIELDApplet.MicroGravity = true; }
         if(RB_AntiInertia.isSelected()) { PolyBATTLEFIELDApplet.MicroGravity = false; }  
         
    //---K1. Special -------------------------------------------------
         
         if(CHECK_RainbowColors.isSelected()) 
         { PolyBATTLEFIELDApplet.RainbowColors = true; }
         else
         { PolyBATTLEFIELDApplet.RainbowColors = false; }
         
         if(CHECK_MixedShapes.isSelected())
         { PolyBATTLEFIELDApplet.MixedShapes = true; }
         else
         { PolyBATTLEFIELDApplet.MixedShapes = false; }

    //---L1. Number of Player Projectiles -------------------------------------
         TEMP = CB_NumPlayerProjectiles.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("1")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 1; }
        if(CHOICE.equals("2")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 2; }
        if(CHOICE.equals("3")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 3; }
        if(CHOICE.equals("4")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 4; }
        if(CHOICE.equals("5")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 5; }
        if(CHOICE.equals("6")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 6; }
        if(CHOICE.equals("7")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 7; }
        if(CHOICE.equals("8")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 8; }
        if(CHOICE.equals("9")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 9; }
        if(CHOICE.equals("10")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 10; }
        if(CHOICE.equals("11")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 11; }
        if(CHOICE.equals("12")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 12; }
        if(CHOICE.equals("13")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 13; }
        if(CHOICE.equals("14")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 14; }
        if(CHOICE.equals("15")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 15; }
        if(CHOICE.equals("16")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 16; }
        if(CHOICE.equals("17")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 17; }
        if(CHOICE.equals("18")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 18; }
        if(CHOICE.equals("19")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 19; }
        if(CHOICE.equals("20")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 20; }
        if(CHOICE.equals("21")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 21; }
        if(CHOICE.equals("22")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 22; }
        if(CHOICE.equals("23")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 23; }
        if(CHOICE.equals("24")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 24; }
        if(CHOICE.equals("25")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 25; }
        if(CHOICE.equals("26")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 26; }
        if(CHOICE.equals("27")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 27; }
        if(CHOICE.equals("28")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 28; }
        if(CHOICE.equals("29")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 29; }
        if(CHOICE.equals("30")) { PolyBATTLEFIELDApplet.NumPlayerProjectiles = 30; }
        
    //---L2. Number of Enemy Projectiles --------------------------------------
         TEMP = CB_NumEnemyProjectiles.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("1")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 1; }
        if(CHOICE.equals("2")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 2; }
        if(CHOICE.equals("3")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 3; }
        if(CHOICE.equals("4")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 4; }
        if(CHOICE.equals("5")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 5; }
        if(CHOICE.equals("6")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 6; }
        if(CHOICE.equals("7")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 7; }
        if(CHOICE.equals("8")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 8; }
        if(CHOICE.equals("9")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 9; }
        if(CHOICE.equals("10")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 10; }
        if(CHOICE.equals("11")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 11; }
        if(CHOICE.equals("12")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 12; }
        if(CHOICE.equals("13")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 13; }
        if(CHOICE.equals("14")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 14; }
        if(CHOICE.equals("15")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 15; }
        if(CHOICE.equals("16")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 16; }
        if(CHOICE.equals("17")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 17; }
        if(CHOICE.equals("18")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 18; }
        if(CHOICE.equals("19")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 19; }
        if(CHOICE.equals("20")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 20; }
        if(CHOICE.equals("21")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 21; }
        if(CHOICE.equals("22")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 22; }
        if(CHOICE.equals("23")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 23; }
        if(CHOICE.equals("24")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 24; }
        if(CHOICE.equals("25")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 25; }
        if(CHOICE.equals("26")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 26; }
        if(CHOICE.equals("27")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 27; }
        if(CHOICE.equals("28")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 28; }
        if(CHOICE.equals("29")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 29; }
        if(CHOICE.equals("30")) { PolyBATTLEFIELDApplet.NumEnemyProjectiles = 30; }
        
    //---M1. Number of Collisions Allowed Per Game ----------------------------
         TEMP = CB_NumCollisions.getSelectedItem();
        
        if(TEMP != null) 
        { CHOICE = TEMP.toString(); }
        else { CHOICE = " "; }        

        if(CHOICE.equals("1")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 1; }
        if(CHOICE.equals("2")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 2; }
        if(CHOICE.equals("3")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 3; }
        if(CHOICE.equals("4")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 4; }
        if(CHOICE.equals("5")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 5; }
        if(CHOICE.equals("6")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 6; }
        if(CHOICE.equals("7")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 7; }
        if(CHOICE.equals("8")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 8; }
        if(CHOICE.equals("9")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 9; }
        if(CHOICE.equals("10")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 10; }
        if(CHOICE.equals("11")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 11; }
        if(CHOICE.equals("12")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 12; }
        if(CHOICE.equals("13")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 13; }
        if(CHOICE.equals("14")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 14; }
        if(CHOICE.equals("15")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 15; }
        if(CHOICE.equals("16")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 16; }
        if(CHOICE.equals("17")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 17; }
        if(CHOICE.equals("18")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 18; }
        if(CHOICE.equals("19")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 19; }
        if(CHOICE.equals("20")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 20; }
        if(CHOICE.equals("21")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 21; }
        if(CHOICE.equals("22")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 22; }
        if(CHOICE.equals("23")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 23; }
        if(CHOICE.equals("24")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 24; }
        if(CHOICE.equals("25")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 25; }
        if(CHOICE.equals("26")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 26; }
        if(CHOICE.equals("27")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 27; }
        if(CHOICE.equals("28")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 28; }
        if(CHOICE.equals("29")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 29; }
        if(CHOICE.equals("30")) { PolyBATTLEFIELDApplet.CollisionsAllowed = 30; }        
        
    //---N1. Show Collision Geometry ------------------------------------------
         
         if(RB_ShowCollisionGeometry_On.isSelected()) 
         { PolyBATTLEFIELDApplet.ShowCollisionGeometry = true; }
         
         if(RB_ShowCollisionGeometry_Off.isSelected())
         { PolyBATTLEFIELDApplet.ShowCollisionGeometry = false; }
         
    //---O1. Show Player Info -------------------------------------------------
         
         if(RB_ShowPlayerInfo_On.isSelected()) 
         { PolyBATTLEFIELDApplet.ShowPlayerInfo = true; }
         
         if(RB_ShowPlayerInfo_Off.isSelected())
         { PolyBATTLEFIELDApplet.ShowPlayerInfo = false; } 
         
    //---P1. Sound Effects ----------------------------------------------------
         
         if(RB_SoundEffects_On.isSelected()) 
         { PolyBATTLEFIELDApplet.SOUNDEFFECTS = true; }
         
         if(RB_SoundEffects_Off.isSelected())
         { PolyBATTLEFIELDApplet.SOUNDEFFECTS = false; }         
         
    //---Q1. Music ----------------------------------------------------
         
         if(RB_Music_On.isSelected()) 
         { PolyBATTLEFIELDApplet.BACKGROUNDMUSIC = true; }
         
         if(RB_Music_Off.isSelected())
         { PolyBATTLEFIELDApplet.BACKGROUNDMUSIC = false; }  
         
         
   //-----------------------------------------------------------------------  
         BFIELD.GameOver();
         BFIELD.NewGame();
         this.dispose();
        
}//GEN-LAST:event_B_CommitChangesActionPerformed

private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        PolyBATTLEFIELDApplet.PAUSED = false;
        this.dispose();
}//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PolyMENU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PolyMENU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PolyMENU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PolyMENU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new PolyMENU(BFIELD).setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup BG_EnemyFire;
    private javax.swing.ButtonGroup BG_FriendlyFire;
    private javax.swing.ButtonGroup BG_Movement;
    private javax.swing.ButtonGroup BG_Music;
    private javax.swing.ButtonGroup BG_ShowCollisionGeometry;
    private javax.swing.ButtonGroup BG_ShowPlayerInfo;
    private javax.swing.ButtonGroup BG_SoundEffects;
    private javax.swing.JButton B_CommitChanges;
    private javax.swing.JComboBox CB_BackgroundColor;
    private javax.swing.JComboBox CB_EnemyAttackStyle;
    private javax.swing.JComboBox CB_EnemyColor;
    private javax.swing.JComboBox CB_EnemyHollowOrSolid;
    private javax.swing.JComboBox CB_EnemyPhysics;
    private javax.swing.JComboBox CB_EnemyProjectileColor;
    private javax.swing.JComboBox CB_EnemyProjectileHollowOrSolid;
    private javax.swing.JComboBox CB_EnemyProjectilePhysics;
    private javax.swing.JComboBox CB_EnemyProjectileShape;
    private javax.swing.JComboBox CB_EnemyShape;
    private javax.swing.JComboBox CB_NumCollisions;
    private javax.swing.JComboBox CB_NumEnemies;
    private javax.swing.JComboBox CB_NumEnemiesFiring;
    private javax.swing.JComboBox CB_NumEnemyProjectiles;
    private javax.swing.JComboBox CB_NumPlayerProjectiles;
    private javax.swing.JComboBox CB_PlayerColor;
    private javax.swing.JComboBox CB_PlayerHollowOrSolid;
    private javax.swing.JComboBox CB_PlayerPhysics;
    private javax.swing.JComboBox CB_PlayerProjectileColor;
    private javax.swing.JComboBox CB_PlayerProjectileHollowOrSolid;
    private javax.swing.JComboBox CB_PlayerProjectilePhysics;
    private javax.swing.JComboBox CB_PlayerProjectileShape;
    private javax.swing.JComboBox CB_PlayerShape;
    private javax.swing.JCheckBox CHECK_MixedShapes;
    private javax.swing.JCheckBox CHECK_RainbowColors;
    private javax.swing.JLabel L_Colors;
    private javax.swing.JLabel L_EnemyFire;
    private javax.swing.JLabel L_EnemyFire1;
    private javax.swing.JLabel L_FriendlyFire;
    private javax.swing.JLabel L_Movement;
    private javax.swing.JLabel L_Music;
    private javax.swing.JLabel L_Physics;
    private javax.swing.JLabel L_ShapeTitle;
    private javax.swing.JLabel L_ShowCollisionGeometry;
    private javax.swing.JLabel L_ShowPlayerInfo;
    private javax.swing.JLabel L_SolidOrHollow;
    private javax.swing.JLabel L_SoundEffects;
    private javax.swing.JLabel L_TItle;
    private javax.swing.JPanel PAN_BackgroundColor;
    private javax.swing.JPanel PAN_Colors;
    private javax.swing.JPanel PAN_EnemyAttackStyle;
    private javax.swing.JPanel PAN_EnemyFire;
    private javax.swing.JPanel PAN_FriendlyFire;
    private javax.swing.JPanel PAN_Movement;
    private javax.swing.JPanel PAN_Music;
    private javax.swing.JPanel PAN_NumCollisions;
    private javax.swing.JPanel PAN_NumEnemies;
    private javax.swing.JPanel PAN_NumEnemiesFiring;
    private javax.swing.JPanel PAN_NumEnemyProjectiles;
    private javax.swing.JPanel PAN_NumPlayerProjectiles;
    private javax.swing.JPanel PAN_Physics;
    private javax.swing.JPanel PAN_Shapes;
    private javax.swing.JPanel PAN_ShowCollisionGeometry;
    private javax.swing.JPanel PAN_ShowPlayerInfo;
    private javax.swing.JPanel PAN_SolidOrHollow;
    private javax.swing.JPanel PAN_SoundEffects;
    private javax.swing.JPanel PAN_Special;
    private javax.swing.JRadioButton RB_AntiInertia;
    private javax.swing.JRadioButton RB_EnemyFire_Off;
    private javax.swing.JRadioButton RB_EnemyFire_On;
    private javax.swing.JRadioButton RB_FriendlyFire_Off;
    private javax.swing.JRadioButton RB_FriendlyFire_On;
    private javax.swing.JRadioButton RB_MicroGravity;
    private javax.swing.JRadioButton RB_Music_Off;
    private javax.swing.JRadioButton RB_Music_On;
    private javax.swing.JRadioButton RB_ShowCollisionGeometry_Off;
    private javax.swing.JRadioButton RB_ShowCollisionGeometry_On;
    private javax.swing.JRadioButton RB_ShowPlayerInfo_Off;
    private javax.swing.JRadioButton RB_ShowPlayerInfo_On;
    private javax.swing.JRadioButton RB_SoundEffects_Off;
    private javax.swing.JRadioButton RB_SoundEffects_On;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
