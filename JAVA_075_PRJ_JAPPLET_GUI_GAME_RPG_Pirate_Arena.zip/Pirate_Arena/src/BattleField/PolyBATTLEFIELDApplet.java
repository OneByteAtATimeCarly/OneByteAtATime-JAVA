//
package BattleField;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.net.URL;
import java.util.*;


public class PolyBATTLEFIELDApplet extends Applet implements Runnable, KeyListener
{
//Globals----------------------------------------------------------------------
    public static Thread MainGameLoop;
    public static Thread EnemyAttackWindow;
    public static PolyMENU TheMenu;
 //------------------------------------------  
    public static final int TRAP = 0;
    public static final int BOUNCE = 1;
    public static final int WRAP = 2;
    public static final int KILL = 3;
    public static int Physics_Player = BOUNCE;
    public static int Physics_Enemy = BOUNCE;
    public static int Physics_PlayerProjectile = KILL;
    public static int Physics_EnemyProjectile = KILL;
    public static boolean MicroGravity = true;
 //------------------------------------------
    public static final int MINES = 4;
    public static final int MISSLES = 5;
    public static int EnemyAttackStyle = MISSLES;
 //------------------------------------------    
    public static boolean EnemyFire = true;    
    public static boolean FriendlyFire = false;
 //------------------------------------------
    public static int Shape_Enemy = PolyENTITY.TRIANGLETINY;
    public static int Shape_Player = PolyENTITY.TRIANGLETINY;
    public static int Shape_EnemyProjectile =  PolyENTITY.RECTANGLETINY;
    public static int Shape_PlayerProjectile =  PolyENTITY.RECTANGLETINY;
    public static Color Color_Enemy = Color.RED;
    public static Color Color_Player = Color.GREEN;
    public static Color Color_EnemyProjectile = Color.MAGENTA;
    public static Color Color_PlayerProjectile = Color.MAGENTA;
    public static Color Color_Background = Color.BLACK;
 //------------------------------------------     
    public static boolean MixedShapes = true;
    public static boolean RainbowColors = true;
    public static boolean HollowEnemies = true;
    public static boolean HollowPlayer = false;
    public static boolean HollowPlayerProjectiles = false;
    public static boolean HollowEnemyProjectiles = false;    
 //------------------------------------------    
    public static boolean ShowCollisionGeometry = false;
    public static boolean ShowPlayerInfo = false;
 //------------------------------------------   
    public static int NumEnemies = 20;
    public static int NumEnemiesFiring = 10;
    public static int NumPlayerProjectiles = 10;
    public static int NumEnemyProjectiles = 10;
    public int CurrentPlayerProjectile = 0;
    public int CurrentEnemyProjectile = 0;
 //------------------------------------------     
    public int SCORE = 0;
    public static int CollisionsAllowed = 5;
    public int CollisionCount = 0;
    public boolean GameOverMan = false;
    public static boolean PAUSED = false;
 //------------------------------------------      
    BufferedImage BUFFER;   //For DoubleBuffering animation
    Graphics2D PaintBrush;  //The paint brush for the back buffer (double buffer)
    Random RN = new Random();    
    
    public static boolean SOUNDEFFECTS = true;
    public static boolean BACKGROUNDMUSIC = true;
    AudioClip MUSIC;
    AudioClip FIRE;
    AudioClip EXPLOSION;
    
    public static int ScreenWidth = 800;
    public static int ScreenHeight = 600;
    
    //Build Global Polygon objects and POPULATE Arrays
    PolyPLAYER POLYPLAYER;
    PolyENEMY[] POLYENEMIES;
    PolyPROJECTILE[] PLAYERPROJECTILES;
    PolyPROJECTILE[] ENEMYPROJECTILES;
    
    //Create instance of AffineTransform. Necessary to rotate and transform
    //objects relative to their current position and not absolute 0,0 x/y. 
    AffineTransform OptimusPrime = new AffineTransform();        
//------------------------------------------------------------------------------
      //Constructor
       public PolyBATTLEFIELDApplet()  {    }     
//------------------------------------------------------------------------------       
       public void Menu()
       {
              PAUSED = true;
              //TheMenu = new PolyMENU(this);
              TheMenu.setVisible(true);
       }
//------------------------------------------------------------------------------       
    public void init() 
    {
        //create the back buffer for smooth graphics
        BUFFER = new BufferedImage(ScreenWidth, ScreenHeight, BufferedImage.TYPE_INT_RGB);
        PaintBrush = BUFFER.createGraphics();
 
        //load sound files
        MUSIC = Applet.newAudioClip(Get_Location("/AUDIO/Music.au"));
        FIRE = Applet.newAudioClip(Get_Location("/AUDIO/Fire.au"));
        EXPLOSION = Applet.newAudioClip(Get_Location("/AUDIO/Explosion.au"));

        //start the user input listener
        addKeyListener(this); 
        this.setSize(new Dimension(ScreenWidth,ScreenHeight+20));
        this.setLocation(0,0);
        
        BuildGameObjects();
    }
//------------------------------------------------------------------------------           
    public void BuildGameObjects()
    {
        POLYPLAYER = new PolyPLAYER();
        POLYENEMIES = new PolyENEMY[NumEnemies];
        PLAYERPROJECTILES = new PolyPROJECTILE[NumPlayerProjectiles];
        ENEMYPROJECTILES = new PolyPROJECTILE[NumEnemyProjectiles];
        
        //Set up the POLYPLAYER
        POLYPLAYER.Set_Shape(Shape_Player);
        POLYPLAYER.Set_Color(Color_Player);
        POLYPLAYER.Set_X(ScreenWidth/2);
        POLYPLAYER.Set_Y(ScreenHeight/2);

        //POPULATE PLAYERPROJECTILES
        for(int n = 0; n<NumPlayerProjectiles; n++) 
        {
            PLAYERPROJECTILES[n] = new PolyPROJECTILE();
            PLAYERPROJECTILES[n].Set_Shape(Shape_PlayerProjectile);
            PLAYERPROJECTILES[n].Set_Color(Color_PlayerProjectile);
        }
        
        //POPULATE ENEMYPROJECTILES
        for(int n = 0; n<NumEnemyProjectiles; n++) 
        {
            ENEMYPROJECTILES[n] = new PolyPROJECTILE();
            ENEMYPROJECTILES[n].Set_Shape(Shape_EnemyProjectile);
            ENEMYPROJECTILES[n].Set_Color(Color_EnemyProjectile);
        }       
        
        int ShapeCount = 0;
        int ColorCount = 0;
        
        //POPULATE POLYENEMIES
        for(int n = 0; n<NumEnemies; n++) 
        {
            POLYENEMIES[n] = new PolyENEMY();
            POLYENEMIES[n].Set_Rotation_Velocity(RN.nextInt(3)+1);
            POLYENEMIES[n].Set_X((double)RN.nextInt(ScreenWidth-40)+20);
            POLYENEMIES[n].Set_Y((double)RN.nextInt(ScreenHeight-40)+20);
            POLYENEMIES[n].Set_Move_Angle(RN.nextInt(360));
            double ang = POLYENEMIES[n].Get_Move_Angle() - 90;
            POLYENEMIES[n].Set_X_Velocity(Calculate_Move_Angle_X(ang));
            POLYENEMIES[n].Set_Y_Velocity(Calculate_Move_Angle_Y(ang));
            
            if(MixedShapes)
            {
               POLYENEMIES[n].Set_Shape(ShapeCount);
               if(ShapeCount < (PolyENTITY.NumShapes-1)) { ShapeCount++; }
               else { ShapeCount = 0; }
            }
            else
            { POLYENEMIES[n].Set_Shape(Shape_Enemy); }
            
            if(RainbowColors)
            {
               switch(ColorCount)
               { 
                   case 0 : POLYENEMIES[n].Set_Color(Color.BLUE); break;
                   case 1 : POLYENEMIES[n].Set_Color(Color.CYAN); break;
                   case 2 : POLYENEMIES[n].Set_Color(Color.GREEN); break;
                   case 3 : POLYENEMIES[n].Set_Color(Color.MAGENTA); break;
                   case 4 : POLYENEMIES[n].Set_Color(Color.ORANGE); break;
                   case 5 : POLYENEMIES[n].Set_Color(Color.PINK); break;
                   case 6 : POLYENEMIES[n].Set_Color(Color.RED); break;
                   case 7 : POLYENEMIES[n].Set_Color(Color.WHITE); break;
                   case 8 : POLYENEMIES[n].Set_Color(Color.YELLOW); break;
                   case 9 : POLYENEMIES[n].Set_Color(Color.LIGHT_GRAY); break;
                   default : ColorCount = 0;   
               }
               
               ColorCount++;
            }
            else
            { POLYENEMIES[n].Set_Color(Color_Enemy); }
            
            if(EnemyFire) 
            {   
                if(n < NumEnemiesFiring)
                { POLYENEMIES[n].Set_Firing(true); } 
            }
        }
        
        if(BACKGROUNDMUSIC) { MUSIC.loop(); }
    }
 //-----------------------------------------------------------------------------    
    public URL Get_Location(String filename)
    {
           URL url = null;
           try { url = this.getClass().getResource(filename); }
           catch (Exception e) { /*STUFF*/ }
           return url;
    }     
//------------------------------------------------------------------------------    
    public void AttackPlayer_Missles(int A)
    {
           CurrentEnemyProjectile++;
                
           //Reset NumPlayerProjectiles if MAX # exceeded
           if(CurrentEnemyProjectile > NumEnemyProjectiles - 1)
           { 
              CurrentEnemyProjectile = 0; 
           }
                                         
           ENEMYPROJECTILES[CurrentEnemyProjectile].Set_Active(true);
                                         
           //Point PolyPROJECTILE in DIRECTION PolyPLAYER is facing
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_X(POLYENEMIES[A].Get_X());
                                         
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_Y(POLYENEMIES[A].Get_Y()); 
           
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_Move_Angle(POLYENEMIES[A].Get_Face_Angle() - 90);
                                         
           //Point PolyPROJECTILE at ANGLE of PolyPLAYER
           double angle = 
           ENEMYPROJECTILES[CurrentEnemyProjectile].Get_Move_Angle();
                                     
           double svx = POLYENEMIES[A].Get_X_Velocity();
           double svy = POLYENEMIES[A].Get_Y_Velocity();
                                        
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_X_Velocity(svx + Calculate_Move_Angle_X(angle) * 2);
                                        
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_Y_Velocity(svy + Calculate_Move_Angle_Y(angle) * 2);     
           
    }
 //-----------------------------------------------------------------------------    
    public void AttackPlayer_Mines(int A)
    {
           CurrentEnemyProjectile++;
                
           //Reset NumEnemyProjectiles if MAX # exceeded
           if(CurrentEnemyProjectile > NumEnemyProjectiles - 1)
           { 
               CurrentEnemyProjectile = 0; 
           }
                                         
           ENEMYPROJECTILES[CurrentEnemyProjectile].Set_Active(true);
                                         
           //Point PolyPROJECTILE in DIRECTION PolyENEMY is facing
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_X(POLYENEMIES[A].Get_X());
                                         
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_Y(POLYENEMIES[A].Get_Y());
                                         
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_Move_Angle(POLYPLAYER.Get_Face_Angle());
       
           //Point PolyPROJECTILE at ANGLE of PolyENEMY
           double angle = 
           POLYPLAYER.Get_Move_Angle();
                                        
           double X = POLYPLAYER.Get_X_Velocity();
           double Y = POLYPLAYER.Get_Y_Velocity();
                                        
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_X_Velocity(X + Calculate_Move_Angle_X(angle) * 2);
                                        
           ENEMYPROJECTILES[CurrentEnemyProjectile].
           Set_Y_Velocity(Y + Calculate_Move_Angle_Y(angle) * 2);
       
    }         
//------------------------------------------------------------------------------
    public void update(Graphics g) 
    {        
           int StartX = 0;
           int StartY = 0;

           //Perform all transformations at "OptimusPrime"
           PaintBrush.setTransform(OptimusPrime); 
           
           //Erase background (paint over)
           PaintBrush.setPaint(Color_Background);
           PaintBrush.fillRect(0, 0, getSize().width, getSize().height);             
           
           StartX = 190;
           StartY = 12; 
           PaintBrush.setColor(Color.WHITE);
           PaintBrush.setFont(new Font("Trebuchet MS", 0, 14));
           PaintBrush.drawString("M=Configuration Menu     P=Pause     N=New Game     Q=Quit", 
                       StartX, StartY);
           StartX = 680;
           StartY = 12; 
           PaintBrush.setColor(Color.WHITE);
           PaintBrush.setFont(new Font("Trebuchet MS", 0, 14));
           PaintBrush.drawString("POLYMADNESS!", 
                       StartX, StartY); 
           
           if(GameOverMan)
           {
              StartX = 270;
              StartY = 200;
              PaintBrush.setColor(Color.LIGHT_GRAY);
              PaintBrush.setFont(new Font("Trebuchet MS", 0, 40));
              PaintBrush.drawString("POLYMADNESS!", StartX, StartY); 
              StartX = 120;
              StartY = 300; 
              PaintBrush.setColor(Color.RED);
              PaintBrush.setFont(new Font("Comic Sans MS", 0, 90));
              PaintBrush.drawString("GAME OVER", StartX, StartY);
              StartX = 330;
              StartY = 340;
              PaintBrush.setColor(Color.LIGHT_GRAY);
              PaintBrush.setFont(new Font("Trebuchet MS", 0, 16));
              PaintBrush.drawString("2011 Charles Germany", StartX, StartY);
 
           }
           else if(PAUSED)
           {
              StartX = 270;
              StartY = 200;
              PaintBrush.setColor(Color.LIGHT_GRAY);
              PaintBrush.setFont(new Font("Trebuchet MS", 0, 40));
              PaintBrush.drawString("POLYMADNESS!", StartX, StartY); 
              StartX = 120;
              StartY = 300; 
              PaintBrush.setColor(Color.RED);
              PaintBrush.setFont(new Font("Comic Sans MS", 0, 80));
              PaintBrush.drawString("GAME PAUSED", StartX, StartY);
              StartX = 330;
              StartY = 340;
              PaintBrush.setColor(Color.LIGHT_GRAY);
              PaintBrush.setFont(new Font("Trebuchet MS", 0, 16));
              PaintBrush.drawString("2011 Charles Germany", StartX, StartY);
           }
           else
           {
              StartX = 10;
              StartY = 20;
              PaintBrush.setColor(Color.WHITE);
              PaintBrush.setFont(new Font("Trebuchet MS", 0, 16));
              PaintBrush.drawString("SCORE: " + SCORE, StartX, StartY);
              StartY += 15;
              PaintBrush.drawString("COLLISIONS: " + CollisionCount, StartX, StartY);
              
              if(ShowPlayerInfo) 
              { DisplayPlayerInfo(); }
           
              //Paint the PIXELS
              Paint_POLYPLAYER();
              Paint_PLAYERPROJECTILEs();
              if(EnemyFire) { Paint_ENEMYPROJECTILEs(); }
              Paint_PolyENEMYs();
           }
           
           //Repaint window
           paint(g);
    }
//------------------------------------------------------------------------------
    public void DisplayPlayerInfo()
    {
           //Player Display
           PaintBrush.setColor(Color.WHITE);
              
           int StartX = 515;
           int StartY = 20;
           PaintBrush.drawString("POLYPLAYER Status:", StartX, StartY);
              
           StartY += 15;
           PaintBrush.drawString("X Coordinate = " + 
           Math.round(POLYPLAYER.Get_X()), StartX, StartY);
              
           StartY += 15;
           PaintBrush.drawString("Y Coordinate = " + 
           Math.round(POLYPLAYER.Get_Y()), StartX, StartY);

           StartY += 15;
           PaintBrush.drawString("Move angle: " + Math.round(
           POLYPLAYER.Get_Move_Angle()), StartX, StartY);
           
           StartY += 15;
           PaintBrush.drawString("Face angle: " +  Math.round(
           POLYPLAYER.Get_Face_Angle()), StartX, StartY);
           
           StartY += 15;
           PaintBrush.drawString("X Velocity: " +  Math.round(
           POLYPLAYER.Get_X_Velocity()), StartX, StartY);
           
           StartY += 15;
           PaintBrush.drawString("Y Velocity: " +  Math.round(
           POLYPLAYER.Get_Y_Velocity()), StartX, StartY);        
    }
//------------------------------------------------------------------------------
    public void GameOver()
    {
           MUSIC.stop();
           GameOverMan = true;
           stop(); 
    }
//------------------------------------------------------------------------------   
    public void NewGame()
    {
           MUSIC.stop();
           PAUSED = false; 
           GameOverMan = false;
           SCORE = 0; 
           CollisionCount = 0;
           if(NumEnemiesFiring > NumEnemies) 
           { NumEnemiesFiring = NumEnemies;}  //bulletproof a little
           CurrentPlayerProjectile = 0;
           CurrentEnemyProjectile = 0;
           BuildGameObjects();
           start();
    }
//------------------------------------------------------------------------------    
    public void Paint_POLYPLAYER() {
        //draw the POLYPLAYER
        PaintBrush.setTransform(OptimusPrime);
        PaintBrush.translate(POLYPLAYER.Get_X(), POLYPLAYER.Get_Y());
        PaintBrush.rotate(Math.toRadians(POLYPLAYER.Get_Face_Angle()));
        PaintBrush.setColor(POLYPLAYER.Get_Color());
        
        if(HollowPlayer) { PaintBrush.draw(POLYPLAYER.Get_Shape()); }
        else { PaintBrush.fill(POLYPLAYER.Get_Shape()); }
        
        //draw bounding rectangle around POLYPLAYER
        if (ShowCollisionGeometry) {
            PaintBrush.setTransform(OptimusPrime);
            PaintBrush.setColor(Color.GREEN);
            PaintBrush.draw(POLYPLAYER.Get_Collision_Geometry());
        }
    }
//------------------------------------------------------------------------------
    public void Paint_PLAYERPROJECTILEs() 
    {
        for (int n = 0; n < NumPlayerProjectiles; n++) 
        {
            if (PLAYERPROJECTILES[n].Get_Active()) 
            {
                //draw the PolyPROJECTILE
                PaintBrush.setTransform(OptimusPrime);
                PaintBrush.translate(PLAYERPROJECTILES[n].Get_X(), PLAYERPROJECTILES[n].Get_Y());
                PaintBrush.setColor(PLAYERPROJECTILES[n].Get_Color());
                
                if(HollowPlayerProjectiles) 
                { PaintBrush.draw(PLAYERPROJECTILES[n].Get_Shape()); }
                else { PaintBrush.fill(PLAYERPROJECTILES[n].Get_Shape()); }
            }
        }
    }
//------------------------------------------------------------------------------
    public void Paint_ENEMYPROJECTILEs() 
    {
        for (int n = 0; n < NumEnemyProjectiles; n++) 
        {
            if (ENEMYPROJECTILES[n].Get_Active()) 
            {
                //draw the PolyPROJECTILE
                PaintBrush.setTransform(OptimusPrime);
                PaintBrush.translate(ENEMYPROJECTILES[n].Get_X(), ENEMYPROJECTILES[n].Get_Y());
                PaintBrush.setColor(ENEMYPROJECTILES[n].Get_Color());
                
                if(HollowEnemyProjectiles) 
                { PaintBrush.draw(ENEMYPROJECTILES[n].Get_Shape()); }
                else { PaintBrush.fill(ENEMYPROJECTILES[n].Get_Shape()); }
            }
        }
    }    
//------------------------------------------------------------------------------
    public void Paint_PolyENEMYs() 
    {
        for (int n = 0; n < NumEnemies; n++) 
        {
            if (POLYENEMIES[n].Get_Active()) 
            {
                //draw the PolyENEMY
                PaintBrush.setTransform(OptimusPrime);
                PaintBrush.translate(POLYENEMIES[n].Get_X(), POLYENEMIES[n].Get_Y());
                PaintBrush.rotate(Math.toRadians(POLYENEMIES[n].Get_Move_Angle()));
                PaintBrush.setColor(POLYENEMIES[n].Get_Color());
                
                if(HollowEnemies) 
                { PaintBrush.draw(POLYENEMIES[n].Get_Shape()); }
                else { PaintBrush.fill(POLYENEMIES[n].Get_Shape()); }

                //draw bounding rectangle
                if (ShowCollisionGeometry) 
                {
                    PaintBrush.setTransform(OptimusPrime);
                    PaintBrush.setColor(Color.BLUE);
                    PaintBrush.draw(POLYENEMIES[n].Get_Collision_Geometry());
                }
            }
        }
    }
//------------------------------------------------------------------------------
    //DoubleBuffer window repaint event - overridden to draw back buffer
    public void paint(Graphics g) 
    {
           g.drawImage(BUFFER, 0, 20, this);
    }
//------------------------------------------------------------------------------
    //Applet start event - start the game loop running
    public void start() 
    {      
           MainGameLoop = new Thread(this);
           EnemyAttackWindow = new Thread(this);

           MainGameLoop.setPriority(1);
           MainGameLoop.start();
           
           if(EnemyFire)
           {
              EnemyAttackWindow.setPriority(1); 
              EnemyAttackWindow.start();
           } 
    }
    
//------------------------------------------------------------------------------    
    //Thread run event (game loop)
     public void run() 
     {      
                Thread t = Thread.currentThread();
            
                while (t == MainGameLoop) 
                {
                   try 
                   {   
                       if(!PAUSED && !GameOverMan)
                       { POLYGON_MASTER_UPDATE(); }
                       Thread.sleep(20);
                   }
                   catch(Exception X) 
                   { X.printStackTrace(); }
                   
                   repaint();
                }
        
                if(EnemyFire)
                {   
                   while(t == EnemyAttackWindow) 
                   { 
                      try 
                      {   if(!PAUSED && !GameOverMan)
                          {   
                              for(int A = 0; A < NumEnemies; A++)
                              { 
                                  if(POLYENEMIES[A].Get_Firing()) 
                                  {
                                      switch(EnemyAttackStyle)
                                      { 
                                          case MISSLES : AttackPlayer_Missles(A);
                                                         Thread.sleep(1000);
                                                         break;
                                          case MINES : AttackPlayer_Mines(A); 
                                                       Thread.sleep(300);
                                                       break;    
                                      }  
                                  }              
                              }
                         }
                     }
                     catch(Exception e) 
                     {
                        e.printStackTrace();
                     }
                     
                     repaint();
                 }
               }
         
    }//close function
//------------------------------------------------------------------------------
    //stop() methods necessary for Thread objects and run() method
    public void stop() 
    {
           MainGameLoop = null;
           EnemyAttackWindow = null;
    }
//------------------------------------------------------------------------------
    //Update POLYGONS that have moved since last paint()
    public void POLYGON_MASTER_UPDATE() 
    {
        //----1. Player--------------------------
           switch(Physics_Player)
           { 
               case TRAP: POLYGON_TRAP(POLYPLAYER); break;
               case BOUNCE: POLYGON_BOUNCE(POLYPLAYER); break;
               case WRAP: POLYGON_WRAP(POLYPLAYER); break;
               case KILL: POLYGON_KILL(POLYPLAYER); break;
           }
           
        //----2. Player Projectiles--------------
           for(int n = 0; n < NumPlayerProjectiles; n++) 
           {    
               switch(Physics_PlayerProjectile)
               { 
                   case TRAP: POLYGON_TRAP(PLAYERPROJECTILES[n]); break;
                   case BOUNCE: POLYGON_BOUNCE(PLAYERPROJECTILES[n]); break;
                   case WRAP: POLYGON_WRAP(PLAYERPROJECTILES[n]); break;
                   case KILL: POLYGON_KILL(PLAYERPROJECTILES[n]); break;
               }   
           }
           
        //----3. Enemies--------------------------
           for(int n = 0; n < NumEnemies; n++) 
           {
              if(POLYENEMIES[n].Get_Firing())
              {
                 ChasePlayer(n);   
              }
              else
              {
                  switch(Physics_Enemy)
                  { 
                     case TRAP: POLYGON_TRAP(POLYENEMIES[n]); break;
                     case BOUNCE: POLYGON_BOUNCE(POLYENEMIES[n]); break;
                     case WRAP: POLYGON_WRAP(POLYENEMIES[n]); break;
                     case KILL: POLYGON_KILL(POLYENEMIES[n]); break;
                  }                    
                     
                  POLYGON_ROTATE(POLYENEMIES[n]);
              }
           }
           
        //---4. Enemy Projectiles--------------------------
           if(EnemyFire) 
           { 
              for(int n = 0; n < NumEnemyProjectiles; n++) 
              {    
                  switch(Physics_EnemyProjectile)
                  { 
                      case TRAP: POLYGON_TRAP(ENEMYPROJECTILES[n]); break;
                      case BOUNCE: POLYGON_BOUNCE(ENEMYPROJECTILES[n]); break;
                      case WRAP: POLYGON_WRAP(ENEMYPROJECTILES[n]); break;
                      case KILL: POLYGON_KILL(ENEMYPROJECTILES[n]); break;
                  }   
              }             
           }
           
           Detect_Collisions(); 
    }
//-----------------------------------------------------------------------------
    
    public void ChasePlayer(int n)
    {
           POLYENEMIES[n].Set_Move_Angle(
           POLYPLAYER.Get_Face_Angle());
           POLYENEMIES[n].Set_Face_Angle(
           POLYPLAYER.Get_Face_Angle());
           
           POLYENEMIES[n].Set_X_Velocity(POLYPLAYER.Get_X_Velocity());
           POLYENEMIES[n].Set_Y_Velocity(POLYPLAYER.Get_Y_Velocity()); 

           if(POLYENEMIES[n].Get_X() > POLYPLAYER.Get_X())
           {
              POLYENEMIES[n].Increase_X(-.3);
           }
           else if(POLYENEMIES[n].Get_X() < POLYPLAYER.Get_X())
           {
                POLYENEMIES[n].Increase_X(.3);
           }
                      
           if(POLYENEMIES[n].Get_Y() > POLYPLAYER.Get_Y())
           {
              POLYENEMIES[n].Increase_Y(-.3);
           }
           else if(POLYENEMIES[n].Get_Y() < POLYPLAYER.Get_Y())
           {
              POLYENEMIES[n].Increase_Y(.3);
           }
    }
    
    public void POLYGON_ROTATE(PolyENTITY POLYGON)
    {
           POLYGON.Increase_Move_Angle(POLYGON.Get_Rotation_Velocity());

           //When POLYENEMIES rotation > 360 or < 0 FLIP/WRAP it around
           if(POLYGON.Get_Move_Angle() < 0)
           {
              POLYGON.Set_Move_Angle(360 - POLYGON.Get_Rotation_Velocity());
           }
           else if(POLYGON.Get_Move_Angle() > 360)
           {
                POLYGON.Set_Move_Angle(POLYGON.Get_Rotation_Velocity());
           }         
    }
 //----------------------------------------------------------------------------   
   //1. TRAP/STOP a POLYGON
    public void POLYGON_TRAP(PolyENTITY POLYGON)
    {                 
        //---Update POLYPLAYER's X position, stop LEFT/RIGHT---
           if(POLYGON.Get_X() < 24)
           { 
               POLYGON.Set_X(24);
               POLYGON.Set_X_Velocity(0.0);
           }
           else if(POLYGON.Get_X() > getSize().width - 24)
           { 
               POLYGON.Set_X(getSize().width - 24);
               POLYGON.Set_X_Velocity(0.0);
           }
           else
           { POLYGON.Increase_X(POLYGON.Get_X_Velocity()); } 
        
           
        //---Update POLYPLAYER's Y position, stop LEFT/RIGHT---
           if(POLYGON.Get_Y() < 35)
           {
               POLYGON.Set_Y(35);
               POLYGON.Set_Y_Velocity(0.0);
           }
           else if(POLYGON.Get_Y() > getSize().height - 24)
           {  
               POLYGON.Set_Y(getSize().height - 24);
               POLYGON.Set_Y_Velocity(0.0);
           }
           else
           { POLYGON.Increase_Y(POLYGON.Get_Y_Velocity()); }    
    }
//-----------------------------------------------------------------------------
    //2. BOUNCE a POLYGON
    public void POLYGON_BOUNCE(PolyENTITY POLYGON) 
    {         
        if(POLYGON.Get_Active()) 
        { 
           //---Update POLYGON's X position, stop LEFT/RIGHT---
           if(POLYGON.Get_X() < 24)
           { 
               POLYGON.Set_X(24);
               POLYGON.Set_Face_Angle(90);
               POLYGON.Set_Move_Angle(0);
               POLYGON.Set_X_Velocity(1.0);
               POLYGON.Increase_X(POLYGON.Get_X_Velocity());
           }
           else if(POLYGON.Get_X() > getSize().width - 24)
           { 
               POLYGON.Set_X(getSize().width - 24);
               POLYGON.Set_Face_Angle(270);
               POLYGON.Set_Move_Angle(270);
               POLYGON.Set_X_Velocity(-1.0);
               POLYGON.Increase_X(POLYGON.Get_X_Velocity());
           }
           else
           { POLYGON.Increase_X(POLYGON.Get_X_Velocity()); } 
        
           
        //---Update POLYGON's Y position, stop LEFT/RIGHT---
           if(POLYGON.Get_Y() < 35)
           {
               POLYGON.Set_Y(35);
               POLYGON.Set_Face_Angle(180);
               POLYGON.Set_Move_Angle(90);
               POLYGON.Set_Y_Velocity(1.0);
               POLYGON.Increase_Y(POLYGON.Get_Y_Velocity());
           }
           else if(POLYGON.Get_Y() > getSize().height - 24)
           {  
               POLYGON.Set_Y(getSize().height - 24);
               POLYGON.Set_Face_Angle(0);
               POLYGON.Set_Move_Angle(-90);
               POLYGON.Set_Y_Velocity(-1.0);
               POLYGON.Increase_Y(POLYGON.Get_Y_Velocity());
           }
           else
           { POLYGON.Increase_Y(POLYGON.Get_Y_Velocity()); }            
        }   
    }
//------------------------------------------------------------------------------        
    //3. WRAP POLYGON around screen
    public void POLYGON_WRAP(PolyENTITY POLYGON) 
    {
           //Update POLYGON's X position, wrap left/right
           POLYGON.Increase_X(POLYGON.Get_X_Velocity());
        
           if(POLYGON.Get_X() < -10)
           {
                POLYGON.Set_X(getSize().width + 10);
           }
           else if(POLYGON.Get_X() > getSize().width + 10)
           {
                POLYGON.Set_X(-10);
           }
        
           //Update POLYGON's Y position, wrap top/bottom
           POLYGON.Increase_Y(POLYGON.Get_Y_Velocity());
        
           if(POLYGON.Get_Y() < 35)
           {
                POLYGON.Set_Y(getSize().height + 10);
           }
           else if(POLYGON.Get_Y() > getSize().height + 10)
           {
                POLYGON.Set_Y(35);
           }
    }
//------------------------------------------------------------------------------       
    //4. KILL POLYGON if leaving screen
    public void POLYGON_KILL(PolyENTITY POLYGON) 
    {
               //Check if PolyPROJECTILEs are ACTIVE
               if(POLYGON.Get_Active()) 
               {
                    //Update PolyPROJECTILE's X position
                    POLYGON.Increase_X(POLYGON.Get_X_Velocity());
                    
                    //Remove PolyPROJECTILEs if they go past left/right screen
                    if(POLYGON.Get_X() < 0 ||
                        POLYGON.Get_X() > getSize().width)
                    {
                          POLYGON.Set_Active(false);
                    }
                
                    //Update PolyPROJECTILE's y position
                    POLYGON.Increase_Y(POLYGON.Get_Y_Velocity());
                    
                    //Remove PolyPROJECTILEs if they go past up/down screen
                    if(POLYGON.Get_Y() < 0 ||
                    POLYGON.Get_Y() > getSize().height)
                    {
                        POLYGON.Set_Active(false);
                    }
                }
    }  
//------------------------------------------------------------------------------      
    public void Detect_Collisions() 
    {
        //---------------------------------------------------------------------
        //Check for PlayerPROJECTILE collisions with PolyENEMYs
           for(int CurrentEnemy = 0; CurrentEnemy<NumEnemies; CurrentEnemy++) 
           {
               if(POLYENEMIES[CurrentEnemy].Get_Active()) 
               {
                   //Check for PolyPROJECTILE collisions
                   for(int A = 0; A < NumPlayerProjectiles; A++) 
                   {
                       if(PLAYERPROJECTILES[A].Get_Active()) 
                       {
                           //Perform COLLISION test
                        if(POLYENEMIES[CurrentEnemy].Get_Collision_Geometry().contains(
                           PLAYERPROJECTILES[A].Get_X(), PLAYERPROJECTILES[A].Get_Y()))
                        {
                            SCORE += 75;
                            PLAYERPROJECTILES[A].SetBounced(false);
                            PLAYERPROJECTILES[A].Set_Active(false);
                            
                            if(CurrentEnemy == 0) { EnemyFire = false; }
                            POLYENEMIES[CurrentEnemy].Set_Active(false);

                            if(SOUNDEFFECTS) { EXPLOSION.play(); } 
                            continue;
                        }
                    }
                }
        //---------------------------------------------------------------------
                //Check for PolyPLAYER collision with PolyENEMY
                if(POLYENEMIES[CurrentEnemy].Get_Collision_Geometry().intersects(
                   POLYPLAYER.Get_Collision_Geometry())) 
                {
                     POLYENEMIES[CurrentEnemy].Set_Firing(false);
                     POLYENEMIES[CurrentEnemy].Set_Active(false);
                     if(SOUNDEFFECTS) { EXPLOSION.play(); }
                     POLYPLAYER.Set_X(ScreenWidth/2);
                     POLYPLAYER.Set_Y(ScreenHeight/2);
                     POLYPLAYER.Set_Face_Angle(0);
                     POLYPLAYER.Set_X_Velocity(0);
                     POLYPLAYER.Set_Y_Velocity(0);
                     CollisionCount++;
                     if(CollisionCount > (CollisionsAllowed - 1)) 
                     { GameOver(); }
                     continue;
                }         
            }
        }
        //---------------------------------------------------------------------        
                if(FriendlyFire)
                {
                   //Check for PlayerPROJECTILE collision with PLAYER
                   for(int B = 0; B < NumPlayerProjectiles; B++) 
                   {
                      if(PLAYERPROJECTILES[B].Get_Active()) 
                      {
                         if(POLYPLAYER.Get_Collision_Geometry().contains(
                            PLAYERPROJECTILES[B].Get_X(), PLAYERPROJECTILES[B].Get_Y()))
                          {   
                               if(PLAYERPROJECTILES[B].GetBounced())
                               {
                                  PLAYERPROJECTILES[B].SetBounced(false); 
                                  PLAYERPROJECTILES[B].Set_Active(false);
                                  POLYPLAYER.Set_X(ScreenWidth/2);
                                  POLYPLAYER.Set_Y(ScreenHeight/2);
                                  POLYPLAYER.Set_Face_Angle(0);
                                  POLYPLAYER.Set_X_Velocity(0);
                                  POLYPLAYER.Set_Y_Velocity(0);
                                  if(SOUNDEFFECTS) { EXPLOSION.play(); }
                                  CollisionCount++;
                                  if(CollisionCount > (CollisionsAllowed - 1)) 
                                  { GameOver(); }
                                  continue; 
                               } 
                          }
                      }
                   }               
                }
        //---------------------------------------------------------------------        
                if(EnemyFire)
                {
                   //Check for EnemyPROJECTILE collision with PLAYER
                   for(int C = 0; C < NumEnemyProjectiles; C++) 
                   {
                      if(ENEMYPROJECTILES[C].Get_Active()) 
                      {
                         if(POLYPLAYER.Get_Collision_Geometry().contains(
                            ENEMYPROJECTILES[C].Get_X(), ENEMYPROJECTILES[C].Get_Y()))
                          {   
                                  ENEMYPROJECTILES[C].SetBounced(false); 
                                  ENEMYPROJECTILES[C].Set_Active(false);
                                  POLYPLAYER.Set_X(ScreenWidth/2);
                                  POLYPLAYER.Set_Y(ScreenHeight/2);
                                  POLYPLAYER.Set_Face_Angle(0);
                                  POLYPLAYER.Set_X_Velocity(0);
                                  POLYPLAYER.Set_Y_Velocity(0);
                                  if(SOUNDEFFECTS) { EXPLOSION.play(); }
                                  CollisionCount++;
                                  if(CollisionCount > (CollisionsAllowed - 1)) 
                                  { GameOver(); }
                                  continue; 
                          }
                      }
                   }               
                }                 
        //---------------------------------------------------------------------         
    }
//------------------------------------------------------------------------------    
    //KeyListener events and event handlers    
    //Empty for now, but necessary (abstract) when implementing KeyListener
    public void keyReleased(KeyEvent k) { }
    public void keyTyped(KeyEvent k) { }
//------------------------------------------------------------------------------
    //The lone, single event handler for key presses at this point
    public void keyPressed(KeyEvent k) 
    {
           int COMMAND = k.getKeyCode();

           switch(COMMAND) 
           {
                case KeyEvent.VK_LEFT : //Rotate POLYPLAYER LEFT 5 degrees
                                        POLYPLAYER.Increase_Face_Angle(-5);
                                        
                                        if(POLYPLAYER.Get_Face_Angle() < 0)
                                        { 
                                           POLYPLAYER.Set_Face_Angle(360-5); 
                                        }
                                        break;

                case KeyEvent.VK_RIGHT : //Rotate POLYPLAYER RIGHT 5 degrees
                                         POLYPLAYER.Increase_Face_Angle(5);
                                         
                                         if(POLYPLAYER.Get_Face_Angle() > 360)
                                         {
                                             POLYPLAYER.Set_Face_Angle(5);
                                         }
                                         break;

                case KeyEvent.VK_UP : //Move or float forward
                                      POLYPLAYER.Set_Move_Angle(
                                      POLYPLAYER.Get_Face_Angle() - 90);
                                      
                                      if(MicroGravity)
                                      {
                                          POLYPLAYER.Increase_X_Velocity(
                                          Calculate_Move_Angle_X(
                                          POLYPLAYER.Get_Move_Angle()) * 0.1);
                                      
                                          POLYPLAYER.Increase_Y_Velocity(
                                          Calculate_Move_Angle_Y(
                                          POLYPLAYER.Get_Move_Angle()) * 0.1);
                                      }
                                      else
                                      {
                                          POLYPLAYER.Increase_X(
                                          Calculate_Move_Angle_X(
                                          POLYPLAYER.Get_Move_Angle()));
                                      
                                          POLYPLAYER.Increase_Y(
                                          Calculate_Move_Angle_Y(
                                          POLYPLAYER.Get_Move_Angle()));
                                      }
                                      break;
        
                case KeyEvent.VK_CONTROL : //CTRL or SPACE fires weapons
                case KeyEvent.VK_SPACE : CurrentPlayerProjectile++;
                
                                         //Reset NumPlayerProjectiles if MAX # exceeded
                                         if(CurrentPlayerProjectile > NumPlayerProjectiles - 1)
                                         { 
                                             CurrentPlayerProjectile = 0; 
                                         }
                                         
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].Set_Active(true);
                                         
                                         //Point PolyPROJECTILE in DIRECTION PolyPLAYER is facing
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].
                                         Set_X(POLYPLAYER.Get_X());
                                         
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].
                                         Set_Y(POLYPLAYER.Get_Y());
                                         
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].
                                         Set_Move_Angle(POLYPLAYER.Get_Face_Angle() - 90);
                                         
                                         //Point PolyPROJECTILE at ANGLE of PolyPLAYER
                                         double angle = 
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].Get_Move_Angle();
                                        
                                         double svx = POLYPLAYER.Get_X_Velocity();
                                         double svy = POLYPLAYER.Get_Y_Velocity();
                                        
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].
                                         Set_X_Velocity(svx + Calculate_Move_Angle_X(angle) * 2);
                                        
                                         PLAYERPROJECTILES[CurrentPlayerProjectile].
                                         Set_Y_Velocity(svy + Calculate_Move_Angle_Y(angle) * 2);

                                         if(SOUNDEFFECTS) { FIRE.play(); }
                                         break;

                case KeyEvent.VK_B : //Show Collision Gemoetry
                                     ShowCollisionGeometry = !ShowCollisionGeometry;
                                     break;
                    
               case KeyEvent.VK_P:   PAUSED = !PAUSED;
                                     break;  
               case KeyEvent.VK_Q:   GameOver();
                                     break; 
               case KeyEvent.VK_N:   NewGame();
                                     break; 
               case KeyEvent.VK_M:   Menu();
                                     break;    
        }
    }
//------------------------------------------------------------------------------ 
    //Calculate X movement value based on direction angle
    public double Calculate_Move_Angle_X(double angle) 
    {
        return (double) (Math.cos(angle * Math.PI / 180));
    }
//------------------------------------------------------------------------------ 
    //Calculate Y movement value based on direction angle
    public double Calculate_Move_Angle_Y(double angle) 
    {
        return (double) (Math.sin(angle * Math.PI / 180));
    }
//------------------------------------------------------------------------------
}
