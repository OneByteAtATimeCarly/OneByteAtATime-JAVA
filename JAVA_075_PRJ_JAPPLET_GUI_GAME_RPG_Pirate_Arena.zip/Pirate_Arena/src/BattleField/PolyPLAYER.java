//PLAYER Polygon
package BattleField;
import java.awt.Polygon;
import java.awt.Rectangle;

public class PolyPLAYER extends PolyENTITY 
{    
//-----------------------------------------------------------------------------    
       //Constructor
       PolyPLAYER() 
       {
            Set_Shape(new Polygon(PLAYER_X, PLAYER_Y, PLAYER_X.length));
            Set_Collision_Geometry(12);
            Set_Active(true); 
       }
//-----------------------------------------------------------------------------         
       //Private Data (Global)
       //Define X and Y Points for PLAYER Polygon in Parallel Arrays (TRIANGLE)
       private int[] PLAYER_X = { -6, -3, 0, 3, 6, 0 };
       private int[] PLAYER_Y = { 6, 7, 7, 7, 6, -7 };
}

