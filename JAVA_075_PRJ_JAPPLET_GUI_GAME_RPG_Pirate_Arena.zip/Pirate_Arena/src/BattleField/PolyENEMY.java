//ENEMY Polygon
package BattleField;
import java.awt.Polygon;
import java.awt.Rectangle;

public class PolyENEMY extends PolyENTITY
{
//-----------------------------------------------------------------------------    
      //Constructor
      public PolyENEMY() 
      {
             Set_Shape(new Polygon(ENEMY_X, ENEMY_Y, ENEMY_X.length));
             Set_Collision_Geometry(40);
             Set_Active(true);
             Set_Rotation_Velocity(0.0);   
      }
//-----------------------------------------------------------------------------
    //Private Data (Globals)
    //Define X and Y Points for ENEMY Polygon in Parallel Arrays (OCTAGON)
    //OCTAGON (Subtact to 0 then X = -20 and Y = -10)
    private int[] ENEMY_X = {-10,  5, 15, 15,  5, -10, -20, -20};
    private int[] ENEMY_Y = {-10,-10,  0, 15, 25,  25,  15,   0};
        
}    

