package Characters;
import Interface.*;

//Child of AI, grandchild of FIGHTER

public class DESTROYER extends AI 
{
       public DESTROYER()
       {
              INTERFACE.TA_Output.append("\n Creating a DESTROYER object!");
              SetCharClass("DESTROYER");
              SetSpcAtk("Beam Cannon");
              SetSpcDef("EMP Shield");
       }
}
