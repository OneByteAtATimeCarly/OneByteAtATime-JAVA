package Characters;
import Interface.*;

public class AI extends FIGHTER
{
//-----------------------------------------------------------------------------    

       //Constructor    
       public AI()
       {
              INTERFACE.TA_Output.append("\n Creating an AI object."); 
       }
 
//-----------------------------------------------------------------------------
             
       //Member methods
       public void Upload()
       {
              INTERFACE.TA_Output.append(
              "\n AI Uploading! Transferring consciousness to new body.");
       }        
               
//-----------------------------------------------------------------------------       
       
       public void Duplicate()
       {
              INTERFACE.TA_Output.append(
              "\n AI duplicating itself.");
       }        
       
//-----------------------------------------------------------------------------       
       //Public Accesor Methods
       public int SetEmp() { return EMPSHIELDING; }
       public void GetEmp(int x) { EMPSHIELDING = x; }
       public String GetInterface() { return AI_INTERFACE; }
       public void SetInterface(String x) { AI_INTERFACE = x; }
       public boolean GetNano() { return NANO; }
       public void SetNano(boolean x) { NANO = x; }
       public boolean GetHeat() { return HEAT; }
       public void SetHeat(boolean x) { HEAT = x; }   
       public boolean GetGamma() { return GAMMA; }
       public void SetGamma(boolean x) { GAMMA = x; }       

//-----------------------------------------------------------------------------              
       
       //Private Data
       private int EMPSHIELDING = 10;
       private String AI_INTERFACE = "Generic";
       private boolean NANO = false;
       private boolean HEAT = false;
       private boolean GAMMA = false;
       
}