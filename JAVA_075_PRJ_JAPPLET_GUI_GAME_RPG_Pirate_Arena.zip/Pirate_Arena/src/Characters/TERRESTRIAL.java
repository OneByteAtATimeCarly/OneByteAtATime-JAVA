package Characters;
import Interface.*;

//Child of Fighter

public class TERRESTRIAL extends FIGHTER
{
    
//---------------------------------------------------------------------------       

       public TERRESTRIAL()
       {
              INTERFACE.TA_Output.append("\n Creating a Terrestrial object!");       
       }
       
//---------------------------------------------------------------------------       
       //Member methods
       public void BERSERK()
       {
              INTERFACE.TA_Output.append("\n Terrestrial entering BERSERK mode!" +
                               "\n Adrenaline is pumping...\n");     
       }
       
//---------------------------------------------------------------------------       
       
       public void FlightorFight()
       {
              INTERFACE.TA_Output.append("\n Initiating Fight or Flight response!\n");     
       }
       
//---------------------------------------------------------------------------       
   
       //Public Accesors
       public int GetEmpWeapon() { return EmpWeapon; }
       public void SetEmpWeapon(int x) { EmpWeapon = x; }
       public boolean GetHeatShield() { return HeatShield; }
       public void SetHeatShield(boolean x) { HeatShield = x; }
       public boolean GetGammaShield() { return GammaShield; }
       public void SetGammaShield(boolean x) { GammaShield = x; }
       
//---------------------------------------------------------------------------       
       
       //Private data
       private int EmpWeapon = 1;
       private boolean HeatShield = false;
       private boolean GammaShield = false;
       
}
