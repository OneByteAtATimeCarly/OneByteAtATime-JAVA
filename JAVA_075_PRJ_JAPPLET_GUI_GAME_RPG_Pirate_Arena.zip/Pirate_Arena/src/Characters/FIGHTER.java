//ADT - (Abstract Data Type) Superclass and Base class for all Fighter objects
package Characters;
import Interface.*;
import GameFunctions.*;
import java.util.Random;
import javax.swing.*;

public class FIGHTER 
{
       //Globals
       public boolean AttackWindow = false;
       public int Damage = 0;
    
//---------------------------------------------------------------------------
       
       //Constructor = always has same name as class, executes automatically
       public FIGHTER()
       {
              INTERFACE.TA_Output.append("\n Creating a Fighter object.");
       }
       
 //---------------------------------------------------------------------------
 
       public void Luck()
       {
              int LUCKY = GameFunctions.IMPROBABILITY.nextInt(2) + 1;
              if(LUCKY == 1)
              { AttackWindow = true; }
              GameFunctions.WAIT(1);
              AttackWindow = false;
       }       
       
//---------------------------------------------------------------------------       
       //Member methods (Things a Fighter does) 
       public void Attack(FIGHTER OPPONENT)
       {
              DisplayStats();
              OPPONENT.DisplayStats();
              
              Damage = 0;
              int AdditionalDamage = 0;
              int CHANCE = 0;
              int ATTACKER_LUCK = 0;
              int ATTACKEE_LUCK = 0;
              String CHOICE = " ";        
           
              INTERFACE.TA_Output.setText(
              "\n ------------------------------------------");
              INTERFACE.TA_Output.append(
              "\n " + FNAME + " attacks " + OPPONENT.GetName() + "!");
              INTERFACE.TA_Output.append(
              "\n " + FNAME + " Health=" + HEALTH + "\n " +
              OPPONENT.GetName() + " Health=" + OPPONENT.GetHealth());
              
              Random RN = new Random();
              Damage = RN.nextInt(MaxDamage) + 1;
              
              INTERFACE.TA_Output.append(
              "\n\n " + FNAME + " does " + Damage + " points of raw\n damage.");
              if(IsPlayer) { Luck(); }
              GameFunctions.WAIT(3);
                
      //SPEED Coefficients------------------------------------------------------
              CHANCE = RN.nextInt(10) + 1;
              ATTACKER_LUCK = RN.nextInt(20) + 1;
              ATTACKEE_LUCK = RN.nextInt(20) + 1;
              
              if(CHANCE < 6)
              {
                   INTERFACE.TA_Output.setText(
                   "\n\n Fate favors the SWIFT in this attack!" +
                   "\n Possible extra attack for\n greater speed!");
                  
                   if( (SPEED + ATTACKER_LUCK) > (OPPONENT.GetSpeed() + ATTACKEE_LUCK) ) 
                   { 
                       INTERFACE.TA_Output.append(
                       "\n\n Due to " + FNAME + "'s greater speed, " +
                       "\n an additional attack is employed\n against" +
                       " " + OPPONENT.GetName());
                       
                       AdditionalDamage = RN.nextInt(MaxDamage) + 1;
                       
                       INTERFACE.TA_Output.append(
                       " doing " + AdditionalDamage + 
                       " pts. \n of additional damage!");
                       
                       Damage = Damage + AdditionalDamage;
                   }
                   else
                   {
                       INTERFACE.TA_Output.append(
                       "\n\n " + FNAME + "'s luck and speed were" +
                       "\n not enough to permit an extra" +
                       "\n attack.\n");
                   }
                   
                   if(IsPlayer) { Luck(); }
                   GameFunctions.WAIT(4);
              }
              
      //STRENGTH Coefficients---------------------------------------------------
              
              CHANCE = RN.nextInt(10) + 1;
              
              if(CHANCE > 5)
              {
                 INTERFACE.TA_Output.setText(
                 "\n\n CHANCE favors additional damage for" + 
                 "\n the strong!");
                  
                 if(STRENGTH > OPPONENT.GetStrength())
                 {
                     AdditionalDamage = ( STRENGTH - OPPONENT.GetStrength() ) * 2;
                     INTERFACE.TA_Output.append(
                     "\n\n Due to greater strength, " + FNAME 
                     + "'s opponent\n suffers " +
                     AdditionalDamage + " points more damage!");
                     
                     Damage = Damage + AdditionalDamage;
                 }
                 else
                 {
                    INTERFACE.TA_Output.append(
                    "\n\n " + FNAME + " does not possess a " + "\n strength " +
                    "advantage over " + OPPONENT.GetName() + ".");
                 }
                 
                 if(IsPlayer) { Luck(); }
                 GameFunctions.WAIT(3);
              }
      //ATK Coefficients--------------------------------------------------------             
              
              INTERFACE.TA_Output.setText(
              "\n\n " + FNAME + "'s ATK capability adds " + ATK +
              "\n points of damage!");
              Damage = Damage + ATK;
              
              if(IsPlayer) { Luck(); }
              GameFunctions.WAIT(2);
              
      //DEF Coefficients--------------------------------------------------------             
              if(Damage - OPPONENT.GetDefense() > 0)
              {
                   INTERFACE.TA_Output.setText(
                   "\n\n " + OPPONENT.GetName() + "'s DEF capability absorbs " + 
                   OPPONENT.GetDefense() + "\n points of damage!");
                   Damage = Damage - OPPONENT.GetDefense();
              }
              else
              {
                   INTERFACE.TA_Output.setText(
                   "\n\n " + OPPONENT.GetName() + "'s DEF capability absorbs " +
                   "\n ALL of " + FNAME + "'s damage!"); 
                   Damage = 0;
              }
              
              if(IsPlayer) { Luck(); }
              GameFunctions.WAIT(2);

    //Special Attack----------------------------------------------------------         
  /*    
      if(ENERGY > 0)
      {
         if(PlayerObject)
         {  //Validate response
            while(CHOICE.charAt(0) != 'n' && CHOICE.charAt(0) != 'y')
            {
               INTERFACE.TA_Output.append(
               "\n Do you want to employ a special attack? ");
            
               CHOICE = JOptionPane.showInputDialog(null, "Special Attack?");
               if(CHOICE.isEmpty()) { CHOICE="Empty"; }
               CHOICE = CHOICE.toLowerCase();
            
               switch(CHOICE.charAt(0))
               {
                  case 'y' : Damage = Damage + SpecialAttack(); break;
                  case 'n' : INTERFACE.TA_Output.append(
                             "\n You decide NOT to use spc atk.");
                  default  : INTERFACE.TA_Output.append(
                             "\n Not an option..."); break;
               }
            }
         }
         else
         {
            CHANCE = RN.nextInt(10) + 1;
            if(CHANCE > 5) { Damage = Damage + SpecialAttack(); }
            //WAIT(2);
         }
      }
      
      //Special Defense----------------------------------------------------------         
      if(ENERGY > 0)
      {
         if(PlayerObject)
         {  //Validate response
            while(CHOICE.charAt(0) != 'n' && CHOICE.charAt(0) != 'y')
            {
               INTERFACE.TA_Output.append(
               "\n Do you want to employ a special defense? ");
            
               CHOICE = JOptionPane.showInputDialog(null, "Special Defense?");
               if(CHOICE.isEmpty()) { CHOICE="Empty"; }
               CHOICE = CHOICE.toLowerCase();
            
               switch(CHOICE.charAt(0))
               {
                  case 'y' : Damage = Damage - SpecialDefense(); break;
                  case 'n' : INTERFACE.TA_Output.append(
                             "\n You decide NOT to use spc def.");
                  default  : INTERFACE.TA_Output.append(
                             "\n Not an option..."); break;
               }
            }
         }
         else
         {
            CHANCE = RN.nextInt(10) + 1;
            if(CHANCE > 5) { Damage = Damage - SpecialDefense(); }
            //WAIT(2);
         }
      }                     
 */    
      //Weapons?        
      if(IsPlayer) { Damage = Damage + UseWeapons(); }
      if(IsPlayer) { Luck(); }
      GameFunctions.WAIT(2);
              
      //RAW Health Coefficient--------------------------------------------------          
              
              if( (OPPONENT.GetHealth() - Damage) > 0 )
              { 
                  INTERFACE.TA_Output.append(
                  "\n\n " + FNAME + " dealt a total of" +
                  "\n " + Damage + " points of damage" +
                  "\n to " + OPPONENT.GetName() + " this round!");
                  
                  OPPONENT.SetHealth(OPPONENT.GetHealth() - Damage); 
              }
              else 
              { 
                  INTERFACE.TA_Output.append(
                  "\n\n " + FNAME + " annhiliated" +
                  "\n " + OPPONENT.GetName() + "!");
                  
                  OPPONENT.SetHealth(0); 
              }  
              
              OPPONENT.DisplayStats();
              
              GameFunctions.WAIT(2);
       }
 
//---------------------------------------------------------------------------              
       
       public int UseWeapons()
       {    
               //JackKnife
               if(INTERFACE.RB_Weapon1.isSelected())
               {
                   INTERFACE.TA_Output.setText(
                   "\n " + FNAME +
                   "\n stabs with the JackKnife!" +
                   "\n Adding 2 points of weapon damage.");
                   INTERFACE.SE_JackKnife.play();
                   return 2;
               }
               
               //Sword
               else if(INTERFACE.RB_Weapon2.isSelected())
               {
                    INTERFACE.TA_Output.setText(
                    "\n " + FNAME +
                    "\n slashes with the Sword!" +
                    "\n Adding 4 points of weapon damage.");
                    INTERFACE.SE_Sword.play();
                    return 4;
               }
               
               //Glock
               else if(INTERFACE.RB_Weapon3.isSelected())
               {
                    if(GlockAmmo > 0)
                    {
                       INTERFACE.TA_Output.setText(
                       "\n " + FNAME +
                       "\n fires the Glock!" +
                        "\n Adding 6 points of weapon damage.");
                        GlockAmmo = GlockAmmo - 1;
                        DisplayInventory();
                        INTERFACE.SE_Gun.play();
                        return 6;
                    }
                    else
                    {
                        INTERFACE.TA_Output.setText(
                       "\n " + FNAME + " out of AMMO!");
                        return 0;
                    }
                    
               }
               
               //Grenade
               else if (INTERFACE.RB_Weapon4.isSelected())
               {
                    if(Grenades > 0)
                    {
                       INTERFACE.TA_Output.setText(
                       "\n " + FNAME +
                       "\n tosses a grenade!" +
                       "\n Adding 8 points of weapon damage.");
                       Grenades = Grenades - 1;
                       DisplayInventory();
                       INTERFACE.SE_Grenade.play();
                       return 8;
                    }
                    else
                    {
                       INTERFACE.TA_Output.setText(
                       "\n " + FNAME + " out of Grenades!");
                        return 0; 
                    }
                    
               }
               
               else
               {
                   INTERFACE.TA_Output.setText(
                    "\n " + FNAME +
                    "\n chooses hand to hand combat!" +
                    "\n Adding 0 points of weapon damage.");
                   INTERFACE.SE_HandToHand.play();
                   return 0;
               }
               
       }
       
//---------------------------------------------------------------------------       
       public int SpecialAttack()
       {
              INTERFACE.TA_Output.append("\n  Special Attack!");
              
              int PointCost = 0;
              
              if(SPECATK.equals("Beam Cannon")) { PointCost = 20; }
              if(SPECATK.equals("EMP Wave")) { PointCost = 15; }
              if(SPECATK.equals("Telekinesis")) { PointCost = 25; }
              if(SPECATK.equals("ShapeShift")) { PointCost = 30; }
              
              if(ENERGY - PointCost >= 0)
              {
                  if(SPECATK.equals("Beam Cannon")) 
                  { 
                     INTERFACE.TA_Output.append(
                     "\n Using special DESTROYER ATK -\n Beam cannon!");
                     INTERFACE.TA_Output.append(
                     "\n Additional 20 pts. of damage!");
                     ENERGY = ENERGY - 20;
                     return 20;
                  }
              
                  else if(SPECATK.equals("EMP Wave")) 
                  { 
                      INTERFACE.TA_Output.append(
                      "\n Using special GENMOD ATK -\n EMP Wave!");
                      INTERFACE.TA_Output.append(
                      "\n Additional 15 pts. of damage!");
                      ENERGY = ENERGY - 15;
                      return 15;
                  }
              
                  else if(SPECATK.equals("Telekinesis")) 
                  { 
                     INTERFACE.TA_Output.append(
                     "\n Using special PSY ATK -\n Telekinesis!");
                     INTERFACE.TA_Output.append(
                     "\n Additional 25 pts. of damage!");
                     ENERGY = ENERGY - 25;
                     return 25;
                  } 
              
                  else if(SPECATK.equals("ShapeShift")) 
                  { 
                     INTERFACE.TA_Output.append(
                     "\n Using special SHAPESHIFTER ATK -\n ShapeShift!");
                     INTERFACE.TA_Output.append(
                     "\n Additional 30 pts. of damage!");
                     ENERGY = ENERGY - 30;
                     return 30;
                  }
                  
              }//closes outer PointCost if

              else 
              { 
                  INTERFACE.TA_Output.append(
                  "\n " + FNAME + " does not possess enough" +
                  "\n energy for a special attack."); 
              }
              
              return 0;
       }
       
//--------------------------------------------------------------------------- 
       
       public int SpecialDefense()
       {
              INTERFACE.TA_Output.append("\n Special Defense!");
              
              int PointCost = 0;
              
              if(SPECATK.equals("EMP Shield")) { PointCost = 20; }
              if(SPECATK.equals("Heat Shield")) { PointCost = 15; }
              if(SPECATK.equals("BioField")) { PointCost = 25; }
              if(SPECATK.equals("NanoRegeneration")) { PointCost = 30; }
              
              if(ENERGY - PointCost >= 0)
              {
                  if(SPECATK.equals("EMP Shield")) 
                  { 
                     INTERFACE.TA_Output.append(
                     "\n Using special DESTROYER DEF -\n EMP Shield!");
                     INTERFACE.TA_Output.append(
                     "\n Absorbs 20 pts. of damage!\n");
                     ENERGY = ENERGY - 20;
                     return 20;
                  }
              
                  else if(SPECATK.equals("Heat Shield")) 
                  { 
                      INTERFACE.TA_Output.append(
                      "\n Using special GENMOD DEF \n Heat Shield!");
                      INTERFACE.TA_Output.append(
                      "\n Absorbs 15 pts. of damage!");
                      ENERGY = ENERGY - 15;
                      return 15;
                  }
              
                  else if(SPECATK.equals("BioField")) 
                  { 
                     INTERFACE.TA_Output.append(
                     "\n Using special PSY DEF -\n" + " BioField!");
                     INTERFACE.TA_Output.append(
                     "\n Absorbs 25 pts. of damage!");
                     ENERGY = ENERGY - 25;
                     return 25;
                  } 
              
                  else if(SPECATK.equals("NanoRegeneration")) 
                  { 
                     INTERFACE.TA_Output.append(
                     "\n Using special SHAPESHIFTER DEF -\n " + 
                     "NanoRegeneration!");
                     INTERFACE.TA_Output.append(
                     "\n Absorbs 30 pts. of damage!");
                     ENERGY = ENERGY - 30;
                     return 30;
                  }
                  
              }//closes outer PointCost if

              else 
              { 
                  INTERFACE.TA_Output.append(
                  "\n " + FNAME + " does not possess enough" +
                  "\n energy for a special defense.\n"); 
              }
              
              return 0;
       }       

//---------------------------------------------------------------------------        

       public void DisplayStats()
       {
              if(IsPlayer) 
              { DisplayPlayerStats(); }
              else if(IsFriend) 
              { DisplayFriendStats(); } 
              else 
              { DisplayOpponentStats(); }
       }
 
//---------------------------------------------------------------------------       

       public void DisplayFriendStats()
       {
              FriendFrame.L_PlayerNameBox.setText(FNAME);
              FriendFrame.L_GenderBox.setText(GENDER);
              FriendFrame.L_ClassBox.setText(CHARCLASS);
              FriendFrame.L_SpcAtkBox.setText(SPECATK);
              FriendFrame.L_SpcDefBox.setText(SPECDEF); 
              FriendFrame.L_HealthBox.setText(Integer.toString(HEALTH));
              FriendFrame.L_SpeedBox.setText(Integer.toString(SPEED));
              FriendFrame.L_StrengthBox.setText(Integer.toString(STRENGTH));
              FriendFrame.L_SizeBox.setText(Integer.toString(SIZE));
              FriendFrame.L_SizeBox.setText(Integer.toString(SIZE));
              FriendFrame.L_WeightBox.setText(Integer.toString(WEIGHT));
              FriendFrame.L_AtkBox.setText(Integer.toString(ATK));
              FriendFrame.L_DefBox.setText(Integer.toString(DEF));
              FriendFrame.L_EnergyBox.setText(Integer.toString(ENERGY));
              FriendFrame.L_MaxDamageBox.setText(Integer.toString(MaxDamage));                      
       }  
       
//---------------------------------------------------------------------------       

       public void DisplayOpponentStats()
       {
              OpponentFrame.L_PlayerNameBox.setText(FNAME);
              OpponentFrame.L_GenderBox.setText(GENDER);
              OpponentFrame.L_ClassBox.setText(CHARCLASS);
              OpponentFrame.L_SpcAtkBox.setText(SPECATK);
              OpponentFrame.L_SpcDefBox.setText(SPECDEF); 
              OpponentFrame.L_HealthBox.setText(Integer.toString(HEALTH));
              OpponentFrame.L_SpeedBox.setText(Integer.toString(SPEED));
              OpponentFrame.L_StrengthBox.setText(Integer.toString(STRENGTH));
              OpponentFrame.L_SizeBox.setText(Integer.toString(SIZE));
              OpponentFrame.L_SizeBox.setText(Integer.toString(SIZE));
              OpponentFrame.L_WeightBox.setText(Integer.toString(WEIGHT));
              OpponentFrame.L_AtkBox.setText(Integer.toString(ATK));
              OpponentFrame.L_DefBox.setText(Integer.toString(DEF));
              OpponentFrame.L_EnergyBox.setText(Integer.toString(ENERGY));
              OpponentFrame.L_MaxDamageBox.setText(Integer.toString(MaxDamage));                      
       }       
       
//---------------------------------------------------------------------------       

       public void DisplayPlayerStats()
       {       
              INTERFACE.L_PlayerNameBox.setText(FNAME);
              INTERFACE.L_GenderBox.setText(GENDER);
              INTERFACE.L_ClassBox.setText(CHARCLASS);
              INTERFACE.L_SpcAtkBox.setText(SPECATK);
              INTERFACE.L_SpcDefBox.setText(SPECDEF); 
              INTERFACE.L_HealthBox.setText(Integer.toString(HEALTH));
              INTERFACE.L_SpeedBox.setText(Integer.toString(SPEED));
              INTERFACE.L_StrengthBox.setText(Integer.toString(STRENGTH));
              INTERFACE.L_SizeBox.setText(Integer.toString(SIZE));
              INTERFACE.L_SizeBox.setText(Integer.toString(SIZE));
              INTERFACE.L_WeightBox.setText(Integer.toString(WEIGHT));
              INTERFACE.L_AtkBox.setText(Integer.toString(ATK));
              INTERFACE.L_DefBox.setText(Integer.toString(DEF));
              INTERFACE.L_EnergyBox.setText(Integer.toString(ENERGY));
              INTERFACE.L_MaxDamageBox.setText(Integer.toString(MaxDamage));
              INTERFACE.PB_HealthBar.setValue(HEALTH);
              INTERFACE.L_LevelBox.setText(Integer.toString(LEVEL));
              
              DisplayInventory();
              DisplayAbilities();
       }
       
//---------------------------------------------------------------------------         

       public void DisplayInventory()
       {                       //0    1   2   3   4   5  6   7   8   9  10  11  12
          String[] INVENTORY = {" "," "," "," "," "," "," "," "," "," "," "," "," "};

          int x = 0;

          if(!Key1 && !Key2 && !Key3 && !Key4 &&
             !JackKnife && !Sword && !Glock && (GlockAmmo < 1)
             && !Armor && (MedKits < 1)    )
          {
             INVENTORY[x] = "No Items Yet!";
          }
          else
          {
             if(Key1)
             {   INVENTORY[x] = (x+1) + ". Key1"; x++; }
             
             if(Key2)
             {   INVENTORY[x] = (x+1) + ". Key2"; x++; }
             
             if(Key3)
             {   INVENTORY[x] = (x+1) + ". Key3"; x++; }
             
             if(Key4)
             {   INVENTORY[x] = (x+1) + ". Key4"; x++; }
           
             if(JackKnife)
             {   INVENTORY[x] = (x+1) + ". Jack Knife"; x++; }

             if(Sword)
             {   INVENTORY[x] = (x+1) + ". Sword"; x++; }

             if(Glock)
             {   INVENTORY[x] = (x+1) + ". Glock"; x++; }

             if(GlockAmmo > 0)
             {   INVENTORY[x] = (x+1) + ". G Ammo: " + GlockAmmo; x++; }
             
             if(Grenades > 0)
             {   INVENTORY[x] = (x+1) + ". Grenades: " + Grenades; x++; }
             
             if(Armor)
             {   INVENTORY[x] = (x+1) + ". Armor"; x++; }
             
             if(MedKits > 0)
             {   INVENTORY[x] = (x+1) + ". MedKits: " + MedKits; x++; }
     
          }
       
          INTERFACE.LB_Inventory.setListData(INVENTORY);
          INTERFACE.L_AmmoBox.setText(Integer.toString(GlockAmmo));
          INTERFACE.L_MoneyBox.setText(Integer.toString(Money));
       }

//---------------------------------------------------------------------------       

    public void DisplayAbilities()
    {
       int x = 0;

       INTERFACE.CB_Abilities.removeAllItems();

       if(!Key1 && !JackKnife && !Sword && !Glock && (GlockAmmo < 1))
       {
           INTERFACE.CB_Abilities.addItem("No Abilities");
       }
       else
       {
          INTERFACE.CB_Abilities.addItem("Abilities");

          if(Upload)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". Upload"); x++; }

          if(Duplicate)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". Duplicate"); x++; }

          if(BeamCannon)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". BeamCannon"); x++; }
          
          if(EmpShield)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". EmpShield"); x++; }

          if(EmpWave)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". EmpWave"); x++; }

          if(HeatShield)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". HeatShield"); x++; } 
          
          if(Telekinesis)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". Telekinesis"); x++; }

          if(BioField)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". BioField"); x++; }

          if(NanoRegenerate)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". NanoRegenerate"); x++; } 
          
          if(ShapeShift)
          { INTERFACE.CB_Abilities.addItem((x+1) + ". ShapeShift"); x++; }
      }
          INTERFACE.L_EnergyBox.setText(Integer.toString(ENERGY));
    }       

//---------------------------------------------------------------------------       

     public void CHEAT()
     {
            //Attributes
            HEALTH = 10000;
            SPEED = 50;
            STRENGTH = 50;
            ENERGY = 9000;
            ATK = 25;
            DEF = 25;
         
            //Inventory
            Key1 = true;
            Key2 = true;
            Key3 = true;
            Key4 = true;
            JackKnife = true;
            Sword = true;
            Glock = true;
            GlockAmmo = 5000;
            Grenades = 1000;
            Armor = true;
            MedKits = 100;
            Money = 9999;
            LEVEL = 10;
            
            //Abilities
            Upload = true;
            Duplicate = true;
            BeamCannon = true;
            EmpShield = true;
            EmpWave = true;
            HeatShield = true;
            Telekinesis = true;
            BioField = true;
            NanoRegenerate = true;
            ShapeShift = true;  
           
            DisplayStats();
            INTERFACE.RB_Weapon1.setText("JackKnife"); 
            INTERFACE.RB_Weapon1.setEnabled(true);
            INTERFACE.RB_Weapon2.setText("Sword"); 
            INTERFACE.RB_Weapon2.setEnabled(true);
            INTERFACE.RB_Weapon3.setText("Glock"); 
            INTERFACE.RB_Weapon3.setEnabled(true);
            INTERFACE.RB_Weapon4.setText("Grenade"); 
            INTERFACE.RB_Weapon4.setEnabled(true);
     }
       
//---------------------------------------------------------------------------       
       
       public void Defense()
       {
              INTERFACE.TA_Output.append("\n Fighter defending!");
       }
       
//---------------------------------------------------------------------------
       
       public void Taunt()
       {
              INTERFACE.TA_Output.append("\n Fighter taunting!");
       }       

//---------------------------------------------------------------------------       
       
       public static void WAIT(int SECONDS)
       {
              try { Thread.sleep(SECONDS * 1000); }
              catch(InterruptedException X) { }  
       }     
       
//---------------------------------------------------------------------------       
       
     //---Public Accessor Methods = GET and SET---------
       public int GetHealth() { return HEALTH; }
       public void SetHealth(int x) { HEALTH = x; }
       public int GetSpeed() { return SPEED; }
       public void SetSpeed(int x) { SPEED = x; }       
       public int GetStrength() { return STRENGTH; }
       public void SetStrength(int x) { STRENGTH = x; }
       public int GetAttack() { return ATK; }
       public void SetAttack(int x) { ATK = x; }
       public int GetDefense() { return DEF; }
       public void SetDefense(int x) { DEF = x; }   
       public int GetSize() { return SIZE; }
       public void SetSize(int x) { SIZE = x; }
       public int GetWeight() { return WEIGHT; }
       public void SetWeight(int x) { WEIGHT = x; }
       public int GetMaxDamage() { return MaxDamage; }
       public void SetMaxDamage(int x) { MaxDamage = x; }
       public int GetMoney() { return Money; }
       public void SetMoney(int X) { Money = X; }
       public int GetLevel() { return LEVEL; }
       public void SetLevel(int x) { LEVEL = x; }
       public int GetEnergy() { return ENERGY; }
       public void SetEnergy(int x) { ENERGY = x; }        
       public String GetName() { return FNAME; }
       public void SetName(String x) { FNAME = x; }
       public String GetGender() { return GENDER; }
       public void SetGender(String x) { GENDER = x; }
       public String GetCharClass() { return CHARCLASS; }
       public void SetCharClass(String x) { CHARCLASS = x; }       
       public String GetSpcAtk() { return SPECATK; }
       public void SetSpcAtk(String x) { SPECATK = x; }       
       public String GetSpcDef() { return SPECDEF; }
       public void SetSpcDef(String x) { SPECDEF = x; }
       public String GetFighterImage() { return FIGHTERIMAGE; }
       public void SetFighterImage(String x) { FIGHTERIMAGE = x; }
       public boolean GetIsPlayer() { return IsPlayer; }
       public void SetIsPlayer(boolean X) { IsPlayer = X; }
       public boolean GetIsFriend() { return IsFriend; }
       public void SetIsFriend(boolean X) { IsFriend = X; }
       public boolean GetIsEnemy() { return IsEnemy; }
       public void SetIsEnemy(boolean X) { IsEnemy = X; }
  
    //---Public Inventory Accessor Methods---------   
       public boolean GetKey1() { return Key1; }
       public void SetKey1(boolean X) { Key1 = X; }
       public boolean GetKey2() { return Key2; }
       public void SetKey2(boolean X) { Key2 = X; }
       public boolean GetKey3() { return Key3; }
       public void SetKey3(boolean X) { Key3 = X; }
       public boolean GetKey4() { return Key4; }
       public void SetKey4(boolean X) { Key4 = X; }     
       public boolean GetJackKnife() { return JackKnife; }
       public void SetJackKnife(boolean X) { JackKnife = X; }
       public boolean GetSword() { return Sword; }
       public void SetSword(boolean X) { Sword = X; }
       public boolean GetGlock() { return Glock; }
       public void SetGlock(boolean X) { Glock = X; }
       public int GetAmmo() { return GlockAmmo; }
       public void SetAmmo(int X) { GlockAmmo = X; } 
       public int GetGrenades() { return Grenades; }
       public void SetGrenades(int X) { Grenades = X; }
       public boolean GetArmor() { return Armor; }
       public void SetArmor(boolean X) { Armor = X; }
       public int GetMedKits() { return MedKits; }
       public void SetMedKits(int X) { MedKits = X; }
       
    //---Public Ability Accessor Methods---------   
       public boolean GetUpload() { return Upload; }
       public void SetUpload(boolean X) { Upload = X; }
       public boolean GetDuplicate() { return Duplicate; }
       public void SetDuplicate(boolean X) { Duplicate = X; }
       public boolean GetBeamCannon() { return BeamCannon; }
       public void SetBeamCannon(boolean X) { BeamCannon = X; }
       public boolean GetEmpShield() { return EmpShield; }
       public void SetEmpShield(boolean X) { EmpShield = X; }
       public boolean GetEmpWave() { return EmpWave; }
       public void SetEmpWave(boolean X) { EmpWave = X; }
       public boolean GetHeatShield() { return HeatShield; }
       public void SetHeatShield(boolean X) { HeatShield = X; }
       public boolean GetTelekinesis() { return Telekinesis; }
       public void SetTelekinesis(boolean X) { Telekinesis = X; }
       public boolean GetBioField() { return BioField; }
       public void SetBioField(boolean X) { BioField = X; }
       public boolean GetNanoRegenerate() { return NanoRegenerate; }
       public void SetNanoRegenerate(boolean X) { NanoRegenerate = X; }
       public boolean GetShapeShift() { return ShapeShift; }
       public void SetShapeShift(boolean X) { ShapeShift = X; }

//---------------------------------------------------------------------------       
       
    //----Private Data Members (Attributes)-------
       private String CHARCLASS = "GENERIC";
       private String FNAME = "Anonymous";
       private String GENDER = "Androgenous";
       private String SPECATK = "NONE";
       private String SPECDEF = "NONE";
       private String FIGHTERIMAGE = "NONE";
       private int HEALTH = 50;
       private int SPEED = 5;
       private int STRENGTH = 5;
       private int ENERGY = 50;
       private int ATK = 5;
       private int DEF = 5;
       private int SIZE = 5;
       private int WEIGHT = 125;
       private int MaxDamage = 100;
       private int Money = 0;
       private int LEVEL = 1;
       private boolean IsPlayer = false;
       private boolean IsFriend = false;
       private boolean IsEnemy = false;
       
    //-----Private Ability Items----------------
       private boolean Upload = false;
       private boolean Duplicate = false;
       private boolean BeamCannon = false;
       private boolean EmpShield = false;
       private boolean EmpWave = false;
       private boolean HeatShield = false;
       private boolean Telekinesis = false;
       private boolean BioField = false;
       private boolean NanoRegenerate = false;
       private boolean ShapeShift = false;     
       
  //-----Private Inventory Items----------------
       private boolean Key1 = false;
       private boolean Key2 = false;
       private boolean Key3 = false;
       private boolean Key4 = false;
       private boolean JackKnife = false;
       private boolean Sword = false;
       private boolean Glock = false;
       private int GlockAmmo = 0;
       private int Grenades = 0;
       private boolean Armor = false;
       private int MedKits = 0;
       
}//close class
