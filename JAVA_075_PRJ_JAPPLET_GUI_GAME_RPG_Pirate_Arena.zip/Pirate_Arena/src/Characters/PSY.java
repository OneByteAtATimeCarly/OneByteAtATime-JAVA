package Characters;
import Interface.*;

//Child object of TERRESTRIAL and grandshild of FIGHTER

public class PSY extends TERRESTRIAL
{    
//----------------------------------------------------------------------------     
       public PSY()
       {
              INTERFACE.TA_Output.append("\n Creating a PSY object!");
              SetCharClass("PSY");
              SetSpcAtk("Telekinesis");
              SetSpcDef("BioField");
       }

//----------------------------------------------------------------------------       
       
       //Member Methods
       public void UsePsyAbility()
       {
              INTERFACE.TA_Output.append("\n Using PSY ability!\n");
       }

//---------------------------------------------------------------------------- 
       
       //Public Accesors
       public boolean GetTeleKinesis() { return TELEKINESIS; }
       public void SetTeleKinesis(boolean x) { TELEKINESIS = x; }
       public boolean GetPyroKinesis() { return PYROKINESIS; }
       public void SetPyroKinesis(boolean x) { PYROKINESIS = x; }
       public boolean GetTelepathy() { return TELEPATHY; }
       public void SetTelepathy(boolean x) { TELEPATHY = x; }              
       
//---------------------------------------------------------------------------- 
       
       //Private Data
       private boolean TELEKINESIS = false;
       private boolean PYROKINESIS = false;
       private boolean TELEPATHY = false;      
}
