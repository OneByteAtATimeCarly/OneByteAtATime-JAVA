package Characters;
import Interface.*;

//Child of AI, grand-child of FIGHTER

public class SHAPESHIFTER extends AI 
{
       public SHAPESHIFTER()
       {
              INTERFACE.TA_Output.append("\n Creating a ShapeShifter object!");
              SetCharClass("SHAPESHIFTER");
              SetNano(true); //Setting parent class attribute 
              SetSpcAtk("ShapeShift");
              SetSpcDef("NanoRegeneration");
       }
       
       //Public Accesors
       public String GetNanoAbility() { return NanoAbility; }
       public void SetNanoAbility(String x) { NanoAbility = x; }
       
       //Private Data
       private String NanoAbility = "Generic";
}
