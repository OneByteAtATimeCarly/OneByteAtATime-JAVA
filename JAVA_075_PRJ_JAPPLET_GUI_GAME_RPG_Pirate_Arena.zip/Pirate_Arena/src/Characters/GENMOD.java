package Characters;
import Interface.*;

//Child of AI, grandchild of FIGHTER

public class GENMOD extends TERRESTRIAL
{
       public GENMOD()
       {
              INTERFACE.TA_Output.append("\n Creating a GENMOD object!");
              SetCharClass("GENMOD");
              SetSpcAtk("EMP Wave");
              SetSpcDef("Heat Shield");
       }
}
