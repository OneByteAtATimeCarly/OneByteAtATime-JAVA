
class Monster extends Thread
{
      final int NumberLoops = 20;
      public int COUNTER = 1;
      String TheMessage = "";

      //Constructor
      public Monster(String mn)  {  MonsterName = mn; }

      public void run()
      {
             for(int x = 0; x < NumberLoops; ++x)
             {
                 TheMessage =
                 "\n" + MonsterName + " attacks the city for the " + COUNTER;
                 if(COUNTER == 1) { TheMessage = TheMessage + "st"; }
                 else if(COUNTER == 2) { TheMessage = TheMessage +"nd"; }
                 else if(COUNTER == 3) { TheMessage = TheMessage +"rd"; }
                 else { TheMessage = TheMessage + "th"; }

                 TheMessage = TheMessage + " time!\n";

	         MonsterCombatThread.OutputArea.setText(
                 MonsterCombatThread.OutputArea.getText() + TheMessage);

                 COUNTER++;
             }//close if

      }//close run() function

      //Accessor Methods
      public void setMonsterName(String m) { MonsterName = m; }
      public String getMonsterName() { return MonsterName; }

      //Data Members
      private String MonsterName = "";

}//close class
