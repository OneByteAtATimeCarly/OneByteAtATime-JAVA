                                  import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MonsterCombatThread extends JApplet implements ActionListener
{
      JButton DaButton1 = new JButton("Rampage 1");
      JButton DaButton2 = new JButton("Rampage 2");
      public static TextArea OutputArea = new TextArea();
      FlowLayout flow = new FlowLayout();
      Font DaFont = new Font("Trebuchet MS", Font.BOLD, 12);

      //Note: For applet to run, it must have either a public
      //constructor or the class must be public
      public MonsterCombatThread() {  }

      public void init()
      { 
             Container DaWindow = getContentPane();
             DaWindow.setLayout(flow);
             DaWindow.setBackground(Color.WHITE);
             DaWindow.add(DaButton1);
             DaWindow.add(DaButton2);
             DaWindow.add(OutputArea);
             DaButton1.addActionListener(this);
             DaButton2.addActionListener(this);

      }//close init()

      public void actionPerformed(ActionEvent e)
      {
             if(e.getSource().equals(DaButton1))
             {
                OutputArea.setText("");
                rampage1();
             }

             if(e.getSource().equals(DaButton2))
             {
                OutputArea.setText("");
                rampage2();
             }
      }

      public void rampage1()
      {
             Graphics BananaSplit = getGraphics();
             BananaSplit.setFont(DaFont);
             BananaSplit.setColor(Color.RED);
             BananaSplit.drawString("Beginning the rampage1...",10,10);
             Monster Godzilla = new Monster("Godzilla");
             Monster Mothra = new Monster("Mothra");
             Monster Snuff = new Monster("MrSnuffaluffagus");
             Godzilla.setPriority(1);
             Mothra.setPriority(5);
             Snuff.setPriority(10);
             Godzilla.start();
             Mothra.start();
             Snuff.start();

      }//close rampage1() function using priority integer values

      public void rampage2()
      {
             Graphics BananaSplit = getGraphics();
             BananaSplit.setFont(DaFont);
             BananaSplit.setColor(Color.RED);
             BananaSplit.drawString("Beginning the rampage2...",10,10);
             Monster Godzilla = new Monster("Godzilla");
             Monster Mothra = new Monster("Mothra");
             Monster Snuff = new Monster("MrSnuffaluffagus");
             Godzilla.setPriority(Thread.MIN_PRIORITY);
             Mothra.setPriority(Thread.NORM_PRIORITY);
             Snuff.setPriority(Thread.MAX_PRIORITY);
             Godzilla.start();
             Mothra.start();
             Snuff.start();

      }//close rampage2() function using priority constants

}//close MonsterMAsh Applet class
